from __future__ import annotations

import tempfile
from pathlib import Path

from market_archive import MarketArchive
from market_archive_collector import MarketArchiveCollector


def quote(timestamp: str, price: float, *, stale: bool = False) -> dict:
    return {
        "status": "success",
        "source": "gold-api.com XAU/USD live market reference",
        "source_symbol": "XAU/USD",
        "instrument": "XAU/USD",
        "source_timestamp": timestamp,
        "fetched_at": timestamp,
        "last_price": price,
        "stale": stale,
        "live_for_analysis": not stale,
        "tradable": False,
        "source_kind": "public_market_reference",
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary_directory:
        archive = MarketArchive(Path(temporary_directory) / "archive.sqlite3")
        first = archive.ingest_gold_api_quote(quote("2026-08-27T12:00:10Z", 4600.0))
        duplicate = archive.ingest_gold_api_quote(quote("2026-08-27T12:00:10Z", 4600.0))
        archive.ingest_gold_api_quote(quote("2026-08-27T12:00:40Z", 4602.0))
        archive.ingest_gold_api_quote(quote("2026-08-27T12:01:05Z", 4601.0))
        assert first["inserted"] is True
        assert duplicate["inserted"] is False

        minute = archive.candles(timeframe="1m")
        assert len(minute) == 2
        completed = minute[0]
        assert completed["bucket_start"] == "2026-08-27T12:00:00.000000Z"
        assert (completed["open"], completed["high"], completed["low"], completed["close"]) == (4600.0, 4602.0, 4600.0, 4602.0)
        assert completed["is_complete"] == 1
        assert completed["quality"] == "COMPLETE"

        stale = archive.ingest_gold_api_quote(quote("2026-08-27T12:01:35Z", 4599.0, stale=True))
        assert stale["status"] == "STALE"
        assert archive.candles(timeframe="1m")[1]["close"] == 4601.0

        archive.ingest_gold_api_quote(quote("2026-08-27T12:05:10Z", 4603.0))
        status = archive.status()
        assert status["observation_count"] == 5
        assert status["gap_count"] == 1
        assert status["state"]["latest_status"] == "LIVE"
        assert "bid" in status["limits"]["does_not_provide"]

        collector = MarketArchiveCollector(archive=archive, get_quote=lambda: quote("2026-08-27T12:05:10Z", 4603.0), interval_seconds=30)
        result = collector.collect_once()
        assert result["ok"] is True and result["inserted"] is False

        collector = MarketArchiveCollector(archive=archive, get_quote=lambda: (_ for _ in ()).throw(RuntimeError("source offline")), interval_seconds=30)
        failure = collector.collect_once()
        assert failure["ok"] is False
        assert archive.status()["state"]["latest_status"] == "ERROR"
    print("PASS: archive deduplicates observations, marks gaps, protects stale data, and records collector failures")


if __name__ == "__main__":
    main()
