"""حارس واجهة تشغيل التحليل عند الطلب داخل لوحة XAUUSD.

هذا اختبار سطح متعمد: التفضيل محلي فقط ولا ينشئ جدولة أو تداولاً آلياً.
"""

from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def run() -> None:
    required_surface = (
        'id="manualAnalysisRunner"',
        'id="analysisPreferredTime"',
        'id="manualAnalysisRun"',
        'id="manualAnalysisStatus"',
        'xauusd-analysis-preferred-time',
        'لا يفعّل جدولة أو تداولاً تلقائياً',
        'requestAIAnalysis(selectedTimeframe)',
        'finally{if(button)button.disabled=false;}',
    )
    for fragment in required_surface:
        assert fragment in SOURCE, f"واجهة التشغيل اليدوي تفتقد: {fragment}"

    assert 'window.TIMEFRAME_LABELS?.[selectedTimeframe]||selectedTimeframe' in SOURCE
    assert 'TIMEFRAME_LABELS[selectedTimeframe]' not in SOURCE, (
        "لا يجوز استخدام قاموس أطر غير مضمون قبل try/finally في زر التشغيل اليدوي"
    )
    print("نجح اختبار واجهة التشغيل اليدوي: تفضيل محلي، تشغيل عند الطلب، وحماية من تعليق الزر.")


if __name__ == "__main__":
    run()
