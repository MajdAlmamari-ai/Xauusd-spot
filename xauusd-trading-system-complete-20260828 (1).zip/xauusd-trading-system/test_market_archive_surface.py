from __future__ import annotations

import tempfile
from pathlib import Path

import production_server
from market_archive import MarketArchive


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary_directory:
        archive = MarketArchive(Path(temporary_directory) / "surface.sqlite3")
        production_server.market_archive = archive
        production_server.market_archive_initialization_error = None
        with production_server.app.test_client() as client:
            initial = client.get("/api/market-archive-status")
            assert initial.status_code == 200
            initial_payload = initial.get_json()
            assert initial_payload["enabled"] is True
            assert initial_payload["status"] == "NOT_STARTED"
            assert initial_payload["execution_classification"] == "public_market_reference_not_executable"

            system = client.get("/api/system-status")
            assert system.status_code == 200
            payload = system.get_json()
            assert "market_archive" in payload
            assert payload["market_archive"]["enabled"] is True

            method_not_allowed = client.post("/api/market-archive-status")
            assert method_not_allowed.status_code == 405
    print("PASS: archive status is visible read-only in system APIs without a write route")


if __name__ == "__main__":
    main()
