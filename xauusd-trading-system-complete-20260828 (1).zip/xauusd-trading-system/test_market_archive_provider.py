from __future__ import annotations

import tempfile
from datetime import datetime, timezone
from pathlib import Path

from market_archive import MarketArchive, iso_utc
from market_data import ArchivedGoldApiLivePriceProvider


def quote(timestamp: str, price: float) -> dict:
    return {
        "status": "success",
        "source": "gold-api.com XAU/USD live market reference",
        "source_symbol": "XAU/USD",
        "instrument": "XAU/USD",
        "source_timestamp": timestamp,
        "fetched_at": timestamp,
        "last_price": price,
        "stale": False,
        "live_for_analysis": True,
        "tradable": False,
    }


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary_directory:
        archive = MarketArchive(Path(temporary_directory) / "archive.sqlite3")
        current_timestamp = iso_utc(datetime.now(timezone.utc))
        archive.ingest_gold_api_quote(quote(current_timestamp, 4600.25))
        provider = ArchivedGoldApiLivePriceProvider(archive)
        current = provider.get_current_price()
        assert current["status"] == "success"
        assert current["last_price"] == 4600.25
        assert current["collector_backed"] is True
        assert current["bid"] is None and current["ask"] is None
        assert current["tradable"] is False
        assert current["execution_classification"] == "public_market_reference_not_executable"

        archive.record_fetch_failure(error="source unavailable")
        unavailable = provider.get_current_price()
        assert unavailable["status"] == "error"
        assert unavailable["stale"] is True
        assert unavailable["live_for_analysis"] is False
    print("PASS: Flask can read only the collector-backed quote and blocks it after collection failure")


if __name__ == "__main__":
    main()
