"""حارس انحدار لواجهة الرسم الواسعة والمستويات القابلة للاستكشاف."""

from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def test_wide_chart_toolbar_keeps_required_controls():
    for token in (
        "proChartToolbar",
        "proTimeframes",
        "['10m','10 د']",
        "['2h','2 س']",
        "['4h','4 ساعات']",
        "proIndicatorOpen",
        "proChartMode",
        "proChartScale",
        "data-pro-range",
        "proDraw",
        "proExitWide",
    ):
        assert token in SOURCE


def test_wide_chart_uses_available_canvas_height():
    assert "document.body.classList.contains('pageLandscapeRequested')" in SOURCE
    assert "host.clientHeight||window.innerHeight-132" in SOURCE


def test_analysis_zones_and_levels_open_a_real_explanation_chart():
    for token in (
        "chartInsightDrawer",
        "insightChart",
        "chartInteractiveZone",
        "toolDrilldown",
        "openInsight(contextFor(key",
        "label:`${names[key]||key} — ${name}`",
        "Order Block صاعد",
        "Fair Value Gap",
    ):
        assert token in SOURCE


def test_chart_api_html_response_is_converted_to_a_clear_arabic_error():
    for token in (
        "async function readApiJson(response,context)",
        "صفحة HTML",
        "بدلاً من بيانات الرسم",
        "const data=await readApiJson(response,'تعذر تحميل الرسم')",
        "const payload=await readApiJson(r,'تعذر تحميل الإطار الزمني')",
    ):
        assert token in SOURCE


def test_ten_minute_frame_uses_a_bounded_reference_window():
    assert '"10m": {"label": "10 دقائق", "interval": "10m", "period": "5d"' in SOURCE
    assert '"10m": "5m"' in Path(__file__).with_name("mt5_price_connector.py").read_text(encoding="utf-8")


if __name__ == "__main__":
    test_wide_chart_toolbar_keeps_required_controls()
    test_wide_chart_uses_available_canvas_height()
    test_analysis_zones_and_levels_open_a_real_explanation_chart()
    test_chart_api_html_response_is_converted_to_a_clear_arabic_error()
    test_ten_minute_frame_uses_a_bounded_reference_window()
    print("نجح اختبار سطح الرسم التفاعلي والوضع الواسع.")
