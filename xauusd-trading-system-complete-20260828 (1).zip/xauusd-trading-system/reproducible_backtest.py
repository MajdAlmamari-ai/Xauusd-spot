"""محرك backtest قابل لإعادة الإنتاج للاستراتيجيات السعرية المرجعية.

الإشارات تتكون عند إغلاق شمعة القرار فقط، والدخول يكون في افتتاح الشمعة التالية.
لا يفسر OHLC كـ Bid/Ask؛ يطبق نموذج تكلفة معلن ويصنف النتائج Research/Rejected فقط.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from technical_indicators import adx as central_adx
from technical_indicators import atr as central_atr
from technical_indicators import ema as central_ema
from technical_indicators import macd as central_macd
from technical_indicators import rsi as central_rsi


STRATEGY_VERSION = "audit-v1.1.0"
WARMUP_BARS = 220
PRICE_ACTION_STRATEGIES = {
    "price_action_sr_rsi",
    "price_action_sr_macd",
    "price_action_sr_rsi_macd",
}
PIVOT_LEFT = 2
PIVOT_RIGHT = 2
STRUCTURE_ZONE_ATR = 0.25


@dataclass(frozen=True)
class CostModel:
    """تكلفة مرجعية معلنة بوحدات سعر XAUUSD، وليست بيانات وسيط حية."""

    spread_price: float = 0.30
    slippage_price_each_side: float = 0.05
    commission_price_round_turn: float = 0.00

    def as_dict(self) -> dict[str, float | str]:
        return {
            "spread_price": self.spread_price,
            "slippage_price_each_side": self.slippage_price_each_side,
            "commission_price_round_turn": self.commission_price_round_turn,
            "basis": "افتراض مرجعي ثابت؛ ليس Bid/Ask تاريخياً من الوسيط.",
        }


def _confirmed_pivot_markers(
    frame: pd.DataFrame,
    *,
    left: int = PIVOT_LEFT,
    right: int = PIVOT_RIGHT,
) -> tuple[pd.Series, pd.Series]:
    """يسجل pivot عند شمعة تأكيده لا عند شمعة حدوثه لمنع التطلع للمستقبل."""
    high = pd.to_numeric(frame["High"], errors="coerce").astype(float)
    low = pd.to_numeric(frame["Low"], errors="coerce").astype(float)
    confirmed_high = pd.Series(np.nan, index=frame.index, dtype=float)
    confirmed_low = pd.Series(np.nan, index=frame.index, dtype=float)
    for pivot_index in range(left, max(left, len(frame) - right)):
        confirmation_index = pivot_index + right
        high_window = high.iloc[pivot_index - left:confirmation_index + 1]
        low_window = low.iloc[pivot_index - left:confirmation_index + 1]
        if high_window.notna().all() and float(high.iloc[pivot_index]) == float(high_window.max()) and int((high_window == high.iloc[pivot_index]).sum()) == 1:
            confirmed_high.iloc[confirmation_index] = float(high.iloc[pivot_index])
        if low_window.notna().all() and float(low.iloc[pivot_index]) == float(low_window.min()) and int((low_window == low.iloc[pivot_index]).sum()) == 1:
            confirmed_low.iloc[confirmation_index] = float(low.iloc[pivot_index])
    return confirmed_high, confirmed_low


def _pivot_direction(marker: pd.Series) -> tuple[pd.Series, pd.Series]:
    """يعيد اتجاه تسلسل pivots المؤكدة المتاح عند كل شمعة فقط."""
    events = marker.dropna()
    changes = events.diff()
    higher_events = pd.Series(pd.NA, index=marker.index, dtype="boolean")
    lower_events = pd.Series(pd.NA, index=marker.index, dtype="boolean")
    higher_events.loc[changes.index] = changes.gt(0).astype("boolean")
    lower_events.loc[changes.index] = changes.lt(0).astype("boolean")
    higher = higher_events.ffill().fillna(False).astype(bool)
    lower = lower_events.ffill().fillna(False).astype(bool)
    return higher, lower


def _add_price_action_structure(out: pd.DataFrame) -> pd.DataFrame:
    """يبني بنية ومناطق سببية من pivots مؤكدة، من دون تلوين تاريخي أو إعادة رسم."""
    confirmed_high, confirmed_low = _confirmed_pivot_markers(out)
    higher_high, lower_high = _pivot_direction(confirmed_high)
    higher_low, lower_low = _pivot_direction(confirmed_low)
    out["CONFIRMED_PIVOT_HIGH"] = confirmed_high
    out["CONFIRMED_PIVOT_LOW"] = confirmed_low
    out["RESISTANCE"] = confirmed_high.ffill()
    out["SUPPORT"] = confirmed_low.ffill()
    out["STRUCTURE_BULL"] = higher_high & higher_low
    out["STRUCTURE_BEAR"] = lower_high & lower_low
    out["STRUCTURE_BUFFER"] = out["ATR"] * STRUCTURE_ZONE_ATR

    close = out["Close"]
    prior_high, prior_low = out["High"].shift(1), out["Low"].shift(1)
    support, resistance, buffer = out["SUPPORT"], out["RESISTANCE"], out["STRUCTURE_BUFFER"]
    out["PA_LONG_LOCATION"] = support.notna() & buffer.notna() & out["Low"].le(support + buffer) & close.ge(support - buffer)
    out["PA_SHORT_LOCATION"] = resistance.notna() & buffer.notna() & out["High"].ge(resistance - buffer) & close.le(resistance + buffer)
    out["PA_LONG_TRIGGER"] = close.gt(out["Open"]) & close.gt(prior_high)
    out["PA_SHORT_TRIGGER"] = close.lt(out["Open"]) & close.lt(prior_low)
    long_risk = close - (support - buffer)
    long_reward = resistance - close
    short_risk = (resistance + buffer) - close
    short_reward = close - support
    out["PA_LONG_RR_OK"] = long_risk.gt(0) & long_reward.gt(0) & long_reward.div(long_risk).ge(1.5)
    out["PA_SHORT_RR_OK"] = short_risk.gt(0) & short_reward.gt(0) & short_reward.div(short_risk).ge(1.5)
    return out


def prepare_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    """يستخدم تعريفات EMA/RSI/ATR/ADX المركزية نفسها، بلا حسابات RSI/ATR محلية."""
    out = frame.copy().dropna(subset=["Open", "High", "Low", "Close"]).sort_index()
    out[["Open", "High", "Low", "Close"]] = out[["Open", "High", "Low", "Close"]].apply(pd.to_numeric, errors="coerce")
    out["ATR"] = central_atr(out, 14)
    out["EMA20"] = central_ema(out["Close"], 20)
    out["EMA50"] = central_ema(out["Close"], 50)
    out["EMA200"] = central_ema(out["Close"], 200)
    out["RSI14"] = central_rsi(out["Close"], 14)
    out["RSI2"] = central_rsi(out["Close"], 2)
    out["MACD_LINE"], out["MACD_SIGNAL"], out["MACD_HIST"] = central_macd(out["Close"])
    out["ADX"] = central_adx(out, 14)[0]
    mid = out["Close"].rolling(20, min_periods=20).mean()
    deviation = out["Close"].rolling(20, min_periods=20).std(ddof=0)
    out["BB_UPPER"], out["BB_LOWER"] = mid + 2 * deviation, mid - 2 * deviation
    out["KC_UPPER"], out["KC_LOWER"] = out["EMA20"] + 1.5 * out["ATR"], out["EMA20"] - 1.5 * out["ATR"]
    out["DONCHIAN_HIGH"] = out["High"].shift(1).rolling(20, min_periods=20).max()
    out["DONCHIAN_LOW"] = out["Low"].shift(1).rolling(20, min_periods=20).min()
    out["RANGE"] = out["High"] - out["Low"]
    out["NR7"] = out["RANGE"].eq(out["RANGE"].rolling(7, min_periods=7).min())
    out["ATR_MEDIAN"] = out["ATR"].rolling(100, min_periods=30).median()
    return _add_price_action_structure(out)


def signal_series(frame: pd.DataFrame, strategy: str) -> pd.Series:
    current, prior = frame, frame.shift(1)
    up, down = current.EMA20 > current.EMA50, current.EMA20 < current.EMA50
    long_price_action = current.STRUCTURE_BULL & current.PA_LONG_LOCATION & current.PA_LONG_TRIGGER & current.PA_LONG_RR_OK
    short_price_action = current.STRUCTURE_BEAR & current.PA_SHORT_LOCATION & current.PA_SHORT_TRIGGER & current.PA_SHORT_RR_OK
    long_rsi = current.RSI14.gt(50) & current.RSI14.gt(prior.RSI14)
    short_rsi = current.RSI14.lt(50) & current.RSI14.lt(prior.RSI14)
    long_macd = current.MACD_LINE.gt(current.MACD_SIGNAL) & current.MACD_HIST.gt(0) & current.MACD_HIST.gt(prior.MACD_HIST)
    short_macd = current.MACD_LINE.lt(current.MACD_SIGNAL) & current.MACD_HIST.lt(0) & current.MACD_HIST.lt(prior.MACD_HIST)
    if strategy == "ema_pullback":
        long, short = up & (current.Close <= current.EMA20) & (current.Close > current.EMA50), down & (current.Close >= current.EMA20) & (current.Close < current.EMA50)
    elif strategy == "ema_adx_pullback":
        long, short = up & (current.ADX >= 25) & current.Close.le(current.EMA20) & current.Close.gt(current.EMA50) & current.RSI14.between(45, 62), down & (current.ADX >= 25) & current.Close.ge(current.EMA20) & current.Close.lt(current.EMA50) & current.RSI14.between(38, 55)
    elif strategy == "donchian_breakout":
        long, short = current.Close > current.DONCHIAN_HIGH, current.Close < current.DONCHIAN_LOW
    elif strategy == "donchian_adx":
        long, short = (current.Close > current.DONCHIAN_HIGH) & (current.ADX >= 22), (current.Close < current.DONCHIAN_LOW) & (current.ADX >= 22)
    elif strategy == "rsi_bollinger":
        long, short = (current.RSI14 < 30) & (current.Close < current.BB_LOWER), (current.RSI14 > 70) & (current.Close > current.BB_UPPER)
    elif strategy == "rsi2_ema200":
        long, short = (current.Close > current.EMA200) & (current.RSI2 < 10), (current.Close < current.EMA200) & (current.RSI2 > 90)
    elif strategy == "keltner_breakout":
        long, short = (current.Close > current.KC_UPPER) & up, (current.Close < current.KC_LOWER) & down
    elif strategy == "squeeze_breakout":
        squeezed = (prior.BB_UPPER < prior.KC_UPPER) & (prior.BB_LOWER > prior.KC_LOWER)
        long, short = squeezed & (current.Close > current.BB_UPPER) & up, squeezed & (current.Close < current.BB_LOWER) & down
    elif strategy == "nr7_trend_breakout":
        long, short = prior.NR7 & (current.Close > prior.High) & up & (current.ADX >= 20), prior.NR7 & (current.Close < prior.Low) & down & (current.ADX >= 20)
    elif strategy == "price_action_sr_rsi":
        long, short = long_price_action & long_rsi, short_price_action & short_rsi
    elif strategy == "price_action_sr_macd":
        long, short = long_price_action & long_macd, short_price_action & short_macd
    elif strategy == "price_action_sr_rsi_macd":
        long, short = long_price_action & long_rsi & long_macd, short_price_action & short_rsi & short_macd
    else:
        raise ValueError(f"استراتيجية غير مدعومة: {strategy}")
    return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=frame.index, dtype="int8")


def _trade_levels(
    frame: pd.DataFrame,
    *,
    strategy: str,
    decision_index: int,
    entry: float,
    side: int,
    stop_atr: float,
    target_r: float,
) -> tuple[float, float, float] | None:
    """يعيد مستوى المخاطرة والوقف والهدف، ويستخدم حدود المنطقة المؤكدة للاستراتيجية السعرية."""
    atr_value = float(frame.ATR.iloc[decision_index]) if pd.notna(frame.ATR.iloc[decision_index]) else 0.0
    if atr_value <= 0:
        return None
    if strategy not in PRICE_ACTION_STRATEGIES:
        risk = stop_atr * atr_value
        stop = entry - risk if side == 1 else entry + risk
        target = entry + target_r * risk if side == 1 else entry - target_r * risk
        return risk, stop, target
    support = float(frame.SUPPORT.iloc[decision_index]) if pd.notna(frame.SUPPORT.iloc[decision_index]) else np.nan
    resistance = float(frame.RESISTANCE.iloc[decision_index]) if pd.notna(frame.RESISTANCE.iloc[decision_index]) else np.nan
    buffer = float(frame.STRUCTURE_BUFFER.iloc[decision_index]) if pd.notna(frame.STRUCTURE_BUFFER.iloc[decision_index]) else np.nan
    if not (np.isfinite(support) and np.isfinite(resistance) and np.isfinite(buffer)):
        return None
    stop = support - buffer if side == 1 else resistance + buffer
    target = resistance if side == 1 else support
    risk = entry - stop if side == 1 else stop - entry
    reward = target - entry if side == 1 else entry - target
    if risk <= 0 or reward <= 0 or reward / risk < target_r:
        return None
    return risk, stop, target


def _regime(row: pd.Series) -> str:
    if pd.notna(row.get("ATR_MEDIAN")) and float(row.ATR) >= 1.25 * float(row.ATR_MEDIAN):
        return "high_volatility"
    if pd.notna(row.get("ADX")) and float(row.ADX) >= 25:
        return "trending"
    return "ranging"


def simulate(
    frame: pd.DataFrame,
    strategy: str,
    *,
    stop_atr: float = 1.5,
    target_r: float = 2.0,
    horizon_bars: int = 12,
    costs: CostModel = CostModel(),
) -> list[dict[str, Any]]:
    """يحاكي التنفيذ: القرار close[i]، الدخول Open[i+1]، والوقف أولاً عند غموض الشمعة."""
    required_indicators = {"ATR", "EMA20", "EMA50", "EMA200", "RSI14", "RSI2", "MACD_LINE", "MACD_SIGNAL", "MACD_HIST", "ADX", "BB_UPPER", "BB_LOWER", "KC_UPPER", "KC_LOWER", "DONCHIAN_HIGH", "DONCHIAN_LOW", "NR7", "ATR_MEDIAN", "SUPPORT", "RESISTANCE", "STRUCTURE_BUFFER", "STRUCTURE_BULL", "STRUCTURE_BEAR", "PA_LONG_LOCATION", "PA_SHORT_LOCATION", "PA_LONG_TRIGGER", "PA_SHORT_TRIGGER", "PA_LONG_RR_OK", "PA_SHORT_RR_OK"}
    prepared = frame if required_indicators.issubset(frame.columns) else prepare_indicators(frame)
    signal = signal_series(prepared, strategy)
    trades: list[dict[str, Any]] = []
    index = WARMUP_BARS
    while index < len(prepared) - 2:
        side = int(signal.iloc[index])
        if side == 0:
            index += 1
            continue
        entry_index = index + 1
        mid_entry = float(prepared.Open.iloc[entry_index])
        entry = mid_entry + (costs.spread_price / 2 + costs.slippage_price_each_side) if side == 1 else mid_entry - (costs.spread_price / 2 + costs.slippage_price_each_side)
        levels = _trade_levels(prepared, strategy=strategy, decision_index=index, entry=mid_entry, side=side, stop_atr=stop_atr, target_r=target_r)
        if levels is None:
            index += 1
            continue
        risk_mid, stop_trigger, target_trigger = levels
        last = min(len(prepared) - 1, entry_index + horizon_bars - 1)
        exit_index, exit_trigger, outcome = last, float(prepared.Close.iloc[last]), "time_exit"
        for cursor in range(entry_index, last + 1):
            high, low = float(prepared.High.iloc[cursor]), float(prepared.Low.iloc[cursor])
            stop_hit = low <= stop_trigger if side == 1 else high >= stop_trigger
            target_hit = high >= target_trigger if side == 1 else low <= target_trigger
            if stop_hit and target_hit:
                exit_index, exit_trigger, outcome = cursor, stop_trigger, "same_bar_conservative_stop"
                break
            if stop_hit:
                exit_index, exit_trigger, outcome = cursor, stop_trigger, "stop"
                break
            if target_hit:
                exit_index, exit_trigger, outcome = cursor, target_trigger, "target"
                break
        exit_fill = exit_trigger - (costs.spread_price / 2 + costs.slippage_price_each_side) if side == 1 else exit_trigger + (costs.spread_price / 2 + costs.slippage_price_each_side)
        gross_r = (exit_fill - entry) / risk_mid if side == 1 else (entry - exit_fill) / risk_mid
        net_r = gross_r - costs.commission_price_round_turn / risk_mid
        slice_ = prepared.iloc[entry_index:exit_index + 1]
        mfe_price = float(slice_.High.max()) - mid_entry if side == 1 else mid_entry - float(slice_.Low.min())
        mae_price = mid_entry - float(slice_.Low.min()) if side == 1 else float(slice_.High.max()) - mid_entry
        trades.append({
            "strategy": strategy,
            "decision_time": str(prepared.index[index]),
            "entry_time": str(prepared.index[entry_index]),
            "exit_time": str(prepared.index[exit_index]),
            "side": "long" if side == 1 else "short",
            "entry": round(entry, 5), "stop_trigger": round(stop_trigger, 5), "target_trigger": round(target_trigger, 5),
            "exit": round(exit_fill, 5), "outcome": outcome,
            "gross_r": round(gross_r, 6), "net_r": round(net_r, 6),
            "mfe_r": round(mfe_price / risk_mid, 6), "mae_r": round(mae_price / risk_mid, 6),
            "holding_bars": exit_index - entry_index + 1,
            "holding_seconds": round(float((prepared.index[exit_index] - prepared.index[entry_index]).total_seconds()), 3),
            "regime": _regime(prepared.iloc[index]),
        })
        index = exit_index + 1
    return trades


def metrics(trades: list[dict[str, Any]]) -> dict[str, Any]:
    results = np.array([float(trade["net_r"]) for trade in trades], dtype=float)
    wins, losses = results[results > 0], results[results < 0]
    curve = np.cumsum(results) if len(results) else np.array([])
    drawdown = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0.0
    gross_profit, gross_loss = float(wins.sum()), abs(float(losses.sum()))
    return {
        "number_of_trades": int(len(trades)),
        "win_rate_pct": round(100 * len(wins) / len(trades), 3) if trades else None,
        "profit_factor": round(gross_profit / gross_loss, 6) if gross_loss else None,
        "expectancy_r": round(float(results.mean()), 6) if len(results) else None,
        "max_drawdown_r": round(drawdown, 6),
        "average_mfe_r": round(float(np.mean([trade["mfe_r"] for trade in trades])), 6) if trades else None,
        "average_mae_r": round(float(np.mean([trade["mae_r"] for trade in trades])), 6) if trades else None,
        "average_holding_seconds": round(float(np.mean([trade["holding_seconds"] for trade in trades])), 3) if trades else None,
        "total_net_r_after_spread_slippage_commission": round(float(results.sum()), 6) if len(results) else None,
        "same_bar_conservative_stops": int(sum(trade["outcome"] == "same_bar_conservative_stop" for trade in trades)),
    }


def split_metrics(trades: list[dict[str, Any]], split_timestamp: pd.Timestamp) -> dict[str, Any]:
    split = pd.Timestamp(split_timestamp)
    if split.tzinfo is None:
        split = split.tz_localize("UTC")
    is_trades = [trade for trade in trades if pd.Timestamp(trade["decision_time"]) < split]
    oos_trades = [trade for trade in trades if pd.Timestamp(trade["decision_time"]) >= split]
    return {"in_sample": metrics(is_trades), "out_of_sample": metrics(oos_trades)}


def walk_forward_metrics(trades: list[dict[str, Any]], start: pd.Timestamp, end: pd.Timestamp, windows: int = 3) -> dict[str, Any]:
    start, end = pd.Timestamp(start), pd.Timestamp(end)
    if start.tzinfo is None: start = start.tz_localize("UTC")
    if end.tzinfo is None: end = end.tz_localize("UTC")
    marks = pd.date_range(start=start, end=end, periods=windows + 1)
    rows = []
    for index in range(windows):
        bucket = [trade for trade in trades if marks[index] <= pd.Timestamp(trade["decision_time"]) < marks[index + 1]]
        rows.append({"start": str(marks[index]), "end": str(marks[index + 1]), **metrics(bucket)})
    evaluated = [row for row in rows if row["number_of_trades"] > 0]
    positive = sum((row["expectancy_r"] or 0) > 0 for row in evaluated)
    return {"windows": rows, "positive_windows": positive, "evaluated_windows": len(evaluated), "stable": len(evaluated) >= 2 and positive >= max(2, len(evaluated) - 1)}


def parameter_stability(frame: pd.DataFrame, strategy: str, costs: CostModel) -> dict[str, Any]:
    grid = ((1.25, 1.75), (1.5, 2.0), (1.75, 2.25))
    rows = []
    for stop_atr, target_r in grid:
        result = metrics(simulate(frame, strategy, stop_atr=stop_atr, target_r=target_r, costs=costs))
        rows.append({"stop_atr": stop_atr, "target_r": target_r, **result})
    viable = sum((row["number_of_trades"] >= 20 and (row["expectancy_r"] or 0) > 0 and (row["profit_factor"] or 0) > 1) for row in rows)
    return {"grid": rows, "viable_variants": viable, "stable": viable >= 2}


def regime_performance(trades: list[dict[str, Any]]) -> dict[str, Any]:
    return {regime: metrics([trade for trade in trades if trade["regime"] == regime]) for regime in ("trending", "ranging", "high_volatility")}


def evaluate_strategy(frame: pd.DataFrame, strategy: str, *, split_timestamp: pd.Timestamp, costs: CostModel = CostModel()) -> dict[str, Any]:
    prepared = prepare_indicators(frame)
    trades = simulate(prepared, strategy, costs=costs)
    sample = metrics(trades)
    split = split_metrics(trades, split_timestamp)
    wf = walk_forward_metrics(trades, frame.index.min(), frame.index.max())
    stability = parameter_stability(prepared, strategy, costs)
    # لا يصدر المحرك Approved: حتى نتيجة قوية تحتاج مصدر Bid/Ask تاريخياً، عينة كافية، ومراجعة مستقلة.
    state = "RESEARCH_ONLY" if sample["number_of_trades"] >= 20 and (split["out_of_sample"]["expectancy_r"] or 0) > 0 and wf["stable"] and stability["stable"] else "REJECTED"
    return {
        "strategy": strategy,
        "strategy_version": STRATEGY_VERSION,
        "parameters": {"stop_atr": 1.5, "target_r": 2.0, "horizon_bars": 12, "warmup_bars": WARMUP_BARS, "same_bar_policy": "conservative_stop"},
        "cost_model": costs.as_dict(),
        "all_data": sample,
        **split,
        "walk_forward": wf,
        "parameter_stability": stability,
        "market_regime_performance": regime_performance(trades),
        "final_classification": state,
        "approval": "NOT_APPROVED",
        "approval_reason": "لا توجد بيانات Bid/Ask تاريخية من وسيط ولا تحقق خارجي كافٍ؛ لا تتحول نتيجة OHLC إلى اعتماد تنفيذي.",
        "trades": trades,
    }
