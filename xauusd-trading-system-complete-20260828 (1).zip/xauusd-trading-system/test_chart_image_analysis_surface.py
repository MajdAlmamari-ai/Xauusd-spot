from __future__ import annotations

import io

import production_server
from PIL import Image


def valid_image() -> io.BytesIO:
    image = Image.new("RGB", (640, 400), color=(10, 20, 30))
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer


def main() -> None:
    with production_server.app.test_client() as client:
        missing = client.post("/api/chart-image-analysis", data={"mode": "platform", "timeframe": "4h"})
        assert missing.status_code == 400
        invalid_frame = client.post(
            "/api/chart-image-analysis",
            data={"mode": "platform", "timeframe": "not-supported", "image": (valid_image(), "chart.png")},
            content_type="multipart/form-data",
        )
        assert invalid_frame.status_code == 400
        invalid_mode = client.post(
            "/api/chart-image-analysis",
            data={"mode": "unknown", "timeframe": "4h", "image": (valid_image(), "chart.png")},
            content_type="multipart/form-data",
        )
        assert invalid_mode.status_code == 400
    html = production_server.HTML
    assert 'id="chartImageInput"' in html
    assert 'data-image-mode="platform"' in html
    assert 'data-image-mode="ai"' in html
    assert "/api/chart-image-analysis" in html
    assert "الصورة لا تُحفظ" in html
    print("PASS: chart-image upload endpoint validates requests and mobile UI exposes both analysis modes")


if __name__ == "__main__":
    main()
