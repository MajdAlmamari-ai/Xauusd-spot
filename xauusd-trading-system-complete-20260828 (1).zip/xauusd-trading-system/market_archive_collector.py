"""خدمة جمع دائمة للقراءة فقط من gold-api.com.

تشغّل هذه الوحدة كعملية مستقلة عن Flask حتى يستمر الأرشيف عند إغلاق الواجهة.
"""

from __future__ import annotations

import logging
import os
import signal
import time
from dataclasses import dataclass
from threading import Event
from typing import Any, Callable

from market_archive import MarketArchive
from market_data import GoldApiLivePriceProvider
from mt5_price_connector import MT5PriceConnector


LOGGER = logging.getLogger("xauusd.market_archive_collector")


@dataclass
class MarketArchiveCollector:
    archive: MarketArchive
    get_quote: Callable[[], dict[str, Any]]
    interval_seconds: float

    @classmethod
    def from_environment(cls) -> "MarketArchiveCollector":
        # الحد الأدنى يطابق سياسة المصدر المرجعي الحالية؛ لا يدّعي Tick feed.
        interval = max(30.0, float(os.getenv("MARKET_ARCHIVE_POLL_SECONDS", "30")))
        provider = GoldApiLivePriceProvider(MT5PriceConnector())
        return cls(archive=MarketArchive.from_environment(), get_quote=provider.get_current_price, interval_seconds=interval)

    def collect_once(self) -> dict[str, Any]:
        try:
            quote = self.get_quote()
            result = self.archive.ingest_gold_api_quote(quote)
            LOGGER.info(
                "archive observation status=%s inserted=%s source_time=%s",
                result["status"],
                result["inserted"],
                result["source_timestamp"],
            )
            return {"ok": True, **result}
        except Exception as error:
            self.archive.record_fetch_failure(error=error)
            LOGGER.warning("archive collection failed: %s", error)
            return {"ok": False, "error": str(error)}

    def run_forever(self, stop_event: Event) -> None:
        LOGGER.info("market archive collector started; interval=%ss", self.interval_seconds)
        while not stop_event.is_set():
            self.collect_once()
            stop_event.wait(self.interval_seconds)
        LOGGER.info("market archive collector stopped")


def main() -> None:
    logging.basicConfig(level=os.getenv("MARKET_ARCHIVE_LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(message)s")
    stop_event = Event()

    def request_stop(_signal: int, _frame: object) -> None:
        stop_event.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    collector = MarketArchiveCollector.from_environment()
    collector.run_forever(stop_event)


if __name__ == "__main__":
    main()
