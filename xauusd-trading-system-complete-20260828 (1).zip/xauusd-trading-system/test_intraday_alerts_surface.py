from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main():
    required = [
        'id="intradayAlerts"',
        'id="intradayAlertPermission"',
        'id="intradayAlertMute"',
        'renderIntradayAlert',
        "xauusd-intraday-alerts-muted",
        "xauusd-intraday-alert-last",
        "Notification.requestPermission",
        "Notification.permission==='granted'",
        "quote.live_for_analysis===true",
        "يؤكد الزخم",
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    assert "setInterval(renderIntradayAlert" not in SOURCE
    assert "new Notification" in SOURCE
    assert "لا تنفذ أوامر" in SOURCE
    print("PASS: intraday EMA+RSI alert surface")


if __name__ == "__main__":
    main()
