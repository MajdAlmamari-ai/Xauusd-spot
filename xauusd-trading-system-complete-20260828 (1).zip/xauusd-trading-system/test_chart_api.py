"""اختبار عقد بيانات الرسم: شموع وطبقات وبيانات حداثة لكل إطار زمني."""

from production_server import TIMEFRAME_IDS, app


def main() -> None:
    client = app.test_client()
    verified_candle_frames = 0
    verified_degraded_frames = 0
    for timeframe_id in TIMEFRAME_IDS:
        response = client.get(f"/api/chart/{timeframe_id}")
        assert response.status_code == 200, (timeframe_id, response.get_data(as_text=True))
        payload = response.get_json()
        assert payload["timeframe"]["id"] == timeframe_id
        if not payload["candles"]:
            # قد يفرض Yahoo تقييد طلبات مؤقتاً. العقد الصحيح هو الإفصاح عن
            # التعذر ورفض تصنيع شموع من السعر العام، لا اختلاق بديل للاختبار.
            assert payload.get("error"), f"فشل الرسم بلا سبب معلن: {timeframe_id}"
            verified_degraded_frames += 1
            continue
        verified_candle_frames += 1
        assert payload["reference_only"] is True
        assert isinstance(payload["last_candle_age_seconds"], int)
        first = payload["candles"][0]
        assert {"time", "open", "high", "low", "close", "volume"}.issubset(first)
        assert first["high"] >= first["low"]
        assert {"ma20", "ma50", "levels", "volume_profile_bins", "zones", "tool_status"}.issubset(payload["overlays"])
        assert {"liquidity", "order_blocks", "support_resistance", "fair_value_gap", "trade_scenario"}.issubset(payload["overlays"]["zones"])
        assert "support_resistance" in payload["overlays"]["levels"]
        bins = payload["overlays"]["volume_profile_bins"]
        if bins:
            assert {"lower", "upper", "volume", "ratio", "in_value_area", "is_poc"}.issubset(bins[0])
            assert max(item["ratio"] for item in bins) == 1.0
    invalid = client.get("/api/chart/invalid")
    assert invalid.status_code == 400
    assert verified_candle_frames + verified_degraded_frames == len(TIMEFRAME_IDS)
    print(f"نجح اختبار عقد الرسم: شموع فعلية={verified_candle_frames}، تدهور معلن عند تقييد المصدر={verified_degraded_frames}.")


if __name__ == "__main__":
    main()
