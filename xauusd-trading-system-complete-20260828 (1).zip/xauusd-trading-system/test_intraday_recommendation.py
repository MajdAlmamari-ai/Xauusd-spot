"""اختبارات عقد التوصية اللحظية دون اتصال خارجي أو تنفيذ أوامر."""
from production_server import make_intraday_recommendation


def technical_snapshot():
    return {
        "latest": 100.0,
        "atr": 2.0,
        "moving_averages": [
            {"name": "MA20", "exponential": 98.0},
            {"name": "MA50", "exponential": 95.0},
        ],
        "indicators": [{"name": "ADX(14)", "value": 28.0}, {"name": "RSI(14)", "value": 58.0}],
        "advanced_tools": {"tools": {"support_resistance": {
            "qualified": True,
            "levels": {"دعم 1": 96.0, "مقاومة 1": 108.0},
        }}},
    }


def main():
    fresh_quote = {"status": "success", "stale": False, "live_for_analysis": True, "tradable": False}
    signal = make_intraday_recommendation(fresh_quote, technical_snapshot())
    assert signal["decision_state"] == "signal"
    assert "شراء" in signal["signal"]
    assert signal["entry"] == 100.0
    assert signal["stop_loss"] is not None and signal["take_profit"] == 108.0
    assert signal["risk_reward"] >= 1.2
    conflict_snapshot = technical_snapshot()
    conflict_snapshot["indicators"][-1]["value"] = 76.0
    conflict = make_intraday_recommendation(fresh_quote, conflict_snapshot)
    assert conflict["decision_state"] == "neutral"
    assert conflict["entry"] is None
    stale = make_intraday_recommendation({"status": "success", "stale": True, "live_for_analysis": False}, technical_snapshot())
    assert stale["decision_state"] == "blocked"
    assert stale["entry"] is None
    print("PASS: intraday recommendation contract + RSI gate")


if __name__ == "__main__":
    main()
