from run_strategy_robustness_2025 import meets_durability


def period(trades: int, after_cost: float, profit_factor: float) -> dict:
    return {"filled_trades": trades, "cost_sensitivity_r": {"0.10_per_trade": after_cost}, "profit_factor": profit_factor}


def main() -> None:
    assert meets_durability(period(25, 1.0, 1.2), period(30, 2.0, 1.3)) is True
    assert meets_durability(period(25, -1.0, 1.2), period(30, 2.0, 1.3)) is False
    assert meets_durability(period(25, 1.0, 1.2), period(19, 2.0, 1.3)) is False
    assert meets_durability(period(25, 1.0, 1.2), period(30, 2.0, 1.05)) is False
    print("PASS: durability gate requires every H1 and H2 condition")


if __name__ == "__main__":
    main()
