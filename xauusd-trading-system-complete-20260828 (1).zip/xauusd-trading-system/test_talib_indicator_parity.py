"""مقارنة حسابات المنصة مع TA-Lib: لا تستخدم بيانات سوق أو نتائج استراتيجية."""

import numpy as np
import pandas as pd
import talib

from technical_indicators import adx, atr, ema, macd, rsi


def compare(label: str, actual: pd.Series, expected: np.ndarray, tolerance: float = 1e-8) -> None:
    mask = np.isfinite(actual.to_numpy(dtype=float)) & np.isfinite(expected)
    assert mask.any(), f"{label}: لا توجد قيم قابلة للمقارنة"
    np.testing.assert_allclose(actual.to_numpy(dtype=float)[mask], expected[mask], rtol=tolerance, atol=tolerance, err_msg=label)


def fixture() -> pd.DataFrame:
    index = pd.date_range("2025-01-01", periods=180, freq="h", tz="UTC")
    base = 2500 + np.linspace(0, 42, len(index)) + np.sin(np.arange(len(index)) / 4) * 7
    return pd.DataFrame({
        "Open": base - np.cos(np.arange(len(index))) * 0.8,
        "High": base + 3.2 + np.abs(np.sin(np.arange(len(index)) / 3)),
        "Low": base - 3.1 - np.abs(np.cos(np.arange(len(index)) / 5)),
        "Close": base + np.sin(np.arange(len(index)) / 2) * 0.9,
    }, index=index)


def main() -> None:
    frame = fixture()
    close = frame["Close"].to_numpy(dtype=float)
    high = frame["High"].to_numpy(dtype=float)
    low = frame["Low"].to_numpy(dtype=float)
    compare("EMA20", ema(frame["Close"], 20), talib.EMA(close, timeperiod=20))
    compare("RSI14", rsi(frame["Close"], 14), talib.RSI(close, timeperiod=14))
    compare("ATR14", atr(frame, 14), talib.ATR(high, low, close, timeperiod=14))
    actual_adx, actual_plus, actual_minus = adx(frame, 14)
    compare("ADX14", actual_adx, talib.ADX(high, low, close, timeperiod=14), tolerance=1e-7)
    compare("PLUS_DI14", actual_plus, talib.PLUS_DI(high, low, close, timeperiod=14), tolerance=1e-7)
    compare("MINUS_DI14", actual_minus, talib.MINUS_DI(high, low, close, timeperiod=14), tolerance=1e-7)
    line, signal, histogram = macd(frame["Close"])
    exp_line, exp_signal, exp_histogram = talib.MACD(close, fastperiod=12, slowperiod=26, signalperiod=9)
    compare("MACD line", line, exp_line, tolerance=1e-7)
    compare("MACD signal", signal, exp_signal, tolerance=1e-7)
    compare("MACD histogram", histogram, exp_histogram, tolerance=1e-7)
    print("PASS: EMA/RSI/ATR/ADX/MACD match TA-Lib on deterministic OHLC fixture")


if __name__ == "__main__":
    main()
