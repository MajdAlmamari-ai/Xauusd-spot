"""يشغل تدقيقاً نظيفاً قابلاً لإعادة الإنتاج على بيانات XAUUSD العامة.

مثال:
  PYTHONHASHSEED=0 TZ=UTC python3 run_reproducible_audit_matrix.py --workspace /tmp/xauusd-clean-audit
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import json
import platform
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

import numpy as np
import pandas as pd

from analysis_contracts import resample_complete_ohlc, validate_ohlc_frame
from reproducible_backtest import CostModel, STRATEGY_VERSION, evaluate_strategy


SOURCE_REPOSITORY = "https://huggingface.co/datasets/ZombitX64/xauusd-gold-price-historical-data-2004-2025"
SOURCE_BASE = "https://huggingface.co/datasets/ZombitX64/xauusd-gold-price-historical-data-2004-2025/resolve/main"
SOURCE_CATALOG = "https://huggingface.co/api/datasets/ZombitX64/xauusd-gold-price-historical-data-2004-2025/tree/main?recursive=true&expand=false"
PERIOD_START = pd.Timestamp("2025-01-01", tz="UTC")
PERIOD_END = pd.Timestamp("2025-10-01 05:30:00", tz="UTC")
SPLIT = pd.Timestamp("2025-07-01", tz="UTC")
TIMEFRAMES = {
    "1m": {"file": "XAU_1m_data.jsonl", "mode": "NATIVE_DATA"},
    "5m": {"file": "XAU_5m_data.jsonl", "mode": "NATIVE_DATA"},
    "10m": {"file": "XAU_5m_data.jsonl", "mode": "RESAMPLED_DATA", "source_interval": "5min", "target_rule": "10min"},
    "15m": {"file": "XAU_15m_data.jsonl", "mode": "NATIVE_DATA"},
    "30m": {"file": "XAU_30m_data.jsonl", "mode": "NATIVE_DATA"},
    "1h": {"file": "XAU_1h_data.jsonl", "mode": "NATIVE_DATA"},
    "2h": {"file": "XAU_1h_data.jsonl", "mode": "RESAMPLED_DATA", "source_interval": "1h", "target_rule": "2h"},
    "4h": {"file": "XAU_1h_data.jsonl", "mode": "RESAMPLED_DATA", "source_interval": "1h", "target_rule": "4h"},
    "1d": {"file": "XAU_1d_data.jsonl", "mode": "NATIVE_DATA"},
    "1wk": {"file": "XAU_1w_data.jsonl", "mode": "NATIVE_DATA"},
    "1mo": {"file": "XAU_1Month_data.jsonl", "mode": "NATIVE_DATA"},
}
EXPECTED_INTERVALS = {"1m": "1min", "5m": "5min", "10m": "10min", "15m": "15min", "30m": "30min", "1h": "1h", "2h": "2h", "4h": "4h", "1d": "1D", "1wk": "7D", "1mo": "30D"}
STRATEGIES = ("ema_pullback", "ema_adx_pullback", "donchian_breakout", "donchian_adx", "rsi_bollinger", "rsi2_ema200", "keltner_breakout", "squeeze_breakout", "nr7_trend_breakout", "ob_fvg")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def download(url: str, path: Path) -> None:
    request = Request(url, headers={"User-Agent": "XAUUSD-Reproducible-Audit/1.0", "Accept": "application/octet-stream"})
    with urlopen(request, timeout=300) as response, path.open("wb") as output:
        shutil.copyfileobj(response, output, length=1024 * 1024)


def normalize(raw: pd.DataFrame) -> pd.DataFrame:
    timestamp = pd.to_datetime(raw.pop("Date"), errors="coerce", utc=True)
    raw = raw.rename(columns={name: str(name).title() for name in raw.columns})
    raw = raw[[column for column in ("Open", "High", "Low", "Close", "Volume") if column in raw.columns]].apply(pd.to_numeric, errors="coerce")
    raw.index = timestamp
    if "Volume" not in raw:
        raw["Volume"] = 0.0
    return raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index().loc[PERIOD_START:PERIOD_END]


def load_jsonl(path: Path) -> pd.DataFrame:
    chunks = []
    for chunk in pd.read_json(path, lines=True, chunksize=200_000):
        timestamps = pd.to_datetime(chunk["Date"], errors="coerce", utc=True)
        filtered = chunk.loc[(timestamps >= PERIOD_START) & (timestamps <= PERIOD_END)]
        if not filtered.empty:
            chunks.append(filtered)
    if not chunks:
        return pd.DataFrame(columns=["Open", "High", "Low", "Close", "Volume"])
    return normalize(pd.concat(chunks, ignore_index=True))


def coverage(frame: pd.DataFrame, timeframe: str) -> dict:
    expected = pd.Timedelta(EXPECTED_INTERVALS[timeframe])
    quality = validate_ohlc_frame(frame, EXPECTED_INTERVALS[timeframe])
    gaps = frame.index.to_series().diff().dropna() if len(frame) else pd.Series(dtype="timedelta64[ns]")
    return {
        "rows": int(len(frame)), "first_timestamp": str(frame.index.min()) if len(frame) else None,
        "last_timestamp": str(frame.index.max()) if len(frame) else None,
        "expected_interval": EXPECTED_INTERVALS[timeframe],
        "gaps_over_expected_interval": int((gaps > expected).sum()) if len(gaps) else 0,
        "largest_gap_seconds": round(float(gaps.max().total_seconds()), 3) if len(gaps) else None,
        "quality": quality,
        "timeframe": timeframe,
    }


def compact(result: dict) -> dict:
    output = dict(result)
    output.pop("trades", None)
    return output


def markdown_matrix(payload: dict) -> str:
    headers = "| Strategy | Timeframe | Data mode | Trades | Win rate | Profit factor | Expectancy R | Max DD R | MFE R | MAE R | Holding (sec) | IS / OOS / WF | Parameter stability | Regimes | Final classification |\n| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- | --- | --- |"
    rows = []
    for entry in payload["matrix"]:
        all_data, ins, oos = entry["all_data"], entry["in_sample"], entry["out_of_sample"]
        rows.append(
            f"| {entry['strategy']} | {entry['timeframe']} | {entry['data_mode']} | {all_data['number_of_trades']} | {all_data['win_rate_pct']} | {all_data['profit_factor']} | {all_data['expectancy_r']} | {all_data['max_drawdown_r']} | {all_data['average_mfe_r']} | {all_data['average_mae_r']} | {all_data['average_holding_seconds']} | {ins['number_of_trades']} / {oos['number_of_trades']} / {entry['walk_forward']['evaluated_windows']} | {entry['parameter_stability']['stable']} | {', '.join(f'{name}:{value["number_of_trades"]}' for name, value in entry['market_regime_performance'].items())} | {entry['final_classification']} |"
        )
    return "# مصفوفة اختبار XAUUSD القابلة لإعادة الإنتاج\n\n" + payload["disclosure"] + "\n\n" + headers + "\n" + "\n".join(rows) + "\n\n> لا توجد أي حالة Approved في هذا التشغيل. \n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--clean", action="store_true")
    parser.add_argument("--max-timeframes", type=int, default=0, help="للتحقق السريع فقط؛ صفر يعني جميع الأطر")
    parser.add_argument("--timeframes", type=str, default="", help="قائمة أطر مفصولة بفواصل، مثال: 1h,4h")
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    if args.clean and workspace.exists():
        shutil.rmtree(workspace)
    data_dir, out_dir = workspace / "data", workspace / "output"
    data_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)
    available_timeframes = [item.strip() for item in args.timeframes.split(",") if item.strip()] if args.timeframes else list(TIMEFRAMES)
    unknown = [item for item in available_timeframes if item not in TIMEFRAMES]
    if unknown:
        raise ValueError(f"أطر غير مدعومة: {', '.join(unknown)}")
    if args.max_timeframes and not args.timeframes:
        available_timeframes = available_timeframes[:args.max_timeframes]
    catalog_path = data_dir / "source_catalog.json"
    download(SOURCE_CATALOG, catalog_path)
    needed_files = sorted({TIMEFRAMES[timeframe]["file"] for timeframe in available_timeframes})
    for filename in needed_files:
        path = data_dir / filename
        if not path.exists():
            download(f"{SOURCE_BASE}/{filename}?download=true", path)
    code_files = [
        Path(__file__),
        Path(__file__).with_name("reproducible_backtest.py"),
        Path(__file__).with_name("technical_indicators.py"),
        Path(__file__).with_name("analysis_contracts.py"),
        Path(__file__).with_name("production_server.py"),
        Path(__file__).with_name("mt5_price_connector.py"),
        Path(__file__).with_name("ai_analysis.py"),
    ]
    manifest = {
        "created_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "dataset": {"repository": SOURCE_REPOSITORY, "catalog_url": SOURCE_CATALOG, "catalog_sha256": sha256(catalog_path), "symbol": "XAUUSD", "price_basis": "public spot reference OHLC", "period_start": str(PERIOD_START), "period_end": str(PERIOD_END)},
        "runtime": {"python": sys.version, "platform": platform.platform(), "pandas": pd.__version__, "numpy": np.__version__},
        "strategy_version": STRATEGY_VERSION,
        "code_hashes": {path.name: sha256(path) for path in code_files},
        "data_files": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in sorted(data_dir.glob("XAU_*.jsonl"))},
    }
    frames: dict[str, pd.DataFrame] = {}
    for timeframe in available_timeframes:
        config = TIMEFRAMES[timeframe]
        source = config["file"]
        if source not in frames:
            frames[source] = load_jsonl(data_dir / source)
        base = frames[source]
        if config["mode"] == "RESAMPLED_DATA":
            frame = resample_complete_ohlc(base, source_interval=config["source_interval"], target_rule=config["target_rule"], timeframe_id=timeframe)
        else:
            frame = base.copy()
        manifest.setdefault("timeframe_coverage", {})[timeframe] = {"data_mode": config["mode"], "source_file": source, **coverage(frame, timeframe), "formation": config.get("target_rule", "native provider bar"), "completeness": getattr(frame, "attrs", {}).get("data_contract", {}).get("completeness_policy", "native source bar")}
        frames[timeframe] = frame
    matrix = []
    for timeframe in available_timeframes:
        frame = frames[timeframe]
        if len(frame) < 260:
            for strategy in STRATEGIES:
                matrix.append({"strategy": strategy, "timeframe": timeframe, "data_mode": TIMEFRAMES[timeframe]["mode"], "final_classification": "NOT_TESTED_INSUFFICIENT_BARS", "approval": "NOT_APPROVED", "approval_reason": "عدد الشموع أقل من الإحماء والاختبار، لذلك لا تُستبدل النتيجة بصفر أو باستنتاج.", "all_data": {"number_of_trades": 0, "win_rate_pct": None, "profit_factor": None, "expectancy_r": None, "max_drawdown_r": None, "average_mfe_r": None, "average_mae_r": None, "average_holding_seconds": None}, "in_sample": {"number_of_trades": 0}, "out_of_sample": {"number_of_trades": 0}, "walk_forward": {"evaluated_windows": 0}, "parameter_stability": {"stable": False}, "market_regime_performance": {}})
            continue
        for strategy in STRATEGIES:
            if strategy == "ob_fvg":
                matrix.append({
                    "strategy": strategy,
                    "timeframe": timeframe,
                    "data_mode": TIMEFRAMES[timeframe]["mode"],
                    "source_file": TIMEFRAMES[timeframe]["file"],
                    "final_classification": "NOT_TESTED_COST_AWARE_ENGINE_REQUIRED",
                    "approval": "NOT_APPROVED",
                    "approval_reason": "محرك OB+FVG القديم لا يسجل spread/slippage/commission أو MFE/MAE أو الثبات؛ لا تُعاد استخدام نتائجه كدليل.",
                    "all_data": {"number_of_trades": None, "win_rate_pct": None, "profit_factor": None, "expectancy_r": None, "max_drawdown_r": None, "average_mfe_r": None, "average_mae_r": None, "average_holding_seconds": None},
                    "in_sample": {"number_of_trades": None}, "out_of_sample": {"number_of_trades": None}, "walk_forward": {"evaluated_windows": 0}, "parameter_stability": {"stable": False}, "market_regime_performance": {},
                })
                continue
            result = compact(evaluate_strategy(frame, strategy, split_timestamp=SPLIT, costs=CostModel()))
            matrix.append({"timeframe": timeframe, "data_mode": TIMEFRAMES[timeframe]["mode"], "source_file": TIMEFRAMES[timeframe]["file"], **result})
        gc.collect()
    payload = {
        "manifest": manifest,
        "matrix": matrix,
        "disclosure": "هذه نتائج OHLC مرجعية عامة مع تكلفة مرجعية ثابتة (spread/slippage/commission). لا تتضمن Bid/Ask تاريخياً للوسيط، ولا تجعل أي استراتيجية Approved أو صالحة للتنفيذ.",
    }
    (out_dir / "audit_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "strategy_timeframe_matrix.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "strategy_timeframe_matrix.md").write_text(markdown_matrix(payload), encoding="utf-8")
    print(json.dumps({"workspace": str(workspace), "manifest": str(out_dir / "audit_manifest.json"), "matrix": str(out_dir / "strategy_timeframe_matrix.json"), "rows": len(matrix)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
