"""يفحص ملف شموع XAUUSD لعام 2025 قبل أي اختبار استراتيجية."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


SOURCE = Path("/tmp/XAU_15m_data.csv")
OUTPUT = Path("/home/ubuntu/xauusd-trading-system/xauusd_2025_data_audit.json")
START = pd.Timestamp("2025-01-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")


def main() -> None:
    raw = pd.read_csv(SOURCE, sep=";")
    stamps = pd.to_datetime(raw["Date"], format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    frame = raw.assign(timestamp=stamps).dropna(subset=["timestamp"]).set_index("timestamp").sort_index()
    frame.columns = [str(column).title() for column in frame.columns]
    year = frame.loc[(frame.index >= START) & (frame.index < END)].copy()
    for column in ("Open", "High", "Low", "Close", "Volume"):
        year[column] = pd.to_numeric(year[column], errors="coerce")
    invalid_ohlc = year[["Open", "High", "Low", "Close"]].isna().any(axis=1)
    non_monotonic = not year.index.is_monotonic_increasing
    duplicates = int(year.index.duplicated().sum())
    gaps = year.index.to_series().diff().dropna()
    expected = pd.Timedelta(minutes=15)
    material_gaps = gaps[gaps > expected]
    largest_gaps = [
        {
            "previous_bar_utc": str(timestamp - gap),
            "next_bar_utc": str(timestamp),
            "minutes": round(float(gap.total_seconds() / 60), 1),
        }
        for timestamp, gap in material_gaps.sort_values(ascending=False).head(12).items()
    ]
    payload = {
        "source": str(SOURCE),
        "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive, normalized UTC",
        "rows": int(len(year)),
        "first_timestamp": str(year.index.min()),
        "last_timestamp": str(year.index.max()),
        "duplicate_timestamps": duplicates,
        "non_monotonic": non_monotonic,
        "invalid_ohlc_rows": int(invalid_ohlc.sum()),
        "zero_or_missing_volume_rows": int((year["Volume"].fillna(0) <= 0).sum()),
        "expected_bar_interval_minutes": 15,
        "gaps_over_15m": int(len(material_gaps)),
        "largest_gap_minutes": round(float(material_gaps.max().total_seconds() / 60), 1) if len(material_gaps) else 0.0,
        "largest_gaps": largest_gaps,
        "note": "تتضمن الفجوات إغلاقات نهاية الأسبوع والجلسات؛ لا تُملأ شموع مصطنعة.",
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
