"""يتحقق من أن حمولة الرسم لا تصف شموع الوسيط بأنها مرجعية."""

from __future__ import annotations

import production_server as server


def main() -> None:
    original_fetch = server.market_data.historical_ohlc
    try:
        bridge_frame = server.connector.fetch_ohlc(period="2y", interval="1d").copy()
        contract = dict(bridge_frame.attrs.get("data_contract", {}))
        contract.update({
            "source": "MT5 read-only bridge candles",
            "source_symbol": "XAUUSD",
            "instrument": "XAUUSD",
            "price_basis": "broker_spot",
            "source_kind": "broker_read_only_ohlc",
        })
        bridge_frame.attrs["data_contract"] = contract
        server.market_data.historical_ohlc = lambda period, timeframe: bridge_frame.copy()
        with server.timeframe_cache_lock:
            server.timeframe_cache.clear()
        with server.candle_cache_lock:
            server.candle_cache.clear()
        payload = server.make_chart_payload("1d")
        assert payload["reference_only"] is False
        assert payload["source"] == "MT5 read-only bridge candles"
        assert payload["reference_validation"]["source"] == "MT5 read-only bridge candles"
        print("نجح اختبار وسم مصدر الرسم: شموع الجسر لا توصف كشموع مرجعية.")
    finally:
        server.market_data.historical_ohlc = original_fetch
        with server.timeframe_cache_lock:
            server.timeframe_cache.clear()
        with server.candle_cache_lock:
            server.candle_cache.clear()


if __name__ == "__main__":
    main()
