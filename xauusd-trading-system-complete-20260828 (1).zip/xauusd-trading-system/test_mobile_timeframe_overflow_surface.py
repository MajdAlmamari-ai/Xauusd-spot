from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = [
        "function compactCandleTime(value)",
        "title=\"${esc(fullTime)}\"",
        "grid-template-columns:repeat(3,minmax(0,1fr))!important",
        "grid-auto-flow:row!important",
        "grid-auto-columns:auto!important",
        ".app.studioLayout .workspaceDock{min-width:0!important;max-width:calc(100% - 24px)!important;overflow:hidden!important}",
        ".app.studioLayout .tfCandle{margin-top:5px!important;white-space:nowrap!important;direction:ltr!important",
        ".app.studioLayout .timeframes .tfPriority{grid-column:auto!important}",
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    print("PASS: mobile timeframe cards use a bounded three-column grid and compact candle timestamps")


if __name__ == "__main__":
    main()
