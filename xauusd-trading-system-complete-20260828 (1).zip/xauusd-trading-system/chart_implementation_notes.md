# مواصفات شاشة الرسم التفاعلي

تستخدم الواجهة مكتبة **TradingView Lightweight Charts 5** لرسم الشموع، وخطوط المتوسطات، وطبقات المستويات. توثيق المكتبة يوضح أن `setData` يملأ السلسلة كاملة، بينما `update` مخصص لتحديث آخر عنصر أو إضافة عنصر جديد؛ تُستخدم الواجهة الحالية `setData` عند تبديل الإطار، ولا تُنشئ شمعة من السعر العام وحده.

توضح مكتبة الرسم أن شمعة OHLC تتكون من `open` و`high` و`low` و`close` ووقت صالح، وأنها تدعم شموعاً وخطوطاً وHistogram في المتصفح. ولأن مصدر السعر العام لا يزوّد شموعاً حية قابلة للتنفيذ، يظهر السعر في العنوان منفصلاً ويظل الرسم قائماً على شموع المصدر المرجعي مع وقت آخر شمعة.

## المراجع

- Lightweight Charts, Getting Started — https://tradingview.github.io/lightweight-charts/docs
- Lightweight Charts, Series types — https://tradingview.github.io/lightweight-charts/docs/series-types
