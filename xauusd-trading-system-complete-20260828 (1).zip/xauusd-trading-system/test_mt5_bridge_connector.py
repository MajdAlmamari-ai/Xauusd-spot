"""اختبار عقد جسر MT5 للقراءة فقط دون الاتصال بوسيط حقيقي."""

from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
from urllib.parse import parse_qs, urlparse

import pandas as pd

from mt5_price_connector import MT5PriceConnector


TOKEN = "test-read-only-token"
requests_seen: list[dict[str, str]] = []


class BridgeStub(BaseHTTPRequestHandler):
    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        requests_seen.append({"path": parsed.path, "authorization": self.headers.get("Authorization", "")})
        if self.headers.get("Authorization") != f"Bearer {TOKEN}":
            self._send(401, {"status": "error", "message": "غير مصرح"})
            return
        if parsed.path == "/quote":
            self._send(200, {
                "status": "success", "symbol": query["symbol"][0], "bid": 4300.10, "ask": 4300.50,
                "last_price": 4300.30, "spread": 0.40, "utc_time": "2026-08-22 00:00:00 UTC", "tick_age_seconds": 1.2, "stale": False,
            })
            return
        if parsed.path == "/ohlc":
            start = datetime(2026, 8, 1, tzinfo=timezone.utc)
            bars = []
            for index in range(250):
                price = 4300.0 + index * 0.1
                bars.append({
                    "time": int((start + timedelta(minutes=index)).timestamp()),
                    "open": price, "high": price + 0.5, "low": price - 0.5,
                    "close": price + 0.1, "tick_volume": 100 + index,
                })
            self._send(200, {"status": "success", "bars": bars})
            return
        self._send(404, {"status": "error", "message": "not found"})

    def _send(self, status: int, body: dict) -> None:
        data = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *_args) -> None:
        return


def main() -> None:
    server = ThreadingHTTPServer(("127.0.0.1", 0), BridgeStub)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    os.environ["MT5_BRIDGE_TOKEN"] = TOKEN
    os.environ["LIVE_PRICE_SOURCE"] = "mt5"
    connector = MT5PriceConnector(symbol="XAUUSD.a", bridge_url=f"http://127.0.0.1:{server.server_port}")
    try:
        quote = connector.fetch_live_quote()
        assert quote["status"] == "success"
        assert quote["source"] == "MT5 broker read-only bridge"
        assert quote["bid"] == 4300.10
        assert quote["ask"] == 4300.50
        assert quote["broker_quote_eligible"] is True
        assert quote["age_seconds"] == 1.2
        assert quote["tradable"] is False
        assert quote["analysis_only"] is True

        index = pd.date_range("2026-08-01", periods=12, freq="1h", tz="UTC")
        reference_candles = pd.DataFrame({"Open": range(1, 13), "High": range(2, 14), "Low": range(0, 12), "Close": [value + 0.5 for value in range(1, 13)], "Volume": range(10, 22)}, index=index)
        five_minute_index = pd.date_range("2026-08-01", periods=24, freq="5min", tz="UTC")
        five_minute_candles = pd.DataFrame({"Open": range(1, 25), "High": range(2, 26), "Low": range(0, 24), "Close": [value + 0.5 for value in range(1, 25)], "Volume": range(10, 34)}, index=five_minute_index)
        with patch("mt5_price_connector.yf.Ticker") as ticker:
            ticker.return_value.history.side_effect = lambda **kwargs: five_minute_candles if kwargs["interval"] == "5m" else reference_candles
            candles = connector.fetch_ohlc(period="2y", interval="1d")
            candles_10m = connector.fetch_ohlc(period="60d", interval="10m")
            candles_2h = connector.fetch_ohlc(period="2y", interval="2h")
            candles_4h = connector.fetch_ohlc(period="2y", interval="4h")
        assert len(candles) == 12
        assert list(candles.columns) == ["Open", "High", "Low", "Close", "Volume"]
        assert str(candles.index.tz) == "UTC"
        assert len(candles_10m) == 12
        assert len(candles_2h) == 6
        assert len(candles_4h) == 3
        assert ticker.return_value.history.call_count == 4
        assert all(row["authorization"] == f"Bearer {TOKEN}" for row in requests_seen)
        assert [row["path"] for row in requests_seen] == ["/quote"]
        print("نجح اختبار موصل MT5: السعر من الجسر والشموع المرجعية من المصدر التاريخي والتوثيق ووضع القراءة فقط.")
    finally:
        server.shutdown()
        server.server_close()
        os.environ.pop("MT5_BRIDGE_TOKEN", None)
        os.environ.pop("LIVE_PRICE_SOURCE", None)

    os.environ["MT5_BRIDGE_URL"] = "https://unused-bridge.invalid"
    os.environ.pop("USE_MARKET_DATA_BRIDGE", None)
    default_connector = MT5PriceConnector(symbol="XAUUSD")
    assert default_connector.bridge_url == "", "لا ينبغي قبول رابط جسر غير مفعّل صراحةً"
    os.environ["USE_MARKET_DATA_BRIDGE"] = "true"
    enabled_connector = MT5PriceConnector(symbol="XAUUSD")
    assert enabled_connector.bridge_url == "https://unused-bridge.invalid"
    os.environ.pop("MT5_BRIDGE_URL", None)
    os.environ.pop("USE_MARKET_DATA_BRIDGE", None)
    print("نجح فحص أولوية المصدر: لا يُستخدم الجسر إلا بعد تفعيله صراحةً.")


if __name__ == "__main__":
    main()
