from __future__ import annotations

import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary_directory:
        os.environ["MARKET_ARCHIVE_DB_PATH"] = str(Path(temporary_directory) / "persistent.sqlite3")
        os.environ["USE_PERSISTENT_MARKET_ARCHIVE"] = "true"
        os.environ["MARKET_PRICE_STALE_SECONDS"] = "60"

        import production_server

        assert production_server.archive_backed_live_price is True
        archive = production_server.market_archive
        assert archive is not None
        timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        archive.ingest_gold_api_quote(
            {
                "status": "success",
                "source": "gold-api.com XAU/USD live market reference",
                "source_symbol": "XAU/USD",
                "instrument": "XAU/USD",
                "source_timestamp": timestamp,
                "fetched_at": timestamp,
                "last_price": 4605.75,
                "stale": False,
                "live_for_analysis": True,
                "tradable": False,
            }
        )
        quote = production_server.refresh_quote_state()
        assert quote["collector_backed"] is True
        assert quote["last_price"] == 4605.75
        assert quote["source"].endswith("(persistent archive)")
        assert quote["bid"] is None and quote["ask"] is None and quote["tradable"] is False
        with production_server.app.test_client() as client:
            status = client.get("/api/market-archive-status").get_json()
        assert status["state"]["latest_status"] == "LIVE"
        assert status["observation_count"] == 1
    print("PASS: persistent archive mode serves the collector quote without a direct market-source request")


if __name__ == "__main__":
    main()
