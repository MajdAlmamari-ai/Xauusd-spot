#!/usr/bin/env python3
"""خادم XAUUSD بصفحة تقنية موحدة مستوحاة من كامل لقطات المرجع."""

from __future__ import annotations

import threading
import time
import json
from collections import defaultdict, deque
from copy import deepcopy
from datetime import datetime, timezone
from os import getenv
from typing import Any

from flask import Flask, Response, jsonify, request, stream_with_context
from flask_cors import CORS

from ai_analysis import build_ai_analysis
from analysis_contracts import decision_data_context_from_contract
from data_transparency import build_data_transparency
from chart_image_analysis import analyze_chart_image_ai, available_chart_ai_providers, build_combined_chart_image_analysis, build_platform_image_analysis, validate_chart_image
from attachment_ai_page import ATTACHMENT_AI_HTML
from economic_calendar import EconomicCalendar
from institutional_flows import InstitutionalFlowTracker
from liquidity_engine import LiquidityEngine
from market_archive import MarketArchive
from market_data import ArchivedGoldApiLivePriceProvider, GoldApiLivePriceProvider, MarketDataService, YahooFinanceHistoricalDataProvider
from mt5_price_connector import MT5PriceConnector
from news_surprise_engine import NewsSurpriseEngine
from ob_fvg_strategy import backtest_ob_fvg_strategy, build_ob_fvg_setup
from reproducible_backtest import CostModel
from technical_indicators import calculate_snapshot, sma, timeframe_signal

app = Flask(__name__)
_cors_origins = [origin.strip() for origin in getenv("ALLOWED_CORS_ORIGINS", "").split(",") if origin.strip()]
if _cors_origins:
    CORS(app, resources={r"/api/*": {"origins": _cors_origins}})

connector = MT5PriceConnector()
calendar = EconomicCalendar()
flow_tracker = InstitutionalFlowTracker()
liquidity_engine = LiquidityEngine()
news_engine = NewsSurpriseEngine()
try:
    market_archive = MarketArchive.from_environment()
    market_archive_initialization_error = None
except Exception as error:
    market_archive = None
    market_archive_initialization_error = str(error)

archive_backed_live_price = (
    market_archive is not None
    and getenv("USE_PERSISTENT_MARKET_ARCHIVE", "").strip().lower() in {"1", "true", "yes"}
)
market_data = MarketDataService(
    live_price_provider=ArchivedGoldApiLivePriceProvider(market_archive) if archive_backed_live_price else GoldApiLivePriceProvider(connector),
    historical_data_provider=YahooFinanceHistoricalDataProvider(connector),
)

state: dict[str, Any] = {
    "status": "بدء التشغيل",
    "last_refresh": None,
    "last_quote_refresh": None,
    "quote_revision": 0,
    "quote_refresh_policy": {
        "provider": "gold-api.com persistent archive" if archive_backed_live_price else "gold-api.com",
        "minimum_refresh_seconds": 30,
        "transport": "server_sent_events_from_archive" if archive_backed_live_price else "server_sent_events_from_cached_reference",
        "is_tick_feed": False,
    },
    "quote": {"status": "pending", "symbol": connector.symbol},
    "last_valid_goldapi_quote": None,
    "technical": None,
    "timeframes": [],
    "liquidity": {"status": "غير متاح", "score": None, "trap_detected": False, "alerts": []},
    "news": {"status": "غير متاح", "pending_event": False, "events": []},
    "order_flow": {"status": "غير متاح", "eligible_for_decision": False, "message": "لم تُفحص تغذية تدفق السيولة بعد."},
    "institutional": {"status": "reference_only", "items": []},
    "external_reference": {},
    "data_transparency": {},
    "market_archive": {"enabled": market_archive is not None, "status": "جارِ تهيئة أرشيف السعر المرجعي"},
    "recommendation": {"signal": "لا توجد إشارة", "reason": "جاري التحقق من البيانات"},
}
state_lock = threading.Lock()
spot_futures_cache_lock = threading.Lock()
spot_futures_cache: dict[str, Any] = {"value": None, "expires_at": 0.0}
SPOT_FUTURES_CACHE_SECONDS = max(60, int(getenv("SPOT_FUTURES_CACHE_SECONDS", "300")))

TIMEFRAME_CONFIGS: dict[str, dict[str, Any]] = {
    "1m": {"label": "دقيقة", "interval": "1m", "period": "5d", "cache_seconds": 30, "chart_cache_seconds": 8},
    "5m": {"label": "5 دقائق", "interval": "5m", "period": "60d", "cache_seconds": 180, "chart_cache_seconds": 45},
    "10m": {"label": "10 دقائق", "interval": "10m", "period": "5d", "cache_seconds": 120, "chart_cache_seconds": 45},
    "15m": {"label": "15 دقيقة", "interval": "15m", "period": "60d", "cache_seconds": 300, "chart_cache_seconds": 90},
    "30m": {"label": "30 دقيقة", "interval": "30m", "period": "60d", "cache_seconds": 300, "chart_cache_seconds": 120},
    "1h": {"label": "كل ساعة", "interval": "1h", "period": "730d", "cache_seconds": 900, "chart_cache_seconds": 180},
    "2h": {"label": "ساعتان", "interval": "2h", "period": "730d", "cache_seconds": 900, "chart_cache_seconds": 240},
    "4h": {"label": "4 ساعات", "interval": "4h", "period": "730d", "cache_seconds": 1200, "chart_cache_seconds": 300},
    "1d": {"label": "يومي", "interval": "1d", "period": "2y", "cache_seconds": 900, "chart_cache_seconds": 300},
    "1wk": {"label": "أسبوعي", "interval": "1wk", "period": "10y", "cache_seconds": 3600, "chart_cache_seconds": 900},
    "1mo": {"label": "شهري", "interval": "1mo", "period": "max", "cache_seconds": 21600, "chart_cache_seconds": 3600},
}
DEFAULT_TIMEFRAME_ID = "1d"
timeframe_cache: dict[str, dict[str, Any]] = {}
timeframe_cache_lock = threading.Lock()
TIMEFRAME_IDS = list(TIMEFRAME_CONFIGS)
candle_cache: dict[str, dict[str, Any]] = {}
candle_cache_lock = threading.Lock()
strategy_backtest_cache: dict[str, dict[str, Any]] = {}
strategy_backtest_cache_lock = threading.Lock()
image_analysis_rate_lock = threading.Lock()
image_analysis_requests: dict[str, deque[float]] = defaultdict(deque)
IMAGE_ANALYSIS_WINDOW_SECONDS = 10 * 60
IMAGE_ANALYSIS_MAX_REQUESTS = 5


def add_higher_timeframe_context(analysis: dict[str, Any], higher_analysis: dict[str, Any] | None) -> None:
    """يضيف فحص توافق مع الإطار الأعلى عند توفره، دون خلق إشارة تنفيذ."""
    snapshot = analysis.get("technical")
    higher_snapshot = (higher_analysis or {}).get("technical")
    if snapshot is None:
        return
    advanced = snapshot.get("advanced_tools")
    if not advanced:
        return
    own_bias = advanced.get("confluence", {}).get("bias", "توافق محدود / مختلط")
    if higher_snapshot is None:
        advanced["multi_timeframe"] = {"status": "غير متاح", "details": "لا توجد لقطة صالحة للإطار الأعلى بعد.", "quality_score": 0}
        return
    higher_advanced = higher_snapshot.get("advanced_tools", {})
    higher_bias = higher_advanced.get("confluence", {}).get("bias", "توافق محدود / مختلط")
    aligned = own_bias in {"توافق صاعد", "توافق هابط"} and own_bias == higher_bias
    conflicting = own_bias in {"توافق صاعد", "توافق هابط"} and higher_bias in {"توافق صاعد", "توافق هابط"} and own_bias != higher_bias
    advanced["multi_timeframe"] = {
        "status": "متوافق" if aligned else "متعارض" if conflicting else "غير حاسم",
        "details": f"الإطار الحالي: {own_bias} | الإطار الأعلى ({higher_analysis.get('label', '—')}): {higher_bias}.",
        "quality_score": 80 if aligned else 25 if conflicting else 45,
    }


def build_signal_layers(technical: dict[str, Any] | None) -> dict[str, Any]:
    """يبني طبقتين مبسطتين: مناطق سعرية واتجاه، من نفس OHLC دون تضخيم عدد الأدلة."""
    if not technical:
        return {
            "status": "غير متاح",
            "zones": {"status": "غير متاح", "items": [], "summary": "لا توجد شموع صالحة."},
            "trend": {"status": "غير متاح", "bias": "محايد", "score": 0, "summary": "لا توجد شموع صالحة."},
            "decision": "انتظار / حياد",
            "decision_reason": "لا يمكن بناء طبقات مبسطة دون لقطة OHLC صالحة.",
        }
    advanced = technical.get("advanced_tools", {}).get("tools", {})
    zone_sources = (
        ("support_resistance", "دعم ومقاومة"),
        ("order_blocks", "Order Block"),
        ("fair_value_gap", "Fair Value Gap"),
        ("liquidity_zones", "منطقة سيولة"),
    )
    zone_items: list[dict[str, Any]] = []
    for key, label in zone_sources:
        item = advanced.get(key, {}) or {}
        zones = item.get("zones", []) or []
        if not zones and item.get("levels"):
            for name, value in list(item.get("levels", {}).items())[:4]:
                try:
                    zone_items.append({"source": label, "label": str(name), "lower": float(value), "upper": float(value), "bias": item.get("bias", "محايد"), "quality_score": item.get("quality_score", 0), "basis": item.get("quality", "OHLC")})
                except (TypeError, ValueError):
                    continue
        for zone in zones[:4]:
            try:
                zone_items.append({"source": label, "label": zone.get("label", label), "lower": float(zone.get("lower")), "upper": float(zone.get("upper")), "bias": zone.get("bias", "محايد"), "quality_score": zone.get("quality_score", 0), "basis": zone.get("quality", item.get("quality", "OHLC + pivots"))})
            except (TypeError, ValueError):
                continue
    zone_items.sort(key=lambda row: float(row.get("quality_score", 0)), reverse=True)
    qualified_zones = [row for row in zone_items if float(row.get("quality_score", 0) or 0) >= 50]
    zones_summary = "لا توجد منطقة مؤهلة" if not qualified_zones else f"{len(qualified_zones)} منطقة مؤهلة من OHLC والقمم/القيعان؛ ليست دليلاً على أوامر مؤسسات حقيقية."

    latest = float(technical.get("latest")) if technical.get("latest") is not None else None
    ma20 = ma50 = None
    for row in technical.get("moving_averages", []) or []:
        if row.get("name") == "MA20":
            ma20 = row.get("exponential")
        elif row.get("name") == "MA50":
            ma50 = row.get("exponential")
    indicators = {str(row.get("name")): row for row in technical.get("indicators", []) or []}
    try:
        adx = float(indicators.get("ADX(14)", {}).get("value"))
    except (TypeError, ValueError):
        adx = None
    try:
        rsi = float(technical.get("rsi"))
    except (TypeError, ValueError):
        rsi = None
    trend_score = 0
    trend_notes: list[str] = []
    if latest is not None and ma20 is not None and ma50 is not None:
        if latest > float(ma20) > float(ma50):
            trend_score += 2
            trend_notes.append("السعر أعلى EMA20 وEMA50 وEMA20 أعلى EMA50")
        elif latest < float(ma20) < float(ma50):
            trend_score -= 2
            trend_notes.append("السعر أدنى EMA20 وEMA50 وEMA20 أدنى EMA50")
        else:
            trend_notes.append("المتوسطات غير متراصة؛ الاتجاه مختلط")
    if adx is not None:
        trend_notes.append(f"ADX(14)={adx:.1f}؛ {'اتجاه واضح' if adx >= 25 else 'سوق ضعيف/عرضي'}")
        if adx < 20:
            trend_score = 0
    trend_bias = "صاعد" if trend_score > 0 else "هابط" if trend_score < 0 else "محايد"
    momentum_bias = "محايد"
    if rsi is not None:
        if 50 <= rsi < 70:
            momentum_bias = "صاعد"
        elif 30 < rsi <= 50:
            momentum_bias = "هابط"
        elif rsi >= 70 or rsi <= 30:
            trend_notes.append("RSI ممتد؛ لا يُستخدم لمطاردة السعر")
    if trend_bias == "محايد":
        trend_status = "غير حاسم"
    elif adx is not None and adx < 25:
        trend_status = "ميل ضعيف"
    else:
        trend_status = "اتجاه مؤهل مبدئياً"
    if trend_bias in {"صاعد", "هابط"} and momentum_bias not in {"محايد", trend_bias}:
        decision = "انتظار / حياد"
        decision_reason = "اتجاه المتوسطات لا يتوافق مع زخم RSI؛ لا تُحوّل الإشارتين إلى صفقة."
    elif trend_bias in {"صاعد", "هابط"} and qualified_zones:
        decision = "شراء مشروط" if trend_bias == "صاعد" else "بيع مشروط"
        decision_reason = "الاتجاه متوافق مع منطقة سعرية مؤهلة؛ القرار يبقى مشروطاً بحداثة السعر ومستويات الإبطال."
    else:
        decision = "انتظار / حياد"
        decision_reason = "لا يوجد اتجاه مؤهل مع منطقة سعرية مؤهلة في الوقت نفسه."
    return {
        "status": "متاح",
        "zones": {"status": "مؤهلة" if qualified_zones else "غير حاسمة", "items": zone_items[:12], "summary": zones_summary, "basis": "OHLC + pivots؛ المناطق المرصودة ليست Order Flow"},
        "trend": {"status": trend_status, "bias": trend_bias, "score": trend_score, "summary": " · ".join(trend_notes) or "لا توجد قراءة اتجاه كافية", "ema20": ma20, "ema50": ma50, "adx": adx, "rsi": rsi, "momentum_bias": momentum_bias, "basis": "EMA20/EMA50 + ADX + RSI من OHLC"},
        "decision": decision,
        "decision_reason": decision_reason,
    }


def get_timeframe_analysis(timeframe_id: str, force: bool = False) -> dict[str, Any]:
    """يجلب شموع الإطار المختار ويحسِب لقطة مستقلة؛ لا ينسخ التحليل اليومي."""
    config = TIMEFRAME_CONFIGS.get(timeframe_id)
    if config is None:
        raise ValueError(f"إطار زمني غير مدعوم: {timeframe_id}")

    now = time.time()
    with timeframe_cache_lock:
        cached = timeframe_cache.get(timeframe_id)
        if cached and not force and now - cached["cached_at_epoch"] < config["cache_seconds"]:
            return cached["payload"]

    try:
        candles = get_timeframe_candles(timeframe_id, force=force)
        snapshot = calculate_snapshot(candles)
        payload = {
            "id": timeframe_id,
            "label": config["label"],
            "interval": config["interval"],
            "period": config["period"],
            "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "technical": snapshot,
            "signal_layers": build_signal_layers(snapshot),
            "ob_fvg_strategy": build_ob_fvg_setup(candles, snapshot),
            "error": None,
        }
    except Exception as error:
        payload = {
            "id": timeframe_id,
            "label": config["label"],
            "interval": config["interval"],
            "period": config["period"],
            "updated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "technical": None,
            "error": str(error),
        }

    with timeframe_cache_lock:
        timeframe_cache[timeframe_id] = {"cached_at_epoch": now, "payload": payload}
    return payload


def get_timeframe_candles(timeframe_id: str, force: bool = False):
    """يحفظ شموع المصدر الخام لكل إطار كي يتطابق الرسم مع التحليل في الاستدعاء نفسه."""
    config = TIMEFRAME_CONFIGS[timeframe_id]
    now = time.time()
    with candle_cache_lock:
        cached = candle_cache.get(timeframe_id)
        if cached and not force and now - cached["cached_at_epoch"] < config.get("chart_cache_seconds", config["cache_seconds"]):
            return cached["frame"]
    candles = market_data.historical_ohlc(period=config["period"], timeframe=config["interval"])
    with candle_cache_lock:
        candle_cache[timeframe_id] = {"cached_at_epoch": now, "frame": candles}
    return candles


def _chart_time(value: Any) -> int:
    if hasattr(value, "timestamp"):
        return int(value.timestamp())
    return int(datetime.fromisoformat(str(value)).replace(tzinfo=timezone.utc).timestamp())


def _chart_line(frame: Any, values: Any, limit: int = 420) -> list[dict[str, float | int]]:
    start = max(0, len(frame) - limit)
    rows: list[dict[str, float | int]] = []
    for index in range(start, len(frame)):
        value = values.iloc[index]
        if value is not None and not getattr(value, "__class__", type(None)).__name__ == "NAType":
            try:
                if float(value) == float(value):
                    rows.append({"time": _chart_time(frame.index[index]), "value": round(float(value), 4)})
            except (TypeError, ValueError):
                continue
    return rows


def make_chart_payload(timeframe_id: str) -> dict[str, Any]:
    analysis = get_timeframe_analysis(timeframe_id)
    technical = analysis.get("technical")
    if technical is None:
        return {"timeframe": analysis, "candles": [], "overlays": {}, "error": analysis.get("error")}
    frame = get_timeframe_candles(timeframe_id)
    limit = 520 if timeframe_id in {"1m", "5m", "10m", "15m", "30m"} else 420
    visible = frame.iloc[-min(limit, len(frame)):]
    candles = [
        {
            "time": _chart_time(index),
            "open": round(float(row["Open"]), 4),
            "high": round(float(row["High"]), 4),
            "low": round(float(row["Low"]), 4),
            "close": round(float(row["Close"]), 4),
            "volume": round(float(row.get("Volume", 0.0)), 2),
        }
        for index, row in visible.iterrows()
    ]
    close = frame["Close"].astype(float)
    last_candle_epoch = _chart_time(frame.index[-1])
    last_candle_age_seconds = max(0, int(time.time() - last_candle_epoch))
    last_two = frame.iloc[-2:] if len(frame) >= 2 else frame.iloc[-1:]
    last_two_times = [str(index) for index in last_two.index]
    last_two_gap_seconds = int((frame.index[-1] - frame.index[-2]).total_seconds()) if len(frame) >= 2 else None
    candle_contract = dict(frame.attrs.get("data_contract", {}))
    candle_quality = dict(frame.attrs.get("data_quality", {}))
    data_mode = candle_contract.get("data_mode", "UNKNOWN")
    source_kind = candle_contract.get("source_kind", "reference_ohlc")
    broker_candles = source_kind == "broker_read_only_ohlc"
    source_label = candle_contract.get("source") or ("MT5 read-only bridge candles" if broker_candles else "Yahoo Finance GC=F reference candles")
    chart_data_quality = {
        "data_mode": data_mode,
        "data_mode_label": "بيانات أصلية" if data_mode == "NATIVE_DATA" else "بيانات مجمعة مكتملة" if data_mode == "RESAMPLED_DATA" else "تصنيف المصدر غير متاح",
        "source_interval": candle_contract.get("source_interval"),
        "target_rule": candle_contract.get("target_rule"),
        "expected_components": candle_contract.get("expected_components"),
        "rejected_incomplete_buckets": candle_contract.get("rejected_incomplete_buckets", 0),
        "completeness_policy": candle_contract.get("completeness_policy"),
        "validated_rows": candle_quality.get("rows"),
        "visible_rows": int(len(visible)),
        "largest_observed_gap_seconds": candle_quality.get("largest_observed_gap_seconds"),
        "last_two_gap_seconds": last_two_gap_seconds,
        "quality_message": candle_quality.get("message"),
    }
    advanced = technical.get("advanced_tools", {}).get("tools", {})
    fvg_tool = advanced.get("fair_value_gap", {})
    fvg_levels = fvg_tool.get("levels", {})
    fvg_zones: list[dict[str, Any]] = []
    if all(name in fvg_levels for name in ("الحد الأدنى", "الحد الأعلى")):
        try:
            fvg_zones.append({
                "kind": "fair_value_gap",
                "label": "FVG صاعدة" if fvg_tool.get("bias") == "صاعد" else "FVG هابطة" if fvg_tool.get("bias") == "هابط" else "Fair Value Gap",
                "lower": float(fvg_levels["الحد الأدنى"]), "upper": float(fvg_levels["الحد الأعلى"]),
                "start_time": _chart_time(fvg_tool.get("formed_at")), "end_time": last_candle_epoch,
                "quality_score": fvg_tool.get("quality_score", 0), "qualified": bool(fvg_tool.get("qualified")),
            })
        except (TypeError, ValueError):
            pass
    with state_lock:
        quote = state.get("quote", {})
        liquidity = state.get("liquidity", {})
        news = state.get("news", {})
        order_flow = state.get("order_flow", {})
    scenario = integrated_recommendation(quote, technical, liquidity, news, order_flow)
    data_transparency = build_data_transparency(quote, technical)
    scenario_zones: list[dict[str, Any]] = []
    if all(scenario.get(name) is not None for name in ("entry", "stop_loss", "take_profit")):
        entry, stop, target = (float(scenario[name]) for name in ("entry", "stop_loss", "take_profit"))
        scenario_zones.append({
            "kind": "trade_scenario", "label": scenario.get("signal", "سيناريو مشروط"),
            "lower": min(entry, stop), "upper": max(entry, stop), "start_time": last_candle_epoch, "end_time": last_candle_epoch,
            "entry": entry, "target": target, "quality_score": scenario.get("confidence", 0), "qualified": True,
        })
    def level(tool: str, name: str):
        return advanced.get(tool, {}).get("levels", {}).get(name)
    overlays = {
        "ma20": _chart_line(frame, sma(close, 20), limit),
        "ma50": _chart_line(frame, sma(close, 50), limit),
        "levels": {
            "anchored_vwap": level("anchored_vwap", "Anchored VWAP"),
            "fibonacci": advanced.get("fibonacci", {}).get("levels", {}),
            "fair_value_gap": fvg_levels,
            "liquidity_sweep": advanced.get("liquidity_sweep", {}).get("levels", {}),
            "volume_profile": advanced.get("volume_profile", {}).get("levels", {}),
            "support_resistance": advanced.get("support_resistance", {}).get("levels", {}),
        },
        "volume_profile_bins": advanced.get("volume_profile", {}).get("bins", []),
        "zones": {
            "liquidity": advanced.get("liquidity_zones", {}).get("zones", []),
            "order_blocks": advanced.get("order_blocks", {}).get("zones", []),
            "support_resistance": advanced.get("support_resistance", {}).get("zones", []),
            "fair_value_gap": fvg_zones,
            "trade_scenario": scenario_zones,
        },
        "tool_status": {name: {"status": item.get("status"), "quality_score": item.get("quality_score", 0)} for name, item in advanced.items()},
    }
    return {
        "timeframe": {key: analysis.get(key) for key in ("id", "label", "interval", "period", "updated_at")},
        "candles": candles,
        "overlays": overlays,
        "last_candle_time": technical.get("last_candle_time"),
        "last_candle_close": round(float(frame["Close"].iloc[-1]), 4),
        "last_candle_age_seconds": last_candle_age_seconds,
        "last_two_candle_times": last_two_times,
        "last_two_gap_seconds": last_two_gap_seconds,
        "chart_data_quality": chart_data_quality,
        "minute_integrity": {
            "has_two_candles": len(frame) >= 2,
            "last_two_gap_seconds": last_two_gap_seconds,
            "source_note": "لا تملأ المنصة فجوات المصدر بشموع مصطنعة؛ يظهر الفاصل الحقيقي بين آخر شمعتين.",
        } if timeframe_id == "1m" else None,
        "source": source_label,
        "reference_validation": ({"source": source_label, "removed_tail_candles": 0, "message": "لا يطبق حارس Yahoo على شموع وسيط للقراءة فقط."} if broker_candles else connector.ohlc_diagnostics.get(analysis.get("interval"), connector.last_ohlc_diagnostics)),
        "reference_only": not broker_candles,
        "data_transparency": data_transparency,
        "error": None,
    }


def make_timeframe_card(analysis: dict[str, Any]) -> dict[str, Any]:
    snapshot = analysis.get("technical")
    if snapshot is None:
        return {
            "id": analysis["id"],
            "label": analysis["label"],
            "action": "غير متاح",
            "score": None,
            "confidence": 0.0,
            "last_candle_time": None,
            "error": analysis.get("error"),
        }
    return {
        "id": analysis["id"],
        **timeframe_signal(snapshot, analysis["label"]),
        "last_candle_time": snapshot["last_candle_time"],
        "error": None,
    }


def make_institutional_context() -> dict[str, Any]:
    """بيانات وصفية صريحة؛ لا نحول الأرقام القديمة إلى تدفق لحظي."""
    return {
        "status": "reference_only",
        "message": "أوامر البنوك والشركات الخاصة ليست مكشوفة لحظياً للعامة.",
        "items": [
            {"name": "COT / CFTC", "value": None, "lag": "أسبوعي", "source": "CFTC"},
            {"name": "تدفقات صناديق الذهب", "value": None, "lag": "يومي/حسب المصدر", "source": "ETF issuer"},
            {"name": "مشتريات البنوك المركزية", "value": None, "lag": "شهري أو متأخر", "source": "WGC/official releases"},
            {"name": "العقود المفتوحة", "value": None, "lag": "حسب سوق العقود", "source": "broker/futures feed"},
        ],
    }


def make_external_reference_context(quote: dict[str, Any] | None = None, spot_futures_comparison: dict[str, Any] | None = None) -> dict[str, Any]:
    tradingview_symbol = getenv("TRADINGVIEW_SYMBOL", "TVC:GOLD")
    quote = quote or {}
    bridge_configured = bool(connector.bridge_url)
    broker_quote_eligible = bool(quote.get("broker_quote_eligible"))
    bridge_status = (
        "متصل: Bid/Ask ووقت آخر Tick اجتازا عقد القراءة والتحليل." if broker_quote_eligible
        else "مضبوط لكن لم يصل Bid/Ask حديث مؤهل بعد." if bridge_configured
        else "غير مضبوط: لا توجد Bid/Ask أو Spread من وسيط المستخدم."
    )
    return {
        "mode": "analysis_only",
        "mt5_bridge_configured": bridge_configured,
        "broker_quote_eligible": broker_quote_eligible,
        "bridge_status": bridge_status,
        "market_data_status": "موصل MT5 للقراءة فقط يزوّد Bid/Ask حديثين" if broker_quote_eligible else "Gold API يزوّد سعراً سوقياً عاماً حديثاً؛ لا تتوفر Bid/Ask أو Spread للتنفيذ",
        "market_reference_target": "XAUUSD — مصدر سوق عام مستقل",
        "phone_only_guidance": "من الهاتف فقط: استخدم TradingView للمخطط. السعر الظاهر حديث للتحليل، لكنه ليس Bid/Ask أو سعراً لتنفيذ أمر.",
        "preferred_visual_reference": "TradingView",
        "tradingview_symbol": tradingview_symbol,
        "tradingview_url": "https://www.tradingview.com/symbols/GOLD/?exchange=TVC",
        "tradingview_status": "TVC:GOLD هو مرجع إغلاق الذهب في TradingView؛ يظل سعر Gold API المتجدد منفصلاً للتحليل والرسم البياني.",
        "spot_futures_comparison": spot_futures_comparison or {"status": "غير متاح", "message": "لم تُجرَ مقارنة الفوري والآجل بعد."},
    }


def make_news_context() -> dict[str, Any]:
    reports = []
    for report in getattr(news_engine, "scheduled_reports", []):
        reports.append({
            "name": report.get("report", "تقرير اقتصادي"),
            "frequency": report.get("frequency", "غير محدد"),
            "impact": report.get("impact_level", "غير محدد"),
            "sensitivity": report.get("gold_sensitivity", "غير محدد"),
            "actual": None,
            "forecast": None,
            "previous": None,
            "source_status": "تقويم وصفي؛ Actual/Forecast يحتاجان موصلاً مرخصاً",
        })
    return {
        "status": "calendar_ready_no_live_release_feed",
        "pending_event": False,
        "geopolitical_risk": False,
        "message": "التقارير المجدولة معروضة، لكن لا نعدّ الخبر لحظياً دون مصدر موثق.",
        "events": reports,
    }


def make_recommendation(quote: dict[str, Any], technical: dict[str, Any] | None, liquidity: dict[str, Any], news: dict[str, Any]) -> dict[str, Any]:
    if not technical:
        return {"signal": "انتظار / لا قرار", "reason": "لا توجد شموع كافية لحساب المؤشرات والأدوات.", "confidence": 0.0, "decision_state": "blocked", "evidence": [], "warnings": ["لن يُستبدل الإطار المختار بلقطة من إطار آخر."], "data_mode": "بيانات غير مكتملة"}
    data_context = decision_data_context_from_contract(quote, technical.get("data_contract"), technical.get("data_quality"))
    if quote.get("status") != "success" or quote.get("stale") or not quote.get("live_for_analysis"):
        return {"signal": "انتظار / السوق غير صالح للتقييم", "reason": "السعر العام غير حديث أو السوق مغلق؛ لا تُبنى مستويات دخول على شمعة أو سعر متأخر.", "confidence": 0.0, "decision_state": "blocked", "evidence": ["المؤشرات والطبقات حُسبت، لكن بوابة حداثة السعر لم تجتز."], "warnings": ["انتظر سعراً حديثاً ثم أعد التقييم قبل أي قرار."], "data_mode": "السوق مغلق أو تغذية السعر متأخرة"}
    if not data_context["compatible_for_price_levels"]:
        return {
            "signal": "NO TRADE",
            "reason": data_context["reason"],
            "confidence": 0.0,
            "decision_state": "blocked",
            "evidence": ["حاجز سياق البيانات منع خلط أداة أو أساس سعر مختلفين في مستويات واحدة."],
            "warnings": ["لا تُشتق نقطة دخول أو وقف أو هدف من سعر XAU/USD وشموع GC=F أو من مصدرين غير متطابقين."],
            "data_mode": "سياق البيانات غير متوافق",
            "data_context": data_context,
        }
    if news.get("pending_event") or liquidity.get("trap_detected"):
        reason = "فلتر خبر عالي الأثر نشط." if news.get("pending_event") else "احتمال فخ سيولة نشط."
        return {"signal": "انتظار / لا دخول", "reason": reason, "confidence": 0.0, "decision_state": "neutral", "evidence": ["قاعدة الحماية ترجّح عدم الدخول أثناء حدث أو فخ محتمل."], "warnings": ["لا تُفتح صفقة جديدة قبل زوال الفلتر وإعادة احتساب القرار."], "data_mode": "قرار تحليلي محمي"}
    action = technical.get("technical_signal", "متعادلة")
    advanced = technical.get("advanced_tools", {}).get("confluence", {})
    advanced_bias = advanced.get("bias")
    advanced_tools = technical.get("advanced_tools", {})
    multi_timeframe = advanced_tools.get("multi_timeframe", {})
    evidence = [
        f"عائلات الأدلة: {technical.get('evidence_strength', {}).get('label', 'غير متاح')}؛ ليست احتمال نجاح.",
        f"توافق السيولة وبنية السوق: {advanced_bias or 'غير حاسم'} ({advanced.get('qualified_tools', 0)} أدوات مؤهلة).",
        f"مقارنة الإطار الأعلى: {multi_timeframe.get('status', 'غير متاح')} (سياق للمراجعة فقط ولا يغيّر قرار هذا الإطار).",
    ]
    warnings: list[str] = []
    if news.get("status") == "calendar_ready_no_live_release_feed":
        warnings.append("لا تتوفر تغذية فورية للقيم الفعلية للأخبار؛ راجع حدثاً اقتصادياً عالي الأثر قبل التنفيذ.")
    if not quote.get("tradable"):
        warnings.append("المستويات مشتقة من شموع مرجعية؛ طابقها مع سعر XAUUSD لدى وسيطك قبل التنفيذ، فقد يختلف السبريد والسعر.")
    if not isinstance(liquidity.get("liquidity_score"), (int, float)):
        warnings.append("لا تتوفر Bid/Ask أو DOM موثقة؛ قراءة السيولة هنا مبنية على بنية الشموع والمناطق فقط.")
    if (action == "شراء" and advanced_bias == "توافق هابط") or (action == "بيع" and advanced_bias == "توافق صاعد"):
        return {"signal": "انتظار / حياد", "reason": "تعارض بين المؤشرات التقليدية وأدوات السيولة وبنية السعر؛ القرار المنضبط هو عدم الدخول حتى يظهر توافق.", "confidence": 0.0, "decision_state": "neutral", "evidence": evidence, "warnings": warnings + ["لا تستخدم إشارة منفردة لتجاوز تعارض الأدلة."], "data_mode": "تحليل مرجعي متعدد الأدوات"}
    support_resistance = advanced_tools.get("tools", {}).get("support_resistance", {})
    levels = support_resistance.get("levels", {})
    if not support_resistance.get("qualified"):
        return {"signal": "انتظار / حياد", "reason": "لا توجد مستويات دعم أو مقاومة مؤهلة لبناء إبطال وهدف واضحين؛ القرار الأفضل هو الانتظار.", "confidence": 0.0, "decision_state": "neutral", "evidence": evidence, "warnings": warnings, "data_mode": "تحليل مرجعي متعدد الأدوات"}
    confidence = float(technical.get("evidence_strength", {}).get("score", 0.0))
    if not quote.get("tradable"):
        confidence -= 8
    if news.get("status") == "calendar_ready_no_live_release_feed":
        confidence -= 10
    if not isinstance(liquidity.get("liquidity_score"), (int, float)):
        confidence -= 7
    confidence = round(max(0.0, min(90.0, confidence)), 1)
    if action == "شراء":
        signal = "شراء مشروط"
    elif action == "بيع":
        signal = "بيع مشروط"
    else:
        return {"signal": "انتظار / حياد", "reason": "القراءة الفنية متعادلة؛ لا توجد أفضلية كمية كافية للشراء أو البيع حالياً.", "confidence": confidence, "decision_state": "neutral", "evidence": evidence, "warnings": warnings, "data_mode": "تحليل مرجعي متعدد الأدوات"}
    current = technical["latest"]
    atr_value = technical.get("atr", 0.0) or 0.0
    supports = sorted(float(value) for name, value in levels.items() if str(name).startswith("دعم") and float(value) < current)
    resistances = sorted(float(value) for name, value in levels.items() if str(name).startswith("مقاومة") and float(value) > current)
    if action == "شراء":
        stop = round((supports[-1] - .25 * atr_value) if supports else current - 1.5 * atr_value, 2)
        target = round(resistances[0] if resistances else current + 3.0 * atr_value, 2)
    elif action == "بيع":
        stop = round((resistances[0] + .25 * atr_value) if resistances else current + 1.5 * atr_value, 2)
        target = round(supports[-1] if supports else current - 3.0 * atr_value, 2)
    else:
        stop = None
        target = None
    risk = abs(float(current) - float(stop)) if stop is not None else 0.0
    reward = abs(float(target) - float(current)) if target is not None else 0.0
    risk_reward = round(reward / risk, 2) if risk > 0 else None
    if risk_reward is None or risk_reward < 1.2:
        return {
            "signal": "انتظار / حياد",
            "reason": f"المستويات المؤهلة لا تحقق عائداً/مخاطرة كافياً (1:{risk_reward or 0.0:.2f})؛ لا تُعرض توصية اتجاهية ضعيفة.",
            "confidence": 0.0,
            "entry": None,
            "stop_loss": None,
            "take_profit": None,
            "risk_reward": None,
            "decision_state": "neutral",
            "evidence": evidence,
            "warnings": warnings + ["يلزم هدف مقابل وإبطال يحققان الحد الأدنى 1:1.20 قبل إظهار شراء أو بيع مشروط."],
            "data_mode": "تحليل مرجعي متعدد الأدوات",
        }
    return {
        "signal": signal,
        "reason": "القرار مبني على اتجاه المؤشرات وتوافق أدوات السيولة وبنية السوق ومستويات الإبطال/الهدف في الإطار المختار.",
        "confidence": confidence,
        "entry": current if action in {"شراء", "بيع"} else None,
        "stop_loss": stop,
        "take_profit": target,
        "risk_reward": risk_reward,
        "decision_state": "signal",
        "evidence": evidence,
        "warnings": warnings,
        "data_mode": "تحليل مرجعي — يلزم مطابقة سعر الوسيط قبل التنفيذ" if not quote.get("tradable") else "سعر وسيط حديث للتحليل",
    }


def make_intraday_recommendation(quote: dict[str, Any], technical: dict[str, Any] | None) -> dict[str, Any]:
    """يوفر توصية لحظية مرجعية من تراصف EMA20/EMA50 ومنطقة سعرية، دون تنفيذ أوامر."""
    base = {
        "signal": "انتظار / حياد", "decision_state": "neutral", "confidence": 0.0,
        "cross_state": "غير متاح", "rsi_state": "غير متاح", "zone_state": "غير متاح", "entry": None,
        "stop_loss": None, "take_profit": None, "risk_reward": None, "evidence": [],
        "warnings": ["هذه قراءة مرجعية؛ لا تمثل سعراً تنفيذياً لدى MT5."],
    }
    if not technical:
        base.update({"decision_state": "blocked", "reason": "لا توجد شموع كافية لحساب تقاطع المتوسطات والمناطق."})
        return base
    if quote.get("status") != "success" or quote.get("stale") or not quote.get("live_for_analysis"):
        base.update({"decision_state": "blocked", "reason": "السعر العام متأخر أو السوق مغلق؛ حُجبت التوصية اللحظية حتى تصل لقطة حديثة."})
        return base
    latest = technical.get("latest")
    ma20 = ma50 = None
    for row in technical.get("moving_averages", []) or []:
        if row.get("name") == "MA20": ma20 = row.get("exponential")
        if row.get("name") == "MA50": ma50 = row.get("exponential")
    try:
        latest, ma20, ma50 = float(latest), float(ma20), float(ma50)
    except (TypeError, ValueError):
        base.update({"decision_state": "blocked", "reason": "قيم EMA20/EMA50 غير مكتملة في اللقطة الحالية."})
        return base
    if latest > ma20 > ma50:
        direction, cross_state = "شراء", "تراصف صاعد EMA20 فوق EMA50"
    elif latest < ma20 < ma50:
        direction, cross_state = "بيع", "تراصف هابط EMA20 تحت EMA50"
    else:
        base.update({"cross_state": "لا يوجد تراصف واضح", "reason": "المتوسطات متداخلة؛ لا يُفترض وجود تقاطع صالح من حالة مختلطة."})
        return base
    rsi_row = next((r for r in technical.get("indicators", []) or [] if r.get("name") == "RSI(14)"), {})
    try:
        rsi_value = float(rsi_row.get("value"))
    except (TypeError, ValueError):
        base.update({"cross_state": cross_state, "rsi_state": "غير متاح", "reason": "قيمة RSI(14) غير متاحة؛ حُجبت التوصية حتى يكتمل تأكيد الزخم."})
        return base
    if direction == "شراء" and 50.0 <= rsi_value <= 70.0:
        rsi_state = f"RSI {rsi_value:.1f} يؤكد الزخم الصاعد"
    elif direction == "بيع" and 30.0 <= rsi_value <= 50.0:
        rsi_state = f"RSI {rsi_value:.1f} يؤكد الزخم الهابط"
    elif direction == "شراء" and rsi_value > 70.0:
        base.update({"cross_state": cross_state, "rsi_state": f"RSI {rsi_value:.1f} متطرف شرائياً", "reason": "تقاطع المتوسطات صاعد، لكن RSI في منطقة تشبع شرائي؛ لا تُطارد الحركة."})
        return base
    elif direction == "بيع" and rsi_value < 30.0:
        base.update({"cross_state": cross_state, "rsi_state": f"RSI {rsi_value:.1f} متطرف بيعياً", "reason": "تقاطع المتوسطات هابط، لكن RSI في منطقة تشبع بيعي؛ لا تُطارد الحركة."})
        return base
    else:
        base.update({"cross_state": cross_state, "rsi_state": f"RSI {rsi_value:.1f} متعارض مع الاتجاه", "reason": "تقاطع المتوسطات لا يحظى بتأكيد RSI؛ القرار انتظار حتى يتوافق الزخم."})
        return base
    tools = (technical.get("advanced_tools") or {}).get("tools") or {}
    sr = tools.get("support_resistance") or {}
    levels = sr.get("levels") or {}
    if not sr.get("qualified"):
        base.update({"cross_state": cross_state, "rsi_state": rsi_state, "zone_state": "غير مؤهلة", "reason": "توافق المتوسطات وRSI موجود، لكن لا توجد منطقة دعم/مقاومة مؤهلة لبناء إبطال وهدف."})
        return base
    try:
        atr_value = float(technical.get("atr") or 0.0)
        supports = sorted(float(v) for k, v in levels.items() if str(k).startswith("دعم") and float(v) < latest)
        resistances = sorted(float(v) for k, v in levels.items() if str(k).startswith("مقاومة") and float(v) > latest)
        if direction == "شراء" and not supports: raise ValueError("لا يوجد دعم أسفل السعر")
        if direction == "بيع" and not resistances: raise ValueError("لا توجد مقاومة أعلى السعر")
        zone = supports[-1] if direction == "شراء" else resistances[0]
        stop = zone - .25 * atr_value if direction == "شراء" else zone + .25 * atr_value
        target = resistances[0] if direction == "شراء" and resistances else (supports[-1] if direction == "بيع" and supports else None)
        if target is None: raise ValueError("لا يوجد مستوى مقابل صالح للهدف")
        risk = abs(latest - stop); reward = abs(target - latest)
        rr = round(reward / risk, 2) if risk > 0 else 0.0
        if rr < 1.2:
            base.update({"cross_state": cross_state, "rsi_state": rsi_state, "zone_state": "المساحة غير كافية", "reason": f"توافق المتوسطات وRSI موجود، لكن المسافة إلى المستوى المقابل تعطي عائداً/مخاطرة 1:{rr:.2f} فقط."})
            return base
        adx_row = next((r for r in technical.get("indicators", []) or [] if r.get("name") == "ADX(14)"), {})
        adx_value = float(adx_row.get("value")) if adx_row.get("value") is not None else None
        confidence = 58.0 + (8.0 if adx_value is not None and adx_value >= 25 else 0.0)
        if not quote.get("tradable"): confidence -= 8.0
        base.update({
            "signal": f"{direction} مشروط — تقاطع متوسطات + منطقة",
            "decision_state": "signal", "confidence": round(max(0.0, min(90.0, confidence)), 1),
            "cross_state": cross_state, "rsi_state": rsi_state, "zone_state": f"منطقة {'دعم' if direction == 'شراء' else 'مقاومة'} مرجعية",
            "reason": "لا تُفعل الإشارة إلا مع تراصف EMA20/EMA50 ومنطقة سعرية مؤهلة ومساحة عائد/مخاطرة كافية.",
            "entry": round(latest, 2), "stop_loss": round(stop, 2), "take_profit": round(target, 2),
            "risk_reward": rr, "zone_level": round(zone, 2),
            "evidence": [cross_state, rsi_state, f"المستوى المرجعي: {zone:.2f}", f"ATR: {atr_value:.2f}"],
        })
        if not quote.get("tradable"): base["warnings"].append("طابق المستوى مع Bid/Ask لدى وسيط MT5؛ السعر العام ليس سعر تنفيذ.")
        return base
    except (TypeError, ValueError) as error:
        base.update({"cross_state": cross_state, "rsi_state": rsi_state, "zone_state": "غير مكتملة", "reason": str(error)})
        return base


def momentum_liquidity_news_analysis(technical: dict[str, Any] | None, liquidity: dict[str, Any], news: dict[str, Any]) -> dict[str, Any]:
    """يقيس توافق الزخم مع بنية السيولة ومخاطر الأخبار من البيانات المتاحة فقط."""
    if not technical:
        return {
            "status": "غير متاح",
            "decision_effect": "منع التقييم",
            "confidence_adjustment": 0.0,
            "summary": "لا توجد شموع صالحة لحساب مكونات الزخم.",
            "components": [],
            "limitations": ["لا يمكن قياس الزخم أو بنية السيولة من دون شموع صالحة."],
        }
    indicators = {str(row.get("name")): row for row in technical.get("indicators", [])}
    rsi_value = float(technical.get("rsi", 50.0) or 50.0)
    macd_histogram = float(technical.get("macd_histogram", 0.0) or 0.0)
    roc_value = float(indicators.get("ROC", {}).get("value", 0.0) or 0.0)
    adx_value = float(indicators.get("ADX(14)", {}).get("value", 0.0) or 0.0)
    momentum_score = 0
    momentum_notes: list[str] = []
    if macd_histogram > 0:
        momentum_score += 2
        momentum_notes.append("MACD histogram موجب")
    elif macd_histogram < 0:
        momentum_score -= 2
        momentum_notes.append("MACD histogram سالب")
    if roc_value > 0:
        momentum_score += 1
        momentum_notes.append("ROC موجب")
    elif roc_value < 0:
        momentum_score -= 1
        momentum_notes.append("ROC سالب")
    extended = False
    if 55 <= rsi_value < 70:
        momentum_score += 1
        momentum_notes.append("RSI يدعم الصعود")
    elif 30 < rsi_value <= 45:
        momentum_score -= 1
        momentum_notes.append("RSI يدعم الهبوط")
    elif rsi_value >= 70:
        extended = True
        momentum_notes.append("RSI في تشبع صاعد؛ خطر مطاردة الحركة")
    elif rsi_value <= 30:
        extended = True
        momentum_notes.append("RSI في تشبع هابط؛ خطر مطاردة الحركة")
    momentum_bias = "صاعد" if momentum_score >= 2 else "هابط" if momentum_score <= -2 else "محايد"
    trend_strength = "قوي" if adx_value >= 25 else "ضعيف/عرضي"

    confluence = technical.get("advanced_tools", {}).get("confluence", {})
    liquidity_bias = {"توافق صاعد": "صاعد", "توافق هابط": "هابط"}.get(confluence.get("bias"), "محايد")
    qualified_tools = int(confluence.get("qualified_tools", 0) or 0)
    components = [
        {"name": "الزخم", "bias": momentum_bias, "score": momentum_score, "details": " · ".join(momentum_notes) or "قراءة زخم محايدة"},
        {"name": "قوة الاتجاه", "bias": trend_strength, "score": round(adx_value, 1), "details": f"ADX(14) = {adx_value:.1f}"},
        {"name": "السيولة والبنية", "bias": liquidity_bias, "score": qualified_tools, "details": f"{confluence.get('bias', 'توافق محدود / مختلط')}؛ أدوات مؤهلة: {qualified_tools}"},
        {"name": "الأخبار", "bias": "حظر" if news.get("pending_event") else "غير مكتملة" if news.get("status") == "calendar_ready_no_live_release_feed" else "لا فلتر نشط", "score": 0, "details": news.get("message", "لا توجد حالة أخبار مؤكدة")},
    ]
    limitations: list[str] = []
    if news.get("pending_event"):
        return {
            "status": "فلتر خبر نشط",
            "decision_effect": "منع دخول جديد",
            "confidence_adjustment": -100.0,
            "summary": "خبر عالي الأثر أو نافذة خبر محمية نشطة؛ يُمنع فتح سيناريو جديد حتى زوال الفلتر.",
            "components": components,
            "limitations": ["هذا الفلتر لا يثبت اتجاه الخبر؛ يطبق قاعدة حماية فقط."],
        }
    if liquidity_bias != "محايد" and momentum_bias != "محايد" and liquidity_bias != momentum_bias:
        limitations.append("تعارض الزخم مع بنية السيولة؛ لا تُستخدم أفضلية أحادية الجانب.")
        return {
            "status": "تعارض جوهري",
            "decision_effect": "تحويل إلى حياد",
            "confidence_adjustment": -25.0,
            "summary": f"الزخم {momentum_bias} بينما توافق السيولة {liquidity_bias}؛ أفضل قرار هو انتظار إعادة التوافق.",
            "components": components,
            "limitations": limitations,
        }
    if momentum_bias != "محايد" and momentum_bias == liquidity_bias and qualified_tools >= 2:
        adjustment = 8.0 if trend_strength == "قوي" and not extended else 3.0
        if extended:
            limitations.append("الزخم متوافق لكنه ممتد؛ تُخفّض الثقة وتُتجنب مطاردة السعر.")
        if news.get("status") == "calendar_ready_no_live_release_feed":
            adjustment -= 7.0
            limitations.append("لا توجد تغذية Actual/Forecast حية؛ تُخصم الثقة احترازياً قبل الأخبار المجدولة.")
        return {
            "status": "تأكيد مشروط",
            "decision_effect": "رفع الثقة" if adjustment > 0 else "تأكيد بحذر",
            "confidence_adjustment": adjustment,
            "summary": f"الزخم {momentum_bias} متوافق مع السيولة وبنية السوق؛ لا يزال القرار مشروطاً بالمستويات وبجودة بيانات المصدر.",
            "components": components,
            "limitations": limitations,
        }
    if news.get("status") == "calendar_ready_no_live_release_feed":
        limitations.append("الأخبار المجدولة متاحة وصفياً فقط؛ لا توجد قيم إصدار حية للتحقق من المفاجأة الاقتصادية.")
    if not isinstance(liquidity.get("liquidity_score"), (int, float)):
        limitations.append("لا توجد Bid/Ask أو DOM؛ جانب السيولة مبني على OHLC والمناطق المرصودة.")
    return {
        "status": "توافق محدود",
        "decision_effect": "لا تعديل",
        "confidence_adjustment": -5.0 if limitations else 0.0,
        "summary": "لا يوجد توافق كافٍ بين الزخم والسيولة لرفع الثقة؛ راقب الإغلاق التالي أو منطقة سيولة مؤهلة.",
        "components": components,
        "limitations": limitations,
    }


def build_reference_watch_rows(technical: dict[str, Any] | None, quote: dict[str, Any]) -> list[dict[str, Any]]:
    """يشتق سيناريوهات مراقبة مرجعية من Pivot المكتمل عند غياب اتجاه نهائي."""
    if not technical:
        return []
    try:
        current = float(quote.get("last_price", technical["latest"]))
        pivots = technical.get("pivots", {}).get("traditional", {})
        supports = sorted(float(value) for name, value in pivots.items() if str(name).startswith("S") and float(value) < current)
        resistances = sorted(float(value) for name, value in pivots.items() if str(name).startswith("R") and float(value) > current)
    except (KeyError, TypeError, ValueError):
        return []
    rows: list[dict[str, Any]] = []
    if supports and resistances:
        buy_entry, buy_stop = resistances[0], current
        buy_risk = buy_entry - buy_stop
        buy_target = next((level for level in resistances[1:] if (level - buy_entry) / buy_risk >= 1.2), buy_entry + 1.5 * buy_risk) if buy_risk > 0 else buy_entry
        buy_rr = (buy_target - buy_entry) / buy_risk if buy_risk > 0 else 0.0
        if buy_rr >= 1.2:
            rows.append({
                "scenario_type": "اختراق مقاومة مرجعية",
                "direction": "شراء مشروط",
                "activation": f"إغلاق شمعة مرجعية فوق {buy_entry:.2f}",
                "entry": round(buy_entry, 2), "stop_loss": round(buy_stop, 2),
                "take_profit": round(buy_target, 2), "risk_reward": round(buy_rr, 2),
                "confidence": 42.0, "fit": "مراقب كسر/زخم؛ لا تطارد الشمعة",
                "source_mode": "شموع مرجعية + سعر سوق عام",
            })
        sell_entry, sell_stop = supports[-1], current
        sell_risk = sell_stop - sell_entry
        sell_target = next((level for level in reversed(supports[:-1]) if (sell_entry - level) / sell_risk >= 1.2), sell_entry - 1.5 * sell_risk) if sell_risk > 0 else sell_entry
        sell_rr = (sell_entry - sell_target) / sell_risk if sell_risk > 0 else 0.0
        if sell_rr >= 1.2:
            rows.append({
                "scenario_type": "كسر دعم مرجعي",
                "direction": "بيع مشروط",
                "activation": f"إغلاق شمعة مرجعية تحت {sell_entry:.2f}",
                "entry": round(sell_entry, 2), "stop_loss": round(sell_stop, 2),
                "take_profit": round(sell_target, 2), "risk_reward": round(sell_rr, 2),
                "confidence": 42.0, "fit": "مراقب كسر/زخم؛ لا تدخل قبل التأكيد",
                "source_mode": "شموع مرجعية + سعر سوق عام",
            })
    return rows


def build_scenario_rows(result: dict[str, Any], quote: dict[str, Any], technical: dict[str, Any] | None = None) -> dict[str, Any]:
    """يبني صفوفاً تحليلية مرجعية؛ لا يساوي ذلك اقتباس تنفيذ وسيط."""
    blocked = {
        "status": "محجوب",
        "rows": [],
        "message": "السعر المرجعي متأخر أو غير صالح؛ حُجبت السيناريوهات حتى تصل قراءة حديثة.",
        "basis": "لا تُعرض مستويات تحليلية عند تأخر المصدر أو توقف السوق.",
    }
    if quote.get("status") != "success" or quote.get("stale") or not quote.get("live_for_analysis"):
        return blocked
    if result.get("decision_state") != "signal":
        watch_rows = build_reference_watch_rows(technical, quote)
        if watch_rows:
            return {
                "status": "مراقبة مرجعية",
                "rows": watch_rows,
                "message": "لا يوجد اتجاه نهائي مكتمل؛ هذه سيناريوهات مراقبة مشروطة بتأكيد الإغلاق عند نقاط الارتكاز.",
                "basis": "سعر سوق عام حديث + شموع مرجعية مكتملة + نقاط ارتكاز تقليدية + عائد/مخاطرة متماسك.",
            }
        return {
            "status": "انتظار",
            "rows": [],
            "message": result.get("reason", "لا يوجد سيناريو مؤهل حالياً."),
            "basis": "لم تجتز حواجز الاتجاه أو الزخم أو الخبر أو بنية السوق.",
        }
    entry, stop, target, rr = (result.get("entry"), result.get("stop_loss"), result.get("take_profit"), result.get("risk_reward"))
    if not all(isinstance(value, (int, float)) for value in (entry, stop, target, rr)) or float(rr) < 1.2:
        return {
            "status": "انتظار",
            "rows": [],
            "message": "مستويات السيناريو غير مكتملة أو لا تحقق عائداً/مخاطرة منطقياً.",
            "basis": "لا تُملأ خلايا الجدول عند فشل حارس المستويات.",
        }
    direction = "شراء" if "شراء" in str(result.get("signal", "")) else "بيع" if "بيع" in str(result.get("signal", "")) else "محايد"
    scenario_type = "منطقة Order Block + FVG" if result.get("strategy_basis") else "سيناريو اتجاه + مناطق"
    activation = "إغلاق مرجعي/تأكيد صاعد عند المستوى" if direction == "شراء" else "رفض مرجعي/تأكيد هابط عند المستوى"
    broker_quote = quote.get("broker_quote_eligible") is True
    return {
        "status": "مؤهل للتقييم" if broker_quote else "مرجعي مؤهل",
        "rows": [{
            "scenario_type": scenario_type,
            "direction": direction,
            "activation": activation,
            "entry": round(float(entry), 2),
            "stop_loss": round(float(stop), 2),
            "take_profit": round(float(target), 2),
            "risk_reward": round(float(rr), 2),
            "confidence": round(float(result.get("confidence", 0.0)), 1),
            "fit": "تقييم مرجعي؛ طابقه مع وسيطك" if not broker_quote else "بعد مطابقة Bid/Ask والسبريد",
            "source_mode": "سعر وسيط للقراءة فقط" if broker_quote else "شموع مرجعية + سعر سوق عام",
        }],
        "message": "المستويات تحليلية ومشروطة؛ راقب التفعيل وطابق السعر والسبريد مع وسيطك قبل أي تنفيذ.",
        "basis": ("Bid/Ask وسيط حديث + الاتجاه + الزخم + بنية السوق + العائد/المخاطرة." if broker_quote else "سعر سوق عام حديث + شموع مرجعية + الاتجاه + الزخم + بنية السوق + العائد/المخاطرة."),
    }


def integrated_recommendation(quote: dict[str, Any], technical: dict[str, Any] | None, liquidity: dict[str, Any], news: dict[str, Any], order_flow: dict[str, Any] | None = None, ob_fvg_setup: dict[str, Any] | None = None) -> dict[str, Any]:
    """يربط توصية القواعد بمقياس الزخم/السيولة/الأخبار دون ادعاء بيانات تنفيذ."""
    result = deepcopy(make_recommendation(quote, technical, liquidity, news))
    result["intraday_recommendation"] = make_intraday_recommendation(quote, technical)
    setup = deepcopy(ob_fvg_setup or {"status": "غير متاح", "qualified": False, "reason": "لم تُحسب استراتيجية المنطقة بعد."})
    result["ob_fvg_strategy"] = setup
    interaction = momentum_liquidity_news_analysis(technical, liquidity, news)
    result["momentum_liquidity_news"] = interaction
    flow = deepcopy(order_flow or {"status": "غير متاح", "eligible_for_decision": False, "message": "لا توجد تغذية تدفق موثقة."})
    result["real_order_flow"] = flow
    if result.get("decision_state") == "signal":
        effect = interaction.get("decision_effect")
        if effect in {"منع دخول جديد", "تحويل إلى حياد"}:
            result.update({
                "signal": "انتظار / لا دخول" if effect == "منع دخول جديد" else "انتظار / حياد",
                "reason": interaction["summary"],
                "confidence": 0.0,
                "entry": None,
                "stop_loss": None,
                "take_profit": None,
                "risk_reward": None,
                "decision_state": "neutral",
            })
        else:
            result["confidence"] = round(max(0.0, min(90.0, float(result.get("confidence", 0.0)) + float(interaction.get("confidence_adjustment", 0.0)))), 1)
    if result.get("decision_state") == "signal" and flow.get("eligible_for_decision") is True:
        direction = "شراء" if "شراء" in str(result.get("signal")) else "بيع" if "بيع" in str(result.get("signal")) else "محايد"
        flow_bias = flow.get("bias", "محايد")
        if flow_bias in {"شراء", "بيع"} and flow_bias != direction:
            result.update({
                "signal": "انتظار / حياد",
                "reason": "تدفق السيولة الحقيقي من Bid/Ask وDOM والصفقات يتعارض مع اتجاه السيناريو؛ يُحجب الدخول حتى يظهر توافق.",
                "confidence": 0.0,
                "entry": None,
                "stop_loss": None,
                "take_profit": None,
                "risk_reward": None,
                "decision_state": "neutral",
            })
        elif flow_bias == direction:
            boost = min(7.0, max(0.0, float(flow.get("confidence", 0.0)) - 50.0) / 5.0)
            result["confidence"] = round(min(90.0, float(result.get("confidence", 0.0)) + boost), 1)
    if result.get("decision_state") == "signal" and setup.get("qualified"):
        strategy_direction = str(setup.get("direction", "محايد"))
        base_direction = "شراء" if "شراء" in str(result.get("signal")) else "بيع" if "بيع" in str(result.get("signal")) else "محايد"
        if strategy_direction != base_direction:
            result.update({
                "signal": "انتظار / حياد",
                "reason": "اتجاه توصية المؤشرات لا يطابق منطقة Order Block + FVG المؤهلة؛ يُحجب الدخول حتى يتوافق الاتجاهان.",
                "confidence": 0.0,
                "entry": None,
                "stop_loss": None,
                "take_profit": None,
                "risk_reward": None,
                "decision_state": "neutral",
            })
        else:
            result.update({
                "signal": f"{strategy_direction} مشروط — منطقة OB + FVG",
                "reason": setup.get("reason", "منطقة تحليلية مركبة مؤهلة."),
                "confidence": round(min(90.0, (float(result.get("confidence", 0.0)) + float(setup.get("confidence", 0.0))) / 2), 1),
                "entry": setup.get("entry"),
                "entry_zone": setup.get("entry_zone"),
                "stop_loss": setup.get("stop_loss"),
                "take_profit": setup.get("take_profit"),
                "risk_reward": setup.get("risk_reward"),
                "strategy_basis": "Order Block + Fair Value Gap متداخلان",
            })
    result["scenario_table"] = build_scenario_rows(result, quote, technical)
    result["scenario_contract"] = build_scenario_contract(result, technical, news)
    result["scenario_type"] = result["scenario_contract"]["scenario_type"]
    # الرقم السابق كان ناتج عد مؤشرات متداخلة، لا Probability Calibration. لا يعرض كمستوى ثقة.
    result["confidence"] = None
    result["confidence_status"] = "غير معاير — لا يفسر كاحتمال نجاح"
    result["evidence_strength"] = (technical or {}).get("evidence_strength", {"score": 0, "label": "غير متاح", "is_probability": False})
    return result


def build_scenario_contract(result: dict[str, Any], technical: dict[str, Any] | None, news: dict[str, Any]) -> dict[str, Any]:
    """يوحد مخرجات القرار في سيناريو قابل للتدقيق، لا في BUY/SELL مختصرة."""
    technical = technical or {}
    families = technical.get("evidence_families", {})
    multi = technical.get("advanced_tools", {}).get("multi_timeframe", {})
    structure = technical.get("advanced_tools", {}).get("confluence", {})
    signal = str(result.get("signal", ""))
    state = result.get("decision_state")
    if state == "signal" and "شراء" in signal:
        scenario_type = "BULLISH_SCENARIO"
    elif state == "signal" and "بيع" in signal:
        scenario_type = "BEARISH_SCENARIO"
    elif state == "neutral" and (families.get("decision_bias") in {"صاعد", "هابط"}):
        scenario_type = "CONDITIONAL"
    else:
        scenario_type = "NO_TRADE"
    current = technical.get("latest")
    data_context = result.get("data_context") or decision_data_context_from_contract({}, technical.get("data_contract"), technical.get("data_quality"))
    return {
        "scenario_type": scenario_type,
        "htf_bias": multi.get("status", "غير متاح"),
        "market_regime": (technical.get("indicator_combinations") or [{"status": "غير متاح"}])[0].get("status", "غير متاح"),
        "structure": structure.get("details", structure.get("bias", "غير متاح")),
        "location": {"reference_price": current, "entry_zone": result.get("entry_zone"), "data_context_compatible": bool(data_context.get("compatible_for_price_levels"))},
        "trigger": "إغلاق شمعة الإطار بعد تحقق عائلات الأدلة ومستوى التفعيل." if scenario_type in {"BULLISH_SCENARIO", "BEARISH_SCENARIO"} else "لا يوجد تفعيل؛ يلزم زوال سبب الحجب أو اكتمال الشرط.",
        "invalidation": result.get("reason") if scenario_type in {"NO_TRADE", "CONDITIONAL"} else f"إبطال تحليلي عند بلوغ {result.get('stop_loss')} على مصدر متوافق.",
        "targets": [result.get("take_profit")] if result.get("take_profit") is not None else [],
        "risk_reward": result.get("risk_reward"),
        "evidence": families,
        "data_quality": data_context,
        "news_risk": {"status": news.get("status"), "pending_event": bool(news.get("pending_event")), "message": "لا تستخدم مفاجأة خبرية حية من دون Actual/Forecast موثقين."},
        "probability": None,
        "evidence_strength": technical.get("evidence_strength", {"score": 0, "is_probability": False}),
    }


def make_order_flow_context() -> dict[str, Any]:
    """يبقي تدفق السيولة مستقلاً عن الشموع ولا ينشئ قيماً بديلة عند فشل المصدر."""
    try:
        return connector.fetch_order_flow()
    except Exception as error:
        return {
            "status": "غير متاح",
            "eligible_for_decision": False,
            "source": "جسر تدفق السيولة",
            "message": f"تعذر التحقق من تدفق السيولة: {error}",
            "requirements": ["Bid/Ask حديثان", "Depth of Market", "صفقات أو أحجام شراء/بيع فعلية"],
        }


STRATEGY_TESTS: dict[str, dict[str, str]] = {
    "liquidity_confluence": {"title": "توافق سيولة صاعد", "description": "يفحص أن توافق المؤشرات وبنية السوق والإطار الأعلى مع مستويات مؤهلة يتيح سيناريو شراء مشروط."},
    "high_impact_news": {"title": "خبر عالي الأثر", "description": "يفحص أن فلتر خبر عالي الأثر يمنع فتح سيناريو جديد حتى لو بدت المؤشرات إيجابية."},
    "conflicting_evidence": {"title": "تعارض الأدلة", "description": "يفحص أن تعارض اتجاه المؤشرات مع بنية السيولة ينتج قرار حياد/انتظار بدلاً من صفقة."},
}


def run_strategy_test(test_id: str, timeframe_id: str) -> dict[str, Any]:
    """يشغل حالة اختبار معزولة؛ لا يغير حالة السوق ولا ينشئ توصية حية."""
    if test_id not in STRATEGY_TESTS:
        raise ValueError("سيناريو اختبار غير مدعوم")
    analysis = get_timeframe_analysis(timeframe_id)
    technical = analysis.get("technical")
    if technical is None:
        return {"test_id": test_id, "test": STRATEGY_TESTS[test_id], "result": {"signal": "تعذر الاختبار", "decision_state": "blocked", "reason": "لا توجد شموع صالحة في الإطار المختار.", "confidence": 0.0}, "test_scope": "لم تُستبدل بيانات الإطار المختار بإطار آخر."}
    with state_lock:
        quote, liquidity, news = deepcopy(state["quote"]), deepcopy(state["liquidity"]), deepcopy(state["news"])
    tested = deepcopy(technical)
    advanced_tools = tested.setdefault("advanced_tools", {})
    confluence = advanced_tools.setdefault("confluence", {})
    multi_timeframe = advanced_tools.setdefault("multi_timeframe", {})
    tools = advanced_tools.setdefault("tools", {})
    support_resistance = tools.setdefault("support_resistance", {})
    levels = support_resistance.setdefault("levels", {})
    quote.update({"status": "success", "stale": False, "live_for_analysis": True, "tradable": False})
    if test_id == "liquidity_confluence":
        tested["technical_signal"] = "شراء"
        tested["technical_confidence"] = max(float(tested.get("technical_confidence", 0.0)), 72.0)
        confluence.update({"bias": "توافق صاعد", "qualified_tools": 6})
        multi_timeframe.update({"status": "متوافق"})
        support_resistance["qualified"] = True
        anchor = float(tested["latest"])
        levels.update({"دعم الاختبار": round(anchor * 0.994, 2), "مقاومة الاختبار": round(anchor * 1.012, 2)})
        liquidity.update({"trap_detected": False, "liquidity_score": 78, "liquidity_status": "اختبار توافق سيولة"})
        news["pending_event"] = False
    elif test_id == "high_impact_news":
        news.update({"pending_event": True, "status": "اختبار: خبر عالي الأثر", "message": "محاكاة فلتر خبر عالي الأثر؛ لا يوجد خبر حي مضاف في هذا الاختبار."})
    else:
        tested["technical_signal"] = "شراء"
        confluence.update({"bias": "توافق هابط", "qualified_tools": 5})
        multi_timeframe.update({"status": "متعارض"})
        support_resistance["qualified"] = True
        news["pending_event"] = False
    result = integrated_recommendation(quote, tested, liquidity, news)
    return {
        "test_id": test_id,
        "timeframe": {key: analysis.get(key) for key in ("id", "label", "updated_at")},
        "test": STRATEGY_TESTS[test_id],
        "result": result,
        "test_scope": "اختبار لقواعد الحماية والتوافق باستخدام لقطة شموع الإطار المختار. لا يغير التوصية الحية، ولا يضيف خبراً فعلياً أو Bid/Ask أو DOM.",
    }


def refresh_quote_state() -> dict[str, Any]:
    """يحدّث السعر منفصلاً عن شموع Yahoo وحساب المؤشرات البطيء."""
    candidate = market_data.live_price()
    with state_lock:
        previous = deepcopy(state.get("quote", {}))
        prior_goldapi = deepcopy(state.get("last_valid_goldapi_quote") or {})
        if candidate.get("status") != "success" and previous.get("status") == "success":
            # لا نعيد قيمة سابقة كسعر حي بعد تعذر التجديد؛ نحتفظ بها للتدقيق فقط ونحجبها من العرض.
            quote = previous
            quote.update({
                "stale": True,
                "live_for_analysis": False,
                "data_quality": "refresh_failed_stale",
                "message": f"تعذر تجديد السعر من المصدر؛ حُجب آخر سعر موثق من العرض الحي. السبب: {candidate.get('message', 'غير معروف')}",
            })
        else:
            quote = candidate
        is_fresh_goldapi = (
            quote.get("status") == "success"
            and not quote.get("stale")
            and quote.get("live_for_analysis") is True
            and str(quote.get("source", "")).startswith("gold-api.com")
        )
        if is_fresh_goldapi:
            try:
                current_price = float(quote["last_price"])
                previous_price = float(prior_goldapi["last_price"])
                delta = current_price - previous_price
                change_pct = delta / previous_price * 100 if previous_price else 0.0
                direction = "up" if delta > 0 else "down" if delta < 0 else "flat"
                quote.update({
                    "previous_price": round(previous_price, 2),
                    "tick_change": round(delta, 2),
                    "tick_change_pct": round(change_pct, 4),
                    "price_direction": direction,
                    "price_direction_label": "ارتفع عن القراءة السابقة" if direction == "up" else "انخفض عن القراءة السابقة" if direction == "down" else "دون تغير عن القراءة السابقة",
                })
            except (KeyError, TypeError, ValueError):
                quote.update({
                    "previous_price": None,
                    "tick_change": None,
                    "tick_change_pct": None,
                    "price_direction": "neutral",
                    "price_direction_label": "بانتظار قراءة gold-api.com سابقة للمقارنة",
                })
            state["last_valid_goldapi_quote"] = deepcopy(quote)
        else:
            quote.update({
                "previous_price": None,
                "tick_change": None,
                "tick_change_pct": None,
                "price_direction": "neutral",
                "price_direction_label": "لا مقارنة اتجاهية عند تأخر المصدر أو غياب قراءة gold-api.com حديثة",
            })
        state["quote"] = quote
        state["status"] = quote_status_label(quote)
        state["last_quote_refresh"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        state["quote_revision"] = int(state.get("quote_revision", 0)) + 1
    return quote


def quote_status_label(quote: dict[str, Any]) -> str:
    """يوحد وسم الحالة مع مصدر Quote الفعلي حتى لا تتأخر واجهة السعر عن عامل التحديث."""
    if quote.get("status") != "success":
        if quote.get("error_code") == "goldapi_quota_exceeded":
            return "تحذير: حصة GoldAPI الشهرية انتهت — لا يوجد سعر حي"
        if quote.get("error_code") == "goldapi_auth_failed":
            return "تحذير: مفتاح GoldAPI غير مقبول — لا يوجد سعر حي"
        return "تحذير: مصدر السعر غير متاح"
    if quote.get("stale") or not quote.get("live_for_analysis"):
        return "السوق مغلق أو السعر المرجعي متأخر — لا يوجد سعر حي"
    if quote.get("broker_quote_eligible"):
        return "يعمل — سعر وسيط MT5 حديث للقراءة والتحليل فقط"
    return "يعمل — سعر سوق عام حديث للتحليل والرسم البياني"


def market_archive_status() -> dict[str, Any]:
    """تعرض حالة أرشيف القراءة فقط دون إدراج قاعدة البيانات أو أي بيانات سرية في الواجهة."""
    if market_archive is None:
        return {
            "enabled": False,
            "status": "غير متاح",
            "message": f"تعذر تهيئة أرشيف السعر المرجعي: {market_archive_initialization_error or 'سبب غير معروف'}",
        }
    try:
        result = market_archive.status()
        result["status"] = result.get("state", {}).get("latest_status", "NOT_STARTED")
        return result
    except Exception as error:
        return {"enabled": False, "status": "ERROR", "message": f"تعذر قراءة حالة الأرشيف: {error}"}


def get_spot_futures_comparison() -> dict[str, Any]:
    """يعيد مقارنة مرجعية مخزنة مؤقتاً كي لا يضغط تحديث الواجهة على مصدر Yahoo."""
    now = time.monotonic()
    with spot_futures_cache_lock:
        cached = spot_futures_cache.get("value")
        if cached is not None and now < float(spot_futures_cache.get("expires_at", 0.0)):
            return deepcopy(cached)
    comparison = connector.fetch_spot_futures_comparison()
    with spot_futures_cache_lock:
        spot_futures_cache["value"] = deepcopy(comparison)
        spot_futures_cache["expires_at"] = now + SPOT_FUTURES_CACHE_SECONDS
    return comparison


def refresh_state() -> None:
    with state_lock:
        quote = deepcopy(state.get("quote", {}))
    if quote.get("status") in {None, "pending"}:
        quote = refresh_quote_state()
    analyses = {timeframe_id: get_timeframe_analysis(timeframe_id) for timeframe_id in TIMEFRAME_IDS}
    for index in range(len(TIMEFRAME_IDS) - 2, -1, -1):
        add_higher_timeframe_context(analyses[TIMEFRAME_IDS[index]], analyses[TIMEFRAME_IDS[index + 1]])
    default_analysis = analyses[DEFAULT_TIMEFRAME_ID]
    technical = default_analysis.get("technical")
    if technical is None:
        print(f"تعذر حساب مؤشرات الإطار اليومي: {default_analysis.get('error')}")

    if quote.get("status") == "success" and quote.get("spread") is not None:
        liquidity = liquidity_engine.analyze_liquidity(
            current_price=float(quote["last_price"]),
            spread=float(quote["spread"]),
            volume_profile="Unavailable without DOM",
        )
    else:
        liquidity = {
            "liquidity_status": "غير متاح: يحتاج Bid/Ask وDepth of Market من MT5",
            "trap_detected": False,
            "liquidity_score": None,
            "alerts": ["لا يتم تقييم السيولة اللحظية من مصدر لا يقدم Bid/Ask حقيقيين."],
        }

    news = make_news_context()
    order_flow = make_order_flow_context()
    institutional = make_institutional_context()
    spot_futures_comparison = get_spot_futures_comparison()
    external_reference = make_external_reference_context(quote, spot_futures_comparison)
    recommendation = integrated_recommendation(quote, technical, liquidity, news, order_flow, default_analysis.get("ob_fvg_strategy"))
    data_transparency = build_data_transparency(quote, technical)
    archive_status = market_archive_status()
    timeframes = [make_timeframe_card(analyses[timeframe_id]) for timeframe_id in TIMEFRAME_IDS]
    refreshed = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    status_label = quote_status_label(quote)
    with state_lock:
        state.update({
            "status": status_label,
            "last_refresh": refreshed,
            "technical": technical,
            "signal_layers": default_analysis.get("signal_layers", build_signal_layers(technical)),
            "default_timeframe_id": DEFAULT_TIMEFRAME_ID,
            "timeframes": timeframes,
            "liquidity": liquidity,
            "news": news,
            "order_flow": order_flow,
            "institutional": institutional,
            "external_reference": external_reference,
            "data_transparency": data_transparency,
            "market_archive": archive_status,
            "recommendation": recommendation,
        })


def worker() -> None:
    while True:
        try:
            refresh_state()
        except Exception as error:
            with state_lock:
                state["status"] = f"خطأ: {error}"
            print(f"خطأ في تحديث النظام: {error}")
        time.sleep(30)


def timeframe_cards_with_fallback(current: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """يعيد جميع بطاقات الأطر فوراً حتى إذا كان التحديث الخلفي لم يكتمل بعد.

    لا يستدعي هذا المسار Yahoo ولا يبدأ حساباً جديداً؛ يعرض فقط تحليل الإطار
    المخبأ إن كان موجوداً، أو بطاقة انتظار معلنة. وبذلك لا تختفي بطاقة 4 ساعات
    أو بقية الأطر من الهاتف خلال بداية تشغيل الخادم أو تحديث ثقيل.
    """
    with timeframe_cache_lock:
        cached = {key: deepcopy(value.get("payload", {})) for key, value in timeframe_cache.items()}
    existing = {row.get("id"): row for row in current.get("timeframes", []) if row.get("id")}
    cards: list[dict[str, Any]] = []
    for timeframe_id in TIMEFRAME_IDS:
        if timeframe_id in existing:
            cards.append(existing[timeframe_id])
            continue
        analysis = cached.get(timeframe_id)
        if analysis:
            cards.append(make_timeframe_card(analysis))
            continue
        cards.append({
            "id": timeframe_id,
            "label": TIMEFRAME_CONFIGS[timeframe_id]["label"],
            "action": "جارِ التحليل",
            "score": None,
            "confidence": 0.0,
            "last_candle_time": None,
            "error": None,
        })
    return cards, cached.get(DEFAULT_TIMEFRAME_ID)


def quote_worker() -> None:
    """يحدّث السعر العام وفق حد التخزين المؤقت للمزود وباستقلال عن تحليل الشموع."""
    while True:
        try:
            refresh_quote_state()
        except Exception as error:
            print(f"خطأ في تحديث السعر السريع: {error}")
        time.sleep(max(30.0, float(getenv("LIVE_QUOTE_REFRESH_SECONDS", "30"))))


@app.get("/api/system-status")
def system_status():
    with state_lock:
        payload = deepcopy(state)
    cards, default_analysis = timeframe_cards_with_fallback(payload)
    payload["timeframes"] = cards
    payload["default_timeframe_id"] = DEFAULT_TIMEFRAME_ID
    if payload.get("technical") is None and default_analysis:
        payload["technical"] = default_analysis.get("technical")
        payload["signal_layers"] = default_analysis.get("signal_layers", payload.get("signal_layers"))
    return jsonify(payload)


def quote_stream_event() -> dict[str, Any]:
    """حمولة SSE مقتصرة على حالة السعر؛ لا تعيد الشموع أو التحليل الثقيل."""
    with state_lock:
        quote = deepcopy(state.get("quote", {}))
        return {
            "revision": int(state.get("quote_revision", 0)),
            "quote": quote,
            "last_quote_refresh": state.get("last_quote_refresh"),
            "refresh_policy": deepcopy(state.get("quote_refresh_policy", {})),
        }


@app.get("/api/quote")
def quote_status():
    """لقطة سعر صغيرة لبديل المتصفحات التي لا تدعم SSE."""
    return jsonify(quote_stream_event())


@app.get("/api/market-archive-status")
def archive_status_endpoint():
    """حالة الأرشيف الدائم؛ لا تفتح أي مسار كتابة أو أوامر تداول."""
    return jsonify(market_archive_status())


@app.get("/api/quote-stream")
def quote_stream():
    """يبث تغيرات الحالة المخزنة فقط؛ مصدر Gold API يظل مجدولاً وفق سياسة 30 ثانية."""
    @stream_with_context
    def events():
        last_revision = -1
        yield "retry: 5000\n\n"
        while True:
            payload = quote_stream_event()
            revision = int(payload["revision"])
            if revision != last_revision:
                last_revision = revision
                yield f"event: quote\ndata: {json.dumps(payload, ensure_ascii=False, separators=(',', ':'))}\n\n"
            else:
                yield ": keepalive\n\n"
            time.sleep(1)
    return Response(events(), mimetype="text/event-stream", headers={"Cache-Control": "no-cache, no-transform", "X-Accel-Buffering": "no"})


@app.get("/sw.js")
def service_worker():
    """يكاش واجهة القراءة فقط؛ بيانات السعر والشموع تبقى دائماً network-only."""
    script = """
const CACHE_NAME = 'xauusd-ui-v1';
const APP_SHELL = ['/'];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  event.respondWith(fetch(request).then(response => {
    if (response.ok && response.type === 'basic') caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
    return response;
  }).catch(() => caches.match(request)));
});
""".strip()
    return Response(script, mimetype="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/api/timeframe/<timeframe_id>")
def timeframe_status(timeframe_id: str):
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار زمني غير مدعوم"}), 400
    analysis = get_timeframe_analysis(timeframe_id)
    position = TIMEFRAME_IDS.index(timeframe_id)
    if position < len(TIMEFRAME_IDS) - 1:
        add_higher_timeframe_context(analysis, get_timeframe_analysis(TIMEFRAME_IDS[position + 1]))
    else:
        add_higher_timeframe_context(analysis, None)
    with state_lock:
        quote = state["quote"]
        liquidity = state["liquidity"]
        news = state["news"]
        order_flow = state["order_flow"]
    return jsonify({
        "timeframe": analysis,
        "recommendation": integrated_recommendation(quote, analysis.get("technical"), liquidity, news, order_flow, analysis.get("ob_fvg_strategy")),
        "data_transparency": build_data_transparency(quote, analysis.get("technical")),
    })


@app.get("/api/chart/<timeframe_id>")
def chart_data(timeframe_id: str):
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار زمني غير مدعوم"}), 400
    return jsonify(make_chart_payload(timeframe_id))


@app.get("/api/ai-analysis/<timeframe_id>")
def ai_analysis(timeframe_id: str):
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار زمني غير مدعوم"}), 400
    analysis = get_timeframe_analysis(timeframe_id)
    position = TIMEFRAME_IDS.index(timeframe_id)
    if position < len(TIMEFRAME_IDS) - 1:
        add_higher_timeframe_context(analysis, get_timeframe_analysis(TIMEFRAME_IDS[position + 1]))
    with state_lock:
        quote, news = state["quote"], state["news"]
    return jsonify(build_ai_analysis(quote, analysis.get("technical"), news, analysis))


def allow_chart_image_analysis(remote_address: str | None) -> bool:
    """حد بسيط لمنع إغراق واجهة الرؤية؛ لا يعتمد على بيانات الصورة أو يخزنها."""
    client_key = remote_address or "unknown"
    now = time.monotonic()
    with image_analysis_rate_lock:
        requests_for_client = image_analysis_requests[client_key]
        while requests_for_client and now - requests_for_client[0] > IMAGE_ANALYSIS_WINDOW_SECONDS:
            requests_for_client.popleft()
        if len(requests_for_client) >= IMAGE_ANALYSIS_MAX_REQUESTS:
            return False
        requests_for_client.append(now)
        return True


@app.post("/api/chart-image-analysis")
def chart_image_analysis():
    """يعالج لقطة بالذاكرة فقط في وضع منصة أو وضع رؤية AI؛ لا ينشئ مسار تداول أو كتابة دائمة."""
    uploaded = request.files.get("image")
    if uploaded is None:
        return jsonify({"error": "أرفق صورة PNG أو JPG أو WEBP للرسم أولاً."}), 400
    try:
        image = validate_chart_image(uploaded.read())
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    mode = str(request.form.get("mode", "platform")).strip().lower()
    timeframe_id = str(request.form.get("timeframe", DEFAULT_TIMEFRAME_ID)).strip()
    if mode not in {"platform", "ai", "combined"}:
        return jsonify({"error": "وضع التحليل غير مدعوم."}), 400
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار التحليل غير مدعوم."}), 400
    if mode != "platform" and not allow_chart_image_analysis(request.remote_addr):
        return jsonify({"error": "وصلت إلى حد تحليلات الصور المؤقت. انتظر بضع دقائق ثم أعد المحاولة."}), 429
    analysis = get_timeframe_analysis(timeframe_id)
    with state_lock:
        quote = deepcopy(state.get("quote", {}))
        news = deepcopy(state.get("news", {}))
    platform = build_platform_image_analysis(image=image, timeframe=analysis, quote=quote, news=news)
    if mode == "platform":
        return jsonify(platform)
    provider_id = str(request.form.get("provider", "gemini")).strip().lower()
    visual = analyze_chart_image_ai(
        image=image,
        user_timeframe=TIMEFRAME_CONFIGS[timeframe_id]["label"],
        provider_id=provider_id,
    )
    if mode == "combined":
        return jsonify(build_combined_chart_image_analysis(platform=platform, visual=visual))
    return jsonify(visual)


@app.get("/api/chart-ai-providers")
def chart_ai_providers():
    """قائمة قدرات واجهة AI؛ لا تكشف المفاتيح ولا توحي باتصال مزود لم يُهيأ."""
    return jsonify({"providers": available_chart_ai_providers()})


@app.get("/api/strategy-test/<test_id>/<timeframe_id>")
def strategy_test(test_id: str, timeframe_id: str):
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار زمني غير مدعوم"}), 400
    try:
        return jsonify(run_strategy_test(test_id, timeframe_id))
    except ValueError as error:
        return jsonify({"error": str(error)}), 400


def parse_backtest_costs() -> CostModel:
    """خيارات بحث افتراضية ومحكومة؛ لا تستبدل بيانات Bid/Ask للوسيط."""
    def bounded(name: str, default: float, maximum: float) -> float:
        raw = request.args.get(name, default)
        try:
            value = float(raw)
        except (TypeError, ValueError) as error:
            raise ValueError(f"قيمة {name} يجب أن تكون رقماً") from error
        if not 0 <= value <= maximum:
            raise ValueError(f"قيمة {name} يجب أن تقع بين 0 و{maximum}")
        return value
    return CostModel(
        spread_price=bounded("spread", 0.30, 10.0),
        slippage_price_each_side=bounded("slippage", 0.05, 5.0),
        commission_price_round_turn=bounded("commission", 0.00, 10.0),
    )


def get_ob_fvg_backtest(timeframe_id: str, costs: CostModel) -> dict[str, Any]:
    """يخزن الاختبار مؤقتاً لأنه يمر على قرارات تاريخية كثيرة ولا يعاد لكل نقرة."""
    now = time.time()
    cache_key = f"{timeframe_id}:{costs.spread_price:.6f}:{costs.slippage_price_each_side:.6f}:{costs.commission_price_round_turn:.6f}"
    with strategy_backtest_cache_lock:
        cached = strategy_backtest_cache.get(cache_key)
        if cached and now - cached["cached_at_epoch"] < 900:
            return cached["payload"]
    candles = get_timeframe_candles(timeframe_id)
    payload = {
        "strategy": "Order Block + Fair Value Gap",
        "timeframe": {"id": timeframe_id, "label": TIMEFRAME_CONFIGS[timeframe_id]["label"]},
        "as_of": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "cost_model": costs.as_dict(),
        "result": backtest_ob_fvg_strategy(candles, costs=costs),
    }
    with strategy_backtest_cache_lock:
        strategy_backtest_cache[cache_key] = {"cached_at_epoch": now, "payload": payload}
    return payload


@app.get("/api/strategy-backtest/ob-fvg/<timeframe_id>")
def ob_fvg_backtest(timeframe_id: str):
    if timeframe_id not in TIMEFRAME_CONFIGS:
        return jsonify({"error": "إطار زمني غير مدعوم"}), 400
    try:
        return jsonify(get_ob_fvg_backtest(timeframe_id, parse_backtest_costs()))
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    except Exception as error:
        return jsonify({"error": f"تعذر تنفيذ الاختبار التاريخي: {error}"}), 500


@app.get("/api/health")
def health():
    with state_lock:
        return jsonify({"status": state["status"], "last_refresh": state["last_refresh"]})


HTML = r'''<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>XAUUSD — التحليل التقني الشامل</title>
	<style>
		.chartImagePanel{padding:13px}.chartImageIntro{margin:0 0 11px;color:var(--muted);font-size:12px;line-height:1.7}.chartImageDrop{display:grid;place-items:center;gap:6px;min-height:106px;padding:14px;border:1px dashed #4b7187;border-radius:9px;background:#111c27;color:#cfe7f3;text-align:center;cursor:pointer;transition:border-color 160ms ease,background 160ms ease}.chartImageDrop:hover,.chartImageDrop:focus-within{border-color:#e0ad44;background:#1a2631}.chartImageDrop b{font-size:14px}.chartImageDrop span{font-size:11px;color:var(--muted)}.chartImageDrop input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.chartImagePreview{display:block;width:100%;max-height:250px;object-fit:contain;background:#070c12;border:1px solid #263747;border-radius:8px;margin-top:10px}.chartImagePreview[hidden]{display:none}.chartImageModes{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}.chartImageMode{min-width:0;min-height:48px;border:1px solid #344a5a;border-radius:7px;background:#192532;color:#c5d0dc;font:700 12px Tahoma,Arial;line-height:1.35;cursor:pointer;padding:7px}.chartImageMode.active{border-color:#e0ad44;background:#3b331e;color:#ffe7ae}.chartImageMode small{display:block;color:inherit;opacity:.78;font-weight:400;font-size:10px;margin-top:3px}.chartImageRun{width:100%;margin-top:9px;border:1px solid #599bbe;border-radius:7px;background:#17455c;color:#e6f7ff;min-height:42px;font:800 13px Tahoma,Arial;cursor:pointer}.chartImageRun:disabled{opacity:.6;cursor:wait}.chartImageResult{margin-top:11px;border-top:1px solid #2b3d4d;padding-top:11px}.chartImageResult .toolLevels{max-height:154px;overflow:auto}.chartImageScope{margin-top:9px;padding:9px;border-radius:6px;background:#101923;color:#aebcca;font-size:10px;line-height:1.7}.chartImageResultTitle{display:flex;gap:8px;align-items:start;justify-content:space-between}.chartImageResultTitle b{font-size:14px}.chartImageNotice{font-size:11px;color:#f1cf7a;line-height:1.7;margin-top:8px}@media(max-width:360px){.chartImageModes{grid-template-columns:1fr}.chartImagePreview{max-height:205px}}
		:root{color-scheme:dark;--bg:#0d1219;--panel:#151c26;--panel2:#1b2430;--line:#2b3543;--text:#f4f7fb;--muted:#9ba7b8;--green:#72c36a;--greenBg:#17361d;--red:#de7d80;--redBg:#3c2025;--neutral:#b7bbc2;--blue:#42a5f5;--amber:#e0ad44}
		*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#080c11;color:var(--text);font-family:Tahoma,"Noto Sans Arabic",Arial,sans-serif;font-size:15px}.app{max-width:520px;margin:0 auto;background:var(--bg);min-height:100vh;box-shadow:0 0 40px #0008}.topbar{display:flex;align-items:center;justify-content:space-between;padding:16px 18px 9px;background:#0d1219}.instrument{font-size:25px;font-weight:700}.meta{font-size:12px;color:var(--muted);margin-top:4px}.icon{color:#a8b1bf;font-size:24px}.quote{padding:4px 18px 18px;background:#0d1219;border-bottom:1px solid var(--line)}.quoteLine{display:flex;align-items:baseline;gap:12px;direction:ltr;justify-content:flex-start}.price{font-size:39px;font-weight:800;letter-spacing:-1px}.change{font-size:21px;color:var(--green);font-weight:700}.priceDirection{display:inline-flex;align-items:center;gap:5px;border-radius:999px;padding:5px 8px;font:700 12px Tahoma,Arial;direction:rtl;transition:background 160ms ease,color 160ms ease,transform 160ms ease}.priceDirection.up{background:var(--greenBg);color:var(--green)}.priceDirection.down{background:var(--redBg);color:var(--red)}.priceDirection.flat,.priceDirection.neutral{background:#27303b;color:var(--neutral)}.priceDirection .arrow{font-size:16px;line-height:1}.quoteSub{color:var(--muted);font-size:13px;margin-top:8px}.status{display:flex;justify-content:space-between;align-items:center;padding:8px 18px;border-bottom:1px solid var(--line);font-size:12px;color:var(--muted)}.dot{width:9px;height:9px;display:inline-block;border-radius:50%;background:var(--green);margin-left:5px}.tabs{display:flex;gap:0;overflow-x:auto;background:#0d1219;border-bottom:1px solid var(--line);scrollbar-width:none}.tab{min-width:91px;text-align:center;padding:14px 8px;color:var(--muted);font-size:14px}.tab.active{color:#fff;border-bottom:3px solid #fff}.sectionTitle{background:#28313e;color:#d8dee8;padding:11px 18px;font-weight:700;font-size:14px;margin-top:12px}.timeframes{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:14px 14px 4px}.tf{appearance:none;width:100%;background:var(--panel2);border-radius:5px;min-height:68px;padding:7px 3px;text-align:center;border:1px solid #212c39;color:var(--text);font:inherit;cursor:pointer;transition:transform 160ms cubic-bezier(.23,1,.32,1),border-color 160ms cubic-bezier(.23,1,.32,1),box-shadow 160ms cubic-bezier(.23,1,.32,1)}.tf:active{transform:scale(.97)}.tf:focus-visible{outline:2px solid var(--amber);outline-offset:2px}.tf.active{border-color:var(--amber);box-shadow:0 0 0 1px #e0ad4455;background:#252b28}.tf.loading{opacity:.58}.tfLabel{font-size:12px;color:var(--muted);margin-bottom:7px}.tfAction{font-size:13px;font-weight:700}.tfCandle{font-size:9px;color:var(--muted);margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.buy{background:var(--greenBg);color:var(--green)}.sell{background:var(--redBg);color:var(--red)}.neutral{background:#27303b;color:var(--neutral)}.tf .tfAction{padding:5px;border-radius:3px}.panel{margin:12px 14px 0;background:var(--panel);border:1px solid var(--line);border-radius:7px;overflow:hidden}.panelHead{display:flex;justify-content:space-between;align-items:center;padding:14px 14px 10px;font-size:18px;font-weight:700}.panelHead small{font-size:11px;color:var(--muted);font-weight:400}.summaryRow{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;padding:0 12px 12px}.summaryCard{background:#202a36;border-radius:5px;padding:9px 4px;text-align:center}.summaryCard span{display:block;color:var(--muted);font-size:11px;margin-top:3px}.dataTable{width:100%;border-collapse:collapse;font-size:14px}.dataTable th{color:var(--muted);font-weight:400;background:#101720;padding:9px 8px}.dataTable td{padding:10px 8px;border-top:1px solid #202b37;text-align:center}.dataTable td:first-child,.dataTable th:first-child{text-align:right;padding-right:14px}.cellBuy{background:var(--greenBg);color:var(--green);font-weight:700}.cellSell{background:var(--redBg);color:var(--red);font-weight:700}.cellNeutral{background:#2b3038;color:#d7d9df}.pivotGroup{margin:0 12px 12px;border:1px solid #26323f;border-radius:5px;overflow:hidden}.groupTitle{padding:9px 12px;background:#101720;color:#dce3ee;font-weight:700}.pivotRow{display:grid;grid-template-columns:64px 1fr 1fr;align-items:center;border-top:1px solid #202b37;min-height:43px}.pivotRow>div{padding:8px;text-align:center}.pivotRow>div:first-child{text-align:right;font-weight:700}.pivotR{background:#4a2429;color:#ef9b9e}.pivotS{background:#1d4324;color:#8bd781}.pivotP{background:#323942;color:#fff}.value{font-variant-numeric:tabular-nums;direction:ltr}.badge{display:inline-block;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:700}.notice{margin:12px 14px;padding:12px 14px;border-right:3px solid var(--amber);background:#332c1b;color:#f3d98e;border-radius:4px;font-size:13px;line-height:1.7}.signalBox{margin:12px 14px;padding:15px;border-radius:7px;border:1px solid var(--line);background:linear-gradient(135deg,#192431,#111821)}.signalMain{font-size:22px;font-weight:800;margin-bottom:8px}.signalReason{font-size:13px;color:var(--muted);line-height:1.7}.signalLevels{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:13px}.level{background:#202a36;border-radius:4px;padding:8px;text-align:center}.level span{display:block;font-size:11px;color:var(--muted)}.level strong{display:block;margin-top:3px;font-size:14px}.toolCard{padding:13px;border-bottom:1px solid #202b37}.toolCard:last-child{border-bottom:0}.toolHead{display:flex;justify-content:space-between;gap:10px;align-items:center}.toolTitle{font-weight:700}.toolDetails{font-size:12px;color:var(--muted);line-height:1.65;margin-top:7px}.toolLevels{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}.toolLevel{background:#202a36;border-radius:4px;padding:5px 7px;font-size:11px}.toolQuality{font-size:10px;color:#a8b1bf;margin-top:8px}.scenarioIntro{margin:0;padding:0 14px 12px;color:var(--muted);font-size:13px;line-height:1.7}.scenarioTableWrap{margin:0 14px 12px;overflow-x:auto;border:1px solid #344150;border-radius:6px;-webkit-overflow-scrolling:touch}.scenarioTable{min-width:760px;width:100%;border-collapse:collapse;font-size:12px}.scenarioTable th{background:#28313e;color:#f5f7fb;font-weight:700;padding:10px 8px;border-left:1px solid #526070;text-align:center;white-space:nowrap}.scenarioTable td{padding:10px 8px;border-top:1px solid #344150;border-left:1px solid #344150;text-align:center;vertical-align:top;line-height:1.55}.scenarioTable .scenarioType{font-weight:700;color:#e7edf5}.scenarioStatus{margin:0 14px 12px;padding:9px 11px;border-radius:5px;background:#202a36;color:var(--muted);font-size:11px;line-height:1.65}.scenarioEmpty{padding:18px!important;color:var(--muted);text-align:center}.footer{height:70px;margin-top:18px;background:#28313e;display:flex;align-items:center;justify-content:space-around;color:#9ba7b8;font-size:12px;position:sticky;bottom:0}.footer a{color:inherit;text-decoration:none;text-align:center}.footer b{display:block;font-size:22px;margin-bottom:2px;color:#e8edf4}.empty{padding:18px;color:var(--muted);text-align:center}.small{font-size:11px;color:var(--muted)}@media(min-width:700px){body{background:#0b1017}.app{max-width:520px}}
</style>
<style>
			.chartShell{margin:12px 14px 0;background:linear-gradient(180deg,#121b25,#0b1118);border:1px solid var(--line);border-radius:9px;overflow:hidden}.chartMeta{padding:11px 13px 7px;display:flex;justify-content:space-between;gap:9px;align-items:center;font-size:12px;color:var(--muted)}.chartMeta b{color:#f4f7fb;font-size:14px}.chartCanvas{height:350px;width:100%;direction:ltr;touch-action:none;position:relative}.chartZoneLayer{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;overflow:visible}.chartZoneLabel{font:10px Tahoma,Arial;paint-order:stroke;stroke:#0d1219;stroke-width:3px;stroke-linejoin:round}.chartControls,.chartActions{display:flex;gap:6px;overflow-x:auto;padding:10px 12px;border-top:1px solid #202b37;scrollbar-width:none}.chartActions{padding-top:8px;padding-bottom:8px}.chartToggle{white-space:nowrap;border:1px solid #344150;background:#18212c;color:#aeb8c6;border-radius:14px;padding:6px 9px;font:inherit;font-size:11px;cursor:pointer}.chartToggle.on{background:#2b4530;border-color:#72c36a;color:#bfeab9}.chartToggle:active{transform:scale(.97)}.chartToggle:focus-visible{outline:2px solid var(--amber);outline-offset:2px}.chartCrosshair{margin:0 12px 8px;padding:7px 9px;background:#101720;border:1px solid #26323f;border-radius:5px;font-size:10px;color:#aeb8c6;direction:rtl;white-space:nowrap;overflow-x:auto}.chartFoot{padding:8px 13px 11px;border-top:1px solid #202b37;color:#9ba7b8;font-size:10px;line-height:1.6}.chartAttribution{color:#7897b8;text-decoration:none}.chartError{height:350px;display:grid;place-items:center;color:#de7d80;padding:18px;text-align:center}.chartLegend{display:flex;gap:8px;flex-wrap:wrap;padding:0 13px 8px;font-size:10px;color:#aeb8c6}.legendDot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-left:3px}.chartShell:fullscreen,.chartShell.chartPseudoFullscreen{margin:0;border:0;border-radius:0;width:100vw;height:100vh;background:#0a1017;display:flex;flex-direction:column;position:fixed;inset:0;z-index:9999}.chartShell:fullscreen .chartCanvas,.chartShell.chartPseudoFullscreen .chartCanvas{flex:1 1 auto;min-height:0;height:auto}.chartShell:fullscreen .chartControls,.chartShell.chartPseudoFullscreen .chartControls,.chartShell:fullscreen .chartActions,.chartShell.chartPseudoFullscreen .chartActions{flex:0 0 auto;flex-wrap:nowrap;overflow-x:auto;padding-bottom:max(10px,env(safe-area-inset-bottom))}body.chartLock{overflow:hidden}#chart{scroll-margin-top:8px}#chart .sectionTitle{margin-top:0}@media(max-width:360px){.chartCanvas{height:305px}.chartToggle{font-size:10px;padding:5px 7px}}@media(orientation:landscape) and (max-height:600px){.chartShell:fullscreen .chartMeta,.chartShell.chartPseudoFullscreen .chartMeta{padding:5px 10px}.chartShell:fullscreen .chartLegend,.chartShell.chartPseudoFullscreen .chartLegend,.chartShell:fullscreen .chartCrosshair,.chartShell.chartPseudoFullscreen .chartCrosshair,.chartShell:fullscreen .chartFoot,.chartShell.chartPseudoFullscreen .chartFoot{display:none}.chartShell:fullscreen .chartActions,.chartShell.chartPseudoFullscreen .chartActions,.chartShell:fullscreen .chartControls,.chartShell.chartPseudoFullscreen .chartControls{padding:5px 10px;min-height:40px}.chartShell:fullscreen .chartDrawingTools,.chartShell.chartPseudoFullscreen .chartDrawingTools{flex:0 0 auto;flex-wrap:nowrap;overflow-x:auto;padding:5px 10px;min-height:40px}.chartShell:fullscreen .chartDrawHint,.chartShell.chartPseudoFullscreen .chartDrawHint{display:none}.chartShell:fullscreen .chartCanvas,.chartShell.chartPseudoFullscreen .chartCanvas{min-height:0;flex:1 1 auto}}
	body.pageLandscapeRequested{background:#0b1017}body.pageLandscapeRequested .app{max-width:none;width:100vw;min-height:100vh;box-shadow:none}.pageLandscapeExit{display:none;position:fixed;z-index:10050;left:max(10px,env(safe-area-inset-left));top:max(10px,env(safe-area-inset-top));border:1px solid #566579;background:#15202c;color:#f4f7fb;border-radius:18px;padding:7px 11px;font:700 12px Tahoma,Arial;cursor:pointer}.pageLandscapeRequested .pageLandscapeExit{display:block}@media(orientation:landscape){body.pageLandscapeRequested .topbar{padding:8px 16px 4px}body.pageLandscapeRequested .quote{padding:3px 16px 9px}body.pageLandscapeRequested .price{font-size:30px}body.pageLandscapeRequested .status{padding:6px 16px}body.pageLandscapeRequested .chartCanvas{height:62vh;min-height:380px}body.pageLandscapeRequested .chartShell{margin:8px 10px 0}body.pageLandscapeRequested .sectionTitle{margin-top:8px;padding:8px 14px}.pageLandscapeRequested .pageLandscapeExit{display:block}}
	</style>
		<style>.chartVolumeProfileLayer{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;overflow:visible}.chartVolumeProfileLabel{font:9px Tahoma,Arial;fill:#bdefff;paint-order:stroke;stroke:#0d1219;stroke-width:3px;stroke-linejoin:round}.chartManualLayer{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;overflow:visible}.chartDrawingTools{display:none;gap:6px;flex-wrap:wrap;padding:8px 12px;border-top:1px solid #25313e;background:#0c131c}.chartShell:fullscreen .chartDrawingTools,.chartShell.chartPseudoFullscreen .chartDrawingTools{display:flex;flex:0 0 auto;flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}.chartDrawingTools input[type=color]{width:31px;height:29px;padding:2px;border:1px solid #344150;background:#18212c;border-radius:7px;flex:0 0 auto}.chartDrawHint{width:100%;font-size:10px;color:#9ba7b8}.chartShell:fullscreen .chartDrawHint,.chartShell.chartPseudoFullscreen .chartDrawHint{display:none}</style>
	<script src="https://unpkg.com/lightweight-charts@5.0.8/dist/lightweight-charts.standalone.production.js"></script>
</head>
	<body><button type="button" class="pageLandscapeExit" id="pageLandscapeExit">↩ عمودي</button><main class="app">
	<header class="topbar"><div><div class="instrument">الذهب</div><div class="meta" id="symbol">XAUUSD</div></div><div class="topActions"><button type="button" class="alertBell" id="alertBell" aria-label="فتح سجل التنبيهات" aria-expanded="false">🔔<span id="alertBellCount" hidden>0</span></button><div class="icon">⋮</div></div></header>
	<section class="quote"><div class="quoteLine"><span class="price" id="price">—</span><span class="priceDirection neutral" id="priceDirection" title="اتجاه آخر قراءة GoldAPI"><span class="arrow" id="priceDirectionArrow">↔</span><span id="priceDirectionText">بانتظار المقارنة</span></span><span class="change" id="change">—</span></div><div class="quoteSub" id="quoteSub">جاري التحقق من مصدر السعر...</div></section>
<div class="status"><span id="systemStatus"><span class="dot"></span>جاري الاتصال</span><span id="lastRefresh">—</span></div>
<nav class="tabs"><a class="tab" href="#overview">نظرة عامة</a><a class="tab active" href="#technical">تقني</a><a class="tab" href="#news">أخبار</a><a class="tab" href="#analysis">تحليلات</a><a class="tab" href="#historical">بيانات تاريخية</a></nav>
		<section id="overview"><div class="sectionTitle timeframeTitle"><span>التقييم حسب الإطار الزمني</span><button type="button" class="chartToggle timeframeFilterToggle" id="timeframeFilterToggle">تخصيص 9 أطر</button></div><div class="timeframeFilterPanel" id="timeframeFilterPanel" hidden></div><div class="timeframes" id="timeframes"></div><div class="selectedFrameContext" id="selectedFrameContext">جارِ ربط التحليل بالإطار المختار...</div><div class="panel"><div class="panelHead">ملخص <small id="timeframeInfo">اختر إطاراً زمنياً</small></div><div class="summaryRow"><div class="summaryCard"><strong id="maSummary">—</strong><span>معدلات متحركة</span></div><div class="summaryCard"><strong id="indicatorSummary">—</strong><span>المؤشرات التقنية</span></div><div class="summaryCard"><strong id="technicalConfidence">—</strong><span>قوة الأدلة</span></div></div><div class="evidenceExplanation" id="evidenceExplanation">اختر إطاراً زمنياً لعرض مكونات قوة الأدلة وأسباب الحياد الخاصة به.</div></div></section>
		<section id="chart"><div class="sectionTitle">الرسم البياني للشموع</div><div class="chartShell" id="chartShell"><div class="chartMeta"><div><b id="chartTitle">XAUUSD · يومي</b><div id="chartStatus">جاري تحميل الشموع...</div></div><button type="button" class="chartToggle on" id="chartFit" aria-label="إظهار كامل البيانات">ملاءمة</button></div><div class="chartLegend"><span><i class="legendDot" style="background:#72c36a"></i>شمعة صاعدة</span><span><i class="legendDot" style="background:#de7d80"></i>شمعة هابطة</span><span><i class="legendDot" style="background:#ffb74d"></i>سيولة فوق القمم</span><span><i class="legendDot" style="background:#c084fc"></i>سيولة تحت القيعان</span><span><i class="legendDot" style="background:#5bc0eb"></i>Volume Profile تقريبي</span></div><div class="chartCanvas" id="chartCanvas"><div class="chartError">جاري تجهيز الرسم...</div></div><div class="chartCrosshair" id="chartCrosshair">حرّك المؤشر فوق شمعة لعرض الوقت والتاريخ وOHLC.</div><div class="chartActions"><button class="chartToggle" id="chartZoomIn" aria-label="تكبير الرسم">＋ تكبير</button><button class="chartToggle" id="chartZoomOut" aria-label="تصغير الرسم">－ تصغير</button><button class="chartToggle" id="chartRealtime" aria-label="الانتقال لآخر شمعة">آخر شمعة</button><button class="chartToggle" id="chartLandscape" aria-label="تدوير العرض أفقياً">↻ عرضي</button><button class="chartToggle" id="chartFullscreen" aria-label="ملء الشاشة">⛶ ملء الشاشة</button></div><div class="chartControls" id="chartControls"><button class="chartToggle on" data-overlay="ma">MA 20/50</button><button class="chartToggle on" data-overlay="vwap">Anchored VWAP</button><button class="chartToggle" data-overlay="fib">Fibonacci</button><button class="chartToggle on" data-overlay="fvg">Fair Value Gap</button><button class="chartToggle" data-overlay="sweep">Liquidity Sweep</button><button class="chartToggle on" data-overlay="profile">Volume Profile</button><button class="chartToggle on" data-overlay="liquidityzones">مناطق السيولة</button><button class="chartToggle on" data-overlay="orderblocks">Order Blocks</button><button class="chartToggle on" data-overlay="scenario">منطقة السيناريو</button><button class="chartToggle" data-overlay="volume">الحجم</button></div><div class="chartFoot">الأزرق: Volume Profile تقريبي. الأخضر/الأحمر: Order Blocks مرشحة. الوردي: Fair Value Gap. منطقة السيناريو لا تظهر إلا مع سعر وسيط موثق، ولا تمثل أمراً مؤكداً. <a class="chartAttribution" href="https://www.tradingview.com" target="_blank" rel="noopener">Charts by TradingView</a></div></div></section>
		<section id="imageAnalysis"><div class="sectionTitle">تحليل رسم بياني مرفوع</div><div class="panel chartImagePanel"><p class="chartImageIntro">أرفق لقطة شاشة للرسم من هاتفك. اختر تحليل قواعد المنصة لاستخدام أدوات الإطار المختار، أو التحليل بالذكاء الاصطناعي لقراءة العناصر المرئية في الصورة. الصورة لا تُحفظ؛ تُعالج في الذاكرة فقط.</p><label class="chartImageDrop" for="chartImageInput"><b>اضغط لإرفاق صورة الرسم</b><span>PNG أو JPG أو WEBP · حتى 8 MB · يفضّل أن يظهر الرمز والإطار والسعر بوضوح</span><input id="chartImageInput" type="file" accept="image/png,image/jpeg,image/webp"></label><img id="chartImagePreview" class="chartImagePreview" alt="معاينة الرسم المرفوع" hidden><div class="chartImageModes" role="group" aria-label="اختر طريقة تحليل الرسم"><button class="chartImageMode active" type="button" data-image-mode="platform">تحليل هنا<small>قواعد ومؤشرات ومناطق الإطار المختار</small></button><button class="chartImageMode" type="button" data-image-mode="ai">تحليل عبر AI<small>قراءة بصرية من الصورة الثابتة</small></button></div><button class="chartImageRun" id="chartImageRun" type="button">حلل الرسم المرفوع</button><div id="chartImageResult" class="chartImageResult" aria-live="polite"><div class="empty">أرفق صورة ثم اختر وضع التحليل.</div></div></div></section>
		<section id="technical"><div class="sectionTitle">نقاط الارتكاز — Pivot Points</div><div class="panel" id="pivots"><div class="empty">جاري حساب نقاط الارتكاز من الشموع الفعلية...</div></div><div class="sectionTitle">المتوسطات المتحركة</div><div class="panel" id="movingAverages"><div class="empty">جاري حساب المتوسطات...</div></div><div class="signalTotals" id="maTotals"></div><div class="sectionTitle">المؤشرات التقنية</div><div class="panel" id="indicators"><div class="empty">جاري حساب المؤشرات...</div></div><div class="signalTotals" id="indicatorTotals"></div></section>
		<section id="analysis"><div class="sectionTitle">توصيات التداول اللحظية</div><div class="panel" id="intradayRecommendation"><div class="empty">جاري التحقق من تقاطع المتوسطات والمناطق السعرية...</div></div><div class="panel" id="intradayAlerts" aria-live="polite"><div class="toolHead"><span class="toolTitle">تنبيهات تقاطع EMA + RSI</span><button type="button" class="chartToggle" id="intradayAlertPermission">تفعيل إشعارات النظام</button></div><div class="toolDetails" id="intradayAlertStatus">التنبيهات داخل الصفحة جاهزة؛ لن يصدر تنبيه قبل اكتمال التقاطع وتأكيد RSI وحداثة المصدر.</div><div class="toolLevels"><button type="button" class="chartToggle on" id="intradayAlertMute">كتم التنبيهات</button><span class="toolLevel">لا تكرار للتنبيه نفسه ما لم تتغير الإشارة أو المنطقة.</span></div></div><div class="sectionTitle">سيناريوهات وتوصيات التعامل</div><div class="panel" id="scenarioTable"><div class="empty">جاري التحقق من جودة الاقتباس وحواجز السيناريو...</div></div><div class="sectionTitle">المكونات الأقل تشويشاً</div><div class="panel compactSignalWorkspace" id="signalLayers"><div class="empty">جاري دمج المناطق السعرية والاتجاه...</div></div><div class="sectionTitle">التوصية المشروطة وإدارة المخاطر</div><div id="recommendation" class="signalBox"><div class="empty">جاري التقييم...</div></div><div class="sectionTitle">تفاعل الزخم والسيولة والأخبار</div><div class="panel" id="momentumInteraction"><div class="empty">جاري قياس تفاعل الزخم والسيولة ومخاطر الأخبار...</div></div><div class="sectionTitle">تدفق السيولة الحقيقي</div><div class="panel" id="realOrderFlow"><div class="empty">جارِ التحقق من Bid/Ask وDOM والصفقات الموثقة...</div></div><div class="sectionTitle">أدوات السيولة وبنية السوق</div><div class="panel" id="advancedTools"><div class="empty">جاري فحص Liquidity Sweep وFVG وVWAP والحجم...</div></div><div class="sectionTitle">السيولة والفخاخ</div><div class="panel" id="liquidity"><div class="empty">جاري فحص السيولة...</div></div><div class="sectionTitle">التدفقات المؤسسية</div><div class="panel" id="institutional"><div class="empty">جاري تحميل حالة المصادر...</div></div></section>
<section id="news"><div class="sectionTitle">الأخبار والتقويم الاقتصادي</div><div class="notice">لا تُصدر المنصة إشارة قبل التحقق من وقت الخبر ومصدره. بيانات Actual وForecast وPrevious لا تُعرض كأنها حية ما لم يصل مصدر موثق.</div><div class="panel" id="newsPanel"><div class="empty">جاري تحميل التقويم...</div></div></section>
<section id="historical"><div class="sectionTitle">حالة البيانات والتدقيق</div><div class="panel"><table class="dataTable"><tbody><tr><td>المصدر الأساسي</td><td id="source">—</td></tr><tr><td>رمز المصدر</td><td id="sourceSymbol">—</td></tr><tr><td>عمر آخر سعر</td><td id="age">—</td></tr><tr><td>الشموع المحللة</td><td id="bars">—</td></tr><tr><td>آخر شمعة</td><td id="lastCandle">—</td></tr></tbody></table></div><div class="notice" id="externalReference">جاري التحقق من مسارات البيانات المرجعية...</div></section>
<footer class="footer"><a href="#overview"><b>▰</b>الأسواق</a><a href="#news"><b>▤</b>أخبار</a><a href="#analysis"><b>✦</b>تحليلات</a><a href="#technical"><b>⌁</b>تقني</a><a href="#historical"><b>☰</b>المزيد</a></footer>
	</main>
	<script>
		(function(){
			let selectedMode='platform',previewUrl=null;
			const input=document.getElementById('chartImageInput'),preview=document.getElementById('chartImagePreview'),result=document.getElementById('chartImageResult'),run=document.getElementById('chartImageRun');
			const imageScenarioClass=value=>String(value||'').includes('BULLISH')?'cellBuy':String(value||'').includes('BEARISH')?'cellSell':'cellNeutral';
			const renderRows=rows=>Array.isArray(rows)&&rows.length?rows.map(item=>`<span class="toolLevel">${esc(typeof item==='string'?item:`${item.name||'أداة'}: ${item.status||'—'}`)}</span>`).join(''):'<span class="small">لا توجد عناصر قابلة للعرض.</span>';
			const renderResult=data=>{const scope=data?.source_scope||{},evidence=data?.evidence||{},limits=[...(data?.limitations||[]),...(data?.uncertainties||[]),...(data?.risk_notes||[])];result.innerHTML=`<div class="chartImageResultTitle"><b>${esc(data?.title||'نتيجة التحليل')}</b><span class="badge ${imageScenarioClass(data?.scenario)}">${esc(data?.scenario||'NO_TRADE')}</span></div><div class="toolDetails">${esc(data?.summary||'—')}</div>${data?.mode==='platform'?`<div class="chartImageScope">الإطار: ${esc(scope.timeframe?.label||scope.timeframe?.id||'—')} · قوة الأدلة: ${esc(evidence.strength??'—')}/100 · ليست احتمال نجاح.<br>دور الصورة: ${esc(scope.image_role||'—')}<br>مصدر السعر: ${esc(scope.quote?.source||'—')} · قابل للتنفيذ: ${scope.quote?.tradable?'نعم':'لا'}</div><div class="toolLevels">${renderRows(data?.tools)}</div>`:`<div class="chartImageScope">قراءة بصرية من الصورة فقط. الرمز أو الوقت أو الأسعار غير المقروءة تُعد غير مؤكدة.</div><div class="toolLevels">${renderRows(data?.observations)}</div>${(data?.visible_levels||[]).length?`<div class="toolLevels">${renderRows(data.visible_levels)}</div>`:''}${(data?.visible_tools||[]).length?`<div class="toolLevels">${renderRows(data.visible_tools)}</div>`:''}`}<div class="chartImageNotice">${limits.map(esc).join('<br>')}</div>`;};
			input?.addEventListener('change',()=>{const file=input.files?.[0];if(previewUrl){URL.revokeObjectURL(previewUrl);previewUrl=null;}if(!file){preview.hidden=true;return;}previewUrl=URL.createObjectURL(file);preview.src=previewUrl;preview.hidden=false;result.innerHTML='<div class="empty">الصورة جاهزة. اختر طريقة التحليل ثم اضغط الزر.</div>';});
			document.querySelectorAll('[data-image-mode]').forEach(button=>button.addEventListener('click',()=>{selectedMode=button.dataset.imageMode||'platform';document.querySelectorAll('[data-image-mode]').forEach(item=>item.classList.toggle('active',item===button));run.textContent=selectedMode==='ai'?'حلل الصورة عبر AI':'حلل الرسم المرفوع هنا';}));
			run?.addEventListener('click',async()=>{const file=input?.files?.[0];if(!file){result.innerHTML='<div class="notice">أرفق صورة رسم بياني أولاً.</div>';return;}const data=new FormData();data.append('image',file);data.append('mode',selectedMode);data.append('timeframe',window.selectedTimeframe||'1d');run.disabled=true;result.innerHTML='<div class="empty">جارِ تحليل الصورة. لا تغلق الصفحة حتى تظهر النتيجة...</div>';try{const response=await fetch('/api/chart-image-analysis',{method:'POST',body:data});const payload=await readApiJson(response,'تحليل الرسم المرفوع');renderResult(payload);}catch(error){result.innerHTML=`<div class="notice">${esc(error.message||'تعذر تحليل الصورة')}</div>`;}finally{run.disabled=false;}});
		})();
		const esc=(x)=>String(x??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=(x,d=2)=>x===null||x===undefined||Number.isNaN(Number(x))?'—':Number(x).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const cls=(action)=>String(action||'').includes('شراء')?'cellBuy':String(action||'').includes('بيع')?'cellSell':'cellNeutral';
const actionText=(action)=>esc(action||'غير متاح');
async function readApiJson(response,context){const contentType=String(response.headers.get('content-type')||'').toLowerCase();const raw=await response.text();if(!contentType.includes('application/json')){const kind=/^\s*</.test(raw)?'صفحة HTML':'محتوى غير JSON';throw new Error(`${context}: استجاب الخادم بـ${kind} بدلاً من بيانات الرسم. حدّث الصفحة أو أعد اختيار الإطار.`);}let data;try{data=JSON.parse(raw);}catch(_){throw new Error(`${context}: وصلت استجابة JSON غير صالحة. حدّث الصفحة ثم أعد المحاولة.`);}if(!response.ok)throw new Error(data?.error||`${context}: تعذر إكمال الطلب (${response.status}).`);return data;}
			let selectedTimeframe=(()=>{try{return localStorage.getItem('xauusd-selected-timeframe')||null}catch(_){return null}})(); let latestSystem=null; let loadingTimeframe=false; let selectedFramePayload=null; let timeframeFilterOpen=false;
		const TIMEFRAME_FILTER_KEY='xauusd-evaluation-timeframes-v1',TIMEFRAME_FILTER_LIMIT=9,TIMEFRAME_ASCENDING=['1m','5m','10m','15m','30m','1h','2h','4h','1d','1wk','1mo'],TIMEFRAME_FILTER_DEFAULT=['1m','5m','10m','15m','30m','1h','2h','4h','1d'];
		const sortTimeframesAscending=rows=>[...(rows||[])].sort((left,right)=>{const a=TIMEFRAME_ASCENDING.indexOf(left.id),b=TIMEFRAME_ASCENDING.indexOf(right.id);return (a<0?99:a)-(b<0?99:b)});
		function readTimeframeFilter(rows){const available=sortTimeframesAscending(rows).map(row=>row.id);let saved=[];try{const value=JSON.parse(localStorage.getItem(TIMEFRAME_FILTER_KEY)||'[]');if(Array.isArray(value))saved=[...new Set(value)].filter(id=>available.includes(id));}catch(_){}if(saved.length===TIMEFRAME_FILTER_LIMIT)return saved;const defaults=TIMEFRAME_FILTER_DEFAULT.filter(id=>available.includes(id));return [...defaults,...available.filter(id=>!defaults.includes(id))].slice(0,TIMEFRAME_FILTER_LIMIT);}
		function writeTimeframeFilter(ids){try{localStorage.setItem(TIMEFRAME_FILTER_KEY,JSON.stringify(ids.slice(0,TIMEFRAME_FILTER_LIMIT)))}catch(_){}}
		function renderSelectedFrameContext(frame,recommendation){const box=document.getElementById('selectedFrameContext');if(!box)return;const label=frame?.label||selectedTimeframe||'—',updated=frame?.updated_at||frame?.technical?.last_candle_time||'—',signal=recommendation?.signal||'انتظار / لا قرار';box.innerHTML=`<b>نطاق التحليل الحالي: ${esc(label)}</b><span>الاستراتيجيات والمناطق والمؤشرات والتوصية المشروطة أدناه مشتقة من شموع هذا الإطار. آخر شمعة: ${esc(updated)} · النتيجة: ${esc(signal)}</span><small>الأخبار والسعر المرجعي العام وبيانات Order Flow—إن وجدت—سياق مشترك وليست شموعاً خاصة بالإطار.</small>`;}
		function renderTimeframeFilter(rows){const panel=document.getElementById('timeframeFilterPanel'),toggle=document.getElementById('timeframeFilterToggle');if(!panel||!toggle)return;const orderedRows=sortTimeframesAscending(rows),selected=readTimeframeFilter(orderedRows);toggle.textContent=`تخصيص 9 أطر (${selected.length}/9)`;toggle.classList.toggle('on',timeframeFilterOpen);panel.hidden=!timeframeFilterOpen;if(!timeframeFilterOpen)return;panel.innerHTML=`<div class="timeframeFilterHead"><b>الأطر الظاهرة في منطقة التقييم</b><span id="timeframeFilterCount">${selected.length}/9</span></div><div class="timeframeFilterOptions">${orderedRows.map(row=>`<label><input type="checkbox" value="${esc(row.id)}" ${selected.includes(row.id)?'checked':''}> ${esc(row.label)}</label>`).join('')}</div><div class="timeframeFilterActions"><button type="button" class="chartToggle" id="timeframeFilterApply">حفظ 9 أطر</button><button type="button" class="chartToggle" id="timeframeFilterReset">الافتراضي</button></div><div class="small" id="timeframeFilterStatus">الأطر مرتبة من الأصغر إلى الأكبر. اختر تسعة أطر بالضبط؛ الإعداد محفوظ على هذا الجهاز.</div>`;const count=()=>[...panel.querySelectorAll('input:checked')].length;panel.querySelectorAll('input').forEach(input=>input.addEventListener('change',event=>{if(event.target.checked&&count()>TIMEFRAME_FILTER_LIMIT){event.target.checked=false;panel.querySelector('#timeframeFilterStatus').textContent='يمكن إظهار تسعة أطر فقط في الوقت نفسه.';}panel.querySelector('#timeframeFilterCount').textContent=`${count()}/9`; }));panel.querySelector('#timeframeFilterApply')?.addEventListener('click',()=>{const ids=[...panel.querySelectorAll('input:checked')].map(input=>input.value);if(ids.length!==TIMEFRAME_FILTER_LIMIT){panel.querySelector('#timeframeFilterStatus').textContent='اختر تسعة أطر بالضبط قبل الحفظ.';return;}writeTimeframeFilter(ids);timeframeFilterOpen=false;renderTimeframes(latestSystem?.timeframes||orderedRows);if(!ids.includes(selectedTimeframe))selectTimeframe(sortTimeframesAscending(orderedRows.filter(row=>ids.includes(row.id)))[0]?.id);});panel.querySelector('#timeframeFilterReset')?.addEventListener('click',()=>{try{localStorage.removeItem(TIMEFRAME_FILTER_KEY)}catch(_){}renderTimeframeFilter(orderedRows);});}
		document.getElementById('timeframeFilterToggle')?.addEventListener('click',()=>{timeframeFilterOpen=!timeframeFilterOpen;renderTimeframeFilter(latestSystem?.timeframes||[]);});
			const chartUI={chart:null,candles:null,ma20:null,ma50:null,volume:null,priceLines:[],zoneLayer:null,profileLayer:null,supportLayer:null,manualLayer:null,manualDrawings:[],drawTool:'none',drawColor:'#f2c14e',drawDashed:false,drawDraft:null,zoneData:{liquidity:[],order_blocks:[],fair_value_gap:[],trade_scenario:[]},profileData:[],supportData:[],overlays:{ma:true,vwap:true,fib:false,fvg:true,sweep:false,profile:true,liquidityzones:true,orderblocks:true,scenario:true,supportresistance:false,volume:false},loadedTimeframe:null};
			function chartShell(){return document.getElementById('chartShell')}function isChartFullscreen(){const shell=chartShell();return document.fullscreenElement===shell||document.webkitFullscreenElement===shell||shell?.classList.contains('chartPseudoFullscreen')}function syncChartFullscreen(){const shell=chartShell(),button=document.getElementById('chartFullscreen');document.body.classList.toggle('chartLock',isChartFullscreen());if(button)button.textContent=isChartFullscreen()?'تصغير الشاشة':'⛶ ملء الشاشة';syncManualDrawingUI();resizeChart();queueZoneDraw()}function toggleChartFullscreen(){const shell=chartShell();if(!shell)return;if(shell.classList.contains('chartPseudoFullscreen')){shell.classList.remove('chartPseudoFullscreen');syncChartFullscreen();return}if(document.fullscreenElement===shell||document.webkitFullscreenElement===shell){(document.exitFullscreen||document.webkitExitFullscreen)?.call(document);return}const request=shell.requestFullscreen||shell.webkitRequestFullscreen;if(request){try{const result=request.call(shell);if(result?.catch)result.catch(()=>{shell.classList.add('chartPseudoFullscreen');syncChartFullscreen()});setTimeout(()=>{if(!isChartFullscreen()){shell.classList.add('chartPseudoFullscreen');syncChartFullscreen()}},250)}catch(_){shell.classList.add('chartPseudoFullscreen');syncChartFullscreen()}}else{shell.classList.add('chartPseudoFullscreen');syncChartFullscreen()}}function requestPageLandscape(){const button=document.getElementById('chartLandscape');document.body.classList.add('pageLandscapeRequested');const request=document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen;if(!document.fullscreenElement&&request){try{const result=request.call(document.documentElement);if(result?.catch)result.catch(()=>{})}catch(_){}}const lock=screen.orientation?.lock;if(lock)Promise.resolve(lock.call(screen.orientation,'landscape')).then(()=>{if(button)button.textContent='عرضي ✓'}).catch(()=>{if(button)button.textContent='دوّر الهاتف'});else if(button)button.textContent='دوّر الهاتف';setTimeout(resizeChart,220)}function exitPageLandscape(){document.body.classList.remove('pageLandscapeRequested');const unlock=screen.orientation?.unlock;if(unlock)try{unlock.call(screen.orientation)}catch(_){}if(document.fullscreenElement===document.documentElement||document.webkitFullscreenElement===document.documentElement)(document.exitFullscreen||document.webkitExitFullscreen)?.call(document);setTimeout(resizeChart,180)}function chartHeight(host){if(document.body.classList.contains('pageLandscapeRequested'))return Math.max(300,host.clientHeight||window.innerHeight-132);return isChartFullscreen()?Math.max(260,window.innerHeight-(matchMedia('(orientation:landscape)').matches?92:190)):(host.clientWidth<370?305:350)}function resizeChart(){const host=document.getElementById('chartCanvas');if(chartUI.chart&&host)chartUI.chart.applyOptions({width:host.clientWidth,height:chartHeight(host)});queueZoneDraw()}function chartZoom(multiplier){const scale=chartUI.chart?.timeScale();const range=scale?.getVisibleLogicalRange();if(!range)return;const middle=(range.from+range.to)/2;const half=(range.to-range.from)/(2*multiplier);scale.setVisibleLogicalRange({from:middle-half,to:middle+half})}function chartDate(value){if(value===undefined||value===null)return '—';const stamp=typeof value==='number'?value*1000:Date.UTC(value.year,value.month-1,value.day);return new Intl.DateTimeFormat('ar-EG',{dateStyle:'medium',timeStyle:typeof value==='number'?'short':undefined}).format(new Date(stamp))}
		function chartColor(name){return {vwap:'#f2c14e',fib:'#bb86fc',fvg:'#ff8b94',sweep:'#ffb74d',profile:'#5bc0eb',support:'#38bdf8',resistance:'#fb7185',liquidity_buy:'#ffb74d',liquidity_sell:'#c084fc',order_bull:'#72c36a',order_bear:'#de7d80'}[name]||'#aeb8c6';}
			function initChart(){const host=document.getElementById('chartCanvas');if(!window.LightweightCharts){host.innerHTML='<div class="chartError">تعذر تحميل مكتبة الرسم. تحقق من الاتصال ثم حدّث الصفحة.</div>';return false;}const L=window.LightweightCharts;host.innerHTML='';chartUI.chart=L.createChart(host,{width:host.clientWidth,height:chartHeight(host),layout:{background:{type:'solid',color:'#0d1219'},textColor:'#9ba7b8',fontFamily:'Tahoma, Arial'},grid:{vertLines:{color:'#17212b'},horzLines:{color:'#202b37'}},rightPriceScale:{borderColor:'#2b3543'},timeScale:{borderColor:'#2b3543',timeVisible:true,secondsVisible:false,rightOffset:4,barSpacing:8,minBarSpacing:2},crosshair:{mode:L.CrosshairMode.Normal,vertLine:{color:'#4c5867',labelBackgroundColor:'#344150'},horzLine:{color:'#4c5867',labelBackgroundColor:'#344150'}},handleScroll:{mouseWheel:true,pressedMouseMove:true,horzTouchDrag:true,vertTouchDrag:true},handleScale:{axisPressedMouseMove:true,pinch:true,mouseWheel:true}});chartUI.candles=chartUI.chart.addSeries(L.CandlestickSeries,{upColor:'#72c36a',downColor:'#de7d80',borderVisible:false,wickUpColor:'#9be293',wickDownColor:'#f0a1a4',lastValueVisible:false,priceLineVisible:false});chartUI.ma20=chartUI.chart.addSeries(L.LineSeries,{color:'#e0ad44',lineWidth:2,lastValueVisible:false,priceLineVisible:false});chartUI.ma50=chartUI.chart.addSeries(L.LineSeries,{color:'#42a5f5',lineWidth:2,lastValueVisible:false,priceLineVisible:false});chartUI.volume=chartUI.chart.addSeries(L.HistogramSeries,{priceScaleId:'volume',lastValueVisible:false,priceLineVisible:false});chartUI.volume.priceScale().applyOptions({scaleMargins:{top:.82,bottom:0},visible:false});chartUI.chart.subscribeCrosshairMove(param=>{const output=document.getElementById('chartCrosshair');const candle=param?.seriesData?.get(chartUI.candles);if(!param?.time||!candle){output.textContent='حرّك المؤشر فوق شمعة لعرض الوقت والتاريخ وOHLC.';return}output.textContent=`${chartDate(param.time)} · O ${num(candle.open)} · H ${num(candle.high)} · L ${num(candle.low)} · C ${num(candle.close)}`});new ResizeObserver(resizeChart).observe(host);window.addEventListener('orientationchange',()=>setTimeout(resizeChart,180));document.addEventListener('fullscreenchange',syncChartFullscreen);document.querySelectorAll('[data-overlay]').forEach(button=>button.addEventListener('click',()=>{const key=button.dataset.overlay;chartUI.overlays[key]=!chartUI.overlays[key];button.classList.toggle('on',chartUI.overlays[key]);if(chartUI.loadedTimeframe)loadChart(chartUI.loadedTimeframe,false);}));document.getElementById('chartFit').addEventListener('click',()=>chartUI.chart?.timeScale().fitContent());document.getElementById('chartZoomIn').addEventListener('click',()=>chartZoom(1.35));document.getElementById('chartZoomOut').addEventListener('click',()=>chartZoom(.74));document.getElementById('chartRealtime').addEventListener('click',()=>chartUI.chart?.timeScale().scrollToRealTime());document.getElementById('chartLandscape').addEventListener('click',requestPageLandscape);document.getElementById('pageLandscapeExit').addEventListener('click',exitPageLandscape);document.getElementById('chartFullscreen').addEventListener('click',toggleChartFullscreen);return true;}
function clearChartPriceLines(){chartUI.priceLines.forEach(line=>{try{chartUI.candles.removePriceLine(line);}catch(_){}});chartUI.priceLines=[];}
function addChartLine(value,title,kind,style=window.LightweightCharts.LineStyle.Dashed,labeled=false){if(!Number.isFinite(Number(value)))return;const line=chartUI.candles.createPriceLine({price:Number(value),color:chartColor(kind),lineWidth:1,lineStyle:style,axisLabelVisible:labeled,title:labeled?title:''});chartUI.priceLines.push(line);}
				function renderChartOverlays(data){const o=data.overlays||{};chartUI.ma20.applyOptions({visible:chartUI.overlays.ma});chartUI.ma50.applyOptions({visible:chartUI.overlays.ma});chartUI.volume.applyOptions({visible:chartUI.overlays.volume});clearChartPriceLines();const levels=o.levels||{};if(chartUI.overlays.vwap)addChartLine(levels.anchored_vwap,'Anchored VWAP','vwap',window.LightweightCharts.LineStyle.Solid,true);if(chartUI.overlays.fib)Object.entries(levels.fibonacci||{}).filter(([key])=>key.includes('%')).forEach(([key,value])=>addChartLine(value,'Fib '+key,'fib'));if(chartUI.overlays.fvg){const gap=levels.fair_value_gap||{};addChartLine(gap['الحد الأدنى'],'FVG lower','fvg');addChartLine(gap['المنتصف'],'FVG mid','fvg',window.LightweightCharts.LineStyle.Dotted);addChartLine(gap['الحد الأعلى'],'FVG upper','fvg');}if(chartUI.overlays.sweep){const sweep=levels.liquidity_sweep||{};addChartLine(sweep['قمة pivot']||sweep['قمة النطاق'],'Sweep high','sweep');addChartLine(sweep['قاع pivot']||sweep['قاع النطاق'],'Sweep low','sweep');}if(chartUI.overlays.profile){const profile=levels.volume_profile||{};['POC','VAL (70%)','VAH (70%)','HVN','LVN'].forEach(key=>addChartLine(profile[key],key,'profile',key==='POC'?window.LightweightCharts.LineStyle.Solid:window.LightweightCharts.LineStyle.Dashed,key==='POC'));}}
			async function loadChart(id,fit=true){if(!chartUI.chart&&!initChart())return;const host=document.getElementById('chartCanvas');try{const response=await fetch('/api/chart/'+encodeURIComponent(id),{cache:'no-store'});const data=await readApiJson(response,'تعذر تحميل الرسم');if(data.error)throw new Error(data.error);if(!data.candles?.length)throw new Error('لا توجد شموع كافية للرسم في الإطار المختار.');window.latestChartPayload=data;chartUI.candles.setData(data.candles.map(x=>({time:x.time,open:x.open,high:x.high,low:x.low,close:x.close})));chartUI.candles.applyOptions({lastValueVisible:false,priceLineVisible:false});chartUI.ma20.setData(data.overlays?.ma20||[]);chartUI.ma50.setData(data.overlays?.ma50||[]);chartUI.volume.setData(data.candles.map(x=>({time:x.time,value:x.volume,color:x.close>=x.open?'rgba(114,195,106,.28)':'rgba(222,125,128,.28)'})));renderChartOverlays(data);chartUI.loadedTimeframe=id;document.getElementById('chartTitle').textContent=`XAUUSD · ${esc(data.timeframe?.label||id)}`;const age=Number(data.last_candle_age_seconds);const isReference=data.reference_only!==false;const candleLabel=isReference?'آخر إغلاق مرجعي':'آخر إغلاق من شموع وسيط MT5 (قراءة فقط)';const freshness=Number.isFinite(age)&&age<120?(isReference?'شمعة مرجعية حديثة':'شمعة وسيط حديثة'):(isReference?'إغلاق مرجعي متأخر / السوق مغلق':'شمعة وسيط متأخرة');document.getElementById('chartStatus').textContent=`${esc(data.source||'—')} · ${candleLabel}: ${num(data.last_candle_close)} · وقت الشمعة: ${esc(data.last_candle_time||'—')} · ${freshness}`;if(fit)chartUI.chart.timeScale().fitContent();}catch(error){const message=error?.message||'تعذر تحميل الرسم. أعد المحاولة لاحقاً.';host.innerHTML=`<div class="chartError">${esc(message)}</div>`;document.getElementById('chartStatus').textContent=message;chartUI.chart=null;}}
	function compactCandleTime(value){const raw=String(value||'').trim(),match=raw.match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);return match?`${match[3]}/${match[2]} · ${match[4]}:${match[5]}`:raw;}
function renderTimeframes(rows){const visibleIds=readTimeframeFilter(rows),ordered=sortTimeframesAscending(rows).filter(row=>visibleIds.includes(row.id));document.getElementById('timeframes').innerHTML=ordered.map(r=>{const fullTime=r.last_candle_time?String(r.last_candle_time):'لا توجد شموع',shortTime=r.last_candle_time?compactCandleTime(r.last_candle_time):fullTime;return `<button type="button" class="tf ${r.id===selectedTimeframe?'active':''} ${loadingTimeframe&&r.id===selectedTimeframe?'loading':''}" data-timeframe="${esc(r.id)}" aria-pressed="${r.id===selectedTimeframe}" aria-label="${esc(r.label)} — ${esc(fullTime)}"><div class="tfLabel">${esc(r.label)}</div><div class="tfAction ${String(r.action).includes('شراء')?'buy':String(r.action).includes('بيع')?'sell':'neutral'}">${actionText(r.action)}</div><div class="tfCandle" title="${esc(fullTime)}">${esc(shortTime)}</div></button>`}).join('')||'<div class="empty">اختر تسعة أطر لعرضها في منطقة التقييم.</div>';document.querySelectorAll('[data-timeframe]').forEach(b=>b.addEventListener('click',()=>selectTimeframe(b.dataset.timeframe)));renderTimeframeFilter(rows);window.dispatchEvent(new CustomEvent('xauusd:timeframe-selected',{detail:{id:selectedTimeframe}}));}
function renderPivots(p){if(!p)return; const group=(title,data)=>`<div class="pivotGroup"><div class="groupTitle">${title}</div><div class="pivotRow"><div>مرحلة</div><div>تقليدي</div><div>Fibonacci</div></div>${['R3','R2','R1','Pivot','S1','S2','S3'].map(k=>`<div class="pivotRow"><div>${k}</div><div class="${k==='Pivot'?'pivotP':k.startsWith('R')?'pivotR':'pivotS'} value">${num(data?.traditional?.[k])}</div><div class="${k==='Pivot'?'pivotP':k.startsWith('R')?'pivotR':'pivotS'} value">${num(data?.fibonacci?.[k])}</div></div>`).join('')}</div>`; document.getElementById('pivots').innerHTML=group('المرجع: آخر شمعة مكتملة',p);}
function renderMAs(rows){if(!rows||!rows.length){document.getElementById('movingAverages').innerHTML='<div class="empty">لا توجد شموع كافية.</div>';return}document.getElementById('movingAverages').innerHTML=`<table class="dataTable"><thead><tr><th>المؤشر</th><th>بسيط</th><th>أسي</th><th>التقييم</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${esc(r.name)}</b></td><td class="value">${num(r.simple)}</td><td class="value">${num(r.exponential)}</td><td class="${cls(r.action)}">${actionText(r.action)}</td></tr>`).join('')}</tbody></table>`;}
function renderIndicators(rows){if(!rows||!rows.length){document.getElementById('indicators').innerHTML='<div class="empty">لا توجد شموع كافية.</div>';return}document.getElementById('indicators').innerHTML=`<table class="dataTable"><thead><tr><th>الرمز</th><th>القيمة</th><th>التصرف</th></tr></thead><tbody>${rows.map(r=>`<tr><td><b>${esc(r.name)}</b></td><td class="value">${num(r.value,4)}</td><td class="${cls(r.action)}">${actionText(r.action)}</td></tr>`).join('')}</tbody></table>`;}
function renderSignalLayers(data){const box=document.getElementById('signalLayers');if(!box)return;if(!data){box.innerHTML='<div class="empty">لا توجد طبقات مبسطة متاحة.</div>';return}const zones=data.zones||{},trend=data.trend||{};const badge=(bias)=>bias==='صاعد'||bias==='شراء مشروط'?'cellBuy':bias==='هابط'||bias==='بيع مشروط'?'cellSell':'cellNeutral';const zoneItems=(zones.items||[]).slice(0,8);const zoneRows=zoneItems.map((item,index)=>`<div class="toolLevels"><button type="button" class="toolLevel zoneFocusPill" data-zone-focus-index="${index}" aria-label="فتح رسم ${esc(item.source||'منطقة')} ${esc(item.label||'')}"><b>${esc(item.source||'منطقة')}</b> · ${esc(item.label||'—')} · ${num(item.lower)}–${num(item.upper)} · ${num(item.quality_score,0)}/100 <span class="zoneFocusHint">فتح الرسم</span></button></div>`).join('');box.innerHTML=`<div class="signalLayerGrid"><article class="toolCard"><div class="toolHead"><span class="toolTitle">خريطة المناطق السعرية</span><span class="badge ${badge(zones.status)}">${esc(zones.status||'غير حاسم')}</span></div><div class="toolDetails">${esc(zones.summary||'—')}</div>${zoneRows||'<div class="empty">لا توجد منطقة مؤهلة للعرض كمرجع.</div>'}<div class="small">${esc(zones.basis||'OHLC + pivots')} — اضغط على أي منطقة لفتح رسمها؛ المناطق المرصودة ليست Order Flow حقيقياً.</div></article><article class="toolCard"><div class="toolHead"><span class="toolTitle">اتجاه السعر</span><span class="badge ${badge(trend.bias)}">${esc(trend.status||'غير حاسم')} · ${esc(trend.bias||'محايد')}</span></div><div class="toolDetails">${esc(trend.summary||'—')}</div><div class="signalLevels"><div class="level"><span>EMA20 / EMA50</span><strong class="value">${num(trend.ema20)} / ${num(trend.ema50)}</strong></div><div class="level"><span>ADX / RSI</span><strong>${num(trend.adx,1)} / ${num(trend.rsi,1)}</strong></div></div><div class="small">${esc(trend.basis||'مؤشرات محسوبة من OHLC')} — لا يُستخدم RSI أو ADX كتصويت مستقل.</div></article></div><div class="notice"><b>${esc(data.decision||'انتظار / حياد')}</b> — ${esc(data.decision_reason||'—')}</div>`;box.querySelectorAll('[data-zone-focus-index]').forEach(button=>button.addEventListener('click',()=>window.openZoneFocus?.(zoneItems[Number(button.dataset.zoneFocusIndex)])));}
		function renderIntradayRecommendation(r){renderIntradayAlert(r);const box=document.getElementById('intradayRecommendation');if(!box)return;if(!r){box.innerHTML='<div class="empty">لا توجد قراءة لحظية.</div>';return}const state=r.decision_state==='signal'?(String(r.signal||'').includes('بيع')?'cellSell':'cellBuy'):r.decision_state==='blocked'?'cellSell':'cellNeutral';box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(r.signal||'انتظار / حياد')}</span><span class="badge ${state}">${esc(r.decision_state==='signal'?'إشارة مشروطة':r.decision_state==='blocked'?'محجوبة':'انتظار')}</span></div><div class="toolDetails">${esc(r.reason||'—')}</div><div class="signalLevels"><div class="level"><span>تقاطع EMA20/EMA50</span><strong>${esc(r.cross_state||'—')}</strong></div><div class="level"><span>المنطقة السعرية</span><strong>${esc(r.zone_state||'—')}</strong></div><div class="level"><span>تأكيد RSI(14)</span><strong>${esc(r.rsi_state||'—')}</strong></div><div class="level"><span>الثقة</span><strong>${r.confidence===undefined?'—':num(r.confidence,1)+'%'}</strong></div></div>${r.decision_state==='signal'?`<div class="signalLevels"><div class="level"><span>الدخول المرجعي</span><strong class="value">${num(r.entry)}</strong></div><div class="level"><span>وقف / هدف</span><strong class="value">${num(r.stop_loss)} / ${num(r.take_profit)}</strong></div><div class="level"><span>العائد/المخاطرة</span><strong>1:${num(r.risk_reward,2)}</strong></div></div>`:''}${(r.evidence||[]).length?`<div class="toolLevels">${r.evidence.map(item=>`<span class="toolLevel">${esc(item)}</span>`).join('')}</div>`:''}${(r.warnings||[]).length?`<div class="notice">${r.warnings.map(esc).join('<br>')}</div>`:''}<div class="small">توصية مرجعية لحظية مشروطة؛ لا تنفذ أوامر ولا تحول السعر العام إلى Bid/Ask.</div></article>`;}
		function renderIntradayAlert(recommendation){const box=document.getElementById('intradayAlerts');const status=document.getElementById('intradayAlertStatus');const muteButton=document.getElementById('intradayAlertMute');if(!box||!status)return;const muteKey='xauusd-intraday-alerts-muted';let muted=localStorage.getItem(muteKey)==='1';if(muteButton){muteButton.classList.toggle('on',!muted);muteButton.textContent=muted?'التنبيهات مكتومة':'كتم التنبيهات';if(!muteButton.dataset.bound){muteButton.dataset.bound='1';muteButton.addEventListener('click',()=>{const next=localStorage.getItem(muteKey)==='1'?'0':'1';localStorage.setItem(muteKey,next);renderIntradayAlert(recommendation);});}}if(!recommendation){status.textContent='لا توجد قراءة لحظية بعد.';return}const quote=latestSystem?.quote||{};const sourceFresh=quote.status==='success'&&!quote.stale&&quote.live_for_analysis===true;const confirmed=recommendation.decision_state==='signal'&&/شراء|بيع/.test(String(recommendation.signal||''))&&/يؤكد الزخم/.test(String(recommendation.rsi_state||''));if(!confirmed){status.textContent=recommendation.decision_state==='blocked'?'التنبيه محجوب: مصدر السعر غير صالح أو متأخر.':(recommendation.rsi_state||'بانتظار توافق EMA20/EMA50 مع RSI.');return}if(!sourceFresh){status.textContent='توجد إشارة مرجعية، لكن التنبيه محجوب حتى يصبح مصدر السعر حديثاً وقابلاً للتحليل.';return}const direction=String(recommendation.signal).includes('بيع')?'بيع':'شراء';const fingerprint=[selectedTimeframe,direction,recommendation.rsi_state,recommendation.zone_level,recommendation.entry].join('|');const lastKey='xauusd-intraday-alert-last';const previous=localStorage.getItem(lastKey);const message=`تنبيه ${direction}: تقاطع EMA20/EMA50 مؤكد بـ RSI — ${recommendation.zone_state||'منطقة سعرية مؤهلة'}`;status.innerHTML=`<b class="${direction==='شراء'?'cellBuy':'cellSell'}">${esc(message)}</b><br><span class="small">${muted?'التنبيهات مكتومة محلياً.':'تمت مراقبة الشرط داخل الصفحة.'}</span>`;if(previous===fingerprint||muted)return;localStorage.setItem(lastKey,fingerprint);const title=`XAUUSD — ${direction} مشروط`;if('Notification' in window&&Notification.permission==='granted')new Notification(title,{body:message});const toast=document.createElement('div');toast.className='intradayAlertToast';toast.setAttribute('role','status');toast.innerHTML=`<b>${esc(title)}</b><br>${esc(message)}<button type="button" aria-label="إغلاق التنبيه">×</button>`;document.body.appendChild(toast);toast.querySelector('button').addEventListener('click',()=>toast.remove());}
function installIntradayAlertPermission(){const button=document.getElementById('intradayAlertPermission');if(!button||button.dataset.bound)return;button.dataset.bound='1';button.addEventListener('click',async()=>{if(!('Notification' in window)){button.textContent='غير مدعوم في المتصفح';return}const permission=await Notification.requestPermission();button.textContent=permission==='granted'?'إشعارات النظام مفعلة':permission==='denied'?'الإشعارات مرفوضة':'تفعيل إشعارات النظام';});}installIntradayAlertPermission();
		function renderScenarioTable(data){const box=document.getElementById('scenarioTable');if(!box)return;const rows=Array.isArray(data?.rows)?data.rows:[];const header='<thead><tr><th>نوع السيناريو</th><th>الاتجاه</th><th>نقطة التفعيل</th><th>الدخول المرجعي</th><th>الإبطال / الوقف</th><th>الهدف الأول</th><th>العائد/المخاطرة</th><th>الثقة</th><th>الأنسب لمن؟</th></tr></thead>';const cells=rows.map(row=>`<tr><td class="scenarioType">${esc(row.scenario_type)}<br><span class="small">${esc(row.source_mode||'تحليل مرجعي')}</span></td><td class="${String(row.direction).includes('شراء')?'cellBuy':'cellSell'}">${esc(row.direction)}</td><td>${esc(row.activation)}</td><td class="value">${num(row.entry)}</td><td class="value">${num(row.stop_loss)}</td><td class="value">${num(row.take_profit)}</td><td>1:${num(row.risk_reward,2)}</td><td>${num(row.confidence,1)}%</td><td>${esc(row.fit)}</td></tr>`).join('');const empty=`<tr><td class="scenarioEmpty" colspan="9">${esc(data?.message||'لا توجد سيناريوهات مؤهلة الآن.')}</td></tr>`;box.innerHTML=`<div class="panelHead">سيناريوهات وتوصيات التعامل <small>${esc(data?.status||'بانتظار التقييم')}</small></div><p class="scenarioIntro">يعرض الجدول السيناريوهات التحليلية المرجعية عند حداثة سعر السوق وتكامل الشموع والمستويات. اسحب الجدول أفقياً لرؤية جميع الأعمدة؛ المستويات ليست Bid/Ask تنفيذيين.</p><div class="scenarioTableWrap"><table class="scenarioTable">${header}<tbody>${cells||empty}</tbody></table></div><div class="scenarioStatus">${esc(data?.basis||'—')}<br>${esc(data?.message||'—')}</div>`;}
	function renderRecommendation(r){renderIntradayRecommendation(r?.intraday_recommendation);renderScenarioTable(r?.scenario_table);const state=r.decision_state==='signal'?'cellBuy':r.decision_state==='neutral'?'cellNeutral':'cellSell';document.getElementById('recommendation').innerHTML=`<div class="signalMain ${state}" style="padding:8px 10px;border-radius:9px;display:inline-block">${esc(r.signal||'انتظار / لا قرار')}</div><div class="signalReason">${esc(r.reason||'—')}</div><div class="signalLevels"><div class="level"><span>الثقة</span><strong>${r.confidence===undefined?'—':num(r.confidence,1)+'%'}</strong></div><div class="level"><span>الدخول المرجعي</span><strong class="value">${num(r.entry)}</strong></div><div class="level"><span>وقف / هدف</span><strong class="value">${num(r.stop_loss)} / ${num(r.take_profit)}</strong></div></div>${r.risk_reward!==null&&r.risk_reward!==undefined?`<div class="toolQuality">نسبة العائد إلى المخاطرة: 1:${num(r.risk_reward,2)}</div>`:''}<div class="toolLevels">${(r.evidence||[]).map(item=>`<span class="toolLevel">${esc(item)}</span>`).join('')}</div>${(r.warnings||[]).length?`<div class="notice">${r.warnings.map(esc).join('<br>')}</div>`:''}<div class="small">${esc(r.data_mode||'—')} · هذه قراءة تحليلية وليست ضماناً؛ القرار والتنفيذ مسؤوليتك.</div>`;renderMomentumInteraction(r.momentum_liquidity_news);}
function renderMomentumInteraction(data){const box=document.getElementById('momentumInteraction');if(!box)return;if(!data){box.innerHTML='<div class="empty">لا توجد قراءة مكتملة للتفاعل بعد.</div>';return}const state=data.decision_effect==='رفع الثقة'||data.decision_effect==='تأكيد بحذر'?'cellBuy':data.decision_effect==='منع دخول جديد'||data.decision_effect==='تحويل إلى حياد'?'cellSell':'cellNeutral';box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(data.status||'—')}</span><span class="badge ${state}">${esc(data.decision_effect||'لا تعديل')}</span></div><div class="toolDetails">${esc(data.summary||'—')}</div><div class="signalLevels"><div class="level"><span>تعديل الثقة</span><strong>${Number(data.confidence_adjustment)>=0?'+':''}${num(data.confidence_adjustment,1)} نقطة</strong></div><div class="level"><span>مصدر الزخم</span><strong>RSI · MACD · ROC · ADX</strong></div><div class="level"><span>مصدر السيولة</span><strong>OHLC + مناطق</strong></div></div>${(data.components||[]).map(item=>`<div class="toolLevels"><span class="toolLevel"><b>${esc(item.name)}</b>: ${esc(item.bias)} · ${esc(item.details)}</span></div>`).join('')}${(data.limitations||[]).length?`<div class="notice">${data.limitations.map(esc).join('<br>')}</div>`:''}<div class="small">القياس يستند إلى الشموع المتاحة وبنية المناطق. لا يساوي Order Flow أو مفاجأة خبر حية دون مصدر موثق.</div></article>`;}
function renderOrderFlow(flow){const box=document.getElementById('realOrderFlow');if(!box)return;const eligible=flow?.eligible_for_decision===true;const biasClass=flow?.bias==='شراء'?'cellBuy':flow?.bias==='بيع'?'cellSell':'cellNeutral';if(!eligible){box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(flow?.status||'غير متاح')}</span><span class="badge cellNeutral">لا وزن في القرار</span></div><div class="toolDetails">${esc(flow?.message||'لا توجد تغذية تدفق موثقة.')}</div><div class="toolLevels">${(flow?.requirements||['Bid/Ask حديثان','Depth of Market','صفقات أو أحجام شراء/بيع فعلية']).map(item=>`<span class="toolLevel">${esc(item)}</span>`).join('')}</div><div class="small">لن تستخدم المنصة شموع OHLC أو Volume Profile التقريبي كبديل عن Order Flow الحقيقي.</div></article>`;return}box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(flow.status)}</span><span class="badge ${biasClass}">${esc(flow.bias)} · ${num(flow.confidence,1)}%</span></div><div class="toolDetails">${esc(flow.source)}<br>${esc(flow.message)}</div><div class="signalLevels"><div class="level"><span>Bid / Ask</span><strong class="value">${num(flow.bid)} / ${num(flow.ask)}</strong></div><div class="level"><span>DOM</span><strong>${num(flow.dom_levels,0)} مستوى</strong></div><div class="level"><span>العمر</span><strong>${num(flow.age_seconds,1)} ث</strong></div></div><div class="toolLevels"><span class="toolLevel">عمق Bid: ${num(flow.bid_depth,2)}</span><span class="toolLevel">عمق Ask: ${num(flow.ask_depth,2)}</span><span class="toolLevel">عدم توازن DOM: ${num(Number(flow.depth_imbalance)*100,1)}%</span><span class="toolLevel">عدم توازن الصفقات: ${num(Number(flow.trade_imbalance)*100,1)}%</span></div><div class="small">تؤثر هذه الطبقة في الثقة فقط عندما تكون Bid/Ask وDOM والصفقات مكتملة وحديثة.</div></article>`;}
function renderLiquidity(l){const has=Number.isFinite(Number(l?.liquidity_score));document.getElementById('liquidity').innerHTML=`<table class="dataTable"><tbody><tr><td>الحالة</td><td>${esc(l?.liquidity_status||'غير متاح')}</td></tr><tr><td>جودة السيولة</td><td>${has?num(l.liquidity_score,0)+'/100':'غير قابلة للقياس'}</td></tr><tr><td>خطر فخ</td><td class="${l?.trap_detected?'cellSell':'cellNeutral'}">${l?.trap_detected?'تحذير فخ محتمل':'لا دليل كافٍ'}</td></tr></tbody></table>${(l?.alerts||[]).map(a=>`<div class="notice">${esc(a)}</div>`).join('')}`;}
		function renderAdvancedTools(advanced){const box=document.getElementById('advancedTools');const tools=advanced?.tools;if(!tools){box.innerHTML='<div class="empty">لا توجد بيانات كافية لأدوات بنية السوق.</div>';return}const labels={liquidity_sweep:'Liquidity Sweep',liquidity_zones:'مناطق السيولة',support_resistance:'دعم ومقاومة',order_blocks:'Order Blocks',order_flow:'Order Flow',anchored_vwap:'Anchored VWAP',volume_profile:'Volume Profile',fibonacci:'Fibonacci',fair_value_gap:'Fair Value Gap'};const order=['liquidity_sweep','liquidity_zones','support_resistance','order_blocks','order_flow','anchored_vwap','volume_profile','fibonacci','fair_value_gap'];const badge=(bias)=>bias==='صاعد'?'cellBuy':bias==='هابط'?'cellSell':'cellNeutral';const con=advanced?.confluence||{};const mtf=advanced?.multi_timeframe||{};box.innerHTML=`<div class="notice">${esc(con.bias||'توافق محدود')} — أدوات مؤهلة: ${esc(con.qualified_tools??0)} · متوسط الجودة: ${num(con.average_quality,0)}/100<br>${esc(con.details||'')}<br><span class="small">توافق الإطار الأعلى: ${esc(mtf.status||'غير متاح')} — ${esc(mtf.details||'')}</span></div>${order.map(key=>{const item=tools[key]||{};const levels=Object.entries(item.levels||{}).map(([name,value])=>`<span class="toolLevel">${esc(name)}: <b class="value">${num(value)}</b></span>`).join('');const zones=(item.zones||[]).slice(0,3).map(zone=>`<span class="toolLevel">${esc(zone.label||zone.kind)} · ${num(zone.lower)}–${num(zone.upper)} · ${num(zone.quality_score,0)}/100</span>`).join('');return `<article class="toolCard"><div class="toolHead"><span class="toolTitle">${labels[key]}</span><span class="badge ${badge(item.bias)}">${esc(item.status||'غير متاح')} · ${esc(item.bias||'—')}</span></div><div class="toolDetails">${esc(item.details||'—')}</div>${levels?`<div class="toolLevels">${levels}</div>`:''}${zones?`<div class="toolLevels">${zones}</div>`:''}${item.anchor_at?`<div class="toolQuality">المرساة/النطاق: ${esc(item.anchor_at)}</div>`:''}<div class="toolQuality">جودة البيانات: ${esc(item.quality||'—')} · درجة القاعدة: ${num(item.quality_score,0)}/100</div></article>`;}).join('')}`;}
		function renderIndicatorCombinations(rows){const box=document.getElementById('indicatorCombinations');if(!box)return;if(!rows?.length){box.innerHTML='<div class="empty">لا توجد تركيبة مؤشرات مؤهلة.</div>';return}box.innerHTML=rows.map(item=>`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(item.title)}</span><span class="badge cellNeutral">${esc(item.status)}</span></div><div class="toolDetails">${esc(item.reading)}</div><div class="toolLevels">${(item.components||[]).map(component=>`<span class="toolLevel">${esc(component)}</span>`).join('')}</div><div class="toolQuality">الشرط: ${esc(item.when)}<br>تنبيه: ${esc(item.caution)}</div></article>`).join('');}
		function renderAIAnalysis(data){const box=document.getElementById('aiAnalysisPanel');if(!box)return;const scope=data?.data_scope||{};box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(data?.title||'تحليل AI')}</span><span class="badge ${data?.scenario?.includes('شراء')?'cellBuy':data?.scenario?.includes('بيع')?'cellSell':'cellNeutral'}">${esc(data?.status||'غير متاح')} · ${esc(data?.scenario||'—')}</span></div><div class="toolDetails">${esc(data?.summary||'—')}</div><div class="signalLevels"><div class="level"><span>الثقة</span><strong>${num(data?.confidence,1)}%</strong></div><div class="level"><span>الدخول</span><strong class="value">${num(data?.entry)}</strong></div><div class="level"><span>وقف / هدف</span><strong class="value">${num(data?.stop_loss)} / ${num(data?.take_profit)}</strong></div></div><div class="toolQuality">الإبطال: ${esc(data?.invalidation||'—')}<br>النطاق: ${esc(scope.source||'—')} · قابل للتنفيذ: ${scope.tradable?'نعم':'لا'} · العمر: ${num(scope.age_seconds,0)} ثانية</div>${(data?.conditions||[]).length?`<div class="toolLevels">${data.conditions.map(value=>`<span class="toolLevel">${esc(value)}</span>`).join('')}</div>`:''}${(data?.risks||[]).length?`<div class="notice">${data.risks.map(esc).join('<br>')}</div>`:''}<div class="small">تحليل آلي مشروط، وليس نصيحة استثمارية مضمونة أو أمراً لتنفيذ صفقة.</div></article>`;}
		async function requestAIAnalysis(id=selectedTimeframe){const box=document.getElementById('aiAnalysisPanel');if(box)box.innerHTML='<div class="empty">جارِ التحقق من صلاحية البيانات قبل التحليل...</div>';try{const response=await fetch('/api/ai-analysis/'+encodeURIComponent(id),{cache:'no-store'});const data=await response.json();if(!response.ok||data.error)throw new Error(data.error||'تعذر تحليل AI');renderAIAnalysis(data);}catch(error){if(box)box.innerHTML=`<div class="notice">${esc(error.message||'تعذر تحليل AI')}</div>`;}}
function renderInstitutional(i){document.getElementById('institutional').innerHTML=`<div class="notice">${esc(i?.message||'القيم المؤسسية العامة ليست لحظية.')}</div><table class="dataTable"><thead><tr><th>المصدر</th><th>القيمة</th><th>التأخر</th></tr></thead><tbody>${(i?.items||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${x.value===null?'غير متاح لحظياً':esc(x.value)}</td><td>${esc(x.lag)}</td></tr>`).join('')}</tbody></table>`;}
function renderNews(n){document.getElementById('newsPanel').innerHTML=`<div class="notice">الحالة: ${esc(n?.status)} — ${esc(n?.message)}</div><table class="dataTable"><thead><tr><th>التقرير</th><th>التكرار</th><th>الأثر</th></tr></thead><tbody>${(n?.events||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.frequency)}</td><td>${esc(x.impact)}</td></tr>`).join('')}</tbody></table>`;}
	function renderSignalTotals(id,summary){const box=document.getElementById(id);if(!box)return;const s=summary||{};const buy=Number(s.buy||0),sell=Number(s.sell||0),neutral=Number(s.neutral??s.neutral_count??0),total=buy+sell+neutral;box.innerHTML=`<div class="signalTotal buy"><b>${buy}</b><span>شراء</span></div><div class="signalTotal sell"><b>${sell}</b><span>بيع</span></div><div class="signalTotal neutral"><b>${neutral}</b><span>حياد · الإجمالي ${total}</span></div>`;} function renderTechnical(t,frame){if(!t){document.getElementById('pivots').innerHTML='<div class="empty">تعذر جلب شموع الإطار المختار.</div>';document.getElementById('movingAverages').innerHTML='<div class="empty">لا توجد بيانات كافية.</div>';document.getElementById('indicators').innerHTML='<div class="empty">لا توجد بيانات كافية.</div>';renderSignalTotals('maTotals',null);renderSignalTotals('indicatorTotals',null);document.getElementById('advancedTools').innerHTML='<div class="empty">لا توجد بيانات كافية لأدوات بنية السوق.</div>';renderSignalLayers(null);return}document.getElementById('maSummary').textContent=`${t.moving_average_summary.buy} شراء / ${t.moving_average_summary.sell} بيع`;document.getElementById('indicatorSummary').textContent=`${t.indicator_summary.buy} شراء / ${t.indicator_summary.sell} بيع`;document.getElementById('technicalConfidence').textContent=num(t.technical_confidence,1)+'%';document.getElementById('bars').textContent=esc(t.bars);document.getElementById('lastCandle').textContent=esc(t.last_candle_time);document.getElementById('timeframeInfo').textContent=`الإطار المختار: ${esc(frame?.label||'—')} · آخر شمعة: ${esc(t.last_candle_time)}`;renderSignalTotals('maTotals',t.moving_average_summary);renderSignalTotals('indicatorTotals',t.indicator_summary);renderPivots(t.pivots);renderMAs(t.moving_averages);renderIndicators(t.indicators);renderAdvancedTools(t.advanced_tools);renderSignalLayers(t.signal_layers);renderIndicatorCombinations(t.indicator_combinations);}
function renderExternalReference(x){const container=document.getElementById('externalReference');if(!container)return;const marketStatus=x?.market_data_status||'غير معروف';const tvUrl=x?.tradingview_url;const tvSymbol=x?.tradingview_symbol||'—';const tv=tvUrl?`<a href="${esc(tvUrl)}" target="_blank" rel="noopener noreferrer" style="color:#f3d98e;font-weight:700">فتح مخطط TradingView (${esc(tvSymbol)})</a>`:'لا يوجد رابط TradingView';const comparison=x?.spot_futures_comparison||{};const sync=comparison.synchronized||{};const n=(v,d=2)=>v===null||v===undefined||Number.isNaN(Number(v))?'—':Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});const futuresRows=(comparison.futures?.days||[]).map(day=>`<tr><td>${esc(day.date_utc||'—')}</td><td>${n(day.open)}</td><td>${n(day.close)}</td><td>${n(day.high)}</td><td>${n(day.low)}</td></tr>`).join('');const comparisonHtml=comparison.status==='success'?`<div class="referenceComparison"><b>مقارنة الذهب الفوري والآجل — مرجعان مختلفان زمنياً</b><div class="small">الفوري: ${esc(comparison.spot?.symbol||'XAU/USD')} من gold-api.com · الآجل: ${esc(comparison.futures?.symbol||'GC=F')} من Yahoo Finance.</div><div class="small">السعر الفوري العام: ${n(sync.spot_close,4)} · وقته: ${esc(sync.spot_timestamp_utc||comparison.spot?.timestamp_utc||'—')}<br>آخر إغلاق آجل: ${n(sync.futures_close,4)} · وقته: ${esc(sync.futures_timestamp_utc||comparison.futures?.timestamp_utc||'—')}<br>لا يوجد توقيت مشترك أو تاريخ فوري يومي في هذا المسار.</div>${futuresRows?`<table><thead><tr><th>يوم الآجل UTC</th><th>افتتاح آجل</th><th>إغلاق آجل</th><th>أعلى آجل</th><th>أدنى آجل</th></tr></thead><tbody>${futuresRows}</tbody></table>`:''}<div class="small">الفارق (الآجل − الفوري): <b>${n(sync.basis,4)}</b> (${n(sync.basis_pct,4)}%) · ${esc(comparison.interpretation||'—')}</div><div class="notice">${esc(comparison.recommendation?.signal||'محايد / انتظار')}: ${esc(comparison.recommendation?.spot_mt5_action||'لا قرار من الفارق وحده')}<br>${esc(comparison.recommendation?.reason||'')}</div></div>`:`<div class="notice">مقارنة الفوري والآجل غير متاحة: ${esc(comparison.message||'تعذر جلب المرجعين.')}</div>`;container.innerHTML=`<b>المصدر المرئي المعتمد: ${esc(x?.preferred_visual_reference||'TradingView')}</b><br>هدف مصدر السوق: ${esc(x?.market_reference_target||'XAUUSD — مصدر سوق عام مستقل')}<br>الحالة: ${esc(marketStatus)}<br>جسر MT5: ${esc(x?.bridge_status||'غير معروف')}<br>${tv}<br><span class="small">${esc(x?.tradingview_status||'TradingView مرجع سياقي منفصل عن سعر التنفيذ.')}<br>${esc(x?.phone_only_guidance||'')}</span>${comparisonHtml}`;}
				function renderSelectedFrameAnalysis(payload){const frame=payload?.timeframe||{},recommendation=payload?.recommendation||{};selectedFramePayload=payload||null;renderTechnical(frame.technical,frame);renderSignalLayers(frame.signal_layers);window.renderObFvgStrategy?.(frame.ob_fvg_strategy,frame);renderRecommendation(recommendation);renderOrderFlow(recommendation.real_order_flow||latestSystem?.order_flow);window.renderDataTransparency?.(payload?.data_transparency);renderSelectedFrameContext(frame,recommendation);}
				async function selectTimeframe(id){if(!id||loadingTimeframe)return;selectedTimeframe=id;selectedFramePayload=null;try{localStorage.setItem('xauusd-selected-timeframe',id)}catch(_){}loadingTimeframe=true;renderTimeframes(latestSystem?.timeframes||[]);document.getElementById('timeframeInfo').textContent='جارِ احتساب تحليل الإطار المختار من شموعه واستراتيجياته...';renderSelectedFrameContext({label:(latestSystem?.timeframes||[]).find(row=>row.id===id)?.label||id},{signal:'جارِ التحميل'});try{const r=await fetch('/api/timeframe/'+encodeURIComponent(id),{cache:'no-store'});const payload=await readApiJson(r,'تعذر تحميل الإطار الزمني');if(payload.error)throw new Error(payload.error);renderSelectedFrameAnalysis(payload);await loadChart(id,true);}catch(e){document.getElementById('timeframeInfo').textContent='تعذر تحميل الإطار المختار: '+esc(e.message);document.getElementById('recommendation').innerHTML='<div class="signalReason">لا يتم استخدام لقطة إطار آخر كبديل عند فشل التحميل.</div>';renderMomentumInteraction(null);renderSelectedFrameContext({label:id},{signal:'تعذر تحميل تحليل الإطار'});}finally{loadingTimeframe=false;renderTimeframes(latestSystem?.timeframes||[]);}}
		function renderPriceDirection(q,isFresh){const box=document.getElementById('priceDirection'),arrow=document.getElementById('priceDirectionArrow'),text=document.getElementById('priceDirectionText');if(!box||!arrow||!text)return;const direction=isFresh?String(q.price_direction||'neutral'):'neutral';const labels={up:'ارتفع',down:'انخفض',flat:'دون تغير',neutral:'بانتظار المقارنة'};const arrows={up:'▲',down:'▼',flat:'↔',neutral:'↔'};box.className='priceDirection '+(['up','down','flat'].includes(direction)?direction:'neutral');arrow.textContent=arrows[direction]||arrows.neutral;if(direction==='up'||direction==='down'){const sign=direction==='up'?'+':'−';text.textContent=`${labels[direction]} ${sign}${num(Math.abs(Number(q.tick_change)))} (${sign}${num(Math.abs(Number(q.tick_change_pct)),3)}%)`;box.title=`مقارنة gold-api.com: ${num(q.previous_price)} ← ${num(q.last_price)}`}else{text.textContent=isFresh?(q.price_direction_label||labels[direction]):'المصدر متأخر / لا مقارنة';box.title=q.price_direction_label||'لا تتوفر قراءة gold-api.com حديثة للمقارنة';}}
			async function update(){try{const r=await fetch('/api/system-status',{cache:'no-store'});const d=await readApiJson(r,'تعذر تحديث حالة المنصة');latestSystem=d;if(!selectedTimeframe)selectedTimeframe=d.default_timeframe_id||'1d';const q=d.quote||{};const quoteFailed=q.status!=='success';document.getElementById('systemStatus').innerHTML=`<span class="dot" style="background:${quoteFailed?'#de7d80':q.stale?'#e0ad44':'#72c36a'}"></span>${esc(d.status)}`;document.getElementById('lastRefresh').textContent='آخر تسعير: '+esc(d.last_quote_refresh||d.last_refresh||'—');const isFreshMarketPrice=q.status==='success'&&!q.stale&&q.live_for_analysis===true;renderPriceDirection(q,isFreshMarketPrice);if(isFreshMarketPrice){document.getElementById('price').textContent=num(q.last_price);const hasChange=q.change!==null&&q.change!==undefined&&q.change_pct!==null&&q.change_pct!==undefined;document.getElementById('change').textContent=hasChange?((Number(q.change)>=0?'+':'')+num(q.change)+' ('+(Number(q.change_pct)>=0?'+':'')+num(q.change_pct,2)+'%)'):(q.broker_quote_eligible?'سعر وسيط للقراءة فقط':'سعر سوق حديث');}else{document.getElementById('price').textContent='—';document.getElementById('change').textContent=q.stale?'السوق مغلق / سعر متأخر':'لا يوجد سعر سوق حديث';}if(q.status==='success'){const brokerDetails=q.broker_quote_eligible?` · Bid ${num(q.bid)} / Ask ${num(q.ask)} · Spread ${num(q.spread,5)}`:'';document.getElementById('quoteSub').textContent=(q.message||q.source||'—')+brokerDetails+' — '+(q.utc_time||'—');document.getElementById('symbol').textContent=q.symbol||'XAUUSD';document.getElementById('source').textContent=q.source||'—';document.getElementById('sourceSymbol').textContent=q.source_symbol||q.symbol||'—';document.getElementById('age').textContent=q.age_seconds===undefined?'—':num(q.age_seconds,0)+' ثانية';}else{document.getElementById('quoteSub').textContent=q.message||'لا يوجد سعر حي موثوق';}renderTimeframes(d.timeframes);if(selectedTimeframe===(d.default_timeframe_id||'1d')&&!loadingTimeframe&&(!selectedFramePayload||selectedFramePayload.timeframe?.id!==selectedTimeframe)){renderSelectedFrameAnalysis({timeframe:{id:selectedTimeframe,label:(d.timeframes||[]).find(x=>x.id===selectedTimeframe)?.label||'يومي',technical:d.technical,signal_layers:d.signal_layers,ob_fvg_strategy:d.ob_fvg_strategy},recommendation:d.recommendation,data_transparency:d.data_transparency});}renderLiquidity(d.liquidity);renderInstitutional(d.institutional);renderNews(d.news);renderExternalReference(d.external_reference);if(!chartUI.loadedTimeframe)loadChart(selectedTimeframe,true);}catch(e){document.getElementById('systemStatus').innerHTML='<span class="dot" style="background:#de7d80"></span>'+esc(e?.message||'تعذر الاتصال');}}
	function ensureZoneLayer(){const host=document.getElementById('chartCanvas');if(!host||chartUI.zoneLayer?.isConnected)return chartUI.zoneLayer;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','chartZoneLayer');svg.setAttribute('aria-hidden','true');host.appendChild(svg);chartUI.zoneLayer=svg;if(!chartUI.zoneSubscribed){chartUI.zoneSubscribed=true;chartUI.chart?.timeScale().subscribeVisibleTimeRangeChange(queueZoneDraw);window.addEventListener('resize',queueZoneDraw)}return svg;}
		function zoneStyle(kind){return kind==='buy_side_liquidity'?{stroke:'#ffb74d',fill:'#ffb74d',label:'سيولة فوق القمم'}:kind==='sell_side_liquidity'?{stroke:'#c084fc',fill:'#c084fc',label:'سيولة تحت القيعان'}:kind==='bullish_order_block'?{stroke:'#72c36a',fill:'#72c36a',label:'Order Block صاعد'}:kind==='bearish_order_block'?{stroke:'#de7d80',fill:'#de7d80',label:'Order Block هابط'}:kind==='fair_value_gap'?{stroke:'#fb7185',fill:'#fb7185',label:'Fair Value Gap'}:{stroke:'#f2c14e',fill:'#f2c14e',label:'سيناريو مشروط'};}
		function ensureVolumeProfileLayer(){const host=document.getElementById('chartCanvas');if(!host||chartUI.profileLayer?.isConnected)return chartUI.profileLayer;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','chartVolumeProfileLayer');svg.setAttribute('aria-hidden','true');host.appendChild(svg);chartUI.profileLayer=svg;return svg;}function drawVolumeProfile(){const svg=ensureVolumeProfileLayer(),host=document.getElementById('chartCanvas');if(!svg||!host||!chartUI.chart||!chartUI.candles)return;const width=host.clientWidth,height=host.clientHeight;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);svg.replaceChildren();if(!chartUI.overlays.profile||!chartUI.profileData?.length)return;const right=Math.max(24,width-58),maxWidth=Math.min(116,width*.28);for(const bin of chartUI.profileData){const top=chartUI.candles.priceToCoordinate(Number(bin.upper)),bottom=chartUI.candles.priceToCoordinate(Number(bin.lower));if(!Number.isFinite(top)||!Number.isFinite(bottom))continue;const ratio=Math.max(0,Math.min(1,Number(bin.ratio)||0)),barWidth=Math.max(1,maxWidth*ratio),barHeight=Math.max(1,Math.abs(bottom-top));const rect=document.createElementNS('http://www.w3.org/2000/svg','rect');rect.setAttribute('x',Math.max(0,right-barWidth));rect.setAttribute('y',Math.min(top,bottom));rect.setAttribute('width',barWidth);rect.setAttribute('height',barHeight);rect.setAttribute('fill',bin.is_poc?'#5bc0eb':bin.in_value_area?'#5bc0eb':'#385871');rect.setAttribute('fill-opacity',bin.is_poc?'.58':bin.in_value_area?'.27':'.14');if(bin.is_poc){rect.setAttribute('stroke','#d5f5ff');rect.setAttribute('stroke-width','1');}svg.appendChild(rect);if(bin.is_poc){const label=document.createElementNS('http://www.w3.org/2000/svg','text');label.setAttribute('x',Math.max(3,right-barWidth-27));label.setAttribute('y',Math.min(top,bottom)+10);label.setAttribute('class','chartVolumeProfileLabel');label.textContent='POC';svg.appendChild(label);}}}function ensureSupportLayer(){const host=document.getElementById('chartCanvas');if(!host||chartUI.supportLayer?.isConnected)return chartUI.supportLayer;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','chartZoneLayer');svg.setAttribute('aria-hidden','true');host.appendChild(svg);chartUI.supportLayer=svg;return svg;}function drawSupportResistance(){const svg=ensureSupportLayer(),host=document.getElementById('chartCanvas');if(!svg||!host||!chartUI.candles)return;const width=host.clientWidth,height=host.clientHeight;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);svg.replaceChildren();if(!chartUI.overlays.supportresistance)return;for(const zone of chartUI.supportData||[]){const top=chartUI.candles.priceToCoordinate(Number(zone.upper)),bottom=chartUI.candles.priceToCoordinate(Number(zone.lower));if(!Number.isFinite(top)||!Number.isFinite(bottom))continue;const color=zone.kind==='support'?'#38bdf8':'#fb7185';const rect=document.createElementNS('http://www.w3.org/2000/svg','rect');rect.setAttribute('x','0');rect.setAttribute('y',Math.min(top,bottom));rect.setAttribute('width',width);rect.setAttribute('height',Math.max(2,Math.abs(bottom-top)));rect.setAttribute('fill',color);rect.setAttribute('fill-opacity',zone.qualified?'.13':'.06');rect.setAttribute('stroke',color);rect.setAttribute('stroke-width',zone.qualified?'1.1':'.7');rect.setAttribute('stroke-dasharray',zone.qualified?'':'4 3');svg.appendChild(rect);const text=document.createElementNS('http://www.w3.org/2000/svg','text');text.setAttribute('x','5');text.setAttribute('y',Math.min(top,bottom)+12);text.setAttribute('fill',color);text.setAttribute('class','chartZoneLabel');text.textContent=`${zone.label} · ${zone.quality_score||0}/100`;svg.appendChild(text);}}function manualKey(){return 'xauusd-manual-drawings-v1'}function saveManualDrawings(){try{localStorage.setItem(manualKey(),JSON.stringify(chartUI.manualDrawings))}catch(_){}}function ensureManualLayer(){const host=document.getElementById('chartCanvas');if(!host||chartUI.manualLayer?.isConnected)return chartUI.manualLayer;const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('class','chartManualLayer');svg.setAttribute('aria-label','طبقة الرسم اليدوي');host.appendChild(svg);chartUI.manualLayer=svg;svg.addEventListener('pointerdown',beginManualDraw);svg.addEventListener('pointermove',moveManualDraw);svg.addEventListener('pointerup',finishManualDraw);svg.addEventListener('pointercancel',()=>{chartUI.drawDraft=null;drawManualLines()});return svg;}function pointFromEvent(event,svg){const rect=svg.getBoundingClientRect(),x=event.clientX-rect.left,y=event.clientY-rect.top,time=chartUI.chart?.timeScale().coordinateToTime(x),price=chartUI.candles?.coordinateToPrice(y);return Number.isFinite(Number(price))&&time!==null&&time!==undefined?{time,price:Number(price),x,y}:null}function drawManualLines(){const svg=ensureManualLayer(),host=document.getElementById('chartCanvas');if(!svg||!host||!chartUI.candles)return;const width=host.clientWidth,height=host.clientHeight;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);svg.replaceChildren();svg.style.pointerEvents=chartUI.drawTool==='none'?'none':'auto';const rows=[...chartUI.manualDrawings.filter(item=>item.timeframe===chartUI.loadedTimeframe),...(chartUI.drawDraft?[chartUI.drawDraft]:[])];for(const row of rows){const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('stroke',row.color||'#f2c14e');line.setAttribute('stroke-width','2');if(row.dashed)line.setAttribute('stroke-dasharray','7 5');if(row.kind==='horizontal'){const y=chartUI.candles.priceToCoordinate(row.price);if(!Number.isFinite(y))continue;line.setAttribute('x1','0');line.setAttribute('y1',y);line.setAttribute('x2',width);line.setAttribute('y2',y)}else{const x1=chartUI.chart.timeScale().timeToCoordinate(row.start_time),y1=chartUI.candles.priceToCoordinate(row.start_price),x2=chartUI.chart.timeScale().timeToCoordinate(row.end_time),y2=chartUI.candles.priceToCoordinate(row.end_price);if(!Number.isFinite(x1)||!Number.isFinite(y1)||!Number.isFinite(x2)||!Number.isFinite(y2))continue;line.setAttribute('x1',x1);line.setAttribute('y1',y1);line.setAttribute('x2',x2);line.setAttribute('y2',y2)}svg.appendChild(line);}}function beginManualDraw(event){if(chartUI.drawTool==='none')return;const point=pointFromEvent(event,event.currentTarget);if(!point)return;if(chartUI.drawTool==='horizontal'){chartUI.manualDrawings.push({kind:'horizontal',price:point.price,color:chartUI.drawColor,dashed:chartUI.drawDashed,timeframe:chartUI.loadedTimeframe});saveManualDrawings();drawManualLines();return}chartUI.drawDraft={kind:'trend',start_time:point.time,start_price:point.price,end_time:point.time,end_price:point.price,color:chartUI.drawColor,dashed:chartUI.drawDashed,timeframe:chartUI.loadedTimeframe};event.currentTarget.setPointerCapture?.(event.pointerId);drawManualLines()}function moveManualDraw(event){if(!chartUI.drawDraft)return;const point=pointFromEvent(event,event.currentTarget);if(!point)return;chartUI.drawDraft.end_time=point.time;chartUI.drawDraft.end_price=point.price;drawManualLines()}function finishManualDraw(event){if(!chartUI.drawDraft)return;const draft=chartUI.drawDraft;chartUI.drawDraft=null;if(draft.start_time!==draft.end_time||Math.abs(draft.start_price-draft.end_price)>0)chartUI.manualDrawings.push(draft);saveManualDrawings();drawManualLines();event.currentTarget.releasePointerCapture?.(event.pointerId)}function syncManualDrawingUI(){const shell=chartShell(),toolbar=document.getElementById('chartDrawingTools');if(toolbar)toolbar.querySelectorAll('[data-draw]').forEach(button=>button.classList.toggle('on',button.dataset.draw===chartUI.drawTool));if(chartUI.manualLayer)chartUI.manualLayer.style.pointerEvents=isChartFullscreen()&&chartUI.drawTool!=='none'?'auto':'none';if(shell&&!isChartFullscreen()){chartUI.drawTool='none';drawManualLines()}}function installDrawingTools(){const shell=chartShell();if(!shell||document.getElementById('chartDrawingTools'))return;shell.insertAdjacentHTML('beforeend','<div class="chartDrawingTools" id="chartDrawingTools"><button class="chartToggle on" data-draw="none">تحريك</button><button class="chartToggle" data-draw="horizontal">خط أفقي</button><button class="chartToggle" data-draw="trend">خط مائل</button><input id="chartDrawColor" type="color" value="#f2c14e" aria-label="لون خط الرسم"><button class="chartToggle" id="chartDrawStyle">متصل</button><button class="chartToggle" id="chartDrawUndo">حذف آخر</button><button class="chartToggle" id="chartDrawClear">مسح الكل</button><span class="chartDrawHint">تظهر الأدوات في ملء الشاشة فقط. اختر أداة ثم المس الرسم؛ تحفظ الخطوط على هذا الجهاز والإطار.</span></div>');document.querySelectorAll('[data-draw]').forEach(button=>button.addEventListener('click',()=>{chartUI.drawTool=button.dataset.draw||'none';syncManualDrawingUI();drawManualLines()}));document.getElementById('chartDrawColor')?.addEventListener('input',event=>{chartUI.drawColor=event.target.value||'#f2c14e'});document.getElementById('chartDrawStyle')?.addEventListener('click',event=>{chartUI.drawDashed=!chartUI.drawDashed;event.currentTarget.textContent=chartUI.drawDashed?'متقطع':'متصل';event.currentTarget.classList.toggle('on',chartUI.drawDashed)});document.getElementById('chartDrawUndo')?.addEventListener('click',()=>{for(let index=chartUI.manualDrawings.length-1;index>=0;index--)if(chartUI.manualDrawings[index].timeframe===chartUI.loadedTimeframe){chartUI.manualDrawings.splice(index,1);break}saveManualDrawings();drawManualLines()});document.getElementById('chartDrawClear')?.addEventListener('click',()=>{chartUI.manualDrawings=chartUI.manualDrawings.filter(item=>item.timeframe!==chartUI.loadedTimeframe);saveManualDrawings();drawManualLines()});try{chartUI.manualDrawings=JSON.parse(localStorage.getItem(manualKey())||'[]')}catch(_){chartUI.manualDrawings=[]}}function queueZoneDraw(){window.requestAnimationFrame(()=>{drawChartZones();drawVolumeProfile();drawSupportResistance();drawManualLines();})}
		function drawChartZones(){const svg=ensureZoneLayer();const host=document.getElementById('chartCanvas');if(!svg||!host||!chartUI.chart||!chartUI.candles)return;const width=host.clientWidth,height=host.clientHeight;svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);svg.replaceChildren();const groups=[];if(chartUI.overlays.liquidityzones)groups.push(...(chartUI.zoneData.liquidity||[]));if(chartUI.overlays.orderblocks)groups.push(...(chartUI.zoneData.order_blocks||[]));if(chartUI.overlays.fvg)groups.push(...(chartUI.zoneData.fair_value_gap||[]));if(chartUI.overlays.scenario)groups.push(...(chartUI.zoneData.trade_scenario||[]));for(const zone of groups){const y1=chartUI.candles.priceToCoordinate(Number(zone.upper));const y2=chartUI.candles.priceToCoordinate(Number(zone.lower));if(!Number.isFinite(y1)||!Number.isFinite(y2))continue;const xStart=chartUI.chart.timeScale().timeToCoordinate(zone.start_time);const xEnd=chartUI.chart.timeScale().timeToCoordinate(zone.end_time);const left=Number.isFinite(xStart)?xStart:Math.max(0,width-118);const right=Number.isFinite(xEnd)&&xEnd>left?xEnd:width;if(right<0||left>width)continue;const top=Math.min(y1,y2),zoneHeight=Math.max(2,Math.abs(y2-y1)),style=zoneStyle(zone.kind);const rect=document.createElementNS('http://www.w3.org/2000/svg','rect');rect.setAttribute('x',Math.max(0,left));rect.setAttribute('y',top);rect.setAttribute('width',Math.max(1,Math.min(width,right)-Math.max(0,left)));rect.setAttribute('height',zoneHeight);rect.setAttribute('fill',style.fill);rect.setAttribute('fill-opacity',zone.kind==='fair_value_gap'?'.24':zone.kind==='trade_scenario'?'.14':zone.qualified?'0.18':'0.08');rect.setAttribute('stroke',style.stroke);rect.setAttribute('stroke-width',zone.kind==='fair_value_gap'?'1.4':zone.qualified?'1.2':'0.7');rect.setAttribute('stroke-dasharray',zone.qualified?'':'4 3');svg.appendChild(rect);if(right-left>48||zone.kind==='fair_value_gap'){const text=document.createElementNS('http://www.w3.org/2000/svg','text');text.setAttribute('x',Math.max(3,left)+4);text.setAttribute('y',top+12);text.setAttribute('fill',style.stroke);text.setAttribute('class','chartZoneLabel');text.textContent=zone.kind==='fair_value_gap'?`FVG · ${zone.quality_score||0}/100`:`${zone.label||style.label} · ${zone.quality_score||0}/100`;svg.appendChild(text);}if(zone.kind==='trade_scenario'&&Number.isFinite(Number(zone.entry))){const entryY=chartUI.candles.priceToCoordinate(Number(zone.entry));const targetY=chartUI.candles.priceToCoordinate(Number(zone.target));if(Number.isFinite(entryY)){const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('x1',Math.max(0,left));line.setAttribute('x2',width);line.setAttribute('y1',entryY);line.setAttribute('y2',entryY);line.setAttribute('stroke','#f2c14e');line.setAttribute('stroke-width','1.3');svg.appendChild(line);}if(Number.isFinite(targetY)){const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('x1',Math.max(0,left));line.setAttribute('x2',width);line.setAttribute('y1',targetY);line.setAttribute('y2',targetY);line.setAttribute('stroke','#72c36a');line.setAttribute('stroke-dasharray','5 3');svg.appendChild(line);}}}}
			const baseRenderChartOverlays=renderChartOverlays;renderChartOverlays=function(data){baseRenderChartOverlays(data);const levels=data?.overlays?.levels?.support_resistance||{};if(chartUI.overlays.supportresistance){Object.entries(levels).forEach(([name,value])=>addChartLine(value,name,name.startsWith('دعم')?'support':'resistance',window.LightweightCharts.LineStyle.Dashed,true));}chartUI.zoneData=data?.overlays?.zones||{liquidity:[],order_blocks:[],fair_value_gap:[],trade_scenario:[]};chartUI.profileData=data?.overlays?.volume_profile_bins||[];chartUI.supportData=data?.overlays?.zones?.support_resistance||[];queueZoneDraw();};function installSupportResistanceControls(){const controls=document.getElementById('chartControls'),legend=document.querySelector('.chartLegend');if(controls&&!controls.querySelector('[data-overlay="supportresistance"]'))controls.insertAdjacentHTML('beforeend','<button class="chartToggle" data-overlay="supportresistance">دعم / مقاومة</button>');if(legend&&!legend.querySelector('[data-legend="supportresistance"]'))legend.insertAdjacentHTML('beforeend','<span data-legend="supportresistance"><i class="legendDot" style="background:#38bdf8"></i>دعم/مقاومة مرصود</span>');}function installAnalysisPanels(){const analysis=document.getElementById('analysis'),actions=document.querySelector('.chartActions');if(analysis&&!document.getElementById('aiAnalysisPanel'))analysis.insertAdjacentHTML('afterbegin','<div class="sectionTitle">تحليلي بالذكاء الاصطناعي</div><div class="panel" id="aiAnalysisPanel"><div class="empty">اضغط «تحليلي AI» قرب الرسم للتحقق من صلاحية البيانات وتشغيل التحليل المنظم.</div></div><div class="sectionTitle">اقتراحات دمج المؤشرات</div><div class="panel" id="indicatorCombinations"><div class="empty">جاري تحديد نظام السوق...</div></div>');if(actions&&!document.getElementById('aiAnalysisButton'))actions.insertAdjacentHTML('afterbegin','<button class="chartToggle" id="aiAnalysisButton">تحليلي AI</button>');}function installManualAnalysisRunner(){const analysis=document.getElementById('analysis');if(!analysis||document.getElementById('manualAnalysisRunner'))return;analysis.insertAdjacentHTML('afterbegin','<div class="sectionTitle">تشغيل التحليل داخل اللوحة</div><div class="panel" id="manualAnalysisRunner"><div class="toolDetails">شغّل التحليل عند الطلب على الإطار المختار. الوقت أدناه تفضيل محفوظ على هذا الجهاز فقط ولا يفعّل جدولة أو تداولاً تلقائياً.</div><div class="toolLevels"><label class="small" for="analysisPreferredTime">وقت مفضل (GMT+3)</label><input id="analysisPreferredTime" type="time" aria-label="وقت التحليل المفضل"><button type="button" class="chartToggle" id="manualAnalysisRun">تشغيل التحليل الآن</button></div><div class="small" id="manualAnalysisStatus">لم يُشغّل تحليل يدوي في هذه الجلسة.</div></div>');const timeInput=document.getElementById('analysisPreferredTime'),status=document.getElementById('manualAnalysisStatus');try{timeInput.value=localStorage.getItem('xauusd-analysis-preferred-time')||''}catch(_){}timeInput?.addEventListener('change',()=>{try{localStorage.setItem('xauusd-analysis-preferred-time',timeInput.value)}catch(_){}if(status)status.textContent=timeInput.value?`حُفظ الوقت المفضل: ${timeInput.value} (GMT+3). التشغيل يبقى يدوياً.`:'أزيل الوقت المفضل؛ التشغيل يبقى يدوياً.'});document.getElementById('manualAnalysisRun')?.addEventListener('click',async()=>{const button=document.getElementById('manualAnalysisRun'),frameLabel=window.TIMEFRAME_LABELS?.[selectedTimeframe]||selectedTimeframe;if(button)button.disabled=true;if(status)status.textContent=`جارِ التحقق من المصدر وتشغيل تحليل ${frameLabel}...`;try{await requestAIAnalysis(selectedTimeframe);if(status)status.textContent=`اكتمل التحليل اليدوي للإطار ${frameLabel}. راجع حواجز المصدر والنتيجة أدناه.`;}finally{if(button)button.disabled=false;}});}
			const chartSection=document.getElementById('chart');document.querySelector('.status')?.after(chartSection);installSupportResistanceControls();installAnalysisPanels();installManualAnalysisRunner();installDrawingTools();initChart();ensureManualLayer();syncManualDrawingUI();document.getElementById('aiAnalysisButton')?.addEventListener('click',()=>requestAIAnalysis(selectedTimeframe));const baseUpdate=update;update=async function(){await baseUpdate();if(selectedTimeframe&&!loadingTimeframe&&(!selectedFramePayload||selectedFramePayload?.timeframe?.id!==selectedTimeframe))selectTimeframe(selectedTimeframe);};update();setInterval(update,2000);setInterval(()=>{if(chartUI.loadedTimeframe)loadChart(selectedTimeframe,false);},30000);
	</script>
	<style>.chartCanvas{overflow:hidden!important}.chartZoneLayer{overflow:hidden!important;clip-path:inset(0)!important}.referenceComparison{margin-top:10px;padding:10px;border:1px solid #35536a;border-radius:10px;background:#0c1b28;overflow-x:auto}.referenceComparison table{width:100%;min-width:540px;border-collapse:collapse;margin-top:8px;font-size:11px}.referenceComparison th,.referenceComparison td{border-bottom:1px solid #243f54;padding:6px;text-align:center;white-space:nowrap}.referenceComparison th{color:#f3d98e;font-weight:700}.referenceComparison td{color:#d8e8f3}.signalLayerGrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.compactSignalWorkspace .toolCard{height:100%;border-color:#2e5065}.compactSignalWorkspace .toolTitle{color:#f3d98e}.compactSignalWorkspace .notice{margin-top:10px}@media(max-width:700px){.signalLayerGrid{grid-template-columns:1fr}}</style>
	<script>
	(function(){
	  const clip=(value,min,max)=>Math.min(max,Math.max(min,value));
	  window.drawChartZones=function(){
	    const svg=ensureZoneLayer(),host=document.getElementById('chartCanvas');
	    if(!svg||!host||!chartUI.chart||!chartUI.candles)return;
	    const width=host.clientWidth,height=host.clientHeight;
	    svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('width',width);svg.setAttribute('height',height);
	    svg.style.overflow='hidden';svg.style.clipPath='inset(0)';svg.replaceChildren();
	    const zones=[];
	    if(chartUI.overlays.liquidityzones)zones.push(...(chartUI.zoneData.liquidity||[]));
	    if(chartUI.overlays.orderblocks)zones.push(...(chartUI.zoneData.order_blocks||[]));
	    if(chartUI.overlays.fvg)zones.push(...(chartUI.zoneData.fair_value_gap||[]));
	    if(chartUI.overlays.scenario)zones.push(...(chartUI.zoneData.trade_scenario||[]));
	    for(const zone of zones){
	      const yA=chartUI.candles.priceToCoordinate(Number(zone.upper)),yB=chartUI.candles.priceToCoordinate(Number(zone.lower));
	      if(!Number.isFinite(yA)||!Number.isFinite(yB))continue;
	      const start=chartUI.chart.timeScale().timeToCoordinate(zone.start_time),end=chartUI.chart.timeScale().timeToCoordinate(zone.end_time);
	      const rawLeft=Number.isFinite(start)?start:Math.max(0,width-118),rawRight=Number.isFinite(end)&&end>rawLeft?end:width;
	      const rawTop=Math.min(yA,yB),rawBottom=Math.max(yA,yB);
	      if(rawRight<=0||rawLeft>=width||rawBottom<=0||rawTop>=height)continue;
	      const left=clip(rawLeft,0,width),right=clip(rawRight,0,width),top=clip(rawTop,0,height),bottom=clip(rawBottom,0,height);
	      if(right-left<1||bottom-top<1)continue;
	      const style=zoneStyle(zone.kind),rect=document.createElementNS('http://www.w3.org/2000/svg','rect');
	      rect.setAttribute('x',left);rect.setAttribute('y',top);rect.setAttribute('width',right-left);rect.setAttribute('height',bottom-top);
	      rect.setAttribute('fill',style.fill);rect.setAttribute('fill-opacity',zone.kind==='fair_value_gap'?'.24':zone.kind==='trade_scenario'?'.14':zone.qualified?'0.18':'0.08');
	      rect.setAttribute('stroke',style.stroke);rect.setAttribute('stroke-width',zone.kind==='fair_value_gap'?'1.4':zone.qualified?'1.2':'0.7');rect.setAttribute('stroke-dasharray',zone.qualified?'':'4 3');svg.appendChild(rect);
	      if(right-left>48||zone.kind==='fair_value_gap'){
	        const text=document.createElementNS('http://www.w3.org/2000/svg','text');
	        text.setAttribute('x',clip(left+4,3,Math.max(3,width-76)));text.setAttribute('y',clip(top+12,12,Math.max(12,height-4)));text.setAttribute('fill',style.stroke);text.setAttribute('class','chartZoneLabel');
	        text.textContent=zone.kind==='fair_value_gap'?`FVG · ${zone.quality_score||0}/100`:`${zone.label||style.label} · ${zone.quality_score||0}/100`;svg.appendChild(text);
	      }
	      if(zone.kind==='trade_scenario'){
	        for(const [price,color,dash] of [[zone.entry,'#f2c14e',''],[zone.target,'#72c36a','5 3']]){
	          const y=chartUI.candles.priceToCoordinate(Number(price));if(!Number.isFinite(y)||y<0||y>height)continue;
	          const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('x1',left);line.setAttribute('x2',right);line.setAttribute('y1',y);line.setAttribute('y2',y);line.setAttribute('stroke',color);line.setAttribute('stroke-width','1.3');if(dash)line.setAttribute('stroke-dasharray',dash);svg.appendChild(line);
	        }
	      }
	    }
	  };
	})();
	</script>
	<style>
	:root{--ink:#071018;--surface:#0e1721;--surface-raised:#131f2d;--surface-soft:#172635;--border:#26384a;--gold:#e4b65e;--cyan:#58b8e8;--success:#76cf7a;--danger:#ed858b;--copy:#eef4fb;--copy-muted:#91a3b8}
	body{background:radial-gradient(90% 55% at 50% -10%,#1b2e43 0%,#0b121a 48%,#060a0f 100%);color:var(--copy);font-family:Tahoma,"Noto Sans Arabic",Arial,sans-serif;letter-spacing:.01em}
	.app.studioLayout{max-width:620px;background:linear-gradient(180deg,#0d1722 0%,#09111a 54%,#0b121a 100%);box-shadow:0 22px 70px #0009;padding-bottom:84px}
	.app.studioLayout .topbar{padding:20px 20px 10px;background:linear-gradient(180deg,#111d2a 0%,#0d1722 100%);border-bottom:0}.app.studioLayout .topbar::after{content:"لوحة أبحاث السوق";font-size:10px;letter-spacing:.12em;color:#7e9bb6;border:1px solid #2d465e;border-radius:999px;padding:5px 8px;margin-right:auto}.app.studioLayout .instrument{font-size:27px;letter-spacing:-.03em}.app.studioLayout .meta{font-size:11px;color:#9eb2c9}
	.app.studioLayout .quote{margin:0 14px 12px;padding:17px 16px 15px;border:1px solid #2a4056;border-radius:16px;background:linear-gradient(135deg,#17283a 0%,#101a26 58%,#101820 100%);box-shadow:0 12px 28px #0004}.app.studioLayout .quoteLine{gap:10px}.app.studioLayout .price{font-size:42px;color:#f8fbff;line-height:1}.app.studioLayout .change{font-size:14px;border-radius:999px;padding:5px 9px;background:#183b28;color:#9be09c}.app.studioLayout .quoteSub{font-size:11px;margin-top:10px;color:#a9b9cb;line-height:1.65}.app.studioLayout .status{margin:0 18px 12px;padding:8px 0;border:0;color:#9db0c3;font-size:11px}.app.studioLayout .dot{background:var(--success);box-shadow:0 0 0 4px #76cf7a1c}
	.app.studioLayout .tabs{margin:0 14px 14px;padding:4px;background:#101b27;border:1px solid #273b4f;border-radius:13px;gap:2px;scrollbar-width:none}.app.studioLayout .tab{min-width:auto;flex:1;padding:9px 11px;border-radius:9px;font-size:12px;border-bottom:0}.app.studioLayout .tab.active{background:#243a50;color:#f8fbff;border-bottom:0;box-shadow:inset 0 0 0 1px #3f617f}.app.studioLayout .tab:focus-visible{outline:2px solid var(--gold)}
	.app.studioLayout .sectionTitle{display:flex;align-items:center;gap:9px;background:transparent;color:#dce8f6;padding:22px 18px 8px;margin:0;font-size:15px;letter-spacing:.015em}.app.studioLayout .sectionTitle::after{content:"";height:1px;flex:1;background:linear-gradient(90deg,#334b63,transparent)}.app.studioLayout .chartShell{margin:0 14px;border-color:#2c435a;border-radius:16px;background:linear-gradient(180deg,#111d2a 0%,#0b131c 100%);box-shadow:0 14px 32px #0006}.app.studioLayout .chartMeta{padding:14px 14px 9px}.app.studioLayout .chartMeta b{font-size:16px;color:#f5f9fd}.app.studioLayout .chartLegend{padding:0 14px 10px;gap:7px;color:#aabbd0}.app.studioLayout .chartCanvas{background:#0a1119}.app.studioLayout .chartCrosshair{margin:0 12px 10px;background:#0c1520;border-color:#263c51;border-radius:9px;color:#9fb2c6}.app.studioLayout .chartActions,.app.studioLayout .chartControls{padding:10px 12px;gap:7px;border-color:#213347;background:#0d1620}.app.studioLayout .chartToggle{border-color:#304861;background:#142233;color:#b6c8da;border-radius:9px;padding:7px 10px;font-size:11px}.app.studioLayout .chartToggle.on{background:#23422f;border-color:#68bf70;color:#d1f2d0}.app.studioLayout .chartFoot{padding:10px 13px 12px;background:#0d1620;border-color:#213347;color:#9bb0c4}
	.app.studioLayout .workspaceDock{margin:14px 14px 0;border:1px solid #2b425a;border-radius:16px;background:linear-gradient(180deg,#111d2a,#0d1721);overflow:hidden;box-shadow:0 10px 26px #0004}.app.studioLayout .workspaceDock .sectionTitle{padding:14px 14px 8px;font-size:14px}.app.studioLayout .timeframes{padding:4px 10px 10px;gap:7px}.app.studioLayout .tf{min-height:71px;border-radius:10px;background:#162433;border-color:#2b4258}.app.studioLayout .tf.active{border-color:var(--gold);background:linear-gradient(145deg,#29372a,#192820);box-shadow:0 0 0 1px #e4b65e33}.app.studioLayout .tfLabel{font-size:11px}.app.studioLayout .tfAction{font-size:12px}.app.studioLayout .panel{margin:0 14px 14px;border-radius:14px;border-color:#2a4056;background:linear-gradient(160deg,#131f2d,#101923);box-shadow:0 8px 24px #0003}.app.studioLayout .workspaceDock .panel{margin:0 10px 12px}.app.studioLayout .panelHead{padding:14px 14px 10px;font-size:16px}.app.studioLayout .summaryRow{padding:0 10px 10px;gap:7px}.app.studioLayout .summaryCard{border:1px solid #2a4157;border-radius:10px;background:#172635;padding:10px 5px}.app.studioLayout .summaryCard strong{font-size:17px}.app.studioLayout .summaryCard span{font-size:10px}.app.studioLayout .dataTable th{background:#0c1520;color:#93a8be}.app.studioLayout .dataTable td{border-color:#213348}.app.studioLayout .notice{margin:0 14px 14px;border:1px solid #685222;border-right:3px solid var(--gold);border-radius:12px;background:#252019;color:#e9d8a7}.app.studioLayout .signalBox{margin:0 14px 14px;border-color:#39556d;border-radius:15px;background:linear-gradient(135deg,#1a2b3d,#111b25);box-shadow:0 10px 24px #0003}.app.studioLayout .signalMain{font-size:20px}.app.studioLayout .level{background:#172635;border:1px solid #2a4056;border-radius:8px}.app.studioLayout .toolCard{padding:14px;border-color:#213348}.app.studioLayout .toolLevel{background:#1a2b3b;border:1px solid #2b435a;border-radius:999px;padding:5px 8px}.app.studioLayout .pivotGroup{margin:0 14px 14px;border-color:#2a4056;border-radius:12px}.app.studioLayout .groupTitle{background:#0d1721}.app.studioLayout .footer{height:68px;margin-top:20px;padding-bottom:env(safe-area-inset-bottom);background:#121f2c;border-top:1px solid #2a4056}.app.studioLayout .footer b{font-size:19px}.app.studioLayout #analysis,.app.studioLayout #technical,.app.studioLayout #news,.app.studioLayout #historical{padding-top:2px}.app.studioLayout #analysis .sectionTitle:first-child{padding-top:20px}
	@media(min-width:640px){.app.studioLayout{max-width:760px}.app.studioLayout .timeframes{grid-template-columns:repeat(8,1fr)}.app.studioLayout .chartCanvas{height:430px}.app.studioLayout .workspaceDock{display:grid;grid-template-columns:1.35fr 1fr;align-items:stretch}.app.studioLayout .workspaceDock .sectionTitle{grid-column:1/-1}.app.studioLayout .workspaceDock .timeframes{align-content:start}.app.studioLayout .workspaceDock .panel{align-self:stretch;margin:4px 10px 12px 0}.app.studioLayout .footer{border-radius:14px 14px 0 0}}
	@media(max-width:380px){.app.studioLayout .price{font-size:36px}.app.studioLayout .tab{padding:8px 9px;font-size:11px}.app.studioLayout .timeframes{grid-template-columns:repeat(4,1fr)}}
	</style>
	<script>
	(function(){
	  const app=document.querySelector('.app'),status=document.querySelector('.status'),tabs=document.querySelector('.tabs'),chart=document.getElementById('chart'),overview=document.getElementById('overview'),analysis=document.getElementById('analysis'),technical=document.getElementById('technical'),news=document.getElementById('news'),historical=document.getElementById('historical');
	  if(!app||!status||!tabs||!chart||!overview||document.querySelector('.workspaceDock'))return;
	  app.classList.add('studioLayout');
	  const dock=document.createElement('section');dock.id='overview';dock.className='workspaceDock';
		  const title=overview.querySelector('.sectionTitle'),filter=overview.querySelector('#timeframeFilterPanel'),timeframes=overview.querySelector('#timeframes'),context=overview.querySelector('#selectedFrameContext'),summary=overview.querySelector('.panel');
		  if(title)dock.appendChild(title);if(filter)dock.appendChild(filter);if(timeframes)dock.appendChild(timeframes);if(context)dock.appendChild(context);if(summary)dock.appendChild(summary);overview.replaceWith(dock);
	  status.after(tabs);tabs.after(chart);chart.after(dock);dock.after(analysis);analysis.after(technical);technical.after(news);news.after(historical);
	  const tabLinks=[...tabs.querySelectorAll('.tab')];tabLinks.forEach(link=>link.addEventListener('click',()=>{tabLinks.forEach(item=>item.classList.toggle('active',item===link));}));
	  window.setTimeout(()=>{resizeChart();queueZoneDraw();},80);
	})();
		</script>
		<style>
		/* وضع الرسم الواسع يعمل حتى عندما يمنع المتصفح قفل اتجاه الشاشة. */
		body.pageLandscapeRequested{overflow:hidden;background:#080f17}body.pageLandscapeRequested .app{max-width:none!important;width:100vw!important;min-height:100dvh!important;padding:0!important;box-shadow:none!important}.pageLandscapeRequested .app>.topbar,.pageLandscapeRequested .app>.quote,.pageLandscapeRequested .app>.status,.pageLandscapeRequested .app>.tabs,.pageLandscapeRequested .app>.workspaceDock,.pageLandscapeRequested .app>#analysis,.pageLandscapeRequested .app>#technical,.pageLandscapeRequested .app>#news,.pageLandscapeRequested .app>#historical,.pageLandscapeRequested .app>.footer{display:none!important}.pageLandscapeRequested .app>#chart{position:fixed;inset:0;z-index:10020;margin:0;background:#080f17;display:flex;flex-direction:column;padding:0}.pageLandscapeRequested #chart>.sectionTitle{display:none}.pageLandscapeRequested .chartShell{margin:0!important;border:0!important;border-radius:0!important;width:100%!important;height:100dvh!important;min-height:100dvh!important;display:flex!important;flex-direction:column!important;background:#080f17!important;box-shadow:none!important}.pageLandscapeRequested .chartCanvas{height:auto!important;min-height:0!important;flex:1 1 auto!important}.pageLandscapeRequested .chartMeta{padding:8px 14px 5px!important;flex:0 0 auto}.pageLandscapeRequested .chartLegend,.pageLandscapeRequested .chartCrosshair,.pageLandscapeRequested .chartFoot{display:none!important}.pageLandscapeRequested .chartActions,.pageLandscapeRequested .chartControls{flex:0 0 auto!important;flex-wrap:nowrap!important;overflow-x:auto!important;padding:7px 12px!important}.pageLandscapeRequested .pageLandscapeExit{display:block!important}.pageLandscapeRequested .chartDrawingTools{display:flex!important;flex:0 0 auto!important;flex-wrap:nowrap!important;overflow-x:auto!important}.pageLandscapeExit{z-index:10080!important;box-shadow:0 6px 18px #0008}.pageLandscapeRequested .pageLandscapeExit::after{content:"خروج من الشاشة الواسعة"}.pageLandscapeRequested .pageLandscapeExit{font-size:0;padding:9px 12px}.pageLandscapeRequested .pageLandscapeExit::after{font-size:12px}.pageWideFallback .chartMeta::after{content:"وضع شاشة واسعة — دوّر الهاتف يدوياً إن بقي عمودياً";color:#a7c0d8;font-size:10px;margin-right:auto;white-space:nowrap}
		</style>
		<script>
		(function(){
		  const preferenceKey='xauusd-chart-preferences-v2';
		  const readPreferences=()=>{try{const value=JSON.parse(localStorage.getItem(preferenceKey)||'{}');return value&&typeof value==='object'?value:{}}catch(_){return {}}};
		  const preferences=readPreferences();
		  const savePreferences=()=>{try{localStorage.setItem(preferenceKey,JSON.stringify({timeframe:window.selectedTimeframe||selectedTimeframe,overlays:window.chartUI?.overlays||chartUI.overlays,updated_at:new Date().toISOString()}))}catch(_){}};
		  const renderQuote=(quote,lastRefresh,policy)=>{
		    if(!quote)return;
		    const fresh=quote.status==='success'&&!quote.stale&&quote.live_for_analysis===true;
		    const status=document.getElementById('systemStatus'),refresh=document.getElementById('lastRefresh'),price=document.getElementById('price'),change=document.getElementById('change'),sub=document.getElementById('quoteSub'),age=document.getElementById('age'),source=document.getElementById('source'),symbol=document.getElementById('symbol'),sourceSymbol=document.getElementById('sourceSymbol');
		    if(status)status.innerHTML=`<span class="dot" style="background:${quote.status!=='success'?'#de7d80':quote.stale?'#e0ad44':'#72c36a'}"></span>${esc(fresh?'يعمل — gold-api.com مرجع سوق حديث':'تحذير: السعر المرجعي غير صالح')}`;
		    if(refresh)refresh.textContent='آخر تحديث من المصدر: '+esc(lastRefresh||'—');
		    if(price)price.textContent=fresh?num(quote.last_price):'—';
		    if(change)change.textContent=fresh?(quote.price_direction_label||'سعر سوق عام مرجعي'):(quote.stale?'السوق مغلق / سعر متأخر':'لا يوجد سعر سوق حديث');
		    if(sub)sub.textContent=(quote.message||quote.source||'—')+' — '+(quote.utc_time||'—')+' · النقل: '+(policy?.transport||'—');
		    if(age)age.textContent=quote.age_seconds===undefined?'—':num(quote.age_seconds,0)+' ثانية';
		    if(source)source.textContent=quote.source||'—';if(symbol)symbol.textContent=quote.symbol||'XAUUSD';if(sourceSymbol)sourceSymbol.textContent=quote.source_symbol||quote.symbol||'—';
		    renderPriceDirection(quote,fresh);
		  };
		  if(preferences.timeframe&&typeof preferences.timeframe==='string')selectedTimeframe=preferences.timeframe;
		  if(preferences.overlays&&typeof preferences.overlays==='object')Object.assign(chartUI.overlays,preferences.overlays);
		  window.addEventListener('xauusd:timeframe-selected',savePreferences);
		  document.addEventListener('click',event=>{if(event.target.closest('[data-overlay]')||event.target.closest('[data-timeframe]'))setTimeout(savePreferences,0)});
		  window.addEventListener('beforeunload',savePreferences);
		  const nativeFetch=window.fetch.bind(window);let statusCache={at:0,value:null};
		  window.fetch=(resource,options)=>{const url=typeof resource==='string'?resource:String(resource?.url||'');if(url==='/api/system-status'&&statusCache.value&&Date.now()-statusCache.at<15000)return Promise.resolve(new Response(JSON.stringify(statusCache.value),{status:200,headers:{'Content-Type':'application/json'}}));return nativeFetch(resource,options).then(response=>{if(url==='/api/system-status'&&response.ok)response.clone().json().then(value=>{statusCache={at:Date.now(),value}}).catch(()=>{});return response;});};
		  if('EventSource' in window){const stream=new EventSource('/api/quote-stream');stream.addEventListener('quote',event=>{try{const payload=JSON.parse(event.data);renderQuote(payload.quote,payload.last_quote_refresh,payload.refresh_policy);if(statusCache.value){statusCache.value.quote=payload.quote;statusCache.value.last_quote_refresh=payload.last_quote_refresh;statusCache.at=Date.now();}}catch(_){}});stream.onerror=()=>{const refresh=document.getElementById('lastRefresh');if(refresh&&!refresh.textContent.includes('آخر تحديث'))refresh.textContent='تعذر اتصال التحديث التدريجي؛ سيستمر التحديث الدوري المحدود.';};}
		  if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
		  const normalizeEvidenceLabels=()=>{const technical=selectedFramePayload?.timeframe?.technical?.evidence_strength;const output=document.getElementById('technicalConfidence');if(output&&technical){output.textContent=`${num(technical.score,0)}/100`;output.title=technical.calibration||'قوة أدلة غير معايرة، وليست احتمال نجاح.';const card=output.closest('.summaryCard');if(card){const label=card.querySelector('span');if(label)label.textContent='قوة الأدلة';}}document.querySelectorAll('.scenarioTable th').forEach(cell=>{if(cell.textContent.trim()==='الثقة')cell.textContent='قوة الأدلة'});document.querySelectorAll('.scenarioTable td:nth-child(8)').forEach(cell=>{if(/%/.test(cell.textContent))cell.textContent='غير معايرة'});document.querySelectorAll('#recommendation .level').forEach(level=>{const label=level.querySelector('span'),value=level.querySelector('strong');if(label?.textContent.trim()==='الثقة'){label.textContent='قوة الأدلة';if(value)value.textContent='غير معايرة';}});};
		  const showEvidenceStrength=(technical)=>{const strength=technical?.evidence_strength,output=document.getElementById('technicalConfidence');if(!output||!strength)return;output.textContent=`${num(strength.score,0)}/100`;output.title=strength.calibration||'قوة أدلة غير معايرة، وليست احتمال نجاح.';const card=output.closest('.summaryCard');if(card){const label=card.querySelector('span');if(label)label.textContent='قوة الأدلة';}};
		  const baseRenderTechnical=renderTechnical;renderTechnical=function(technical,frame){baseRenderTechnical(technical,frame);showEvidenceStrength(technical);const evidence=technical?.evidence_strength||{},families=technical?.evidence_families||{},parts=Array.isArray(evidence.components)?evidence.components:[],reasons=Array.isArray(families.neutral_reasons)?families.neutral_reasons:[],explanation=document.getElementById('evidenceExplanation');if(explanation&&technical){const componentText=parts.map(part=>`${esc(part.family)}: ${esc(part.direction)}`).join(' · ')||'لا توجد عائلات مؤهلة';const decision=String(families.decision_bias||'محايد');const rationale=decision==='محايد'?(reasons.join(' ')||'لا توجد عائلتان مستقلتان تؤكدان الاتجاه نفسه.'):`توافقت عائلات هذا الإطار على اتجاه ${decision}.`;explanation.innerHTML=`<b>أساس ${num(evidence.score,0)}/100 للإطار ${esc(frame?.label||'المختار')}:</b> ${componentText}<br><span>النتيجة: ${esc(decision)}. ${esc(rationale)}</span><small>${esc(evidence.calibration||'غير معاير؛ لا يفسر كاحتمال نجاح أو كنسبة ربح.')}</small>`;}normalizeEvidenceLabels();};
		  const neutralizeFourHourChrome=()=>{const style=document.createElement('style');style.textContent='.chartTfRail button[data-chart-timeframe="4h"]{min-width:47px!important;border-color:transparent!important;background:#102539!important;color:#a7c4d6!important}.chartTfRail button[data-chart-timeframe="4h"].active{background:linear-gradient(145deg,#f0bf62,#b47931)!important;color:#14212b!important;box-shadow:0 5px 13px #0005!important}';document.head.appendChild(style);};neutralizeFourHourChrome();
		  const renderTechnicalWithIndependentFrames=renderTechnical;renderTechnical=function(technical,frame){renderTechnicalWithIndependentFrames(technical,frame);const mtf=technical?.advanced_tools?.multi_timeframe||{},node=document.querySelector('#advancedTools .notice .small');if(node)node.textContent=`مقارنة إطار آخر للمراجعة فقط: ${mtf.status||'غير متاح'} — لا تغيّر قرار الإطار المختار أو قوة أدلته.`;};
		  const normalizeReferenceLabels=()=>{document.querySelectorAll('#intradayRecommendation .level,#recommendation .level').forEach(level=>{const label=level.querySelector('span'),value=level.querySelector('strong');if(label?.textContent.trim()==='الثقة'){label.textContent='قوة الأدلة';if(value)value.textContent='غير معايرة';}});document.querySelectorAll('#momentumInteraction .level').forEach(level=>{const label=level.querySelector('span');if(label?.textContent.trim()==='تعديل الثقة')label.textContent='تعديل قوة الأدلة';});};
		  window.setInterval(normalizeEvidenceLabels,400);
		  window.setInterval(normalizeReferenceLabels,400);
		})();
		</script>
		<script>
		(function(){
		  function installDataTransparencyPanel(){
		    const historical=document.getElementById('historical');
		    if(!historical||document.getElementById('dataTransparency'))return;
		    historical.insertAdjacentHTML('afterbegin','<div class="sectionTitle">سياق المصدر وحاجز القرار</div><div class="panel" id="dataTransparency"><div class="empty">جارِ توثيق مصدر السعر والشموع...</div></div>');
		  }
		  function renderDataTransparency(data){
		    const box=document.getElementById('dataTransparency');if(!box)return;
		    if(!data){box.dataset.ready='0';box.innerHTML='<div class="empty">لا توجد حالة مصدر مكتملة بعد.</div>';return;}
		    const quote=data.quote||{},candles=data.candles||{},guard=data.decision_guard||{},diagnostic=data.price_close_diagnostic||{};
		    box.dataset.ready=quote.source&&candles.source?'1':'0';
		    const compatible=guard.compatible_for_price_levels===true;
		    const stateClass=compatible?'cellBuy':'cellSell';
		    const stateText=compatible?'متوافق للتحليل المرجعي':'محجوب عن مستويات السعر';
		    const difference=diagnostic.status==='diagnostic_only'?`${num(diagnostic.difference,4)} (${num(diagnostic.difference_pct,4)}%)`:'محجوب';
		    box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">مصدر السعر والشموع</span><span class="badge ${stateClass}">${stateText}</span></div><div class="signalLevels"><div class="level"><span>السعر المرجعي</span><strong>${esc(quote.source||'—')}</strong></div><div class="level"><span>أساس السعر</span><strong>${esc(quote.price_basis||'—')}</strong></div><div class="level"><span>عمر القراءة</span><strong>${quote.age_seconds===undefined?'—':num(quote.age_seconds,0)+' ث'}</strong></div></div><div class="signalLevels"><div class="level"><span>مصدر الشموع</span><strong>${esc(candles.source||'—')}</strong></div><div class="level"><span>الأداة / الأساس</span><strong>${esc(candles.instrument||candles.symbol||'—')} · ${esc(candles.price_basis||'—')}</strong></div><div class="level"><span>حالة الرسم</span><strong>${esc(candles.chart_label||'—')}</strong></div></div><div class="toolLevels"><span class="toolLevel">فرق السعر وآخر إغلاق: <b class="value">${difference}</b></span><span class="toolLevel">${esc(diagnostic.message||'—')}</span></div><div class="notice"><b>سبب القرار:</b> ${esc(data.wait_explanation||guard.reason||'—')}</div><div class="small">هذه البطاقة توثق توافق البيانات فقط. لا تحول فرق المرجعين إلى شراء أو بيع أو سعر Bid/Ask تنفيذي.</div></article>`;
		  }
		  window.renderDataTransparency=renderDataTransparency;
		  function installEvidenceFamilyPanel(){
		    const analysis=document.getElementById('analysis');
		    if(!analysis||document.getElementById('evidenceFamilies'))return;
		    analysis.insertAdjacentHTML('beforeend','<div class="sectionTitle">خلاصة الأدلة وسبب الانتظار</div><div class="panel" id="evidenceFamilies"><div class="empty">جارِ تنظيم الأدلة بحسب المصدر والعائلة...</div></div>');
		  }
		  function renderEvidenceFamilies(recommendation){
		    const box=document.getElementById('evidenceFamilies');if(!box)return;
		    const technical=latestSystem?.technical||{},layers=latestSystem?.signal_layers||{},trend=layers.trend||{},zones=layers.zones||{},news=latestSystem?.news||{},transparency=latestSystem?.data_transparency||{};
		    if(!recommendation){box.innerHTML='<div class="empty">لا توجد نتيجة قرار مكتملة بعد.</div>';return;}
		    const groups=[
		      ['الاتجاه',trend.summary||'لا توجد قراءة اتجاه مكتملة.',trend.basis||'EMA20 / EMA50 وADX من شموع مرجعية'],
		      ['المناطق السعرية',zones.summary||'لا توجد منطقة مؤهلة.',zones.basis||'OHLC + pivots؛ ليست تدفق أوامر موثقاً'],
		      ['مخاطر الأخبار',news.message||'لا توجد حالة خبر مكتملة.',news.status||'غير متاح'],
		      ['جودة البيانات',transparency.wait_explanation||recommendation.reason||'—',transparency.candles?.chart_label||'—'],
		    ];
		    const reason=recommendation.reason||'لا يوجد سبب مسجل.';
		    box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(recommendation.signal||'انتظار / لا قرار')}</span><span class="badge ${recommendation.decision_state==='signal'?'cellBuy':recommendation.decision_state==='blocked'?'cellSell':'cellNeutral'}">قرار مشروط</span></div><div class="toolLevels">${groups.map(([title,summary,basis])=>`<span class="toolLevel"><b>${esc(title)}</b>: ${esc(summary)}<br><small>${esc(basis)}</small></span>`).join('')}</div><details class="notice"><summary><b>لماذا هذه النتيجة؟</b></summary><p>${esc(reason)}</p>${(recommendation.warnings||[]).map(item=>`<p>${esc(item)}</p>`).join('')}</details><div class="small">تُعرض العائلات لتفادي عدّ مؤشرات السعر المترابطة كأدلة مستقلة أو تحويل قوة الأدلة إلى احتمال نجاح.</div></article>`;
		  }
		  installDataTransparencyPanel();installEvidenceFamilyPanel();
		  const baseRenderRecommendation=renderRecommendation;
		  renderRecommendation=function(recommendation){baseRenderRecommendation(recommendation);renderEvidenceFamilies(recommendation);};
		  const hasTransparencySource=data=>Boolean(data?.quote?.source&&data?.candles?.source);
		  const baseUpdate=update;
		  update=async function(){await baseUpdate();if(hasTransparencySource(latestSystem?.data_transparency))renderDataTransparency(latestSystem.data_transparency);};
		  window.setTimeout(()=>{if(hasTransparencySource(latestSystem?.data_transparency))renderDataTransparency(latestSystem.data_transparency);},0);
		  window.setInterval(()=>{if(hasTransparencySource(latestSystem?.data_transparency))renderDataTransparency(latestSystem.data_transparency);renderEvidenceFamilies(latestSystem?.recommendation);},1000);
		  const hydrateTransparency=async()=>{const panel=document.getElementById('dataTransparency');if(!panel||panel.dataset.ready==='1')return;panel.dataset.hydration='loading';try{const response=await fetch('/api/timeframe/'+encodeURIComponent(selectedTimeframe||'1d'),{cache:'no-store'});if(!response.ok){panel.dataset.hydration='http-'+response.status;return;}const payload=await response.json();window.renderDataTransparency?.(payload.data_transparency);panel.dataset.hydration='ready';}catch(error){panel.dataset.hydration='error';panel.dataset.hydrationError=String(error?.message||'unknown').slice(0,80);}};
		  window.setTimeout(hydrateTransparency,1200);
		  window.setInterval(hydrateTransparency,6000);
		  window.addEventListener('load',hydrateTransparency,{once:true});
		})();
		</script>
		<script>
		(function(){
		  const key='xauusd-backtest-cost-model-v1',safe=value=>Math.max(0,Math.min(Number(value)||0,10));
		  const values=()=>{try{return {...{spread:0.30,slippage:0.05,commission:0.00},...JSON.parse(localStorage.getItem(key)||'{}')}}catch(_){return {spread:0.30,slippage:0.05,commission:0.00}}};
		  const install=()=>{const host=document.getElementById('obFvgStrategyPanel');if(!host||document.getElementById('backtestCostControls'))return;const v=values(),controls=document.createElement('div');controls.id='backtestCostControls';controls.className='toolLevels';controls.innerHTML=`<span class="small">نموذج تكلفة بحثي (لا يمثل Bid/Ask وسيط):</span><label class="small">سبريد <input aria-label="سبريد الاختبار" inputmode="decimal" data-cost="spread" value="${v.spread}" style="width:58px"></label><label class="small">انزلاق/جهة <input aria-label="انزلاق الاختبار" inputmode="decimal" data-cost="slippage" value="${v.slippage}" style="width:58px"></label><label class="small">عمولة/دورة <input aria-label="عمولة الاختبار" inputmode="decimal" data-cost="commission" value="${v.commission}" style="width:58px"></label><button type="button" class="chartToggle" id="costedObFvgBacktest">تشغيل بصافي التكلفة</button>`;const result=document.getElementById('obFvgBacktestResult');(result||host).before(controls);controls.querySelectorAll('[data-cost]').forEach(input=>input.addEventListener('change',()=>{const current=values();current[input.dataset.cost]=safe(input.value);localStorage.setItem(key,JSON.stringify(current));input.value=current[input.dataset.cost];}));controls.querySelector('#costedObFvgBacktest').addEventListener('click',async()=>{const box=document.getElementById('obFvgBacktestResult'),costs=values(),params=new URLSearchParams(costs);if(box)box.innerHTML='<div class="empty">جارِ تشغيل الاختبار بصافي السبريد والانزلاق والعمولة...</div>';try{const response=await fetch('/api/strategy-backtest/ob-fvg/'+encodeURIComponent(selectedTimeframe||chartUI.loadedTimeframe||'1d')+'?'+params,{cache:'no-store'}),payload=await response.json();if(!response.ok||payload.error)throw new Error(payload.error||'تعذر الاختبار');const m=payload.result?.metrics||{},n=(x,d=2)=>x===null||x===undefined?'—':Number(x).toFixed(d);if(box)box.innerHTML=`<div class="toolDetails">صافي بعد التكلفة: ${n(m.total_r)}R · PF ${n(m.profit_factor)} · صفقات ${n(m.filled_trades,0)}</div><div class="small">سبريد ${n(costs.spread)} · انزلاق/جهة ${n(costs.slippage)} · عمولة/دورة ${n(costs.commission)}. افتراض بحثي معلن، وليس تسعير وسيط.</div>`;}catch(error){if(box)box.innerHTML='<div class="notice">'+esc(error.message||'تعذر الاختبار')+'</div>';}});};
		  new MutationObserver(install).observe(document.body,{childList:true,subtree:true});window.addEventListener('load',install);
		})();
		</script>
		<script>
		(function(){
		  const wideButton=document.getElementById('chartLandscape'),exitButton=document.getElementById('pageLandscapeExit');
		  if(!wideButton||!exitButton)return;
		  const resizeWide=()=>{setTimeout(()=>{resizeChart();queueZoneDraw();},80)};
		  window.requestPageLandscape=async function(){
		    document.body.classList.add('pageLandscapeRequested','pageWideFallback');
		    wideButton.textContent='شاشة واسعة ✓';
		    const request=document.documentElement.requestFullscreen||document.documentElement.webkitRequestFullscreen;
		    try{if(!document.fullscreenElement&&!document.webkitFullscreenElement&&request)await request.call(document.documentElement)}catch(_){}
		    try{if(screen.orientation?.lock){await screen.orientation.lock('landscape');document.body.classList.remove('pageWideFallback');wideButton.textContent='عرضي ✓'}}catch(_){document.body.classList.add('pageWideFallback')}
		    resizeWide();
		  };
		  const resetWideLayout=()=>{
		    document.body.classList.remove('pageLandscapeRequested','pageWideFallback','chartLock');
		    document.getElementById('chartShell')?.classList.remove('chartPseudoFullscreen');
		    document.getElementById('chartDrawingTools')?.classList.remove('is-open');
		    document.getElementById('proIndicatorModal')?.classList.remove('open');
		    wideButton.textContent='↻ عرضي';
		    try{screen.orientation?.unlock?.()}catch(_){}
		    resizeWide();
		  };
		  window.exitPageLandscape=async function(){
		    resetWideLayout();
		    const fullscreen=document.fullscreenElement||document.webkitFullscreenElement;
		    if(fullscreen){try{await (document.exitFullscreen||document.webkitExitFullscreen)?.call(document)}catch(_){}}
		    window.setTimeout(resetWideLayout,140);
		  };
		  document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)resetWideLayout()});
		  document.addEventListener('webkitfullscreenchange',()=>{if(!document.webkitFullscreenElement)resetWideLayout()});
		  wideButton.replaceWith(wideButton.cloneNode(true));
		  const activeButton=document.getElementById('chartLandscape');activeButton.addEventListener('click',window.requestPageLandscape);
		  exitButton.replaceWith(exitButton.cloneNode(true));document.getElementById('pageLandscapeExit').addEventListener('click',window.exitPageLandscape);
		  window.visualViewport?.addEventListener('resize',resizeWide);window.addEventListener('orientationchange',resizeWide);
		})();
		</script>
		<style>
		/* مساحة عمل الرسم الواسعة: تحكم مركز وطبقات قابلة للبحث. */
		.proChartToolbar{display:none;align-items:center;gap:0;min-height:48px;padding:5px 64px 5px 10px;background:#080d13;border-bottom:1px solid #334151;overflow:visible;scrollbar-width:none;direction:ltr}.proChartGroup{display:flex;align-items:center;gap:0;border:1px solid #536171;margin-left:10px;flex:0 0 auto}.proChartGroup:last-child{margin-left:0}.proChartBtn{height:38px;min-width:48px;padding:0 12px;border:0;border-left:1px solid #536171;background:#0c1118;color:#d9e2ec;font:700 12px Tahoma,Arial;cursor:pointer;white-space:nowrap}.proChartBtn:last-child{border-left:0}.proChartBtn.active,.proChartBtn:hover{background:#1d3348;color:#f3c96b}.proChartBtn:active{transform:scale(.97)}.proChartBtn.indicator{min-width:104px;color:#bfe2ff}.proChartBtn.exit{color:#ffb4b7;background:#2e1b23}.proTfDropdown{position:relative;overflow:visible}.proTimeframeMenu{display:none;position:absolute;top:calc(100% + 5px);left:0;z-index:10090;min-width:210px;padding:6px;background:#0b131c;border:1px solid #536171;border-radius:9px;box-shadow:0 18px 42px #000c;grid-template-columns:repeat(3,1fr);gap:4px}.proTfDropdown.open .proTimeframeMenu{display:grid}.proTimeframeMenu .proChartBtn{min-width:0!important;width:100%;height:34px;padding:0 7px;font-size:11px}.signalTotals{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:0 14px 14px}.signalTotal{padding:9px 6px;text-align:center;border:1px solid #2b4055;border-radius:9px;background:#142231}.signalTotal b{display:block;font-size:17px;line-height:1.1}.signalTotal span{display:block;margin-top:4px;color:#9eb0c2;font-size:10px}.signalTotal.buy b{color:#78d17f}.signalTotal.sell b{color:#ed858b}.signalTotal.neutral b{color:#c8ced8}.proChartTitle{color:#aebdce;font-size:12px;min-width:170px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-left:auto;padding:0 10px;direction:rtl}.proIndicatorModal{display:none;position:absolute;z-index:10060;top:62px;left:50%;transform:translateX(-50%);width:min(610px,calc(100vw - 36px));max-height:calc(100dvh - 100px);background:#0c1219;border:1px solid #617387;box-shadow:0 26px 70px #000c;flex-direction:column;direction:rtl}.proIndicatorModal.open{display:flex}.proIndicatorHead{display:flex;align-items:center;gap:12px;padding:15px 17px;border-bottom:1px solid #2d3b4b;font-size:20px;font-weight:700}.proIndicatorClose{margin-right:auto;width:34px;height:34px;border:0;background:transparent;color:#d5dde7;font-size:28px;cursor:pointer}.proIndicatorSearch{margin:14px 17px 10px;padding:11px 13px;border:1px solid #405164;background:#111a25;color:#eef5fc;font:inherit;outline:none}.proIndicatorSearch:focus{border-color:#e4b65e;box-shadow:0 0 0 3px #e4b65e1c}.proIndicatorHint{padding:0 17px 10px;color:#8fa5ba;font-size:11px;line-height:1.6}.proIndicatorList{overflow:auto;padding:0 8px 12px}.proIndicatorItem{width:100%;display:flex;align-items:center;justify-content:space-between;padding:13px 12px;border:0;border-top:1px solid #202d3b;background:transparent;color:#e8f0f8;text-align:right;font:600 15px Tahoma,Arial;cursor:pointer}.proIndicatorItem:hover{background:#162536}.proIndicatorState{font-size:11px;color:#7ed487}.proIndicatorItem.off .proIndicatorState{color:#91a3b8}.pageLandscapeRequested .app>#chart{height:100dvh!important}.pageLandscapeRequested .proChartToolbar{display:flex}.pageLandscapeRequested .chartShell{height:auto!important;min-height:0!important;flex:1 1 auto!important}.pageLandscapeRequested .chartCanvas{height:auto!important;min-height:0!important;flex:1 1 auto!important}.pageLandscapeRequested .chartMeta{padding:7px 14px!important}.pageLandscapeRequested .chartMeta b{font-size:14px}.pageLandscapeRequested .chartDrawingTools{border-top:1px solid #263545}.pageLandscapeRequested .pageLandscapeExit{display:none!important}@media(max-width:700px){.proChartToolbar{padding-left:10px;padding-right:10px}.proChartTitle{display:none}.proChartBtn{min-width:44px;padding:0 10px}.proChartBtn.indicator{min-width:92px}}
		/* في الهاتف تُنقل الأزرار الثانوية إلى درجين قصيرين بدلاً من حجز الشاشة دائماً. */
		.chartMobileBar{display:none}.chartCompactPanel{display:flex}.chartDrawingTools.is-open{display:flex!important}@media(max-width:639px){.chartMobileBar{display:flex;gap:8px;padding:8px 12px;border-top:1px solid #213347;background:#0d1620}.chartMobileBar button{flex:1;min-height:34px;border:1px solid #304861;border-radius:9px;background:#142233;color:#d7e3ef;font:700 11px Tahoma,Arial;cursor:pointer}.chartMobileBar button.active{border-color:#e4b65e;background:#263a4f;color:#f7d77e}.chartCompactPanel{display:none!important}.chartCompactPanel.compactOpen{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto!important;padding:8px 12px!important}.chartShell:fullscreen .chartMobileBar,.chartShell.chartPseudoFullscreen .chartMobileBar{display:none!important}.chartShell:fullscreen .chartCompactPanel,.chartShell.chartPseudoFullscreen .chartCompactPanel{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto!important}body.pageLandscapeRequested .chartMobileBar,body.pageLandscapeRequested .chartCompactPanel{display:none!important}body.pageLandscapeRequested .chartDrawingTools{display:none!important}body.pageLandscapeRequested .chartDrawingTools.is-open{display:flex!important;flex-wrap:nowrap!important;overflow-x:auto!important}}
			/* في الشاشة الواسعة لا تحجب صفوف الأدوات أسفل الشموع. يفتح الرسم اليدوي من زر الشريط العلوي كلوحة عائمة. */
			body.pageLandscapeRequested .chartActions,body.pageLandscapeRequested .chartControls,body.pageLandscapeRequested .chartMobileBar{display:none!important}body.pageLandscapeRequested .chartDrawingTools{display:none!important}body.pageLandscapeRequested .chartDrawingTools.is-open{display:flex!important;position:absolute!important;z-index:10075;top:64px;left:12px;right:auto;max-width:calc(100vw - 24px);padding:8px 10px!important;border:1px solid #3c5063!important;border-radius:10px;background:#0b131ddd;box-shadow:0 14px 36px #0009;flex-wrap:nowrap!important;overflow-x:auto!important}.pageLandscapeRequested .chartDrawHint{display:none!important}.pageLandscapeRequested .proChartToolbar{position:relative;z-index:10076}.pageLandscapeRequested .chartCanvas{min-height:0!important}
			/* سكة الأطر تبقى ظاهرة حتى إن استعمل المستخدم دوران الهاتف أو ملء الرسم بدلاً من زر العرضي. */
			.chartShell:fullscreen .proChartToolbar,.chartShell.chartPseudoFullscreen .proChartToolbar{display:flex;position:relative;z-index:10076}.chartShell:fullscreen .chartActions,.chartShell:fullscreen .chartControls,.chartShell.chartPseudoFullscreen .chartActions,.chartShell.chartPseudoFullscreen .chartControls{display:none!important}.chartShell:fullscreen .chartDrawingTools,.chartShell.chartPseudoFullscreen .chartDrawingTools{display:none!important}.chartShell:fullscreen .chartDrawingTools.is-open,.chartShell.chartPseudoFullscreen .chartDrawingTools.is-open{display:flex!important;position:absolute!important;z-index:10075;top:64px;left:12px;max-width:calc(100vw - 24px);overflow-x:auto!important}
				@media(orientation:landscape) and (max-height:600px){#chart .proChartToolbar{display:flex!important;position:relative;z-index:10076;flex-wrap:nowrap;align-items:center;gap:5px;padding:max(4px,env(safe-area-inset-top)) max(8px,env(safe-area-inset-right)) 4px max(8px,env(safe-area-inset-left));min-height:0;overflow:visible}#chart #proTimeframes{order:0;flex:0 0 auto;width:auto;min-width:0;margin:0;overflow:visible;border-color:#536171;direction:ltr}#chart #proTimeframes .proChartBtn{min-width:70px;height:34px;padding:0 9px;font-size:11px;flex:0 0 auto}#chart .proChartGroup{margin:0}#chart .proChartTitle{display:none}#chart .chartActions,#chart .chartControls,#chart .chartMobileBar{display:none!important}#chart .chartDrawingTools{display:none!important}#chart .chartDrawingTools.is-open{display:flex!important;position:absolute!important;z-index:10075;top:58px;left:8px;max-width:calc(100vw - 16px);overflow-x:auto!important}body.pageLandscapeRequested #chart .chartCanvas{height:auto!important;min-height:0!important;flex:1 1 auto!important}}
				</style>
			<style>
			/* شريط بيانات الرسم وإعدادات مساحة العمل: لا يغيران مصدر الشموع أو منطق التحليل. */
			.chartWorkspaceBand{display:flex;flex-direction:column;gap:8px;padding:0 12px 10px;border-bottom:1px solid #202b37;background:#0d141d}.chartDataBand{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;direction:rtl}.chartDataChip{flex:0 0 auto;border:1px solid #304255;border-radius:999px;background:#13202d;color:#b7c7d8;padding:5px 8px;font:700 10px Tahoma,Arial;white-space:nowrap}.chartDataChip.good{border-color:#477b56;color:#bfeab9;background:#14291a}.chartDataChip.warn{border-color:#836d3a;color:#f3d98e;background:#302a1a}.chartTfRail{display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;direction:ltr}.chartTfRail button{flex:0 0 auto;min-width:44px;border:1px solid #314457;background:#111c27;color:#adbed0;border-radius:7px;padding:7px 9px;font:700 11px Tahoma,Arial;cursor:pointer}.chartTfRail button[data-chart-timeframe="4h"]{min-width:68px;border-color:#a98637;color:#f3d98e;background:#221e14}.chartTfRail button.active{border-color:#e0ad44;background:#2e2819;color:#f6d98c}.chartSettingsPanel{display:none;margin:0 12px 10px;padding:10px;border:1px solid #304255;border-radius:8px;background:#101a24;gap:10px;align-items:center;flex-wrap:wrap}.chartSettingsPanel.open{display:flex}.chartSettingsLabel{display:flex;align-items:center;gap:7px;color:#b9c8d8;font:700 11px Tahoma,Arial}.chartSettingsLabel input[type=range]{accent-color:#e0ad44;width:118px}.chartSettingsNote{flex:1 1 180px;color:#8da0b2;font:11px/1.55 Tahoma,Arial}.chartSettingsPanel .chartToggle.on{background:#2b4530;border-color:#72c36a;color:#bfeab9}@media(max-width:639px){.chartWorkspaceBand{padding:0 10px 8px}.chartTfRail button{min-width:42px;padding:6px 8px}.chartTfRail button[data-chart-timeframe="4h"]{min-width:66px}.chartSettingsPanel{margin:0 10px 8px}.chartSettingsNote{order:5;flex-basis:100%}}body.pageLandscapeRequested .chartWorkspaceBand,body.pageLandscapeRequested .chartSettingsPanel,.chartShell:fullscreen .chartWorkspaceBand,.chartShell.chartPseudoFullscreen .chartWorkspaceBand,.chartShell:fullscreen .chartSettingsPanel,.chartShell.chartPseudoFullscreen .chartSettingsPanel{display:none!important}
			</style>
		<script>
		(function(){
		  const shell=document.getElementById('chartShell'),chart=document.getElementById('chart');
		  if(!shell||!chart||document.getElementById('proChartToolbar'))return;
  const timeframes=[['1m','1 د'],['5m','5 د'],['10m','10 د'],['15m','15 د'],['30m','30 د'],['1h','1 س'],['2h','2 س'],['4h','4 ساعات'],['1d','1 ي'],['1wk','1 أ'],['1mo','1 ش']];
  const indicators=[['ma','MA 20 / 50'],['vwap','Anchored VWAP'],['fvg','Fair Value Gap'],['sweep','Liquidity Sweep'],['profile','Volume Profile'],['liquidityzones','مناطق السيولة'],['orderblocks','Order Blocks'],['supportresistance','دعم / مقاومة'],['fib','Fibonacci'],['scenario','منطقة السيناريو'],['volume','الحجم']];
		  const escPro=value=>String(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  shell.insertAdjacentHTML('afterbegin',`<div class="proChartToolbar" id="proChartToolbar"><div class="proChartGroup proTfDropdown" id="proTimeframes"><button class="proChartBtn" id="proTimeframeOpen" aria-expanded="false">الإطار <span id="proCurrentTf">1 ي</span>⌄</button><div class="proTimeframeMenu">${timeframes.map(([id,label])=>`<button class="proChartBtn" data-pro-tf="${id}">${label}</button>`).join('')}</div></div><div class="proChartGroup"><button class="proChartBtn indicator" id="proIndicatorOpen">الأدوات</button><button class="proChartBtn" id="proFit">ملاءمة</button><button class="proChartBtn" id="proZoomOut">−</button><button class="proChartBtn" id="proZoomIn">+</button></div><div class="proChartTitle" id="proChartTitle">XAUUSD · رسم مرجعي</div><div class="proChartGroup"><button class="proChartBtn" id="proDraw">✎ رسم</button><button class="proChartBtn exit" id="proExitWide">× خروج</button></div></div><aside class="proIndicatorModal" id="proIndicatorModal" aria-label="لوحة أدوات الرسم"><div class="proIndicatorHead">الأدوات والطبقات <button type="button" class="proIndicatorClose" id="proIndicatorClose" aria-label="إغلاق">×</button></div><input class="proIndicatorSearch" id="proIndicatorSearch" placeholder="ابحث في الأدوات المتاحة..." autocomplete="off"><div class="proIndicatorHint">تؤثر كل أداة معروضة في الرسم عند تفعيلها. لا تعرض اللوحة Order Flow أو بيانات DOM غير المتوفرة.</div><div class="proIndicatorList" id="proIndicatorList"></div></aside>`);
		  const modal=document.getElementById('proIndicatorModal'),list=document.getElementById('proIndicatorList'),search=document.getElementById('proIndicatorSearch');
function syncProControls(){
			    document.querySelectorAll('[data-pro-tf]').forEach(button=>button.classList.toggle('active',button.dataset.proTf===selectedTimeframe));
			    const selectedLabel=timeframes.find(([id])=>id===selectedTimeframe)?.[1]||selectedTimeframe;const current=document.getElementById('proCurrentTf');if(current)current.textContent=selectedLabel;
			    document.getElementById('proChartTitle').textContent=`XAUUSD · ${document.getElementById('chartTitle')?.textContent?.split('·').pop()?.trim()||selectedTimeframe} · شموع مرجعية`;
			    document.querySelectorAll('[data-overlay]').forEach(button=>button.classList.toggle('on',!!chartUI.overlays[button.dataset.overlay]));
			  }
		  function renderIndicatorList(query=''){
		    const term=query.trim().toLowerCase();
		    list.innerHTML=indicators.filter(([,name])=>!term||name.toLowerCase().includes(term)).map(([key,name])=>`<button class="proIndicatorItem ${chartUI.overlays[key]?'':'off'}" data-pro-overlay="${key}"><span>${escPro(name)}</span><span class="proIndicatorState">${chartUI.overlays[key]?'ظاهر ✓':'مخفي'}</span></button>`).join('')||'<div class="empty">لا توجد طبقة مطابقة للبحث.</div>';
		    list.querySelectorAll('[data-pro-overlay]').forEach(button=>button.addEventListener('click',()=>{const key=button.dataset.proOverlay;chartUI.overlays[key]=!chartUI.overlays[key];if(chartUI.loadedTimeframe)loadChart(chartUI.loadedTimeframe,false);renderIndicatorList(search.value);syncProControls();}));
		  }
		  document.getElementById('proIndicatorOpen').addEventListener('click',()=>{modal.classList.add('open');renderIndicatorList(search.value);search.focus();});
		  document.getElementById('proIndicatorClose').addEventListener('click',()=>modal.classList.remove('open'));
		  search.addEventListener('input',()=>renderIndicatorList(search.value));
  const tfDropdown=document.getElementById('proTimeframes'),tfOpen=document.getElementById('proTimeframeOpen');tfOpen?.addEventListener('click',()=>{const open=tfDropdown.classList.toggle('open');tfOpen.setAttribute('aria-expanded',String(open));});document.querySelectorAll('[data-pro-tf]').forEach(button=>button.addEventListener('click',async()=>{tfDropdown.classList.remove('open');tfOpen?.setAttribute('aria-expanded','false');await selectTimeframe(button.dataset.proTf);syncProControls();}));document.addEventListener('click',event=>{if(tfDropdown&&!tfDropdown.contains(event.target)){tfDropdown.classList.remove('open');tfOpen?.setAttribute('aria-expanded','false');}});
		  document.getElementById('proFit').addEventListener('click',()=>chartUI.chart?.timeScale().fitContent());
		  document.getElementById('proZoomIn').addEventListener('click',()=>chartZoom(1.35));
		  document.getElementById('proZoomOut').addEventListener('click',()=>chartZoom(.74));
		  document.getElementById('proDraw').addEventListener('click',()=>{const tools=document.getElementById('chartDrawingTools');tools?.classList.toggle('is-open');document.getElementById('proDraw')?.classList.toggle('active',!!tools?.classList.contains('is-open'));});
		  document.getElementById('proExitWide').addEventListener('click',()=>window.exitPageLandscape?.());
  const baseLoad=window.loadChart;window.loadChart=async function(...args){const result=await baseLoad(...args);syncProControls();return result};
  window.addEventListener('xauusd:timeframe-selected',syncProControls);
		  window.setTimeout(syncProControls,120);
		})();
		</script>
		<script>
		(function(){
		  const shell=document.getElementById('chartShell'),actions=shell?.querySelector('.chartActions'),controls=shell?.querySelector('.chartControls');
		  if(!shell||!actions||!controls||document.getElementById('chartMobileBar'))return;
		  actions.classList.add('chartCompactPanel');controls.classList.add('chartCompactPanel');
		  actions.insertAdjacentHTML('beforebegin','<div class="chartMobileBar" id="chartMobileBar"><button type="button" id="chartActionsToggle">إجراءات الرسم</button><button type="button" id="chartLayersToggle">الطبقات والمؤشرات</button></div>');
		  const actionsToggle=document.getElementById('chartActionsToggle'),layersToggle=document.getElementById('chartLayersToggle');
		  const setOpen=(name)=>{const actionOpen=name==='actions'&&!actions.classList.contains('compactOpen'),layerOpen=name==='layers'&&!controls.classList.contains('compactOpen');actions.classList.toggle('compactOpen',actionOpen);controls.classList.toggle('compactOpen',layerOpen);actionsToggle.classList.toggle('active',actionOpen);layersToggle.classList.toggle('active',layerOpen);};
		  actionsToggle.addEventListener('click',()=>setOpen('actions'));layersToggle.addEventListener('click',()=>setOpen('layers'));
		  window.addEventListener('xauusd:timeframe-selected',()=>setOpen('none'));
		})();
			</script>
			<script>
			(function(){
			  const shell=document.getElementById('chartShell');
			  if(!shell||document.getElementById('chartWorkspaceBand'))return;
			  const chartMeta=shell.querySelector('.chartMeta'),actions=shell.querySelector('.chartActions');
			  if(!chartMeta||!actions)return;
			  const frames=[['1m','1د'],['5m','5د'],['10m','10د'],['15m','15د'],['30m','30د'],['1h','1س'],['2h','2س'],['4h','4 ساعات'],['1d','1ي'],['1wk','1أ'],['1mo','1ش']];
			  const key='xauusd-chart-workspace-v1';
			  const defaults={grid:true,density:8};
			  let preferences=defaults;
			  try{preferences={...defaults,...JSON.parse(localStorage.getItem(key)||'{}')}}catch(_){preferences={...defaults}}
			  chartMeta.insertAdjacentHTML('afterend',`<div class="chartWorkspaceBand" id="chartWorkspaceBand"><div class="chartDataBand" id="chartDataBand"><span class="chartDataChip">جاري فحص جودة الشموع…</span></div><div class="chartTfRail" id="chartTfRail" aria-label="أطر الرسم">${frames.map(([id,label])=>`<button type="button" data-chart-timeframe="${id}">${label}</button>`).join('')}</div></div>`);
			  actions.insertAdjacentHTML('beforeend',`<button class="chartToggle" id="chartSettingsToggle" aria-expanded="false">⚙ إعدادات</button>`);
			  actions.insertAdjacentHTML('afterend',`<section class="chartSettingsPanel" id="chartWorkspaceSettings" aria-label="إعدادات الرسم"><label class="chartSettingsLabel"><input type="checkbox" id="chartGridToggle"> شبكة الرسم</label><label class="chartSettingsLabel">كثافة الشموع <input type="range" id="chartDensity" min="4" max="16" step="1"></label><output class="chartDataChip" id="chartDensityValue"></output><button type="button" class="chartToggle" id="chartSettingsReset">استعادة</button><span class="chartSettingsNote">هذه الإعدادات تغير طريقة العرض المحلية فقط؛ لا تغير OHLC أو المؤشرات أو مصدر الشموع.</span></section>`);
			  const gridToggle=document.getElementById('chartGridToggle'),density=document.getElementById('chartDensity'),densityValue=document.getElementById('chartDensityValue'),settings=document.getElementById('chartWorkspaceSettings'),settingsToggle=document.getElementById('chartSettingsToggle');
			  const formatGap=value=>{const seconds=Number(value);if(!Number.isFinite(seconds))return 'غير متاح';if(seconds<60)return seconds+' ث';if(seconds<3600)return (seconds/60).toFixed(0)+' د';return (seconds/3600).toFixed(1)+' س'};
			  const apply=()=>{gridToggle.checked=!!preferences.grid;density.value=String(preferences.density);densityValue.textContent=preferences.density+' px';localStorage.setItem(key,JSON.stringify(preferences));if(!chartUI?.chart)return;chartUI.chart.applyOptions({grid:{vertLines:{color:preferences.grid?'#17212b':'transparent'},horzLines:{color:preferences.grid?'#202b37':'transparent'}},timeScale:{barSpacing:Number(preferences.density),minBarSpacing:2}});};
			  const syncFrames=()=>document.querySelectorAll('[data-chart-timeframe]').forEach(button=>button.classList.toggle('active',button.dataset.chartTimeframe===selectedTimeframe));
			  const renderQuality=data=>{const box=document.getElementById('chartDataBand');if(!box)return;const quality=data?.chart_data_quality||{},mode=quality.data_mode_label||'تصنيف المصدر غير متاح',source=data?.source||'مصدر غير متاح',gap=formatGap(quality.last_two_gap_seconds),modeClass=quality.data_mode==='NATIVE_DATA'?'good':'warn',gapClass=Number(quality.rejected_incomplete_buckets||0)>0?'warn':'good';box.innerHTML=`<span class="chartDataChip ${modeClass}">${esc(mode)}</span><span class="chartDataChip">${esc(source)}</span><span class="chartDataChip">مرئي ${num(quality.visible_rows,0)} / متحقق ${num(quality.validated_rows,0)}</span><span class="chartDataChip ${gapClass}">فاصل آخر شمعتين: ${esc(gap)}</span>${quality.rejected_incomplete_buckets?`<span class="chartDataChip warn">استبعاد ${num(quality.rejected_incomplete_buckets,0)} سلال غير مكتملة</span>`:''}`;};
			  const refreshWorkspace=()=>{const payload=window.latestChartPayload;if(payload?.timeframe?.id===selectedTimeframe)renderQuality(payload);};
			  gridToggle.addEventListener('change',()=>{preferences.grid=gridToggle.checked;apply();});
			  density.addEventListener('input',()=>{preferences.density=Math.max(4,Math.min(16,Number(density.value)||defaults.density));apply();});
			  settingsToggle.addEventListener('click',()=>{const open=settings.classList.toggle('open');settingsToggle.classList.toggle('on',open);settingsToggle.setAttribute('aria-expanded',String(open));});
			  document.getElementById('chartSettingsReset').addEventListener('click',()=>{preferences={...defaults};apply();});
			  document.querySelectorAll('[data-chart-timeframe]').forEach(button=>button.addEventListener('click',()=>selectTimeframe(button.dataset.chartTimeframe)));
			  window.addEventListener('xauusd:timeframe-selected',()=>{syncFrames();refreshWorkspace();});
			  const previousLoad=window.loadChart;window.loadChart=async function(...args){const result=await previousLoad(...args);apply();syncFrames();refreshWorkspace();return result;};
			  apply();syncFrames();window.setTimeout(refreshWorkspace,500);
			})();
			</script>
			<script>
			(function(){
			  const analysis=document.getElementById('analysis');
			  if(!analysis||document.getElementById('strategyLab'))return;
			  const markup=`<div class="sectionTitle">مختبر استراتيجيات السيولة والأخبار</div><div class="panel" id="strategyLab"><div class="toolCard"><div class="toolDetails">اختبر قواعد القرار على الإطار المختار. حالات الاختبار لا تغير بيانات السوق ولا تمثل خبراً أو أمراً حقيقياً.</div><div class="toolLevels"><button class="chartToggle" data-strategy-test="liquidity_confluence">توافق السيولة</button><button class="chartToggle" data-strategy-test="high_impact_news">خبر عالي الأثر</button><button class="chartToggle" data-strategy-test="conflicting_evidence">تعارض الأدلة</button></div></div><div id="strategyLabResult" class="empty">اختر حالة اختبار لعرض أثرها على الدخول والوقف والهدف أو قرار الحياد.</div></div>`;
			  const anchor=document.getElementById('advancedTools');
			  anchor?.closest('.panel')?.insertAdjacentHTML('afterend',markup);
			  const escLab=value=>String(value??'—').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
			  const numberLab=(value,digits=2)=>value===null||value===undefined||Number.isNaN(Number(value))?'—':Number(value).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits});
			  const render=(payload)=>{const box=document.getElementById('strategyLabResult'),result=payload?.result||{};if(!box)return;const style=result.decision_state==='signal'?'cellBuy':result.decision_state==='neutral'?'cellNeutral':'cellSell';box.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${escLab(payload?.test?.title||'نتيجة الاختبار')}</span><span class="badge ${style}">${escLab(result.signal||'—')}</span></div><div class="toolDetails">${escLab(payload?.test?.description||'')}<br>${escLab(result.reason||'—')}</div><div class="signalLevels"><div class="level"><span>الثقة</span><strong>${numberLab(result.confidence,1)}%</strong></div><div class="level"><span>الدخول المرجعي</span><strong class="value">${numberLab(result.entry)}</strong></div><div class="level"><span>وقف / هدف</span><strong class="value">${numberLab(result.stop_loss)} / ${numberLab(result.take_profit)}</strong></div></div><div class="toolLevels">${(result.evidence||[]).map(item=>`<span class="toolLevel">${escLab(item)}</span>`).join('')}</div>${(result.warnings||[]).length?`<div class="notice">${result.warnings.map(escLab).join('<br>')}</div>`:''}<div class="small">${escLab(payload?.test_scope||'')}</div></article>`;};
			  document.querySelectorAll('[data-strategy-test]').forEach(button=>button.addEventListener('click',async()=>{const box=document.getElementById('strategyLabResult'),timeframe=document.querySelector('[data-timeframe].active')?.dataset.timeframe||chartUI.loadedTimeframe||'1d';if(box)box.innerHTML='<div class="empty">جارِ تشغيل اختبار القواعد على الإطار المختار...</div>';try{const response=await fetch('/api/strategy-test/'+encodeURIComponent(button.dataset.strategyTest)+'/'+encodeURIComponent(timeframe),{cache:'no-store'});const payload=await response.json();if(!response.ok||payload.error)throw new Error(payload.error||'تعذر تشغيل الاختبار');render(payload);}catch(error){if(box)box.innerHTML=`<div class="notice">${escLab(error.message||'تعذر تشغيل الاختبار')}</div>`;}}));
			})();
			</script>
			<script>
			(() => {
			  const syncQuotePresentation = () => {
			    const q = latestSystem?.quote || {};
			    const label = q.status !== 'success' ? 'تحذير: مصدر السعر غير متاح' : q.stale ? 'السعر العام متأخر — لا يوجد سعر حي' : q.live_for_analysis ? 'سعر سوق عام حديث للتحليل والرسم' : 'سعر سوق عام مرجعي — ليس Bid/Ask للتنفيذ';
			    const dot = q.status === 'success' && !q.stale && q.live_for_analysis ? '#72c36a' : '#e0ad44';
			    const status = document.getElementById('systemStatus');
			    if (status) status.innerHTML = `<span class="dot" style="background:${dot}"></span>${esc(label)}`;
			  };
			  setInterval(syncQuotePresentation, 2100);
			  syncQuotePresentation();
			})();
			</script>
			<style>
			/* مساحة تحليل واسعة بطابع طرفية: أدوات مركزة، تباين عالٍ، ومساحة أكبر للشموع. */
			.terminalWorkspace .proChartToolbar{background:#05070a;border-bottom:1px solid #59636e;min-height:58px;padding:8px 64px 8px 12px;gap:8px;box-shadow:0 8px 18px #0008}.terminalWorkspace .proChartGroup{border-color:#69747f;margin-left:0}.terminalWorkspace .proChartBtn{height:38px;background:#06080c;color:#f4f6f8;border-left-color:#69747f;font-size:12px;letter-spacing:.01em}.terminalWorkspace .proChartBtn.active,.terminalWorkspace .proChartBtn:hover{background:#17283a;color:#f6d367}.terminalWorkspace .proChartBtn.exit{background:#3a2227;color:#ffd6d8}.terminalWorkspace .proChartBtn.indicator{min-width:96px;color:#d4eaff}.terminalWorkspace .chartShell{background:#05070a!important}.terminalWorkspace .chartCanvas{background:#05070a!important}.terminalWorkspace .chartMeta{background:#05070a;border-bottom:1px solid #29313a}.terminalWorkspace .chartMeta b{color:#eef4f8}.terminalWorkspace .chartActions,.terminalWorkspace .chartControls{background:#080b10;border-color:#26303a}.terminalWorkspace .chartToggle{background:#0b1118;border-color:#485564;color:#ced9e5}.terminalWorkspace .chartToggle.on{background:#193326;border-color:#75ce79;color:#e0f7dd}.terminalWorkspace .chartDrawingTools{background:#080d13;border-color:#354252}.terminalWorkspace .chartCrosshair{background:#080d13;border-color:#354252;color:#d2dce7}.terminalWorkspace .chartZoneLabel{stroke:#05070a;stroke-width:3.4px}.terminalWorkspace .chartCanvas::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,transparent 0%,transparent 94%,#ffffff08 100%)}
			.proMarketReadout{display:none;align-items:center;gap:10px;min-width:240px;max-width:360px;padding:0 10px;color:#bac6d2;font:700 11px Tahoma,Arial;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:ltr}.proMarketReadout b{color:#f7f9fc;font-weight:800}.proMarketReadout .proMarketState{color:#9ca9b7;font-weight:400}.proChartBtn.chartMode{min-width:69px}.proChartBtn.range{min-width:42px;padding:0 9px;color:#aab8c6}.proChartBtn.range.active{color:#f6d367;background:#17283a}.terminalWorkspace .proMarketReadout{display:flex}.intradayAlertToast{position:fixed;z-index:10200;top:16px;right:16px;max-width:min(390px,calc(100vw - 32px));padding:14px 42px 14px 14px;border:1px solid #f0c760;border-right:4px solid #72c36a;border-radius:10px;background:#111b25;color:#eef6fb;box-shadow:0 18px 44px #000b;font:700 13px/1.65 Tahoma,Arial;direction:rtl}.intradayAlertToast button{position:absolute;top:5px;right:7px;width:28px;height:28px;border:0;background:transparent;color:#dce7f1;font-size:22px;cursor:pointer}.intradayAlertToast b{color:#f6d36f}@media(max-width:639px){.intradayAlertToast{top:10px;right:10px;left:10px;max-width:none}}
			.chartInteractiveZone{cursor:pointer;pointer-events:all;transition:filter 150ms ease,fill-opacity 150ms ease}.chartInteractiveZone:hover,.chartInteractiveZone:focus{filter:brightness(1.32);outline:none}.chartInteractiveZone:focus{stroke:#f7e19b!important;stroke-width:2.2!important}.toolCard.toolInspectable{cursor:pointer;position:relative;transition:background 160ms cubic-bezier(.23,1,.32,1),transform 160ms cubic-bezier(.23,1,.32,1)}.toolCard.toolInspectable:hover{background:#182a3b}.toolCard.toolInspectable:focus-visible{outline:2px solid var(--gold);outline-offset:-2px}.toolExplore{margin-right:auto;flex:0 0 auto;border:1px solid #48657f;border-radius:999px;background:#13283a;color:#bfe5ff;padding:5px 8px;font:700 10px Tahoma,Arial;cursor:pointer}.toolExplore:hover{background:#1c3b55;color:#fff}.toolLevel.toolDrilldown{cursor:pointer;border-color:#4f7492;color:#d5ecff;transition:background 150ms ease,border-color 150ms ease}.toolLevel.toolDrilldown:hover,.toolLevel.toolDrilldown:focus-visible{background:#203d55;border-color:#87c9f0;outline:none}
			.chartInsightDrawer{position:fixed;z-index:10110;left:50%;bottom:max(12px,env(safe-area-inset-bottom));transform:translate(-50%,calc(100% + 28px));width:min(455px,calc(100vw - 24px));max-height:min(590px,calc(100dvh - 30px));overflow:auto;background:linear-gradient(160deg,#111a25,#080d13);border:1px solid #53687e;box-shadow:0 26px 74px #000d;color:#edf3f8;transition:transform 230ms cubic-bezier(.23,1,.32,1),opacity 180ms ease;opacity:0;pointer-events:none;direction:rtl}.chartInsightDrawer.open{transform:translate(-50%,0);opacity:1;pointer-events:auto}.insightHead{display:flex;align-items:flex-start;gap:10px;padding:14px 15px 10px;border-bottom:1px solid #28394a}.insightEyebrow{font-size:10px;color:#91b9d8;letter-spacing:.09em}.insightTitle{font-size:17px;font-weight:800;color:#f6fafc;margin-top:3px}.insightClose{margin-right:auto;width:32px;height:32px;border:1px solid #3b4c5d;background:#152230;color:#e7edf4;font-size:21px;cursor:pointer}.insightChart{height:172px;margin:12px;border:1px solid #314458;background:#05070a;direction:ltr}.insightSummary{padding:0 14px 5px;color:#b4c2cf;font-size:12px;line-height:1.7}.insightStats{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;padding:9px 14px 13px}.insightStat{border:1px solid #2e4255;background:#142231;padding:8px 7px;text-align:center}.insightStat span{display:block;font-size:10px;color:#8fa5ba}.insightStat b{display:block;margin-top:4px;color:#f0f6fa;font-size:12px;direction:ltr}.insightActions{display:flex;gap:8px;padding:0 14px 14px}.insightActions button{flex:1;border:1px solid #48657f;background:#142a3d;color:#d8ecfc;border-radius:7px;padding:9px;font:700 12px Tahoma,Arial;cursor:pointer}.insightActions button.primary{background:#23422f;border-color:#75ce79;color:#e5f8df}.insightDisclaimer{padding:0 14px 14px;color:#8fa1b3;font-size:10px;line-height:1.6}@media(orientation:landscape) and (max-height:600px){.chartInsightDrawer{left:auto;right:12px;bottom:12px;transform:translateX(calc(100% + 28px));width:min(395px,calc(100vw - 126px));max-height:calc(100dvh - 88px)}.chartInsightDrawer.open{transform:translateX(0)}.insightChart{height:142px}.proMarketReadout{min-width:205px}.terminalWorkspace .proChartToolbar{padding-right:12px}.terminalWorkspace #proTimeframes{border-color:#69747f}.terminalWorkspace .proChartBtn{height:34px}}
			</style>
			<script>
			(() => {
			  const names={liquidity_zones:'مناطق السيولة',fair_value_gap:'Fair Value Gap',order_blocks:'Order Blocks',fibonacci:'Fibonacci',liquidity_sweep:'Liquidity Sweep',anchored_vwap:'Anchored VWAP',volume_profile:'Volume Profile',support_resistance:'دعم / مقاومة'};
			  const zoneTool={buy_side_liquidity:'liquidity_zones',sell_side_liquidity:'liquidity_zones',fair_value_gap:'fair_value_gap',bullish_order_block:'order_blocks',bearish_order_block:'order_blocks',support:'support_resistance',resistance:'support_resistance'};
			  const safe=value=>String(value??'—').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
			  const format=value=>value===null||value===undefined||Number.isNaN(Number(value))?'—':Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
			  const terminal=()=>document.body.classList.contains('pageLandscapeRequested')||document.fullscreenElement===document.getElementById('chartShell')||document.getElementById('chartShell')?.classList.contains('chartPseudoFullscreen');
			  function applyTerminalTheme(){
			    const L=window.LightweightCharts;if(!chartUI.chart||!L)return;
			    chartUI.chart.applyOptions({layout:{background:{type:'solid',color:'#05070a'},textColor:'#aeb9c6',fontFamily:'Tahoma, Arial'},grid:{vertLines:{color:'#1d252e'},horzLines:{color:'#1d252e'}},rightPriceScale:{borderColor:'#69747f'},timeScale:{borderColor:'#69747f',timeVisible:true,secondsVisible:false,rightOffset:4,barSpacing:8,minBarSpacing:2},crosshair:{mode:L.CrosshairMode.Normal,vertLine:{color:'#758391',labelBackgroundColor:'#344353'},horzLine:{color:'#758391',labelBackgroundColor:'#344353'}}});
			    chartUI.candles?.applyOptions({upColor:'#42dd54',downColor:'#fb3e43',borderUpColor:'#42dd54',borderDownColor:'#fb3e43',wickUpColor:'#e7f0f3',wickDownColor:'#e7f0f3',lastValueVisible:false,priceLineVisible:false});
			  }
			  function ensureDrawer(){
			    if(document.getElementById('chartInsightDrawer'))return;
			    document.body.insertAdjacentHTML('beforeend','<aside class="chartInsightDrawer" id="chartInsightDrawer" aria-live="polite"><div class="insightHead"><div><div class="insightEyebrow" id="insightEyebrow">طبقة تحليلية</div><div class="insightTitle" id="insightTitle">تفاصيل المستوى</div></div><button type="button" class="insightClose" id="insightClose" aria-label="إغلاق">×</button></div><div class="insightChart" id="insightChart"></div><div class="insightSummary" id="insightSummary"></div><div class="insightStats" id="insightStats"></div><div class="insightActions"><button type="button" class="primary" id="insightFocus">تمركز على الرسم</button><button type="button" id="insightDismiss">إغلاق</button></div><div class="insightDisclaimer">المنطقة أو المستوى ناتج من الشموع والقواعد المعلنة؛ لا يثبت أمراً مؤسسياً أو تدفق أوامر حقيقياً.</div></aside>');
			    const close=()=>document.getElementById('chartInsightDrawer')?.classList.remove('open');
			    document.getElementById('insightClose')?.addEventListener('click',close);document.getElementById('insightDismiss')?.addEventListener('click',close);
			    document.getElementById('insightFocus')?.addEventListener('click',()=>focusInsight(chartUI.insightContext));
			  }
			  async function cacheChartPayload(){
			    const id=chartUI.loadedTimeframe||selectedTimeframe||'1d';
			    if(chartUI.insightPayload?._timeframeId===id)return chartUI.insightPayload;
				    const response=await fetch('/api/chart/'+encodeURIComponent(id),{cache:'no-store'});const data=await readApiJson(response,'تعذر تحميل بيانات الشرح');
				    if(data.error)throw new Error(data.error);data._timeframeId=id;chartUI.insightPayload=data;return data;
			  }
			  function contextFor(kind,payload={}){
			    const toolKey=zoneTool[kind]||kind;const tool=chartUI.inspectorTools?.[toolKey]||{};const lower=payload.lower??tool.levels?.['الحد الأدنى'];const upper=payload.upper??tool.levels?.['الحد الأعلى'];const level=payload.level??payload.value??(Number.isFinite(Number(lower))&&Number.isFinite(Number(upper))?(Number(lower)+Number(upper))/2:undefined);
			    return {toolKey,title:payload.label||names[toolKey]||names[kind]||kind,details:payload.details||tool.details||'لا توجد تفاصيل إضافية لهذه الطبقة.',lower,upper,level,quality:payload.quality_score??tool.quality_score,anchor:payload.formed_at||payload.anchor_at||tool.anchor_at||tool.formed_at||'',start_time:payload.start_time||payload.formed_at||tool.formed_at,end_time:payload.end_time||payload.bos_at||tool.bos_at,levels:tool.levels||{},status:tool.status||payload.status||'مرصود'};
			  }
			  function insightRows(data,context){
			    const rows=data?.candles||[];if(!rows.length)return [];let index=rows.length-1;const focus=Number(context.start_time||context.end_time||0);if(focus)index=Math.max(0,rows.findIndex(row=>Number(row.time)>=focus));
			    return rows.slice(Math.max(0,index-30),Math.min(rows.length,index+38));
			  }
			  function renderInsightChart(rows,context){
			    const host=document.getElementById('insightChart');const L=window.LightweightCharts;if(!host||!L||!rows.length)return;
			    if(chartUI.insightChart){try{chartUI.insightChart.remove()}catch(_){}}host.replaceChildren();
			    const chart=L.createChart(host,{width:host.clientWidth,height:host.clientHeight,layout:{background:{type:'solid',color:'#05070a'},textColor:'#aeb9c6',fontFamily:'Tahoma, Arial'},grid:{vertLines:{color:'#1d252e'},horzLines:{color:'#1d252e'}},rightPriceScale:{borderColor:'#536273'},timeScale:{borderColor:'#536273',timeVisible:true,secondsVisible:false},crosshair:{mode:L.CrosshairMode.Normal}});
			    const series=chart.addSeries(L.CandlestickSeries,{upColor:'#42dd54',downColor:'#fb3e43',wickUpColor:'#e7f0f3',wickDownColor:'#e7f0f3',borderVisible:false,lastValueVisible:false,priceLineVisible:false});
			    series.setData(rows.map(row=>({time:row.time,open:row.open,high:row.high,low:row.low,close:row.close})));
			    const add=(price,label,color,style)=>{if(Number.isFinite(Number(price)))series.createPriceLine({price:Number(price),title:label,color,lineWidth:1,lineStyle:style??L.LineStyle.Dashed,axisLabelVisible:true});};
			    add(context.lower,'حد أدنى','#7bc7ff');add(context.upper,'حد أعلى','#ff9ca1');if(!Number.isFinite(Number(context.lower))&&!Number.isFinite(Number(context.upper)))add(context.level,'مستوى','#f5cf6e',L.LineStyle.Solid);
			    chart.timeScale().fitContent();chartUI.insightChart=chart;
			  }
			  async function openInsight(context){
			    ensureDrawer();chartUI.insightContext=context;const drawer=document.getElementById('chartInsightDrawer');drawer.classList.add('open');
			    document.getElementById('insightEyebrow').textContent=`${context.status||'طبقة تحليلية'} · ${selectedTimeframe||'—'}`;document.getElementById('insightTitle').textContent=context.title;
			    document.getElementById('insightSummary').textContent=context.details;
			    document.getElementById('insightStats').innerHTML=`<div class="insightStat"><span>النطاق</span><b>${Number.isFinite(Number(context.lower))?format(context.lower)+' — '+format(context.upper):format(context.level)}</b></div><div class="insightStat"><span>الجودة</span><b>${context.quality===undefined?'—':format(context.quality).replace('.00','')+'/100'}</b></div><div class="insightStat"><span>المرساة</span><b>${safe(context.anchor||'آخر بيانات')}</b></div>`;
			    try{const data=await cacheChartPayload();renderInsightChart(insightRows(data,context),context);}catch(error){document.getElementById('insightSummary').textContent=`${context.details} — تعذر تحميل الرسم المصغر: ${error.message}`;}
			  }
			  function focusInsight(context){
			    if(!context||!chartUI.chart)return;const data=chartUI.insightPayload;const rows=data?.candles||[];if(context.start_time&&context.end_time){const start=Number(context.start_time),end=Number(context.end_time);try{chartUI.chart.timeScale().setVisibleRange({from:Math.max(0,start-86400*8),to:end+86400*8});}catch(_){}}
			    else if(rows.length){const end=rows.length-1;chartUI.chart.timeScale().setVisibleLogicalRange({from:Math.max(0,end-58),to:end+6});}
			    if(Number.isFinite(Number(context.level))||Number.isFinite(Number(context.lower))){const price=Number.isFinite(Number(context.level))?Number(context.level):(Number(context.lower)+Number(context.upper))/2;try{chartUI.candles.createPriceLine({price,color:'#f5cf6e',lineWidth:2,lineStyle:window.LightweightCharts.LineStyle.Solid,axisLabelVisible:true,title:'المستوى المختار'});}catch(_){}}
			    document.getElementById('chartInsightDrawer')?.classList.remove('open');
			  }
			  function decorateZones(){
			    const svg=chartUI.zoneLayer;if(!svg)return;const zones=[];if(chartUI.overlays.liquidityzones)zones.push(...(chartUI.zoneData.liquidity||[]));if(chartUI.overlays.orderblocks)zones.push(...(chartUI.zoneData.order_blocks||[]));if(chartUI.overlays.fvg)zones.push(...(chartUI.zoneData.fair_value_gap||[]));if(chartUI.overlays.scenario)zones.push(...(chartUI.zoneData.trade_scenario||[]));
			    svg.querySelectorAll('rect').forEach((node,index)=>{const zone=zones[index];if(!zone||node.dataset.insightBound)return;node.dataset.insightBound='true';node.classList.add('chartInteractiveZone');node.setAttribute('tabindex','0');node.setAttribute('role','button');node.setAttribute('aria-label',`${zone.label||zone.kind} — فتح شرح الرسم`);const open=event=>{event.stopPropagation();openInsight(contextFor(zone.kind,zone));};node.addEventListener('click',open);node.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open(event);}});});
			  }
			  function decorateToolCards(){
			    const order=['liquidity_sweep','liquidity_zones','support_resistance','order_blocks','order_flow','anchored_vwap','volume_profile','fibonacci','fair_value_gap'];
			    const decorateChip=(chip,key,context)=>{if(chip.dataset.insightBound)return;chip.dataset.insightBound='true';chip.classList.add('toolDrilldown');chip.setAttribute('tabindex','0');chip.setAttribute('role','button');chip.setAttribute('aria-label',`${context.title} — فتح الرسم المصغر`);const open=event=>{event.preventDefault();event.stopPropagation();openInsight(context);};chip.addEventListener('click',open);chip.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){open(event);}});};
			    document.querySelectorAll('#advancedTools .toolCard').forEach((card,index)=>{const key=order[index];if(!key)return;const tool=chartUI.inspectorTools?.[key]||{};if(!card.dataset.insightBound){card.dataset.insightBound='true';card.classList.add('toolInspectable');card.setAttribute('tabindex','0');card.setAttribute('role','button');const open=event=>{if(event?.target?.closest?.('button'))return;openInsight(contextFor(key));};card.addEventListener('click',open);card.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();open(event);}});const head=card.querySelector('.toolHead');if(head)head.insertAdjacentHTML('beforeend','<button type="button" class="toolExplore">فتح الرسم</button>');head?.querySelector('.toolExplore')?.addEventListener('click',event=>{event.stopPropagation();openInsight(contextFor(key));});}card.querySelectorAll('.toolLevel').forEach(chip=>{const text=chip.textContent||'';const level=Object.entries(tool.levels||{}).find(([name])=>text.includes(name));if(level){const [name,value]=level;decorateChip(chip,key,contextFor(key,{label:`${names[key]||key} — ${name}`,level:value,value,details:tool.details,quality_score:tool.quality_score,anchor_at:tool.anchor_at}));return;}const zone=(tool.zones||[]).find(item=>text.includes(String(item.label||item.kind||''))&&text.includes(format(item.lower)));if(zone)decorateChip(chip,key,contextFor(key,zone));});});
			  }
			  function addTerminalControls(){
			    const toolbar=document.getElementById('proChartToolbar');if(!toolbar||toolbar.dataset.terminalReady)return;toolbar.dataset.terminalReady='true';toolbar.classList.add('terminalToolbar');
			    const indicator=document.getElementById('proIndicatorOpen');if(indicator)indicator.textContent='المؤشرات';
			    const readout=document.createElement('div');readout.className='proMarketReadout';readout.id='proMarketReadout';readout.innerHTML='<b>O — H — L — C —</b><span class="proMarketState">شموع مرجعية</span>';toolbar.insertBefore(readout,toolbar.querySelector('.proChartTitle'));
			    const group=document.createElement('div');group.className='proChartGroup';group.innerHTML='<button class="proChartBtn chartMode" id="proChartMode">شموع</button><button class="proChartBtn" id="proChartScale">لوغ</button><button class="proChartBtn range" data-pro-range="18">1 أ</button><button class="proChartBtn range" data-pro-range="54">3 أ</button><button class="proChartBtn range" data-pro-range="120">6 أ</button><button class="proChartBtn range active" data-pro-range="all">الكل</button>';toolbar.querySelector('.proChartTitle')?.after(group);
			    document.getElementById('proChartMode')?.addEventListener('click',()=>{chartUI.displayMode=chartUI.displayMode==='line'?'candles':'line';const isLine=chartUI.displayMode==='line';chartUI.candles?.applyOptions({visible:!isLine});chartUI.closeLine?.applyOptions({visible:isLine});document.getElementById('proChartMode').textContent=isLine?'خط':'شموع';document.getElementById('proChartMode')?.classList.toggle('active',isLine);});
			    document.getElementById('proChartScale')?.addEventListener('click',()=>{const L=window.LightweightCharts;if(!L||!chartUI.chart)return;chartUI.logScale=!chartUI.logScale;chartUI.chart.priceScale('right').applyOptions({mode:chartUI.logScale?L.PriceScaleMode.Logarithmic:L.PriceScaleMode.Normal,autoScale:true});document.getElementById('proChartScale').classList.toggle('active',chartUI.logScale);});
			    group.querySelectorAll('[data-pro-range]').forEach(button=>button.addEventListener('click',()=>{const range=button.dataset.proRange;const rows=chartUI.insightPayload?.candles||[];if(!rows.length)return;if(range==='all')chartUI.chart?.timeScale().fitContent();else{const end=rows.length-1,n=Number(range);chartUI.chart?.timeScale().setVisibleLogicalRange({from:Math.max(0,end-n),to:end+4});}group.querySelectorAll('[data-pro-range]').forEach(item=>item.classList.toggle('active',item===button));}));
			  }
			  function syncReadout(){
			    const readout=document.getElementById('proMarketReadout');const rows=chartUI.insightPayload?.candles||[];const row=rows[rows.length-1];if(!readout||!row)return;readout.innerHTML=`<b>O ${format(row.open)} · H ${format(row.high)} · L ${format(row.low)} · C ${format(row.close)}</b><span class="proMarketState">${safe(chartUI.insightPayload?.source||'شموع مرجعية')}</span>`;
			  }
			  function makeCloseLine(){
			    const L=window.LightweightCharts;if(!L||!chartUI.chart||chartUI.closeLine)return;chartUI.closeLine=chartUI.chart.addSeries(L.LineSeries,{color:'#f5cf6e',lineWidth:2,lastValueVisible:false,priceLineVisible:false,visible:false});
			  }
			  const priorLoad=window.loadChart;
			  window.loadChart=async function(...args){const result=await priorLoad(...args);applyTerminalTheme();addTerminalControls();makeCloseLine();try{const data=await cacheChartPayload();chartUI.closeLine?.setData((data.candles||[]).map(row=>({time:row.time,value:row.close})));chartUI.closeLine?.applyOptions({visible:chartUI.displayMode==='line'});decorateZones();syncReadout();}catch(_){}return result;};
			  const priorRenderTools=window.renderAdvancedTools;
			  window.renderAdvancedTools=function(advanced){chartUI.inspectorTools=advanced?.tools||{};const result=priorRenderTools(advanced);window.setTimeout(decorateToolCards,0);return result;};
				  function renderObFvgStrategy(setup,frame){
			    const anchor=document.getElementById('advancedTools')?.closest('.panel');if(!anchor)return;let section=document.getElementById('obFvgStrategySection');if(!section){anchor.insertAdjacentHTML('afterend','<section id="obFvgStrategySection"><div class="sectionTitle">استراتيجية المنطقة المركبة — Order Block + Fair Value Gap</div><div class="panel" id="obFvgStrategyPanel"></div></section>');section=document.getElementById('obFvgStrategySection');}
				    const panel=document.getElementById('obFvgStrategyPanel');if(!panel)return;const zone=setup?.entry_zone;const direction=setup?.direction||'محايد';const state=direction==='شراء'?'cellBuy':direction==='بيع'?'cellSell':'cellNeutral';const n=(value,digits=2)=>value===null||value===undefined||Number.isNaN(Number(value))?'—':Number(value).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits});const zoneLabel=direction==='بيع'?'منطقة بيع تاريخية للمراقبة':direction==='شراء'?'منطقة شراء تاريخية للمراقبة':'منطقة تاريخية للمراقبة';const zoneDescription=zone?`${zoneLabel}: حدود المنطقة من ${n(zone.lower)} إلى ${n(zone.upper)}. ${setup?.activation||'تُراقب المنطقة عند وصول السعر إليها.'}`:'لا توجد حدود سعرية مكتملة للمنطقة في هذه اللحظة.';const strength=setup?.historical_strength||{};const strengthScore=Math.max(0,Math.min(100,Number(strength.score)||0));const strengthTone=strengthScore>=75?'strong':strengthScore>=45?'medium':'weak';const strengthCard=zone&&strength.available===true?`<div class="zoneStrength" data-strength="${strengthTone}"><div class="zoneStrengthHead"><b>قوة المنطقة التاريخية</b><strong>${n(strengthScore,0)}/100</strong></div><div class="zoneStrengthTrack" aria-label="قوة المنطقة التاريخية"><i style="width:${strengthScore}%"></i></div><div class="zoneStrengthMeta"><span>${esc(strength.label||'—')}</span><span>${n(strength.test_count,0)} اختبار سابق</span></div><div class="small">${esc(strength.basis||'')} ${esc(strength.interpretation||'')}</div></div>`:`<div class="zoneStrength" data-strength="unavailable"><div class="zoneStrengthHead"><b>قوة المنطقة التاريخية</b><strong>غير متاح</strong></div><div class="zoneStrengthTrack" aria-label="قوة المنطقة التاريخية غير متاحة"><i style="width:0%"></i></div><div class="zoneStrengthMeta"><span>بانتظار منطقة متداخلة مكتملة</span><span>— اختبار</span></div><div class="small">${esc(strength.basis||'يظهر عداد الاختبارات فقط عندما تتوفر منطقة Order Block + FVG بحدود مكتملة من شموع OHLC.')}</div></div>`;
				    panel.innerHTML=`<article class="toolCard"><div class="toolHead"><span class="toolTitle">${esc(setup?.status||'غير متاح')}</span><span class="badge ${state}">${esc(direction)}</span></div><div class="toolDetails">${esc(setup?.reason||'لم تتوفر بيانات كافية لحساب المنطقة.')}</div><div class="signalLevels"><div class="level"><span>منطقة الدخول</span><strong class="value">${zone?n(zone.lower)+' — '+n(zone.upper):'—'}</strong></div><div class="level"><span>الدخول / الإبطال</span><strong class="value">${n(setup?.entry)} / ${n(setup?.stop_loss)}</strong></div><div class="level"><span>الهدف / R:R</span><strong class="value">${n(setup?.take_profit)} / 1:${n(setup?.risk_reward)}</strong></div></div><div class="toolDetails zoneHistoryNote" style="margin-top:10px;padding:9px 10px;border:1px solid #394858;border-radius:6px;background:#111a24;color:#d5e0ed"><b style="color:#f3d98e">${esc(zoneLabel)}</b><br>${esc(zoneDescription)}</div>${strengthCard}<div class="toolLevels">${(setup?.evidence||[]).map(item=>`<span class="toolLevel">${esc(item)}</span>`).join('')}</div>${(setup?.warnings||[]).length?`<div class="notice">${setup.warnings.map(esc).join('<br>')}</div>`:''}<div class="small">${esc(setup?.activation||setup?.data_basis||'شموع OHLC فقط')}</div><div class="toolLevels"><button type="button" class="chartToggle" id="obFvgBacktestButton" onclick="event.stopImmediatePropagation();window.runObFvgBacktest()">اختبار الأداء التاريخي</button></div><div id="obFvgBacktestResult" class="empty">${window.__obFvgBacktestHtml||'شغّل الاختبار على الإطار المختار. النتيجة تاريخية ولا تشمل السبريد أو الانزلاق.'}</div></article>`;
			    document.getElementById('obFvgBacktestButton')?.addEventListener('click',async()=>{const box=document.getElementById('obFvgBacktestResult');const id=frame?.id||selectedTimeframe||'1d';if(box)box.innerHTML='<div class="empty">جارِ تنفيذ الاختبار الزمني بلا تسريب مستقبلي...</div>';try{const response=await fetch('/api/strategy-backtest/ob-fvg/'+encodeURIComponent(id),{cache:'no-store'});const payload=await response.json();if(!response.ok||payload.error)throw new Error(payload.error||'تعذر تشغيل الاختبار التاريخي');const r=payload.result||{},m=r.metrics||{};const trades=(r.trades||[]).slice(-5);if(box)box.innerHTML=`<div class="toolDetails">${esc(r.message||'')}</div><div class="signalLevels"><div class="level"><span>الفرص / المملوءة</span><strong>${n(m.eligible_setups,0)} / ${n(m.filled_trades,0)}</strong></div><div class="level"><span>نسبة النجاح / متوسط R</span><strong>${n(m.win_rate_pct,1)}% / ${n(m.average_r,2)}</strong></div><div class="level"><span>إجمالي R / PF</span><strong>${n(m.total_r,2)} / ${n(m.profit_factor,2)}</strong></div></div>${trades.length?`<div class="toolLevels">${trades.map(t=>`<span class="toolLevel">${esc(t.direction)} · ${esc(t.outcome)} · R ${n(t.r_multiple,2)} · ${esc(t.entry_time)}</span>`).join('')}</div>`:''}<div class="notice">فجوة رقابة: ${n(r.methodology?.censor_gap_bars,0)} شمعة. إذا لُمس الوقف والهدف في الشمعة نفسها، يُحتسب وقفاً محافظاً.</div><div class="small">${esc(r.methodology?.costs||'')}</div>`;}catch(error){if(box)box.innerHTML=`<div class="notice">${esc(error.message||'تعذر تشغيل الاختبار')}</div>`;}});
			  }
			  window.renderObFvgStrategy=renderObFvgStrategy;
			  const renderObFvgBacktestResult=payload=>{const box=document.getElementById('obFvgBacktestResult'),r=payload?.result||{},m=r.metrics||{},n=(value,digits=2)=>value===null||value===undefined||Number.isNaN(Number(value))?'—':Number(value).toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits});if(!box)return;const trades=(r.trades||[]).slice(-5);box.innerHTML=`<div class="toolDetails">${esc(r.message||'')}</div><div class="signalLevels"><div class="level"><span>الفرص / المملوءة</span><strong>${n(m.eligible_setups,0)} / ${n(m.filled_trades,0)}</strong></div><div class="level"><span>نسبة النجاح / متوسط R</span><strong>${n(m.win_rate_pct,1)}% / ${n(m.average_r,2)}</strong></div><div class="level"><span>إجمالي R / PF</span><strong>${n(m.total_r,2)} / ${n(m.profit_factor,2)}</strong></div></div>${trades.length?`<div class="toolLevels">${trades.map(t=>`<span class="toolLevel">${esc(t.direction)} · ${esc(t.outcome)} · R ${n(t.r_multiple,2)} · ${esc(t.entry_time)}</span>`).join('')}</div>`:''}<div class="notice">فجوة رقابة: ${n(r.methodology?.censor_gap_bars,0)} شمعة. ${m.sample_adequate===false?'العينة أقل من الحد الأدنى الإرشادي ('+n(m.minimum_sample,0)+' صفقة)، فلا تعد دليلاً على أداء مثبت.':'إذا لُمس الوقف والهدف في الشمعة نفسها، يُحتسب وقفاً محافظاً.'}</div><div class="small">${esc(r.methodology?.costs||'')}</div>`;};
			  window.runObFvgBacktest=async()=>{const box=document.getElementById('obFvgBacktestResult'),id=selectedTimeframe||chartUI.loadedTimeframe||'1d';window.__obFvgBacktestHtml='<div class="empty">جارِ تنفيذ الاختبار الزمني بلا تسريب مستقبلي...</div>';if(box)box.innerHTML=window.__obFvgBacktestHtml;try{const response=await fetch('/api/strategy-backtest/ob-fvg/'+encodeURIComponent(id),{cache:'no-store'});const payload=await response.json();if(!response.ok||payload.error)throw new Error(payload.error||'تعذر تشغيل الاختبار التاريخي');renderObFvgBacktestResult(payload);window.__obFvgBacktestHtml=document.getElementById('obFvgBacktestResult')?.innerHTML||'';}catch(error){window.__obFvgBacktestHtml=`<div class="notice">${esc(error.message||'تعذر تشغيل الاختبار')}</div>`;const current=document.getElementById('obFvgBacktestResult');if(current)current.innerHTML=window.__obFvgBacktestHtml;}};
			  document.addEventListener('click',async event=>{const button=event.target?.closest?.('#obFvgBacktestButton');if(!button)return;event.preventDefault();event.stopImmediatePropagation();const box=document.getElementById('obFvgBacktestResult'),id=selectedTimeframe||chartUI.loadedTimeframe||'1d';if(box)box.innerHTML='<div class="empty">جارِ تنفيذ الاختبار الزمني بلا تسريب مستقبلي...</div>';try{const response=await fetch('/api/strategy-backtest/ob-fvg/'+encodeURIComponent(id),{cache:'no-store'});const payload=await response.json();if(!response.ok||payload.error)throw new Error(payload.error||'تعذر تشغيل الاختبار التاريخي');renderObFvgBacktestResult(payload);}catch(error){const current=document.getElementById('obFvgBacktestResult');if(current)current.innerHTML=`<div class="notice">${esc(error.message||'تعذر تشغيل الاختبار')}</div>`;}},true);
			  async function refreshObFvgStrategyCard(id){try{const response=await fetch('/api/timeframe/'+encodeURIComponent(id||selectedTimeframe||'1d'),{cache:'no-store'});const payload=await response.json();if(response.ok&&!payload.error)renderObFvgStrategy(payload.timeframe?.ob_fvg_strategy,payload.timeframe);}catch(_){}}
			  window.refreshObFvgStrategyCard=refreshObFvgStrategyCard;
			  const priorRenderTechnicalWithObFvg=window.renderTechnical;
			  window.renderTechnical=function(technical,frame){const result=priorRenderTechnicalWithObFvg(technical,frame);window.setTimeout(()=>renderObFvgStrategy(frame?.ob_fvg_strategy,frame),0);return result;};
			  const priorRenderRecommendationWithObFvg=window.renderRecommendation;
			  window.renderRecommendation=function(recommendation){const result=priorRenderRecommendationWithObFvg(recommendation);const zone=recommendation?.entry_zone;if(zone){const target=document.querySelector('#recommendation .signalLevels');target?.insertAdjacentHTML('beforeend',`<div class="level"><span>منطقة OB + FVG</span><strong class="value">${Number(zone.lower).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} — ${Number(zone.upper).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}</strong></div>`);}return result;};
			  const baseRenderScenarioTable=renderScenarioTable;
			  renderScenarioTable=function(data){const hasRows=Array.isArray(data?.rows)&&data.rows.length>0;if(hasRows)window.__scenarioTableSnapshot={data,savedAt:Date.now(),timeframeId:selectedTimeframe};const cached=window.__scenarioTableSnapshot;const quoteFresh=latestSystem?.quote?.status==='success'&&!latestSystem?.quote?.stale&&latestSystem?.quote?.live_for_analysis===true;const useCached=!hasRows&&data?.status==='انتظار'&&cached&&cached.timeframeId===selectedTimeframe&&Date.now()-cached.savedAt<35000&&quoteFresh;return baseRenderScenarioTable(useCached?cached.data:data);};
			  const scenarioTableNode=document.getElementById('scenarioTable');
			  const restoreScenarioSnapshot=()=>{const cached=window.__scenarioTableSnapshot,quoteFresh=latestSystem?.quote?.status==='success'&&!latestSystem?.quote?.stale&&latestSystem?.quote?.live_for_analysis===true;if(cached&&cached.timeframeId===selectedTimeframe&&Date.now()-cached.savedAt<35000&&quoteFresh&&!scenarioTableNode?.querySelector('.scenarioType'))baseRenderScenarioTable(cached.data);};
			  if(scenarioTableNode)new MutationObserver(()=>window.setTimeout(restoreScenarioSnapshot,0)).observe(scenarioTableNode,{childList:true,subtree:true});
			  window.addEventListener('xauusd:timeframe-selected',event=>{if(window.__scenarioTableSnapshot&&window.__scenarioTableSnapshot.timeframeId!==event.detail?.id)delete window.__scenarioTableSnapshot;});
			  const priorDraw=window.drawChartZones;
			  window.drawChartZones=function(...args){const result=priorDraw?.apply(this,args);decorateZones();return result;};
			  document.addEventListener('fullscreenchange',()=>{document.body.classList.toggle('terminalWorkspace',terminal());applyTerminalTheme();addTerminalControls();});
			  window.addEventListener('xauusd:timeframe-selected',()=>window.setTimeout(()=>{applyTerminalTheme();addTerminalControls();decorateToolCards();refreshObFvgStrategyCard(selectedTimeframe);},0));
			  const observer=new MutationObserver(()=>{document.body.classList.toggle('terminalWorkspace',terminal());applyTerminalTheme();addTerminalControls();});observer.observe(document.body,{attributes:true,attributeFilter:['class']});
			  window.setTimeout(()=>{document.body.classList.toggle('terminalWorkspace',terminal());applyTerminalTheme();addTerminalControls();refreshObFvgStrategyCard(selectedTimeframe||'1d');},160);
			  window.setTimeout(()=>{const hasTechnical=latestSystem?.technical&&Object.keys(latestSystem.technical).length>0;if(!loadingTimeframe&&!hasTechnical)selectTimeframe(selectedTimeframe||'1d');},1200);
			})();
			</script><style>
      .timeframes .tfPriority{border-color:#c99c42;background:linear-gradient(145deg,#2c2a18,#172431);box-shadow:inset 0 0 0 1px #c99c4233}.timeframes .tfPriority .tfLabel{color:#f3d98e;font-weight:800}.zoneStrength{margin-top:10px;padding:10px;border:1px solid #3c536b;border-radius:8px;background:#0d1721}.zoneStrengthHead,.zoneStrengthMeta{display:flex;justify-content:space-between;gap:8px;align-items:center}.zoneStrengthHead b{color:#e8f0f7;font-size:12px}.zoneStrengthHead strong{font-variant-numeric:tabular-nums;color:#f3d98e}.zoneStrengthTrack{height:8px;margin:8px 0;border-radius:99px;background:#263445;overflow:hidden}.zoneStrengthTrack i{display:block;height:100%;border-radius:inherit;background:#de7d80}.zoneStrength[data-strength="strong"] .zoneStrengthTrack i{background:#72c36a}.zoneStrength[data-strength="medium"] .zoneStrengthTrack i{background:#e0ad44}.zoneStrength[data-strength="unavailable"]{border-color:#40505f;background:#101820}.zoneStrength[data-strength="unavailable"] .zoneStrengthHead strong,.zoneStrength[data-strength="unavailable"] .zoneStrengthMeta{color:#a9b5c0}.zoneStrength[data-strength="unavailable"] .zoneStrengthTrack i{background:#64748b}.zoneStrengthMeta{font-size:11px;color:#b3c0ce}.priceAlertForm{display:grid;grid-template-columns:1fr 1.2fr auto;gap:7px;margin:10px 12px}.priceAlertForm input,.priceAlertForm select{min-width:0;border:1px solid #385067;border-radius:7px;background:#0d1721;color:#eaf1f8;padding:9px;font:inherit;font-size:12px}.priceAlertList{display:grid;gap:7px;padding:0 12px 12px}.priceAlertRow{display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;padding:9px;border:1px solid #2f465c;border-radius:8px;background:#101b27}.priceAlertRow small{display:block;color:#aabaca;margin-top:3px}.priceAlertRow strong{color:#f3d98e}.priceAlertActions{display:flex;gap:5px}.priceAlertActions button{border:1px solid #415a70;border-radius:6px;background:#1b2a39;color:#d9e4ed;padding:5px 7px;font:700 10px Tahoma,Arial;cursor:pointer}.priceAlertActions button.danger{border-color:#7a3c44;color:#f2a0a4}.priceAlertStatus{margin:0 12px 10px;color:#9fb1c2;font-size:11px;line-height:1.6}.priceAlertToast{position:fixed;z-index:10250;top:14px;right:14px;left:14px;max-width:480px;margin:auto;padding:13px 38px 13px 13px;border:1px solid #e0ad44;border-right:4px solid #72c36a;border-radius:10px;background:#101b27;color:#edf4fb;box-shadow:0 18px 42px #000b;font:700 13px/1.65 Tahoma,Arial}.priceAlertToast button{position:absolute;right:7px;top:4px;border:0;background:transparent;color:#fff;font-size:22px;cursor:pointer}@media(max-width:360px){.priceAlertForm{grid-template-columns:1fr 1fr}.priceAlertForm button{grid-column:1/-1}}
      </style><script>
      (function(){
        const KEY='xauusd-price-alerts-v1',LIMIT=10;let lastReferencePrice=null;
        const read=()=>{try{const rows=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(rows)?rows.slice(0,LIMIT):[]}catch(_){return []}};
        const write=rows=>{try{localStorage.setItem(KEY,JSON.stringify(rows.slice(0,LIMIT)))}catch(_){}};
        const label=mode=>({touch:'الوصول إلى السعر',above:'اختراق صعودي',below:'كسر هبوطي'})[mode]||'الوصول إلى السعر';
        const freshQuote=quote=>quote?.status==='success'&&quote?.stale!==true&&quote?.live_for_analysis===true&&Number.isFinite(Number(quote?.last_price));
        const showToast=message=>{document.querySelector('.priceAlertToast')?.remove();const toast=document.createElement('div');toast.className='priceAlertToast';toast.innerHTML=`<button type="button" aria-label="إغلاق">×</button><b>تنبيه سعر XAUUSD</b><br>${esc(message)}`;toast.querySelector('button').addEventListener('click',()=>toast.remove());document.body.appendChild(toast);setTimeout(()=>toast.remove(),10000);};
	        const notify=(row,price)=>{const message=`${label(row.mode)} عند ${Number(row.target).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} · القراءة المرجعية: ${Number(price).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`;window.addXauusdAlertHistory?.({kind:'price',title:'تنبيه سعر مرجعي',detail:message,key:`price:${row.id}`});showToast(message);if('Notification'in window&&Notification.permission==='granted')new Notification('تنبيه سعر XAUUSD',{body:message});};
        const render=()=>{const panel=document.getElementById('priceAlertsPanel');if(!panel)return;const rows=read();panel.innerHTML=`<div class="priceAlertStatus">أضف حتى <b>${LIMIT}</b> تنبيهات. يفحص التنبيه سعر Gold API المرجعي الحديث أثناء بقاء الصفحة مفتوحة؛ لا يمثل Bid/Ask أو أمراً تنفيذياً.</div><div class="priceAlertForm"><input id="priceAlertTarget" inputmode="decimal" type="number" min="0" step="0.01" placeholder="السعر المرجعي"><select id="priceAlertMode" aria-label="نوع التنبيه"><option value="touch">وصول إلى السعر</option><option value="above">اختراق صعودي</option><option value="below">كسر هبوطي</option></select><button type="button" class="chartToggle" id="priceAlertAdd">إضافة</button></div><div class="toolLevels" style="padding:0 12px 10px"><button type="button" class="chartToggle" id="priceAlertPermission">تفعيل إشعار النظام</button><button type="button" class="chartToggle" id="priceAlertClear">حذف الكل</button><span class="toolLevel">${rows.filter(row=>row.active).length}/${LIMIT} فعّال</span></div><div class="priceAlertList">${rows.length?rows.map(row=>`<div class="priceAlertRow"><div><strong>${label(row.mode)} · ${Number(row.target).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}</strong><small>${row.active?'قيد المراقبة':'تم إطلاقه'}${row.triggered_at?` · ${esc(row.triggered_at)}`:''}</small></div><div class="priceAlertActions"><button type="button" data-price-alert="reset" data-id="${row.id}">إعادة</button><button type="button" class="danger" data-price-alert="remove" data-id="${row.id}">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد تنبيهات سعرية حالياً.</div>'}</div>`;panel.querySelector('#priceAlertPermission')?.addEventListener('click',async()=>{if(!('Notification'in window)){showToast('إشعارات النظام غير مدعومة في هذا المتصفح؛ سيظهر التنبيه داخل الصفحة.');return;}try{await Notification.requestPermission();showToast(Notification.permission==='granted'?'فُعّلت إشعارات النظام.':'لم يُمنح إذن إشعار النظام؛ سيظهر التنبيه داخل الصفحة.');}catch(_){showToast('تعذر طلب إذن إشعار النظام.');}});panel.querySelector('#priceAlertAdd')?.addEventListener('click',()=>{const target=Number(panel.querySelector('#priceAlertTarget')?.value),mode=panel.querySelector('#priceAlertMode')?.value||'touch',current=read();if(!Number.isFinite(target)||target<=0){showToast('أدخل سعراً مرجعياً صحيحاً أولاً.');return;}if(current.length>=LIMIT){showToast(`الحد الأقصى هو ${LIMIT} تنبيهات في الوقت نفسه.`);return;}write([...current,{id:String(Date.now())+Math.random().toString(16).slice(2),target,mode,active:true,created_at:new Date().toLocaleString('ar-EG')}]);render();});panel.querySelector('#priceAlertClear')?.addEventListener('click',()=>{write([]);render();});panel.querySelectorAll('[data-price-alert]').forEach(button=>button.addEventListener('click',()=>{const rows=read(),id=button.dataset.id;if(button.dataset.priceAlert==='remove')write(rows.filter(row=>row.id!==id));else write(rows.map(row=>row.id===id?{...row,active:true,triggered_at:null}:row));render();}));};
        window.evaluatePriceAlerts=quote=>{if(!freshQuote(quote))return;const price=Number(quote.last_price),previous=lastReferencePrice;lastReferencePrice=price;if(!Number.isFinite(previous)||previous===price)return;let changed=false;const rows=read().map(row=>{if(!row.active)return row;const target=Number(row.target);const hit=row.mode==='above'?previous<target&&price>=target:row.mode==='below'?previous>target&&price<=target:(previous<=target&&price>=target)||(previous>=target&&price<=target);if(!hit)return row;changed=true;notify(row,price);return {...row,active:false,triggered_at:new Date().toLocaleString('ar-EG')};});if(changed){write(rows);render();}};
        const install=()=>{const anchor=document.getElementById('intradayAlerts');if(!anchor||document.getElementById('priceAlertsPanel'))return;anchor.insertAdjacentHTML('afterend','<div class="sectionTitle">تنبيهات السعر المرجعي</div><div class="panel" id="priceAlertsPanel"></div>');render();};
        install();setInterval(()=>window.evaluatePriceAlerts?.(window.latestSystem?.quote),1000);
      })();
	      </script><style>
	      .topActions{display:flex;align-items:center;gap:12px}.alertBell{position:relative;width:38px;height:38px;border:1px solid #3b536a;border-radius:12px;background:#142434;color:#e7eff7;font-size:22px;line-height:1;cursor:pointer}.alertBell:focus-visible{outline:2px solid #e0ad44;outline-offset:2px}.alertBellCount{position:absolute;top:-7px;left:-7px;min-width:19px;height:19px;padding:1px 5px;border-radius:99px;background:#de7d80;color:#fff;font:800 10px/17px Tahoma,Arial}.chartTfRail button[data-chart-timeframe="4h"]{border-color:#314457!important;background:#111c27!important;color:#adbed0!important}.chartTfRail button[data-chart-timeframe="4h"].active{border-color:#e0ad44!important;background:#2e2819!important;color:#f6d98c!important}.timeframes .tfPriority{border-color:#2b4258!important;background:#162433!important;box-shadow:none!important}.timeframes .tfPriority .tfLabel{color:#b6c8da!important}.timeframes .tfPriority.active{border-color:#e0ad44!important;background:linear-gradient(145deg,#29372a,#192820)!important;box-shadow:0 0 0 1px #e4b65e33!important}.timeframes .tfPriority.active .tfLabel{color:#f3d98e!important}.timeframeTitle{display:flex;align-items:center;justify-content:space-between;gap:8px}.timeframeFilterToggle{padding:5px 8px;font-size:10px}.timeframeFilterPanel{margin:8px 12px 0;padding:10px;border:1px solid #3a556e;border-radius:10px;background:#101c28}.timeframeFilterPanel[hidden]{display:none}.timeframeFilterHead,.timeframeFilterActions{display:flex;align-items:center;justify-content:space-between;gap:8px}.timeframeFilterHead b{font-size:12px}.timeframeFilterHead span{font:800 11px Tahoma,Arial;color:#e0ad44}.timeframeFilterOptions{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:9px 0}.timeframeFilterOptions label{display:flex;align-items:center;gap:4px;min-width:0;padding:6px;border:1px solid #2e465b;border-radius:7px;background:#162433;color:#cbd9e6;font-size:11px}.timeframeFilterOptions input{accent-color:#e0ad44}.selectedFrameContext{margin:8px 14px 0;padding:9px 11px;border:1px solid #34516b;border-right:3px solid #5bc0eb;border-radius:8px;background:#10202e;color:#b8cadb;font-size:11px;line-height:1.65}.selectedFrameContext b{display:block;color:#eaf4fd;font-size:12px}.selectedFrameContext span,.selectedFrameContext small{display:block;margin-top:3px}.selectedFrameContext small{color:#8fa7bd}.alertCenter{position:fixed;z-index:10300;top:68px;left:50%;width:min(480px,calc(100vw - 20px));max-height:min(580px,calc(100dvh - 86px));overflow:auto;transform:translate(-50%,-12px);opacity:0;pointer-events:none;transition:transform 180ms cubic-bezier(.23,1,.32,1),opacity 160ms ease;background:linear-gradient(155deg,#142433,#0b131c);border:1px solid #46627c;border-radius:14px;box-shadow:0 24px 66px #000d;color:#eaf2fa}.alertCenter.open{transform:translate(-50%,0);opacity:1;pointer-events:auto}.alertCenterHead{display:flex;align-items:center;gap:9px;padding:13px 14px;border-bottom:1px solid #294156}.alertCenterHead b{font-size:16px}.alertCenterHead small{margin-right:auto;color:#9ab0c5}.alertCenterHead button{border:1px solid #47627a;border-radius:7px;background:#172b3e;color:#d7e8f8;padding:6px 8px;font:700 11px Tahoma,Arial;cursor:pointer}.alertCenterIntro{padding:10px 14px;color:#9fb2c5;font-size:11px;line-height:1.65}.alertHistoryList{display:grid;gap:7px;padding:0 10px 12px}.alertHistoryRow{padding:10px;border:1px solid #2c455c;border-right:4px solid #a4b1bf;border-radius:9px;background:#101c28}.alertHistoryRow.bullish{border-right-color:#72c36a}.alertHistoryRow.bearish{border-right-color:#de7d80}.alertHistoryRow.zone{border-right-color:#e0ad44}.alertHistoryRow.price{border-right-color:#5bc0eb}.alertHistoryRow b{display:block;color:#edf5fb;font-size:12px}.alertHistoryRow p{margin:5px 0;color:#aebfd0;font-size:11px;line-height:1.6}.alertHistoryRow small{color:#8297ab;font-size:10px}.alertHistoryEmpty{padding:24px 14px;color:#93a8bc;text-align:center}.alertBasis{margin:0 14px 12px;padding:8px 10px;border:1px solid #38526a;border-radius:8px;color:#a9bdcf;background:#10202d;font-size:10px;line-height:1.65}
	      /* هوية بصرية موحدة: كحلي عميق، سيان هادئ، ولمسة ذهبية للحالة النشطة فقط. */
	      :root{--bg:#07131f;--panel:#0d1d2c;--panel2:#10283a;--line:#28465d;--text:#f3f8fc;--muted:#9db4c8;--green:#67d39a;--greenBg:#123e35;--red:#ff8f96;--redBg:#4a2631;--amber:#f0bf62;--blue:#54c9e8}.app.studioLayout{max-width:650px;background:radial-gradient(85% 52% at 50% -9%,#183c57 0%,#0b1927 42%,#07131f 100%);box-shadow:0 26px 76px #000a}.app.studioLayout .topbar{padding:19px 19px 11px;background:linear-gradient(115deg,#102c42,#0a1724 74%);border-bottom:1px solid #2a5069}.app.studioLayout .topbar::after{content:"XAUUSD · MARKET WORKSPACE";color:#87cde3;border-color:#2e657e;background:#0b2030;font-weight:800}.app.studioLayout .instrument{color:#f6fbff;letter-spacing:-.04em}.app.studioLayout .quote{margin:10px 12px 12px;padding:18px;border:1px solid #315d75;border-radius:18px;background:linear-gradient(135deg,#123046,#0b1725);box-shadow:0 12px 32px #0005}.app.studioLayout .status{margin:0 18px 12px;padding:8px 3px;border-bottom:1px solid #24475e}.app.studioLayout .tabs{margin:0 12px 14px;padding:4px;border:1px solid #294d65;border-radius:14px;background:#0c1b29}.app.studioLayout .tab.active{background:linear-gradient(145deg,#1d4c66,#16354b);box-shadow:inset 0 0 0 1px #4a96b7}.app.studioLayout .sectionTitle{margin:15px 14px 8px;padding:0 4px;background:transparent;color:#e6f2fa;font-size:16px}.app.studioLayout .sectionTitle::after{background:linear-gradient(90deg,#4a98b9,transparent)}.app.studioLayout .chartShell{margin:0 12px 16px;border:1px solid #3b6a82;border-radius:20px;background:linear-gradient(180deg,#102b3d 0%,#09141f 26%,#07111a 100%);box-shadow:0 18px 40px #0008;overflow:hidden}.app.studioLayout .chartMeta{padding:15px 15px 11px;background:linear-gradient(105deg,#153a52,#102536);border-bottom:1px solid #315a71}.app.studioLayout .chartMeta b{font-size:18px;color:#f6fbff}.app.studioLayout .chartStatus{color:#a9c3d5}.app.studioLayout .chartWorkspaceBand{padding:10px 11px 9px;background:#0c1c2a;border-bottom:1px solid #25475d}.app.studioLayout .chartDataBand{padding:0 0 8px;gap:6px}.app.studioLayout .chartDataChip{border-color:#2b5a71;background:#112c3e;color:#b8d7e6}.app.studioLayout .chartTfRail{padding:5px;border:1px solid #24485e;border-radius:12px;background:#07131f;gap:5px}.app.studioLayout .chartTfRail button{min-width:47px;border-color:transparent;background:#102539;color:#a7c4d6;border-radius:8px;padding:7px 8px}.app.studioLayout .chartTfRail button.active{background:linear-gradient(145deg,#f0bf62,#b47931);color:#14212b;box-shadow:0 5px 13px #0005}.app.studioLayout .chartCanvas{height:370px;margin:0 10px 10px;width:calc(100% - 20px);border:1px solid #2b5a71;border-radius:14px;background:#06101a;box-shadow:inset 0 0 0 1px #0008;overflow:hidden}.app.studioLayout .chartLegend{margin:0 12px 8px;padding:8px 9px;border:1px solid #203f53;border-radius:10px;background:#0a1926}.app.studioLayout .chartCrosshair{margin:0 12px 10px;border-color:#315b72;background:#0b1d2b}.app.studioLayout .chartMobileBar{margin:0 12px 10px;border:1px solid #285066;border-radius:11px;background:#0d2333}.app.studioLayout .chartMobileBar button{color:#b9d9e7}.app.studioLayout .chartActions,.app.studioLayout .chartControls{margin:0 12px 10px;padding:8px;border:1px solid #24485f;border-radius:11px;background:#0b1b28}.app.studioLayout .chartToggle{border-color:#335f76;background:#10293a;color:#c4dbe8}.app.studioLayout .chartToggle.on{border-color:#4aa5c8;background:#164355;color:#def7ff}.app.studioLayout .chartFoot{margin:0 12px 12px;padding:9px;border:1px solid #203e52;border-radius:10px;background:#091824}.app.studioLayout .workspaceDock{margin:14px 12px 0;border:1px solid #335f77;border-radius:18px;background:linear-gradient(180deg,#10273a,#0b1825);box-shadow:0 14px 30px #0005}.app.studioLayout .workspaceDock .sectionTitle{margin:0;padding:14px 14px 8px}.app.studioLayout .timeframes{padding:10px;gap:7px}.app.studioLayout .tf{min-height:70px;border-color:#294d64;background:linear-gradient(145deg,#122d40,#0c1d2b);border-radius:11px}.app.studioLayout .tf.active{border-color:#f0bf62;background:linear-gradient(145deg,#3a3a2b,#1a2d35);box-shadow:0 0 0 1px #f0bf6255,0 7px 18px #0006}.app.studioLayout .tfAction{border-radius:6px}.app.studioLayout .timeframeFilterPanel{margin:0 10px 8px;border-color:#3a6b82;background:#0b1d2b}.app.studioLayout .selectedFrameContext{margin:0 10px 10px;border-color:#3b718b;border-right-color:#54c9e8;background:#0d2637}.app.studioLayout .workspaceDock .panel{margin:0 10px 12px;border-color:#294f65;background:#0d2030}.app.studioLayout .panel{border-color:#294f65;background:linear-gradient(145deg,#10273a,#0b1825)}.app.studioLayout .toolCard,.app.studioLayout .dataTable td{border-color:#203e52}.app.studioLayout .summaryCard,.app.studioLayout .level,.app.studioLayout .toolLevel{background:#112b3d;border-color:#264d64}.app.studioLayout .footer{background:#0c1d2a;border-top-color:#2d5870}.app.studioLayout .footer b{color:#7ad6ec}@media(max-width:380px){.app.studioLayout .chartCanvas{height:330px;margin:0 8px 8px;width:calc(100% - 16px)}.app.studioLayout .chartTfRail button{min-width:43px;padding:6px}.app.studioLayout .chartMeta{padding:12px}.app.studioLayout .chartMeta b{font-size:16px}}
	      /* تثبيت منطقة التقييم داخل عرض الهاتف: لا أعمدة ضمنية ولا نص زمني طويل يوسع البطاقة. */
	      .app.studioLayout .workspaceDock{min-width:0!important;max-width:calc(100% - 24px)!important;overflow:hidden!important}.app.studioLayout .timeframes{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;grid-auto-flow:row!important;grid-auto-columns:auto!important;width:100%!important;max-width:100%!important;min-width:0!important;box-sizing:border-box!important;padding:10px!important;gap:7px!important;overflow:hidden!important}.app.studioLayout .tf{display:grid!important;grid-template-rows:auto auto auto!important;align-content:start!important;min-width:0!important;width:100%!important;max-width:100%!important;min-height:74px!important;box-sizing:border-box!important;padding:8px 6px!important;overflow:hidden!important}.app.studioLayout .tfLabel,.app.studioLayout .tfAction,.app.studioLayout .tfCandle{min-width:0!important;max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important}.app.studioLayout .tfLabel{white-space:nowrap!important;font-size:12px!important}.app.studioLayout .tfAction{margin-top:6px!important;white-space:nowrap!important}.app.studioLayout .tfCandle{margin-top:5px!important;white-space:nowrap!important;direction:ltr!important;unicode-bidi:plaintext!important;text-align:center!important;font-size:9px!important;letter-spacing:-.01em!important;color:#a4bdd0!important}.app.studioLayout .timeframes .tfPriority{grid-column:auto!important}@media(max-width:380px){.app.studioLayout .workspaceDock{margin-right:8px!important;margin-left:8px!important;max-width:calc(100% - 16px)!important}.app.studioLayout .timeframes{padding:8px!important;gap:6px!important}.app.studioLayout .tf{min-height:71px!important;padding:7px 5px!important}.app.studioLayout .tfLabel{font-size:11px!important}.app.studioLayout .tfCandle{font-size:8px!important}}
	      </style><script>
	      (function(){
	        const KEY='xauusd-alert-history-v1',MAX=160,COOLDOWN=30*60*1000;let daily=null,lastDailyFetch=0;
	        const escH=v=>String(v??'—').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
	        const read=()=>{try{const r=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(r)?r.slice(0,MAX):[]}catch(_){return []}};
	        const write=r=>{try{localStorage.setItem(KEY,JSON.stringify(r.slice(0,MAX)))}catch(_){}};
	        const stamp=()=>new Date().toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'medium'});
	        const draw=()=>{const box=document.getElementById('alertCenter'),badge=document.getElementById('alertBellCount');if(!box||!badge)return;const rows=read(),unread=rows.filter(r=>!r.read).length;badge.hidden=!unread;badge.textContent=unread>99?'99+':String(unread);box.innerHTML=`<div class="alertCenterHead"><b>سجل التنبيهات</b><small>${rows.length} محفوظ</small><button type="button" id="alertHistoryClear">حذف السجل</button></div><div class="alertCenterIntro">السجل محفوظ محلياً على هذا الجهاز. التنبيهات تحليلية ومرجعية، وليست أمراً أو سعر Bid/Ask لدى وسيط.</div><div class="alertHistoryList">${rows.length?rows.map(r=>`<article class="alertHistoryRow ${escH(r.kind)}"><b>${escH(r.title)}</b><p>${escH(r.detail)}</p><small>${escH(r.time)} · ${escH(r.timeframe)}</small></article>`).join(''):'<div class="alertHistoryEmpty">لا توجد تنبيهات مسجلة بعد.</div>'}</div><div class="alertBasis">تنبيه توافق المؤشرات يتطلب عائلتين متوافقتين على الأقل من الاتجاه والزخم وبنية السوق. تنبيهات الدعم والمقاومة والمناطق مشتقة من OHLC وpivots وليست Order Flow حقيقياً.</div>`;box.querySelector('#alertHistoryClear')?.addEventListener('click',()=>{write([]);draw();});};
	        const add=entry=>{if(!entry?.key)return false;const now=Date.now(),rows=read();if(rows.some(r=>r.key===entry.key&&now-Number(r.at||0)<COOLDOWN))return false;rows.unshift({id:`${now}-${Math.random().toString(16).slice(2)}`,key:entry.key,kind:entry.kind||'zone',title:entry.title||'تنبيه تحليلي',detail:entry.detail||'—',time:stamp(),timeframe:entry.timeframe||window.selectedTimeframe||'—',at:now,read:false});write(rows);draw();return true;};window.addXauusdAlertHistory=add;
	        const install=()=>{const header=document.querySelector('.topbar'),bell=document.getElementById('alertBell');if(!header||!bell||document.getElementById('alertCenter'))return;header.insertAdjacentHTML('afterend','<aside class="alertCenter" id="alertCenter" aria-label="سجل التنبيهات"></aside>');bell.addEventListener('click',()=>{const center=document.getElementById('alertCenter'),open=!center.classList.contains('open');center.classList.toggle('open',open);bell.setAttribute('aria-expanded',String(open));if(open){write(read().map(r=>({...r,read:true})));draw();}});document.addEventListener('click',e=>{const center=document.getElementById('alertCenter');if(center?.classList.contains('open')&&!center.contains(e.target)&&!bell.contains(e.target)){center.classList.remove('open');bell.setAttribute('aria-expanded','false');}});draw();};
	        const current=()=>Number(window.latestSystem?.quote?.last_price),fresh=()=>window.latestSystem?.quote?.status==='success'&&window.latestSystem?.quote?.stale!==true&&window.latestSystem?.quote?.live_for_analysis===true&&Number.isFinite(current());
	        const evaluate=()=>{if(!fresh())return;const tech=window.latestSystem?.technical||{},evidence=tech.evidence_families||{},frame=window.selectedTimeframe||'4h',bias=evidence.decision_bias,score=Number(evidence.evidence_strength?.score||0),familyNames={trend:'الاتجاه',momentum:'الزخم',market_structure:'بنية السوق'},families=['trend','momentum','market_structure'].filter(k=>evidence[k]?.qualified&&evidence[k]?.direction===bias);if((bias==='صاعد'||bias==='هابط')&&families.length>=2&&score>=70)add({kind:bias==='صاعد'?'bullish':'bearish',title:`توافق عائلات الأدلة — ${bias}`,detail:`توافقت ${families.length} عائلات: ${families.map(k=>familyNames[k]).join(' + ')}. قوة الأدلة ${score}/100 غير معايرة وليست احتمال نجاح.`,key:`confluence:${frame}:${bias}:${families.join('-')}`,timeframe:frame});const buffer=Math.max(Number(tech.atr||0)*.25,Math.abs(current())*.0007);for(const zone of (window.latestSystem?.signal_layers?.zones?.items||[]).slice(0,12)){const lo=Number(zone.lower),hi=Number(zone.upper),quality=Number(zone.quality_score||0),source=String(zone.source||zone.label||'منطقة');if(!Number.isFinite(lo)||!Number.isFinite(hi)||quality<60||current()<lo-buffer||current()>hi+buffer)continue;const historic=/دعم|مقاومة|support|resistance/i.test(source);add({kind:historic?'zone':zone.bias==='صاعد'?'bullish':zone.bias==='هابط'?'bearish':'zone',title:historic?'اقتراب دعم/مقاومة تاريخية':'اقتراب منطقة سعرية مهمة',detail:`${source}: ${lo.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}–${hi.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} · جودة القاعدة ${quality}/100. منطقة مراقبة من OHLC وليست ضمان ارتداد.`,key:`zone:${frame}:${source}:${lo}:${hi}`,timeframe:frame});}const pivots=daily?.technical?.pivots?.traditional||daily?.pivots?.traditional||{};for(const key of ['R3','R2','R1','Pivot','S1','S2','S3']){const level=Number(pivots[key]);if(!Number.isFinite(level)||Math.abs(current()-level)>buffer)continue;const title=key.startsWith('R')?'اقتراب مقاومة يومية مرجعية':key.startsWith('S')?'اقتراب دعم يومي مرجعي':'اقتراب محور يومي مرجعي';add({kind:'zone',title,detail:`${key}: ${level.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} · مشتق من آخر شمعة يومية مكتملة في مصدر OHLC المرجعي.`,key:`daily-pivot:${key}:${level}`,timeframe:'يومي'});}};
	        const refreshDaily=async()=>{if(Date.now()-lastDailyFetch<60000)return;lastDailyFetch=Date.now();try{const r=await fetch('/api/timeframe/1d',{cache:'no-store'});if(r.ok){const p=await r.json();daily=p.timeframe||null;}}catch(_){}};
	        install();refreshDaily();setInterval(refreshDaily,60000);setInterval(evaluate,1500);window.addEventListener('xauusd:timeframe-selected',evaluate);
	      })();
	      </script>
	      <style>
	      .zoneFocusPill{display:flex!important;align-items:center;justify-content:space-between;gap:8px;width:100%;min-width:0;text-align:inherit;cursor:pointer;color:#d7e8f3!important;transition:transform 150ms cubic-bezier(.23,1,.32,1),border-color 150ms ease,background 150ms ease}.zoneFocusPill:hover,.zoneFocusPill:focus-visible{border-color:#61b7d5!important;background:#17364a!important;outline:0}.zoneFocusPill:active{transform:scale(.985)}.zoneFocusHint{flex:0 0 auto;color:#8ad7ec;font-size:10px;white-space:nowrap}.zoneFocusModal{position:fixed;z-index:12000;inset:0;display:grid;place-items:center;padding:12px;background:#02080dcc;backdrop-filter:blur(7px)}.zoneFocusModal[hidden]{display:none}.zoneFocusDialog{display:flex;flex-direction:column;width:min(900px,100%);height:min(720px,calc(100dvh - 24px));min-width:0;border:1px solid #3f7189;border-radius:18px;overflow:hidden;background:linear-gradient(155deg,#102c3f,#08131e);box-shadow:0 28px 80px #000c;color:#eef7fc}.zoneFocusHeader{display:flex;align-items:center;gap:8px;padding:11px 12px;border-bottom:1px solid #294d63;background:#10283a}.zoneFocusHeader b{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:15px}.zoneFocusHeader small{margin-right:auto;color:#9ec1d2;font-size:11px;white-space:nowrap}.zoneFocusHeader button{flex:0 0 auto;border:1px solid #426e83;border-radius:9px;background:#153448;color:#e4f5fb;padding:7px 9px;font:800 11px Tahoma,Arial;cursor:pointer}.zoneFocusHeader button:focus-visible{outline:2px solid #f0bf62;outline-offset:2px}.zoneFocusHeader #zoneFocusClose{background:#28303b;border-color:#596574;color:#f1f5f9}.zoneFocusMeta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;padding:10px 12px;background:#0c1e2c}.zoneFocusMeta span{min-width:0;padding:7px;border:1px solid #27495d;border-radius:8px;background:#0d2636;color:#bdd4e2;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.zoneFocusMeta b{color:#f0bf62}.zoneFocusCanvasWrap{position:relative;min-height:0;flex:1;margin:0 10px 10px;border:1px solid #315d74;border-radius:12px;overflow:hidden;background:#06111a}.zoneFocusCanvas{position:absolute;inset:0}.zoneFocusShade{position:absolute;right:0;left:0;pointer-events:none;border-top:1px solid var(--zone-color,#f0bf62);border-bottom:1px solid var(--zone-color,#f0bf62);background:color-mix(in srgb,var(--zone-color,#f0bf62) 18%,transparent);z-index:5}.zoneFocusFoot{padding:8px 12px;border-top:1px solid #24455a;background:#0a1926;color:#a7c1d0;font-size:10px;line-height:1.55}.zoneFocusModal.focusFullscreen{padding:0}.zoneFocusModal.focusFullscreen .zoneFocusDialog{width:100vw;height:100dvh;border:0;border-radius:0}.zoneFocusModal:fullscreen{padding:0;background:#06111a}.zoneFocusModal:fullscreen .zoneFocusDialog{width:100vw;height:100dvh;border:0;border-radius:0}@media(max-width:520px){.zoneFocusModal{padding:0}.zoneFocusDialog{width:100vw;height:100dvh;border-radius:0;border:0}.zoneFocusHeader{padding:10px}.zoneFocusHeader small{display:none}.zoneFocusHeader button{padding:7px}.zoneFocusMeta{grid-template-columns:1fr 1fr;padding:8px;gap:5px}.zoneFocusMeta span{font-size:10px;padding:6px}.zoneFocusMeta span:last-child{grid-column:1/-1}.zoneFocusCanvasWrap{margin:0 7px 7px;border-radius:10px}.zoneFocusFoot{padding:7px 10px;font-size:9px}}
	      </style>
	      <script>
	      (function(){
	        const state={chart:null,candles:null,upper:null,lower:null,observer:null,zone:null};
	        const getStyle=zone=>{const source=String(zone?.source||''),bias=String(zone?.bias||'');if(/Order Block/i.test(source))return bias==='هابط'?{color:'#ff8f96',name:'Order Block هابط'}:{color:'#67d39a',name:'Order Block صاعد'};if(/سيولة|Liquidity/i.test(source))return {color:'#c084fc',name:zone?.label||'منطقة سيولة'};if(/دعم|مقاومة|support|resistance/i.test(source))return {color:/مقاومة|resistance/i.test(String(zone?.label||''))?'#ff8f96':'#54c9e8',name:zone?.label||'دعم / مقاومة'};if(/Fair Value Gap|FVG/i.test(source))return {color:'#fb7185',name:'Fair Value Gap'};return {color:'#f0bf62',name:zone?.label||source||'منطقة سعرية'};};
	        const format=value=>Number.isFinite(Number(value))?Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
	        const destroy=()=>{try{state.observer?.disconnect()}catch(_){}state.observer=null;try{state.chart?.remove()}catch(_){}state.chart=null;state.candles=null;state.upper=null;state.lower=null;};
	        const resize=()=>{const host=document.getElementById('zoneFocusCanvas');if(!host||!state.chart)return;state.chart.applyOptions({width:host.clientWidth,height:host.clientHeight});requestAnimationFrame(drawShade);};
	        const drawShade=()=>{const shade=document.getElementById('zoneFocusShade'),wrap=document.getElementById('zoneFocusCanvasWrap'),zone=state.zone;if(!shade||!wrap||!state.candles||!zone)return;const a=state.candles.priceToCoordinate(Number(zone.upper)),b=state.candles.priceToCoordinate(Number(zone.lower));if(!Number.isFinite(a)||!Number.isFinite(b)){shade.hidden=true;return;}const top=Math.max(0,Math.min(a,b)),bottom=Math.min(wrap.clientHeight,Math.max(a,b));shade.hidden=false;shade.style.top=`${top}px`;shade.style.height=`${Math.max(2,bottom-top)}px`;shade.style.setProperty('--zone-color',getStyle(zone).color);};
	        const exitFullscreen=()=>{const modal=document.getElementById('zoneFocusModal');modal?.classList.remove('focusFullscreen');if(document.fullscreenElement===modal||document.webkitFullscreenElement===modal)(document.exitFullscreen||document.webkitExitFullscreen)?.call(document);try{screen.orientation?.unlock?.()}catch(_){}setTimeout(resize,100);};
	        const close=()=>{const modal=document.getElementById('zoneFocusModal');if(!modal)return;exitFullscreen();modal.hidden=true;document.body.classList.remove('zoneFocusOpen');destroy();document.getElementById('zoneFocusReturnTarget')?.focus?.();};
	        const requestLandscape=async()=>{const modal=document.getElementById('zoneFocusModal'),button=document.getElementById('zoneFocusLandscape');if(!modal)return;modal.classList.add('focusFullscreen');const request=modal.requestFullscreen||modal.webkitRequestFullscreen;try{if(!document.fullscreenElement&&request)await request.call(modal)}catch(_){}try{await screen.orientation?.lock?.('landscape');if(button)button.textContent='عرضي ✓'}catch(_){if(button)button.textContent='دوّر الهاتف'}setTimeout(resize,240);};
	        const install=()=>{if(document.getElementById('zoneFocusModal'))return;document.body.insertAdjacentHTML('beforeend','<section class="zoneFocusModal" id="zoneFocusModal" role="dialog" aria-modal="true" aria-labelledby="zoneFocusTitle" hidden><div class="zoneFocusDialog"><header class="zoneFocusHeader"><button type="button" id="zoneFocusClose">↩ رجوع</button><b id="zoneFocusTitle">رسم المنطقة</b><small id="zoneFocusFrame">—</small><button type="button" id="zoneFocusLandscape">⛶ شاشة أفقية</button></header><div class="zoneFocusMeta"><span id="zoneFocusKind">النوع: —</span><span id="zoneFocusRange">الحدود: —</span><span id="zoneFocusScore">الجودة: —</span></div><div class="zoneFocusCanvasWrap" id="zoneFocusCanvasWrap"><div class="zoneFocusCanvas" id="zoneFocusCanvas"></div><div class="zoneFocusShade" id="zoneFocusShade" hidden></div></div><footer class="zoneFocusFoot">الرسم يعرض شموع الإطار المختار وحدود المنطقة المرصودة. المنطقة مشتقة من OHLC وpivots وليست إثباتاً لأوامر مؤسسات أو Order Flow حقيقي.</footer></div></section>');const modal=document.getElementById('zoneFocusModal');document.getElementById('zoneFocusClose')?.addEventListener('click',close);document.getElementById('zoneFocusLandscape')?.addEventListener('click',requestLandscape);modal.addEventListener('click',event=>{if(event.target===modal)close();});document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!modal.hidden)close();});document.addEventListener('fullscreenchange',()=>{if(document.fullscreenElement!==modal)modal.classList.remove('focusFullscreen');setTimeout(resize,80);});};
	        window.openZoneFocus=zone=>{install();const modal=document.getElementById('zoneFocusModal'),host=document.getElementById('zoneFocusCanvas'),payload=window.latestChartPayload,candles=payload?.candles||[];if(!modal||!host)return;if(!zone||!candles.length){document.getElementById('zoneFocusTitle').textContent='تعذر فتح رسم المنطقة';return;}const style=getStyle(zone),rawLow=Number(zone.lower),rawHigh=Number(zone.upper),center=(rawLow+rawHigh)/2,pad=Math.max(Math.abs(center)*.0004,Number(selectedFramePayload?.timeframe?.technical?.atr||latestSystem?.technical?.atr||0)*.12,0.01),low=Math.min(rawLow,rawHigh),high=Math.max(rawLow,rawHigh),focusZone={...zone,lower:high-low<pad*.1?low-pad:low,upper:high-low<pad*.1?high+pad:high};state.zone=focusZone;document.getElementById('zoneFocusTitle').textContent=style.name;document.getElementById('zoneFocusFrame').textContent=`الإطار: ${payload?.timeframe?.label||selectedTimeframe}`;document.getElementById('zoneFocusKind').innerHTML=`النوع: <b>${esc(zone.source||'منطقة')}</b>`;document.getElementById('zoneFocusRange').innerHTML=`الحدود: <b>${format(zone.lower)} – ${format(zone.upper)}</b>`;document.getElementById('zoneFocusScore').innerHTML=`الجودة: <b>${format(zone.quality_score).replace('.00','')}/100</b>`;modal.hidden=false;document.body.classList.add('zoneFocusOpen');destroy();if(!window.LightweightCharts){host.textContent='تعذر تحميل مكتبة الرسم.';return;}const L=window.LightweightCharts;state.chart=L.createChart(host,{width:host.clientWidth,height:host.clientHeight,layout:{background:{type:'solid',color:'#06111a'},textColor:'#b9d2df',fontFamily:'Tahoma, Arial'},grid:{vertLines:{color:'#142635'},horzLines:{color:'#1a3040'}},rightPriceScale:{borderColor:'#31566a'},timeScale:{borderColor:'#31566a',timeVisible:true,secondsVisible:false,barSpacing:9},crosshair:{mode:L.CrosshairMode.Normal}});state.candles=state.chart.addSeries(L.CandlestickSeries,{upColor:'#67d39a',downColor:'#ff8f96',borderVisible:false,wickUpColor:'#9ae7bf',wickDownColor:'#ffb3b8',lastValueVisible:false,priceLineVisible:false});state.candles.setData(candles.map(row=>({time:row.time,open:row.open,high:row.high,low:row.low,close:row.close})));state.upper=state.chart.addSeries(L.LineSeries,{color:style.color,lineWidth:2,lastValueVisible:true,priceLineVisible:false,title:'الحد الأعلى'});state.lower=state.chart.addSeries(L.LineSeries,{color:style.color,lineWidth:2,lastValueVisible:true,priceLineVisible:false,title:'الحد الأدنى'});const first=candles[0]?.time,last=candles[candles.length-1]?.time;state.upper.setData([{time:first,value:focusZone.upper},{time:last,value:focusZone.upper}]);state.lower.setData([{time:first,value:focusZone.lower},{time:last,value:focusZone.lower}]);state.chart.timeScale().fitContent();state.observer=new ResizeObserver(resize);state.observer.observe(host);requestAnimationFrame(()=>{resize();drawShade();});document.getElementById('zoneFocusClose')?.focus();};
	      })();
	      </script></body></html>'''


@app.get("/")
def index():
    return HTML.replace(
        '<nav class="tabs">',
        '<nav class="tabs"><a class="tab" href="/attachment-ai">تحليل مرفق AI</a>',
        1,
    )


@app.get("/attachment-ai")
def attachment_ai_page():
    return ATTACHMENT_AI_HTML


if __name__ == "__main__":
    threading.Thread(target=quote_worker, daemon=True).start()
    threading.Thread(target=worker, daemon=True).start()
    print("واجهة XAUUSD الموحدة تعمل على http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=False)
