"""اختبار استكشافي قصير للأطر 5/15/30 دقيقة على المقطع المتصل من يناير 2026.

لا يعبر المقطع فجوة البيانات الكبيرة ولا يحول OHLC مرجعي إلى سعر تنفيذ أو Order Flow.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy
from run_strategy_expansion_2026_4h import RULES, add_indicators, signals


ROOT = Path("/tmp/xauusd-2026-intraday")
OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2026_intraday_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2026_intraday_report.md")
WARMUP = 220
MIN_TRADES = 15
MAX_GAP = pd.Timedelta(days=4)
SPECS = {
    "5m": {"file": "XAU_5m_data.csv", "horizon": 24, "censor": 288},
    "15m": {"file": "XAU_15m_data.csv", "horizon": 24, "censor": 96},
    "30m": {"file": "XAU_30m_data.csv", "horizon": 24, "censor": 48},
}


def load(path: Path) -> pd.DataFrame:
    raw = pd.read_csv(path, sep=";")
    index = pd.to_datetime(raw.pop("Date"), format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    raw.columns = [str(column).title() for column in raw.columns]
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = index
    return raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index().loc["2026-01-01":"2026-12-31 23:59:59"]


def first_contiguous_segment(frame: pd.DataFrame) -> pd.DataFrame:
    groups = frame.index.to_series().diff().gt(MAX_GAP).cumsum()
    candidates = [part.copy() for _, part in frame.groupby(groups)]
    valid = [part for part in candidates if len(part) >= WARMUP + 30]
    if not valid:
        raise ValueError("لا يوجد مقطع 2026 متصل كافٍ بعد الإحماء.")
    return max(valid, key=len)


def simulate(frame: pd.DataFrame, signal: pd.Series, stop_atr: float, target_r: float, horizon: int, start: int, end: int) -> dict:
    outcomes: list[float] = []
    trades: list[dict] = []
    first, last = max(WARMUP, start), min(len(frame) - 1, end)
    i = first
    while i < last - 1:
        side = int(signal.iloc[i])
        atr = float(frame.ATR.iloc[i]) if pd.notna(frame.ATR.iloc[i]) else 0.0
        if side == 0 or atr <= 0:
            i += 1
            continue
        entry_i, entry, risk = i + 1, float(frame.Open.iloc[i + 1]), stop_atr * atr
        stop = entry - risk if side == 1 else entry + risk
        target = entry + target_r * risk if side == 1 else entry - target_r * risk
        maximum = min(last, entry_i + horizon - 1)
        exit_i, exit_price, outcome = maximum, float(frame.Close.iloc[maximum]), "انتهت المدة"
        for j in range(entry_i, maximum + 1):
            high, low = float(frame.High.iloc[j]), float(frame.Low.iloc[j])
            hit_stop, hit_target = (low <= stop, high >= target) if side == 1 else (high >= stop, low <= target)
            if hit_stop and hit_target:
                exit_i, exit_price, outcome = j, stop, "غموض داخل الشمعة — وقف محافظ"
                break
            if hit_stop:
                exit_i, exit_price, outcome = j, stop, "وقف"
                break
            if hit_target:
                exit_i, exit_price, outcome = j, target, "هدف"
                break
        result = (exit_price - entry) / risk if side == 1 else (entry - exit_price) / risk
        outcomes.append(float(result))
        trades.append({"decision_time": str(frame.index[i]), "entry_time": str(frame.index[entry_i]), "exit_time": str(frame.index[exit_i]), "direction": "شراء" if side == 1 else "بيع", "outcome": outcome, "r_multiple": round(float(result), 4)})
        i = exit_i + 1
    return {"outcomes": outcomes, "trades": trades, "signals": int((signal.iloc[start:end] != 0).sum())}


def metrics(parts: list[dict]) -> dict:
    outcomes = [value for part in parts for value in part["outcomes"]]
    trades = [item for part in parts for item in part["trades"]]
    wins, losses = [item for item in outcomes if item > 0], [item for item in outcomes if item < 0]
    curve = np.cumsum(outcomes) if outcomes else np.array([])
    drawdown = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0.0
    total, gross_profit, gross_loss = sum(outcomes), sum(wins), abs(sum(losses))
    return {
        "signals": sum(part["signals"] for part in parts),
        "filled_trades": len(outcomes),
        "wins": len(wins),
        "losses": len(losses),
        "win_rate_pct": round(100 * len(wins) / len(outcomes), 1) if outcomes else None,
        "total_r": round(float(total), 2),
        "average_r": round(float(total / len(outcomes)), 3) if outcomes else None,
        "profit_factor": round(float(gross_profit / gross_loss), 2) if gross_loss else None,
        "max_drawdown_r": round(drawdown, 2),
        "sample_adequate": len(outcomes) >= MIN_TRADES,
        "cost_sensitivity_r": {"0.15_per_trade": round(float(total - 0.15 * len(outcomes)), 2), "0.25_per_trade": round(float(total - 0.25 * len(outcomes)), 2)},
        "trades": trades,
    }


def score_rule(frame: pd.DataFrame, name: str, stop_atr: float, target_r: float, spec: dict) -> dict:
    signal = signals(frame, name)
    split = int(len(frame) * 0.40)
    h2_start = min(len(frame) - 1, split + spec["censor"])
    full = metrics([simulate(frame, signal, stop_atr, target_r, spec["horizon"], 0, len(frame) - 1)])
    h1 = metrics([simulate(frame, signal, stop_atr, target_r, spec["horizon"], 0, split)])
    h2 = metrics([simulate(frame, signal, stop_atr, target_r, spec["horizon"], h2_start, len(frame) - 1)])
    eligible = bool(h2["filled_trades"] >= MIN_TRADES and h2["cost_sensitivity_r"]["0.25_per_trade"] > 0 and (h2["profit_factor"] or 0) >= 1.10)
    return {"metrics": full, "development_h1": h1, "oos_h2": h2, "eligible_for_exploratory_watchlist": eligible}


def score_ob_fvg(frame: pd.DataFrame, spec: dict) -> dict:
    split = int(len(frame) * 0.40)
    h2_start = min(len(frame) - 1, split + spec["censor"])

    def run(scoped: pd.DataFrame) -> dict:
        if len(scoped) < 220:
            return metrics([])
        response = backtest_ob_fvg_strategy(scoped, warmup_bars=180, horizon_bars=spec["horizon"], censor_gap_bars=1, evaluation_stride=1, max_evaluation_points=500, signal_lookback_bars=600, trade_output_limit=None)
        return metrics([{"outcomes": [float(row.get("r_multiple", 0)) for row in response.get("trades", [])], "trades": response.get("trades", []), "signals": int(response.get("metrics", {}).get("decision_points", 0))}])

    full, h1, h2 = run(frame), run(frame.iloc[:split]), run(frame.iloc[h2_start:])
    return {"metrics": full, "development_h1": h1, "oos_h2": h2, "eligible_for_exploratory_watchlist": False, "exclusion_reason": "الاستراتيجية البنيوية لا ترقى من اختبار يناير القصير مهما بدت نتيجتها."}


def main() -> None:
    results: dict[str, dict] = {}
    segments: dict[str, dict] = {}
    for timeframe, spec in SPECS.items():
        frame = add_indicators(first_contiguous_segment(load(ROOT / spec["file"])))
        segments[timeframe] = {"start": str(frame.index.min()), "end": str(frame.index.max()), "bars": len(frame), "horizon_bars": spec["horizon"], "censor_bars": spec["censor"]}
        for name, stop_atr, target_r, family in RULES:
            record = score_rule(frame, name, stop_atr, target_r, spec)
            record.update({"timeframe": timeframe, "strategy": name, "family": family, "rules": {"stop_atr": stop_atr, "target_r": target_r, "horizon_bars": spec["horizon"]}})
            results[f"{timeframe}:{name}"] = record
        record = score_ob_fvg(frame, spec)
        record.update({"timeframe": timeframe, "strategy": "ob_fvg", "family": "منطقة بنيوية OHLC", "rules": {"horizon_bars": spec["horizon"]}})
        results[f"{timeframe}:ob_fvg"] = record
    ranking = sorted(({"key": key, "timeframe": item["timeframe"], "strategy": item["strategy"], "family": item["family"], "eligible": item["eligible_for_exploratory_watchlist"], **{field: item["oos_h2"].get(field) for field in ("filled_trades", "total_r", "profit_factor", "max_drawdown_r")}, "total_r_after_0_25_cost": item["oos_h2"]["cost_sensitivity_r"]["0.25_per_trade"]} for key, item in results.items()), key=lambda row: (row["eligible"], row["total_r_after_0_25_cost"] if row["total_r_after_0_25_cost"] is not None else -9999), reverse=True)
    actual_period = "; ".join(f"{timeframe}: {record['start']} إلى {record['end']}" for timeframe, record in segments.items())
    payload = {"data_contract": {"source": "Kaggle v11 XAU/USD OHLC/tick-volume reference", "period": f"largest contiguous 2026 segment only; {actual_period}; all later segments after a >4-day gap excluded", "reference_only": True, "entry": "next bar open", "same_bar_policy": "conservative stop", "cost_sensitivity_r": [0.15, 0.25], "minimum_oos_sample": MIN_TRADES, "not_available": ["Bid/Ask", "spread", "commission", "slippage", "DOM", "trade side/size", "volume-at-price", "verified news actuals"]}, "segments": segments, "results": results, "oos_ranking": ranking}
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = "\n".join(f"| {row['key']} | {'مراقبة استكشافية' if row['eligible'] else 'غير مؤهل'} | {row['filled_trades']} | {row['total_r']} | {row['total_r_after_0_25_cost']} | {row['profit_factor']} | {row['max_drawdown_r']} |" for row in ranking)
    OUT_MD.write_text(f"""# اختبار XAUUSD داخل اليوم — 2026، المقطع المتصل من يناير

اختُبرت عشر قواعد OHLC محددة مسبقاً واستراتيجية OB+FVG على ملفات 5 و15 و30 دقيقة الأصلية. لا يغطي المصدر سوى أكبر مقطع متصل موضح أدناه؛ لا تمثل النتائج سنة كاملة ولا سعراً تنفيذياً.

**نطاق كل إطار:** {actual_period}

| القاعدة | الحالة | صفقات H2 | صافي H2 قبل التكلفة (R) | صافي H2 بعد 0.25R/صفقة | معامل الربح H2 | أقصى سحب H2 (R) |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
{rows}

لا يضاف أي صف إلى محرك القرار الحي من هذا التقرير. بوابة «مراقبة استكشافية» مجرد فلتر للعينة القصيرة: 15 صفقة H2، وصافي موجب بعد 0.25R لكل صفقة، ومعامل ربح 1.10 أو أعلى.
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for row in ranking:
        print(row)


if __name__ == "__main__":
    main()
