"""يفحص استقرار المرشحين بقواعد قريبة محددة قبل قراءة النتائج.

لا يختار إعداداً جديداً من H2؛ الغرض هو رفض النتائج التي تعتمد على حد واحد هش.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from run_strategy_expansion_2025 import END, SPLIT, add_indicators, load_base, metrics, resample, simulate_segment, split_segments


OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_robustness_2025_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_robustness_2025_report.md")
H1_START = pd.Timestamp("2025-01-01", tz="UTC")
MIN_TRADES = 20


def make_signal(frame: pd.DataFrame, name: str) -> pd.Series:
    up, down = frame.EMA20 > frame.EMA50, frame.EMA20 < frame.EMA50
    if name == "donchian_adx22":
        long, short = (frame.Close > frame.DONCHIAN_HIGH) & (frame.ADX >= 22), (frame.Close < frame.DONCHIAN_LOW) & (frame.ADX >= 22)
    elif name == "donchian_adx30":
        long, short = (frame.Close > frame.DONCHIAN_HIGH) & (frame.ADX >= 30), (frame.Close < frame.DONCHIAN_LOW) & (frame.ADX >= 30)
    elif name == "donchian30_adx25":
        upper, lower = frame.High.shift(1).rolling(30, min_periods=30).max(), frame.Low.shift(1).rolling(30, min_periods=30).min()
        long, short = (frame.Close > upper) & (frame.ADX >= 25), (frame.Close < lower) & (frame.ADX >= 25)
    elif name == "rsi_bb_30_70":
        long, short = (frame.RSI14 < 30) & (frame.Close < frame.BB_LOWER), (frame.RSI14 > 70) & (frame.Close > frame.BB_UPPER)
    elif name == "rsi_bb_25_75":
        long, short = (frame.RSI14 < 25) & (frame.Close < frame.BB_LOWER), (frame.RSI14 > 75) & (frame.Close > frame.BB_UPPER)
    elif name == "rsi_bb_range":
        long, short = (frame.RSI14 < 30) & (frame.Close < frame.BB_LOWER) & (frame.ADX < 20), (frame.RSI14 > 70) & (frame.Close > frame.BB_UPPER) & (frame.ADX < 20)
    elif name == "keltner_1_5":
        long, short = (frame.Close > frame.KC_UPPER) & up, (frame.Close < frame.KC_LOWER) & down
    elif name == "keltner_2_0":
        upper, lower = frame.EMA20 + 2.0 * frame.ATR, frame.EMA20 - 2.0 * frame.ATR
        long, short = (frame.Close > upper) & up, (frame.Close < lower) & down
    elif name == "keltner_1_5_adx":
        long, short = (frame.Close > frame.KC_UPPER) & up & (frame.ADX >= 22), (frame.Close < frame.KC_LOWER) & down & (frame.ADX >= 22)
    else:
        raise ValueError(name)
    return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=frame.index)


def meets_durability(h1: dict, h2: dict) -> bool:
    """يتطلب اجتياز شروط العينة والتكلفة وPF في كل من التطوير وخارج العينة."""
    return all(
        all((period["filled_trades"] >= MIN_TRADES, period["cost_sensitivity_r"]["0.10_per_trade"] > 0, (period["profit_factor"] or 0) >= 1.1))
        for period in (h1, h2)
    )


def score(segments: list[pd.DataFrame], name: str, stop_atr: float, target_r: float) -> dict:
    prepared = [(segment, make_signal(segment, name)) for segment in segments]
    h1 = metrics([simulate_segment(segment, signal, stop_atr, target_r, H1_START, SPLIT) for segment, signal in prepared])
    h2 = metrics([simulate_segment(segment, signal, stop_atr, target_r, SPLIT, END) for segment, signal in prepared])
    durable = meets_durability(h1, h2)
    return {"h1_development": h1, "h2_observed_oos": h2, "durable": durable}


FAMILIES = {
    "donchian_adx": {"timeframe": "1h", "stop_atr": 2.0, "target_r": 2.0, "rules": ("donchian_adx22", "donchian_adx30", "donchian30_adx25")},
    "rsi_bollinger": {"timeframe": "1h", "stop_atr": 1.5, "target_r": 1.5, "rules": ("rsi_bb_30_70", "rsi_bb_25_75", "rsi_bb_range")},
    "keltner_breakout": {"timeframe": "4h", "stop_atr": 1.75, "target_r": 2.0, "rules": ("keltner_1_5", "keltner_2_0", "keltner_1_5_adx")},
}


def main() -> None:
    base = load_base()
    results: dict[str, dict] = {}
    for family, spec in FAMILIES.items():
        segments = [add_indicators(segment) for segment in split_segments(resample(base, spec["timeframe"]))]
        variants = {rule: score(segments, rule, spec["stop_atr"], spec["target_r"]) for rule in spec["rules"]}
        results[family] = {"timeframe": spec["timeframe"], "variants": variants, "durable_variant_count": sum(item["durable"] for item in variants.values())}
    OUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = []
    for family, group in results.items():
        for rule, item in group["variants"].items():
            h1, h2 = item["h1_development"], item["h2_observed_oos"]
            rows.append(f"| {family} | {rule} | {h1['filled_trades']} | {h1['cost_sensitivity_r']['0.10_per_trade']} | {h2['filled_trades']} | {h2['cost_sensitivity_r']['0.10_per_trade']} | {h2['profit_factor']} | {'نعم' if item['durable'] else 'لا'} |")
    OUT_MD.write_text(f"""# فحص متانة مرشحي XAUUSD — 2025

يختبر هذا الفحص قواعد قريبة معلنة مسبقاً لكل عائلة مرشحة. تعد النتيجة متينة فقط عندما تجتاز H1 للتطوير وH2 المرصودة خارج العينة 20 صفقة على الأقل، وصافي R بعد حساسية 0.10R موجباً، ومعامل ربح لا يقل عن 1.10. لا تملأ الاختبارات فجوة بيانات المصدر، ولا تتضمن تكاليف وسيط فعلية.

| العائلة | المتغير | صفقات H1 | H1 بعد 0.10R | صفقات H2 | H2 بعد 0.10R | PF H2 | متين؟ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
{"\n".join(rows)}
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for family, group in results.items():
        print(family, "durable_variants", group["durable_variant_count"])


if __name__ == "__main__":
    main()
