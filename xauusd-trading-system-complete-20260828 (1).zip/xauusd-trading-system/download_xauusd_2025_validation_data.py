"""ينزل ملفات OHLC العامة للتحقق فقط ويخزنها خارج المشروع."""
from __future__ import annotations

from pathlib import Path

import requests


BASE = "https://huggingface.co/datasets/ZombitX64/xauusd-gold-price-historical-data-2004-2025/resolve/main"
TARGET_DIR = Path("/tmp/xauusd-validation-data")
FILES = ("XAU_1h_data.jsonl", "XAU_4h_data.jsonl")


def main() -> None:
    TARGET_DIR.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        target = TARGET_DIR / name
        response = requests.get(f"{BASE}/{name}?download=true", timeout=90)
        response.raise_for_status()
        target.write_bytes(response.content)
        print(f"{target} bytes={target.stat().st_size}")


if __name__ == "__main__":
    main()
