"""اختبار XAUUSD لعام 2026 على OHLC مرجعي متاح فقط، بلا ادعاء تنفيذ أو سعر وسيط."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy


SOURCE = Path("/tmp/xauusd_2026_myfxbook_4h.csv")
OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2026_4h_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2026_4h_report.md")
HORIZON_BARS = 12
WARMUP_BARS = 220
MIN_TRADES = 12
MAX_GAP = pd.Timedelta(days=4)
PARAMETER_VARIANTS = 3


RULES: tuple[tuple[str, float, float, str], ...] = (
    ("ema_adx_pullback", 1.5, 2.0, "اتجاه — EMA + ADX + RSI"),
    ("donchian_adx", 2.0, 2.0, "اختراق نطاق"),
    ("rsi_bollinger", 1.5, 1.5, "ارتداد متوسط"),
    ("rsi2_ema200", 1.25, 1.5, "ارتداد قصير داخل اتجاه أعلى"),
    ("keltner_breakout", 1.75, 2.0, "قناة ATR"),
    ("squeeze_breakout", 1.5, 2.0, "انكماش Bollinger–Keltner"),
    ("nr7_trend_breakout", 1.5, 2.0, "ضغط نطاق NR7"),
    ("supertrend_pullback", 1.5, 2.0, "اتجاه ATR — SuperTrend"),
    ("zscore_trend_reversion", 1.5, 1.5, "انحراف معياري داخل اتجاه أعلى"),
    ("failed_breakout_reversal", 1.5, 1.5, "فشل اختراق نطاق — انعكاس"),
)


def load() -> pd.DataFrame:
    frame = pd.read_csv(SOURCE)
    frame["Date"] = pd.to_datetime(frame["Date"], utc=True, errors="coerce")
    frame = frame.dropna(subset=["Date"]).set_index("Date").sort_index()
    for column in ("Open", "High", "Low", "Close"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    return frame.dropna(subset=["Open", "High", "Low", "Close"])


def split_segments(frame: pd.DataFrame) -> list[pd.DataFrame]:
    groups = frame.index.to_series().diff().gt(MAX_GAP).cumsum()
    return [part.copy() for _, part in frame.groupby(groups) if len(part) >= WARMUP_BARS + HORIZON_BARS]


def add_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    prior_close = out.Close.shift(1)
    true_range = pd.concat([out.High - out.Low, (out.High - prior_close).abs(), (out.Low - prior_close).abs()], axis=1).max(axis=1)
    out["ATR"] = true_range.rolling(14, min_periods=14).mean()
    for span in (20, 50, 200):
        out[f"EMA{span}"] = out.Close.ewm(span=span, adjust=False, min_periods=span).mean()
    delta = out.Close.diff()
    for period, label in ((14, "RSI14"), (2, "RSI2")):
        gain = delta.clip(lower=0).rolling(period, min_periods=period).mean()
        loss = (-delta.clip(upper=0)).rolling(period, min_periods=period).mean().replace(0, np.nan)
        out[label] = 100 - 100 / (1 + gain / loss)
    mean = out.Close.rolling(20, min_periods=20).mean()
    stdev = out.Close.rolling(20, min_periods=20).std(ddof=0)
    out["BB_UPPER"], out["BB_LOWER"], out["ZSCORE"] = mean + 2 * stdev, mean - 2 * stdev, (out.Close - mean) / stdev.replace(0, np.nan)
    out["KC_UPPER"], out["KC_LOWER"] = out.EMA20 + 1.5 * out.ATR, out.EMA20 - 1.5 * out.ATR
    out["DONCHIAN_HIGH"] = out.High.shift(1).rolling(20, min_periods=20).max()
    out["DONCHIAN_LOW"] = out.Low.shift(1).rolling(20, min_periods=20).min()
    out["RANGE"] = out.High - out.Low
    out["NR7"] = out.RANGE.eq(out.RANGE.rolling(7, min_periods=7).min())
    up_move, down_move = out.High.diff(), -out.Low.diff()
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=out.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=out.index)
    atr_sum = true_range.rolling(14, min_periods=14).sum().replace(0, np.nan)
    plus_di, minus_di = 100 * plus_dm.rolling(14, min_periods=14).sum() / atr_sum, 100 * minus_dm.rolling(14, min_periods=14).sum() / atr_sum
    out["ADX"] = (100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)).rolling(14, min_periods=14).mean()
    midpoint = (out.High + out.Low) / 2
    upper, lower = midpoint + 3 * out.ATR, midpoint - 3 * out.ATR
    final_upper, final_lower, supertrend = upper.copy(), lower.copy(), pd.Series(np.nan, index=out.index)
    for i in range(1, len(out)):
        if pd.isna(out.ATR.iloc[i]) or pd.isna(supertrend.iloc[i - 1]):
            supertrend.iloc[i] = lower.iloc[i] if out.Close.iloc[i] >= midpoint.iloc[i] else upper.iloc[i]
            continue
        final_upper.iloc[i] = min(upper.iloc[i], final_upper.iloc[i - 1]) if out.Close.iloc[i - 1] <= final_upper.iloc[i - 1] else upper.iloc[i]
        final_lower.iloc[i] = max(lower.iloc[i], final_lower.iloc[i - 1]) if out.Close.iloc[i - 1] >= final_lower.iloc[i - 1] else lower.iloc[i]
        supertrend.iloc[i] = final_lower.iloc[i] if out.Close.iloc[i] >= final_upper.iloc[i - 1] else final_upper.iloc[i] if out.Close.iloc[i] <= final_lower.iloc[i - 1] else supertrend.iloc[i - 1]
    out["SUPERTREND"] = supertrend
    return out


def signals(frame: pd.DataFrame, name: str) -> pd.Series:
    current, prior = frame, frame.shift(1)
    up, down = current.EMA20 > current.EMA50, current.EMA20 < current.EMA50
    if name == "ema_adx_pullback":
        long = up & (current.ADX >= 25) & (current.Close <= current.EMA20) & (current.Close > current.EMA50) & current.RSI14.between(45, 62)
        short = down & (current.ADX >= 25) & (current.Close >= current.EMA20) & (current.Close < current.EMA50) & current.RSI14.between(38, 55)
    elif name == "donchian_adx":
        long, short = (current.Close > current.DONCHIAN_HIGH) & (current.ADX >= 22), (current.Close < current.DONCHIAN_LOW) & (current.ADX >= 22)
    elif name == "rsi_bollinger":
        long, short = (current.RSI14 < 30) & (current.Close < current.BB_LOWER), (current.RSI14 > 70) & (current.Close > current.BB_UPPER)
    elif name == "rsi2_ema200":
        long, short = (current.Close > current.EMA200) & (current.RSI2 < 10), (current.Close < current.EMA200) & (current.RSI2 > 90)
    elif name == "keltner_breakout":
        long, short = (current.Close > current.KC_UPPER) & up, (current.Close < current.KC_LOWER) & down
    elif name == "squeeze_breakout":
        squeezed = (prior.BB_UPPER < prior.KC_UPPER) & (prior.BB_LOWER > prior.KC_LOWER)
        long, short = squeezed & (current.Close > current.BB_UPPER) & up, squeezed & (current.Close < current.BB_LOWER) & down
    elif name == "nr7_trend_breakout":
        long, short = prior.NR7 & (current.Close > prior.High) & up & (current.ADX >= 20), prior.NR7 & (current.Close < prior.Low) & down & (current.ADX >= 20)
    elif name == "supertrend_pullback":
        long = up & (current.Close > current.SUPERTREND) & (current.Close <= current.EMA20) & current.RSI14.between(45, 62)
        short = down & (current.Close < current.SUPERTREND) & (current.Close >= current.EMA20) & current.RSI14.between(38, 55)
    elif name == "zscore_trend_reversion":
        long, short = (current.Close > current.EMA200) & (current.ZSCORE <= -2), (current.Close < current.EMA200) & (current.ZSCORE >= 2)
    elif name == "failed_breakout_reversal":
        long = (prior.Low < prior.DONCHIAN_LOW) & (current.Close > current.DONCHIAN_LOW) & (current.RSI14 < 55)
        short = (prior.High > prior.DONCHIAN_HIGH) & (current.Close < current.DONCHIAN_HIGH) & (current.RSI14 > 45)
    else:
        raise ValueError(name)
    return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=frame.index)


def simulate(frame: pd.DataFrame, signal: pd.Series, stop_atr: float, target_r: float, start: int, end: int) -> dict:
    outcomes: list[float] = []
    trades: list[dict] = []
    i = max(WARMUP_BARS, start)
    while i < end - 1:
        side, atr = int(signal.iloc[i]), float(frame.ATR.iloc[i]) if pd.notna(frame.ATR.iloc[i]) else 0.0
        if side == 0 or atr <= 0:
            i += 1
            continue
        entry_i, entry, risk = i + 1, float(frame.Open.iloc[i + 1]), stop_atr * atr
        stop = entry - risk if side == 1 else entry + risk
        target = entry + target_r * risk if side == 1 else entry - target_r * risk
        maximum = min(end, entry_i + HORIZON_BARS - 1)
        exit_i, exit_price, outcome = maximum, float(frame.Close.iloc[maximum]), "انتهت المدة"
        for j in range(entry_i, maximum + 1):
            high, low = float(frame.High.iloc[j]), float(frame.Low.iloc[j])
            hit_stop, hit_target = (low <= stop, high >= target) if side == 1 else (high >= stop, low <= target)
            if hit_stop and hit_target:
                exit_i, exit_price, outcome = j, stop, "غموض داخل الشمعة — وقف محافظ"
                break
            if hit_stop:
                exit_i, exit_price, outcome = j, stop, "وقف"
                break
            if hit_target:
                exit_i, exit_price, outcome = j, target, "هدف"
                break
        r = (exit_price - entry) / risk if side == 1 else (entry - exit_price) / risk
        outcomes.append(float(r))
        trades.append({"decision_time": str(frame.index[i]), "entry_time": str(frame.index[entry_i]), "exit_time": str(frame.index[exit_i]), "direction": "شراء" if side == 1 else "بيع", "outcome": outcome, "r_multiple": round(float(r), 4)})
        i = exit_i + 1
    return {"outcomes": outcomes, "trades": trades, "signals": int((signal.iloc[start:end] != 0).sum())}


def metrics(parts: list[dict]) -> dict:
    outcomes = [x for part in parts for x in part["outcomes"]]
    trades = [item for part in parts for item in part["trades"]]
    wins, losses = [x for x in outcomes if x > 0], [x for x in outcomes if x < 0]
    curve = np.cumsum(outcomes) if outcomes else np.array([])
    drawdown = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0.0
    profit, loss = sum(wins), abs(sum(losses))
    total = sum(outcomes)
    return {"signals": sum(p["signals"] for p in parts), "filled_trades": len(outcomes), "wins": len(wins), "losses": len(losses), "win_rate_pct": round(100 * len(wins) / len(outcomes), 1) if outcomes else None, "total_r": round(float(total), 2), "average_r": round(float(total / len(outcomes)), 3) if outcomes else None, "profit_factor": round(float(profit / loss), 2) if loss else None, "max_drawdown_r": round(drawdown, 2), "sample_adequate": len(outcomes) >= MIN_TRADES, "cost_sensitivity_r": {"0.05_per_trade": round(float(total - 0.05 * len(outcomes)), 2), "0.10_per_trade": round(float(total - 0.10 * len(outcomes)), 2)}, "trades": trades}


def evaluate_rule(segments: list[pd.DataFrame], name: str, stop_atr: float, target_r: float) -> dict:
    all_parts, h1_parts, h2_parts = [], [], []
    for frame in segments:
        signal = signals(frame, name)
        split = int(len(frame) * 0.40)
        h1_end, h2_start = split, split + 1
        all_parts.append(simulate(frame, signal, stop_atr, target_r, 0, len(frame) - 1))
        h1_parts.append(simulate(frame, signal, stop_atr, target_r, 0, h1_end))
        h2_parts.append(simulate(frame, signal, stop_atr, target_r, h2_start, len(frame) - 1))
    full, h1, h2 = metrics(all_parts), metrics(h1_parts), metrics(h2_parts)
    eligible = bool(h2["filled_trades"] >= MIN_TRADES and h2["cost_sensitivity_r"]["0.10_per_trade"] > 0 and (h2["profit_factor"] or 0) >= 1.10)
    return {"metrics": full, "development_h1": h1, "oos_h2_observed": h2, "eligible_for_research_watchlist": eligible}


def evaluate_ob_fvg(segments: list[pd.DataFrame]) -> dict:
    def run(half: str) -> dict:
        parts: list[dict] = []
        for frame in segments:
            split = int(len(frame) * 0.40)
            scoped = frame.iloc[:split] if half == "h1" else frame.iloc[split + 1:]
            if len(scoped) < 220:
                continue
            result = backtest_ob_fvg_strategy(scoped, warmup_bars=180, horizon_bars=HORIZON_BARS, censor_gap_bars=1, evaluation_stride=1, max_evaluation_points=500, signal_lookback_bars=600, trade_output_limit=None)
            parts.append({"outcomes": [float(row.get("r_multiple", 0)) for row in result.get("trades", [])], "trades": result.get("trades", []), "signals": int(result.get("metrics", {}).get("decision_points", 0))})
        return metrics(parts)
    h1, h2 = run("h1"), run("h2")
    return {"metrics": None, "development_h1": h1, "oos_h2_observed": h2, "eligible_for_research_watchlist": False, "exclusion_reason": "حجم H2 غير كافٍ لتشغيل OB+FVG مع الإحماء دون تجاوز الحد الزمني."}


def main() -> None:
    segments = [add_indicators(part) for part in split_segments(load())]
    results: dict[str, dict] = {}
    for name, stop_atr, target_r, family in RULES:
        record = evaluate_rule(segments, name, stop_atr, target_r)
        record.update({"strategy": name, "family": family, "rules": {"stop_atr": stop_atr, "target_r": target_r, "horizon_bars": HORIZON_BARS}})
        results[name] = record
    ob = evaluate_ob_fvg(segments)
    ob.update({"strategy": "ob_fvg", "family": "منطقة بنيوية", "rules": {"source_engine": "ob_fvg_strategy.py", "horizon_bars": HORIZON_BARS}})
    results["ob_fvg"] = ob
    ranking = sorted(({"strategy": key, "family": record["family"], "eligible": record["eligible_for_research_watchlist"], **{field: record["oos_h2_observed"].get(field) for field in ("filled_trades", "total_r", "profit_factor", "max_drawdown_r")}} for key, record in results.items()), key=lambda x: (x["eligible"], x["total_r"] if x["total_r"] is not None else -9999), reverse=True)
    payload = {"data_contract": {"source": "Myfxbook public XAUUSD 4h OHLC, captured 2026-08-25", "period": "2026-03-11 16:00 UTC to 2026-08-25 00:00 UTC only", "reference_only": True, "entry": "افتتاح الشمعة التالية", "same_bar_policy": "وقف محافظ", "costs": "0.05R و0.10R حساسية مجردة لكل صفقة", "minimum_sample": MIN_TRADES, "parameter_variants_declared": PARAMETER_VARIANTS, "not_available": ["Bid/Ask", "spread", "commission", "slippage", "order flow", "volume-at-price", "verified news actuals"]}, "segments": [{"start": str(s.index.min()), "end": str(s.index.max()), "bars": len(s)} for s in segments], "results": results, "oos_ranking": ranking}
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = "\n".join(f"| {item['strategy']} | {'مرشح مراقبة' if item['eligible'] else 'غير مؤهل'} | {item['filled_trades']} | {item['total_r']} | {item['profit_factor']} | {item['max_drawdown_r']} |" for item in ranking)
    OUT_MD.write_text(f"""# مقارنة XAUUSD لعام 2026 — مشاهدات الأربع ساعات المتاحة

تختبر هذه الدراسة قواعد محددة مسبقاً على OHLC مرجعي من 11 مارس إلى 25 أغسطس 2026 فقط. لا تمثل سنة كاملة ولا سعراً تنفيذياً لدى وسيط. تتضمن المقارنة عائلات الاتجاه والاختراق والارتداد والانكماش والبنية، مع دخول افتراضي في افتتاح الشمعة التالية وسياسة وقف محافظة عند غموض ترتيب الوقف والهدف.

| الاستراتيجية | الحالة | صفقات H2 | صافي H2 (R) | معامل الربح H2 | أقصى سحب H2 (R) |
| --- | --- | ---: | ---: | ---: | ---: |
{rows}

## بوابة المراقبة

لا تدخل القاعدة قائمة مراقبة بحثية إلا عند 12 صفقة H2 على الأقل، وصافي موجب بعد حساسية `0.10R` لكل صفقة، ومعامل ربح `1.10` أو أعلى. لا يمنح هذا أي وزن لبطاقة القرار الحي ولا يثبت القابلية للتنفيذ دون Bid/Ask وتكاليف وسيط وفترة أطول مستقلة.
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for item in ranking:
        print(item)


if __name__ == "__main__":
    main()
