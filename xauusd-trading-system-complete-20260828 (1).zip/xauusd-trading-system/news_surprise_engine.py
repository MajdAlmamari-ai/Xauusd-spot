#!/usr/bin/env python3
"""
محرك رصد التقارير الاقتصادية المجدولة، المفاجآت (Surprises)، والأخبار الجيوسياسية لزوج XAUUSD
"""

class NewsSurpriseEngine:
    def __init__(self):
        # التقارير القياسية المؤثرة على الذهب ومواعيدها المتوقعة وأثرها
        self.scheduled_reports = [
            {
                "report": "Non-Farm Payrolls (NFP - تقرير الوظائف الأمريكية)",
                "frequency": "Monthly (First Friday)",
                "impact_level": "Extreme",
                "gold_sensitivity": "Very High (Inverse to USD/Yields)"
            },
            {
                "report": "FOMC Rate Decision & Press Conference (قرار الفائدة الفيدرالية)",
                "frequency": "Every 6 weeks",
                "impact_level": "Extreme",
                "gold_sensitivity": "Very High (Direct impact from real rates)"
            },
            {
                "report": "CPI / Core CPI (مؤشر أسعار المستهلكين والتضخم)",
                "frequency": "Monthly",
                "impact_level": "High",
                "gold_sensitivity": "High (Inflation hedge sentiment)"
            },
            {
                "report": "US GDP Growth Rate (الناتج المحلي الإجمالي الأمريكي)",
                "frequency": "Quarterly (Advance/Second/Final)",
                "impact_level": "Medium-High",
                "gold_sensitivity": "Medium"
            },
            {
                "report": "Retail Sales (مبيعات التجزئة)",
                "frequency": "Monthly",
                "impact_level": "Medium-High",
                "gold_sensitivity": "Medium"
            }
        ]

    def evaluate_news_environment(self, active_geopolitical_risk=False, pending_high_impact_event=False):
        """
        تقييم البيئة الإخبارية والجيوسياسية وإصدار قيود التداول
        """
        warnings = []
        news_status = "Normal News Flow"

        if pending_high_impact_event:
            news_status = "High-Impact Event Pending"
            warnings.append("تحذير أخبار كبرى: موعد تقرير اقتصادي حاسم (مثل FOMC أو NFP) اقترب؛ يمنع التداول أو تفتح صفقات جديدة قبل صدوره.")

        if active_geopolitical_risk:
            news_status = "Geopolitical Risk Elevated"
            warnings.append("مخاطر جيوسياسية نشطة: توترات إقليمية أو دولية تدعم التدفق نحو الملاذ الآمن (الذهب)، مع توقع قفزات سعرية مفاجئة وانزلاق.")

        return {
            "news_status": news_status,
            "geopolitical_risk": active_geopolitical_risk,
            "pending_event": pending_high_impact_event,
            "warnings": warnings,
            "key_monitored_reports": [r["report"] for r in self.scheduled_reports]
        }

if __name__ == "__main__":
    engine = NewsSurpriseEngine()
    print(engine.evaluate_news_environment(True, False))
