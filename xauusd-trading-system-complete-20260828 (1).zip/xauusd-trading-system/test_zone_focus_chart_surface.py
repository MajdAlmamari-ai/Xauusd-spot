from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = [
        'data-zone-focus-index',
        'window.openZoneFocus=zone=>',
        'id="zoneFocusModal"',
        'id="zoneFocusCanvas"',
        'id="zoneFocusLandscape"',
        'id="zoneFocusClose"',
        'requestFullscreen||modal.webkitRequestFullscreen',
        "screen.orientation?.lock?.('landscape')",
        'zoneFocusShade',
        'OHLC وpivots وليست إثباتاً لأوامر مؤسسات أو Order Flow حقيقي',
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    print("PASS: zone pills open a focused chart with boundaries, fullscreen landscape control, and source disclaimer")


if __name__ == "__main__":
    main()
