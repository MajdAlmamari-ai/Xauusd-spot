"""عقود سوق واضحة تفصل السعر المرجعي الحي عن OHLC التاريخي.

لا تحتوي هذه الطبقة على أوامر أو تنفيذ؛ وهي تفرض Yahoo Finance لمسار الشموع
في المنصة الشخصية الحالية، بينما يبقى gold-api.com لمسار السعر فقط.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import pandas as pd

from market_archive import MarketArchive
from mt5_price_connector import MT5PriceConnector


class LivePriceProvider(Protocol):
    def get_current_price(self) -> dict: ...


class HistoricalDataProvider(Protocol):
    def get_ohlc(self, *, period: str, timeframe: str) -> pd.DataFrame: ...


@dataclass
class GoldApiLivePriceProvider:
    connector: MT5PriceConnector
    name: str = "gold-api.com"

    def get_current_price(self) -> dict:
        quote = self.connector._fetch_gold_api_reference()
        quote["provider_role"] = "live_price_provider"
        quote["execution_classification"] = "public_market_reference_not_executable"
        return quote


@dataclass
class ArchivedGoldApiLivePriceProvider:
    """واجهة Flask تقرأ آخر لقطة جمعها العامل المستقل ولا تضاعف طلب المصدر."""

    archive: MarketArchive
    name: str = "gold-api.com persistent market archive"

    def get_current_price(self) -> dict:
        quote = self.archive.latest_live_quote()
        quote["provider_role"] = "live_price_provider"
        quote["execution_classification"] = "public_market_reference_not_executable"
        return quote


@dataclass
class YahooFinanceHistoricalDataProvider:
    connector: MT5PriceConnector
    name: str = "Yahoo Finance"

    def get_ohlc(self, *, period: str, timeframe: str) -> pd.DataFrame:
        candles = self.connector.fetch_ohlc(period=period, interval=timeframe, provider="yahoo")
        candles.attrs["provider_role"] = "historical_data_provider"
        return candles


@dataclass
class MarketDataService:
    """النقطة الوحيدة التي تستعملها واجهة التحليل للرسم والسعر."""

    live_price_provider: LivePriceProvider
    historical_data_provider: HistoricalDataProvider

    def live_price(self) -> dict:
        try:
            return self.live_price_provider.get_current_price()
        except Exception as error:
            return {
                "status": "error",
                "source": "gold-api.com XAU/USD live market reference",
                "source_symbol": "XAU/USD",
                "provider_role": "live_price_provider",
                "execution_classification": "public_market_reference_not_executable",
                "stale": True,
                "live_for_analysis": False,
                "tradable": False,
                "message": f"تعذر الوصول إلى سعر gold-api.com: {error}",
            }

    def historical_ohlc(self, *, period: str, timeframe: str) -> pd.DataFrame:
        return self.historical_data_provider.get_ohlc(period=period, timeframe=timeframe)

    def source_inventory(self) -> dict:
        return {
            "live_price_provider": {
                "name": "gold-api.com",
                "symbol": "XAU/USD",
                "role": "current_market_reference_only",
                "provides": ["current_price", "source_timestamp", "data_status"],
                "does_not_provide": ["OHLC", "bid", "ask", "broker_spread", "execution"],
            },
            "historical_data_provider": {
                "name": "Yahoo Finance",
                "symbol": "GC=F",
                "role": "reference_ohlc_for_chart_and_analysis",
                "provides": ["OHLCV", "candle_timestamp"],
                "does_not_provide": ["XAUUSD_spot_execution_quote", "broker_bid_ask"],
            },
        }
