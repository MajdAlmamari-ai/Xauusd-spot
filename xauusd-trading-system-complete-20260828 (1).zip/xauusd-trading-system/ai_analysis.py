"""تحليل AI منظم؛ يمنع تحويل بيانات مرجعية أو متأخرة إلى قرار تنفيذ."""

from __future__ import annotations

import json
from os import getenv
from typing import Any

import requests

from analysis_contracts import decision_data_context_from_contract


def _blocked(reason: str, quote: dict[str, Any]) -> dict[str, Any]:
    return {
        "status": "محجوب",
        "title": "تحليل AI غير متاح للتنفيذ",
        "summary": reason,
        "scenario": "NO_TRADE",
        "confidence": None,
        "confidence_status": "غير معاير — لا يفسر كاحتمال نجاح",
        "evidence_strength": {"score": 0, "is_probability": False},
        "entry": None,
        "stop_loss": None,
        "take_profit": None,
        "invalidation": "لا توجد بيانات تنفيذ موثقة.",
        "conditions": [],
        "risks": ["السعر المرجعي أو بيانات الشموع لا تمثل سعر تنفيذ لدى الوسيط."],
        "data_scope": {"source": quote.get("source"), "tradable": bool(quote.get("tradable")), "age_seconds": quote.get("age_seconds")},
    }


def _reference_analysis(quote: dict[str, Any], technical: dict[str, Any], news: dict[str, Any]) -> dict[str, Any]:
    """قراءة منظمة من حقائق الشموع عندما لا تتوفر تغذية تنفيذ من الوسيط."""
    advanced = technical.get("advanced_tools", {})
    confluence = advanced.get("confluence", {})
    multi = advanced.get("multi_timeframe", {})
    action = technical.get("technical_signal", "متعادلة")
    bias = confluence.get("bias", "توافق محدود / مختلط")
    conflict = (action == "شراء" and bias == "توافق هابط") or (action == "بيع" and bias == "توافق صاعد")
    if conflict or action not in {"شراء", "بيع"}:
        scenario = "انتظار"
        summary = "القراءة المحسوبة لا تمنح أفضلية متماسكة للشراء أو البيع؛ الحياد هو القرار المنضبط حتى تتفق الأدوات."
        entry = stop_loss = take_profit = None
    else:
        scenario = f"{action} تحليلي مشروط"
        latest = float(technical.get("latest", 0.0))
        atr = float(technical.get("atr", 0.0) or 0.0)
        entry = round(latest, 2)
        if action == "شراء":
            stop_loss, take_profit = round(latest - 1.5 * atr, 2), round(latest + 3.0 * atr, 2)
        else:
            stop_loss, take_profit = round(latest + 1.5 * atr, 2), round(latest - 3.0 * atr, 2)
        summary = "قراءة مرجعية مشروطة من اتجاه المؤشرات وتوافق السيولة وبنية السوق؛ طابق المستويات مع سعر وسيطك قبل أي تنفيذ."
    return {
        "status": "قراءة مرجعية",
        "title": "محرك القرار المنضبط — قراءة مرجعية",
        "summary": summary,
        "scenario": scenario,
        "confidence": None,
        "confidence_status": "غير معاير — تستخدم قوة الأدلة الوصفية فقط",
        "evidence_strength": technical.get("evidence_strength", {"score": 0, "is_probability": False}),
        "entry": entry,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "invalidation": "يبطل السيناريو عند اختراق مستوى الوقف على سعر وسيطك، أو ظهور خبر عالي الأثر، أو تعارض الإطار الأعلى.",
        "conditions": [
            f"توافق أدوات السيولة وبنية السوق: {bias}.",
            f"توافق الإطار الأعلى: {multi.get('status', 'غير متاح')}.",
            "لا توجد تغذية Actual/Forecast حية؛ راجع التقويم عالي الأثر قبل التنفيذ.",
        ],
        "risks": [
            "السعر والشموع مرجعيان؛ Bid/Ask والسبريد لدى الوسيط قد يغيران مستوى التنفيذ الفعلي.",
            "لا تتوفر بيانات DOM أو تدفق أوامر حقيقي؛ السيولة مبنية على بنية الشموع والمناطق.",
        ],
        "data_scope": {"source": quote.get("source"), "tradable": False, "age_seconds": quote.get("age_seconds")},
    }


def build_ai_analysis(quote: dict[str, Any], technical: dict[str, Any] | None, news: dict[str, Any], timeframe: dict[str, Any]) -> dict[str, Any]:
    """يستدعي نموذجاً بخطّة JSON فقط بعد تحقق البيانات؛ لا يستبدل المحرك الفني."""
    if quote.get("status") != "success" or quote.get("stale") or not quote.get("live_for_analysis"):
        return _blocked("يلزم سعر سوق حديث وصالح للتحليل قبل تشغيل تحليل AI.", quote)
    if technical is None:
        return _blocked("لا توجد لقطة شموع صالحة للإطار الزمني المختار.", quote)
    data_context = decision_data_context_from_contract(quote, technical.get("data_contract"), technical.get("data_quality"))
    if not data_context["compatible_for_price_levels"]:
        blocked = _blocked(f"حُجب السيناريو السعري: {data_context['reason']}", quote)
        blocked["data_scope"]["data_context"] = data_context
        return blocked
    if news.get("pending_event"):
        return _blocked("فلتر الخبر الاقتصادي النشط يمنع إنشاء سيناريو AI تنفيذي.", quote)
    if not quote.get("tradable"):
        return _reference_analysis(quote, technical, news)
    api_base, api_key = getenv("OPENAI_API_BASE"), getenv("OPENAI_API_KEY")
    if not api_base or not api_key:
        return _blocked("خدمة تحليل AI غير مهيأة على الخادم.", quote)
    advanced = technical.get("advanced_tools", {})
    tools = advanced.get("tools", {})
    facts = {
        "timeframe": {key: timeframe.get(key) for key in ("id", "label", "updated_at")},
        "execution_quote": {key: quote.get(key) for key in ("source", "symbol", "last_price", "bid", "ask", "age_seconds", "tradable")},
        "technical": {key: technical.get(key) for key in ("latest", "atr", "rsi", "macd", "macd_signal", "macd_histogram", "technical_signal", "evidence_strength", "last_candle_time")},
        "confluence": advanced.get("confluence", {}),
        "support_resistance": tools.get("support_resistance", {}),
        "liquidity_sweep": tools.get("liquidity_sweep", {}),
        "fair_value_gap": tools.get("fair_value_gap", {}),
        "order_blocks": tools.get("order_blocks", {}),
        "indicator_combinations": technical.get("indicator_combinations", []),
    }
    schema = {
        "name": "xauusd_analysis",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["متاح", "انتظار"]},
                "title": {"type": "string"}, "summary": {"type": "string"}, "scenario": {"type": "string", "enum": ["BULLISH_SCENARIO", "BEARISH_SCENARIO", "CONDITIONAL", "NO_TRADE"]},
                "evidence_strength": {"type": "string"}, "entry": {"type": ["number", "null"]}, "stop_loss": {"type": ["number", "null"]}, "take_profit": {"type": ["number", "null"]},
                "invalidation": {"type": "string"}, "conditions": {"type": "array", "items": {"type": "string"}}, "risks": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["status", "title", "summary", "scenario", "evidence_strength", "entry", "stop_loss", "take_profit", "invalidation", "conditions", "risks"],
            "additionalProperties": False,
        },
    }
    system = (
        "أنت محلل سوق منضبط. استخدم الحقائق المرسلة فقط ولا تخترع مصدراً أو خبراً أو مستوى سعرياً. "
        "إذا كان التوافق أو مستويات الدعم/المقاومة أو المخاطرة غير كافٍ فاختر NO_TRADE أو CONDITIONAL واجعل entry/stop_loss/take_profit null. "
        "لا تدّع ضماناً أو تنفيذ صفقة. اجعل الشروط والمخاطر محددة وقصيرة بالعربية."
    )
    payload = {
        "model": getenv("AI_ANALYSIS_MODEL", "gpt-5-mini"),
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(facts, ensure_ascii=False)}],
        "response_format": {"type": "json_schema", "json_schema": schema},
        "max_completion_tokens": 1000,
    }
    try:
        response = requests.post(f"{api_base.rstrip('/')}/chat/completions", headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}, json=payload, timeout=30)
        response.raise_for_status()
        result = json.loads(response.json()["choices"][0]["message"]["content"])
    except (requests.RequestException, KeyError, IndexError, TypeError, ValueError):
        return _blocked("تعذر الحصول على تحليل AI منظم؛ لم تُستبدل النتيجة بتخمين.", quote)
    result["confidence"] = None
    result["confidence_status"] = "غير معاير — لا يفسر كاحتمال نجاح"
    result["data_scope"] = {"source": quote.get("source"), "tradable": True, "age_seconds": quote.get("age_seconds"), "data_context": data_context}
    return result
