"""يفحص ملفات التحقق المتقاطع للأطر التي ستستعمل في اختبار 2025 الموسع."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


BASE = Path("/tmp/xauusd-validation-data")
OUTPUT = Path("/home/ubuntu/xauusd-trading-system/xauusd_2025_validation_frames_audit.json")
START = pd.Timestamp("2025-01-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")
SPECS = {"1h": ("XAU_1h_data.jsonl", pd.Timedelta(hours=1)), "4h": ("XAU_4h_data.jsonl", pd.Timedelta(hours=4))}


def summarize(name: str, filename: str, expected: pd.Timedelta) -> dict:
    frame = pd.read_json(BASE / filename, lines=True)
    frame["Date"] = pd.to_datetime(frame["Date"], format="%Y.%m.%d %H:%M", errors="coerce", utc=True)
    frame = frame.dropna(subset=["Date"]).set_index("Date").sort_index().loc[START:END - pd.Timedelta(nanoseconds=1)]
    gaps = frame.index.to_series().diff().dropna()
    material = gaps[gaps > pd.Timedelta(days=7)]
    return {
        "timeframe": name,
        "rows_2025": int(len(frame)),
        "first_timestamp": str(frame.index.min()),
        "last_timestamp": str(frame.index.max()),
        "duplicates": int(frame.index.duplicated().sum()),
        "invalid_ohlc": int(frame[["Open", "High", "Low", "Close"]].isna().any(axis=1).sum()),
        "gaps_over_nominal_interval": int((gaps > expected).sum()),
        "gaps_over_7_days": [
            {"previous_bar_utc": str(timestamp - gap), "next_bar_utc": str(timestamp), "days": round(float(gap.total_seconds() / 86400), 2)}
            for timestamp, gap in material.sort_values(ascending=False).items()
        ],
    }


def main() -> None:
    payload = {
        "source": "Hugging Face mirror of Kaggle XAU/USD dataset; OHLC reference only",
        "period": "2025 UTC-normalized",
        "frames": [summarize(name, filename, expected) for name, (filename, expected) in SPECS.items()],
        "decision": "لا تُستخدم أي فترة مفقودة لتوليد شموع أو نتائج؛ يعاد تسخين المؤشرات بعد الفجوة الطويلة.",
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
