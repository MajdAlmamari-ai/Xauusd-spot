"""تحليل لقطات الرسوم البيانية دون تحويل الصورة إلى بيانات سوق أو سعر تنفيذ."""

from __future__ import annotations

import base64
import hashlib
import io
import json
import os
from dataclasses import dataclass
from typing import Any

import requests
from PIL import Image, UnidentifiedImageError


ALLOWED_IMAGE_FORMATS = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp"}
MAX_IMAGE_BYTES = int(os.getenv("CHART_IMAGE_MAX_BYTES", str(8 * 1024 * 1024)))
MAX_IMAGE_PIXELS = int(os.getenv("CHART_IMAGE_MAX_PIXELS", "24000000"))
MAX_VISION_EDGE = int(os.getenv("CHART_IMAGE_VISION_MAX_EDGE", "1920"))


@dataclass(frozen=True)
class ValidatedChartImage:
    raw: bytes
    mime_type: str
    width: int
    height: int
    sha256: str

    def public_metadata(self) -> dict[str, Any]:
        return {
            "mime_type": self.mime_type,
            "width": self.width,
            "height": self.height,
            "sha256": self.sha256,
            "storage": "temporary_in_memory_only",
        }


def validate_chart_image(raw: bytes) -> ValidatedChartImage:
    """يتحقق من صورة صغيرة مرفوعة في الذاكرة فقط ولا يحفظها على القرص."""
    if not raw:
        raise ValueError("لم تُرفق صورة للرسم.")
    if len(raw) > MAX_IMAGE_BYTES:
        raise ValueError(f"حجم الصورة يتجاوز الحد المسموح ({MAX_IMAGE_BYTES // (1024 * 1024)} MB).")
    try:
        with Image.open(io.BytesIO(raw)) as image:
            image.verify()
        with Image.open(io.BytesIO(raw)) as image:
            image_format = str(image.format or "").upper()
            width, height = image.size
    except (UnidentifiedImageError, OSError, ValueError) as error:
        raise ValueError("الصورة غير صالحة أو لا يمكن قراءتها.") from error
    if image_format not in ALLOWED_IMAGE_FORMATS:
        raise ValueError("الصيغ المسموحة هي PNG وJPG وWEBP فقط.")
    if width < 160 or height < 120:
        raise ValueError("دقة الصورة صغيرة جداً؛ أرفق لقطة يظهر فيها الرسم بوضوح.")
    if width * height > MAX_IMAGE_PIXELS:
        raise ValueError("أبعاد الصورة كبيرة جداً؛ خفف الدقة ثم أعد المحاولة.")
    return ValidatedChartImage(
        raw=raw,
        mime_type=ALLOWED_IMAGE_FORMATS[image_format],
        width=width,
        height=height,
        sha256=hashlib.sha256(raw).hexdigest(),
    )


def chart_image_for_vision(image: ValidatedChartImage) -> tuple[str, str]:
    """يوحّد صور الإدخال في PNG مصغر داخل الذاكرة لتجنب اختلاف دعم WebP بين النماذج."""
    try:
        with Image.open(io.BytesIO(image.raw)) as source:
            normalized = source.convert("RGB")
            normalized.thumbnail((MAX_VISION_EDGE, MAX_VISION_EDGE))
            output = io.BytesIO()
            normalized.save(output, format="PNG", optimize=True)
    except (UnidentifiedImageError, OSError, ValueError) as error:
        raise ValueError("تعذر تهيئة الصورة بشكل آمن لتحليل الرؤية.") from error
    return "image/png", base64.b64encode(output.getvalue()).decode("ascii")


def _analysis_tools(technical: dict[str, Any] | None) -> list[dict[str, str]]:
    advanced = (technical or {}).get("advanced_tools", {}) or {}
    tools = advanced.get("tools", {}) or {}
    names = {
        "support_resistance": "دعم ومقاومة",
        "order_blocks": "Order Blocks",
        "fair_value_gap": "Fair Value Gap",
        "liquidity_sweep": "Liquidity Sweep",
        "volume_profile": "Volume Profile",
        "anchored_vwap": "Anchored VWAP",
        "fibonacci": "Fibonacci",
        "market_structure": "بنية السوق",
    }
    result: list[dict[str, str]] = []
    for key, label in names.items():
        details = tools.get(key)
        if not isinstance(details, dict):
            result.append({"name": label, "status": "غير متاح في حمولة الإطار"})
            continue
        status = str(details.get("status") or details.get("quality") or details.get("message") or "محتسب من شموع الإطار")
        result.append({"name": label, "status": status[:180]})
    return result


def build_platform_image_analysis(
    *,
    image: ValidatedChartImage,
    timeframe: dict[str, Any],
    quote: dict[str, Any],
    news: dict[str, Any],
) -> dict[str, Any]:
    """يربط اللقطة بسياق الإطار المختار، من دون ادعاء استخراج OHLC من بكسلات الصورة."""
    technical = timeframe.get("technical") or {}
    evidence = technical.get("evidence_families", {}) or {}
    strength = (evidence.get("evidence_strength") or technical.get("evidence_strength") or {}).get("score", 0)
    bias = evidence.get("decision_bias") or "محايد"
    qualified_families = [
        title
        for key, title in (("trend", "الاتجاه"), ("momentum", "الزخم"), ("market_structure", "بنية السوق"))
        if isinstance(evidence.get(key), dict)
        and evidence[key].get("qualified")
        and evidence[key].get("direction") == bias
    ]
    active_news = bool(news.get("pending_event"))
    fresh_reference = (
        quote.get("status") == "success"
        and not quote.get("stale")
        and quote.get("live_for_analysis") is True
    )
    if active_news:
        scenario = "NO_TRADE"
        summary = "فلتر خبر اقتصادي نشط؛ يحجب النظام السيناريو الاتجاهي حتى تتضح حركة ما بعد الخبر."
    elif bias in {"صاعد", "هابط"} and len(qualified_families) >= 2 and float(strength or 0) >= 70:
        scenario = "CONDITIONAL"
        summary = f"توجد قراءة {bias} وصفية من {len(qualified_families)} عائلات أدلة مستقلة نسبياً، لكنها مشروطة بتطابق المستويات مع الرسم وسعر الوسيط."
    else:
        scenario = "NO_TRADE"
        summary = "لا تظهر عائلتا أدلة مستقلتان مؤهلتان بالاتجاه نفسه في الإطار المختار؛ لا يصدر النظام مستوى دخول من الصورة."
    return {
        "mode": "platform",
        "status": "قراءة مرجعية" if fresh_reference else "سياق جزئي",
        "title": "تحليل قواعد المنصة للرسم المرفوع",
        "scenario": scenario,
        "summary": summary,
        "image": image.public_metadata(),
        "source_scope": {
            "image_role": "مرجع بصري للمراجعة فقط؛ لم تُستخرج منه شموع أو أسعار رقمية.",
            "timeframe": {key: timeframe.get(key) for key in ("id", "label", "updated_at")},
            "quote": {
                key: quote.get(key)
                for key in ("source", "source_symbol", "last_price", "source_timestamp", "age_seconds", "stale", "tradable")
            },
            "candle_contract": technical.get("data_contract"),
        },
        "evidence": {
            "bias": bias,
            "strength": strength,
            "is_probability": False,
            "qualified_families": qualified_families,
        },
        "tools": _analysis_tools(technical),
        "limitations": [
            "الصورة الثابتة ليست بيانات OHLC قابلة لإعادة الحساب؛ لا يمكن منها إجراء Backtest أو قراءة Tick/Order Flow حقيقي.",
            "تُعرض مناطق السيولة وOrder Blocks وFVG هنا من بيانات الإطار المختار في المنصة، لا من بكسلات اللقطة.",
            "السعر المرجعي العام ليس Bid/Ask أو سعراً تنفيذياً لدى الوسيط.",
        ],
    }


def _ai_unavailable(image: ValidatedChartImage, reason: str) -> dict[str, Any]:
    return {
        "mode": "ai",
        "status": "غير متاح",
        "title": "تحليل الصورة بالذكاء الاصطناعي",
        "scenario": "NO_TRADE",
        "summary": reason,
        "image": image.public_metadata(),
        "observations": [],
        "visible_levels": [],
        "uncertainties": ["لم يكتمل تحليل بصري موثق؛ لا تُستبدل النتيجة بتخمين."],
        "limitations": ["لا يصدر هذا المسار أمراً أو مستوى تنفيذ أو احتمال نجاح."],
    }


def available_chart_ai_providers() -> list[dict[str, Any]]:
    """سجل واجهة المستخدم؛ لا يعلن اتصالاً خارجياً غير مهيأ كأنه متاح."""
    proxy_ready = bool(os.getenv("OPENAI_API_BASE", "").strip() and os.getenv("OPENAI_API_KEY", "").strip())
    return [
        {
            "id": "manus",
            "label": "Manus AI",
            "model": os.getenv("AI_CHART_MANUS_MODEL", "gpt-5-mini"),
            "available": proxy_ready,
            "status": "متاح عبر خدمة المنصة" if proxy_ready else "خدمة المنصة غير مهيأة على هذا الخادم",
            "kind": "منسق تحليل المرفق داخل المنصة",
        },
        {
            "id": "gemini",
            "label": "Gemini AI",
            "model": os.getenv("AI_CHART_GEMINI_MODEL", "gemini-3-flash-preview"),
            "available": proxy_ready,
            "status": "متاح عبر خدمة المنصة" if proxy_ready else "خدمة المنصة غير مهيأة على هذا الخادم",
            "kind": "تحليل بصري منظم للصورة",
        },
        {
            "id": "claude",
            "label": "Claude AI",
            "model": None,
            "available": False,
            "status": "غير مهيأ؛ يحتاج تكاملاً مستقلاً وحساباً يدعم تحليل الصور",
            "kind": "خيار خارجي غير متصل حالياً",
        },
        {
            "id": "deepseek",
            "label": "DeepSeek AI",
            "model": None,
            "available": False,
            "status": "غير مهيأ؛ يحتاج تكاملاً مستقلاً وحساباً يدعم تحليل الصور",
            "kind": "خيار خارجي غير متصل حالياً",
        },
        {
            "id": "perplexity",
            "label": "Perplexity AI",
            "model": None,
            "available": False,
            "status": "غير مهيأ؛ يحتاج تكاملاً مستقلاً وحساباً يدعم تحليل الصور",
            "kind": "خيار خارجي غير متصل حالياً",
        },
    ]


def _resolve_provider(provider_id: str) -> dict[str, Any] | None:
    requested = str(provider_id or "gemini").strip().lower()
    return next((item for item in available_chart_ai_providers() if item["id"] == requested), None)


def analyze_chart_image_ai(*, image: ValidatedChartImage, user_timeframe: str | None, provider_id: str = "gemini") -> dict[str, Any]:
    """تحليل بصري منظم؛ لا يخلط ما يراه النموذج مع بيانات السوق الحية أو قرارات التنفيذ."""
    provider = _resolve_provider(provider_id)
    if provider is None:
        return _ai_unavailable(image, "خيار الذكاء الاصطناعي المطلوب غير معروف.")
    if not provider["available"]:
        return _ai_unavailable(image, f"{provider['label']}: {provider['status']}.")
    api_base = os.getenv("OPENAI_API_BASE", "").strip()
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    requested_timeframe = str(user_timeframe or "غير محدد")[:24]
    schema = {
        "name": "chart_image_visual_analysis",
        "strict": True,
        "schema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["observed", "insufficient"]},
                "title": {"type": "string"},
                "summary": {"type": "string"},
                "scenario": {"type": "string", "enum": ["BULLISH_SCENARIO", "BEARISH_SCENARIO", "CONDITIONAL", "NO_TRADE"]},
                "observations": {"type": "array", "items": {"type": "string"}},
                "visible_levels": {"type": "array", "items": {"type": "string"}},
                "visible_tools": {"type": "array", "items": {"type": "string"}},
                "uncertainties": {"type": "array", "items": {"type": "string"}},
                "risk_notes": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["status", "title", "summary", "scenario", "observations", "visible_levels", "visible_tools", "uncertainties", "risk_notes"],
            "additionalProperties": False,
        },
    }
    prompt = (
        "حلل لقطة الرسم بصرياً بالعربية. صف فقط ما يظهر بوضوح: اتجاه تقريبي، بنية سعرية، "
        "مؤشرات أو مستويات أو مناطق مرئية. لا تستنتج OHLC أو أسعاراً دقيقة أو حجم تداول أو Bid/Ask أو أخباراً "
        "إن لم تظهر. لا تخترع Order Flow أو Order Blocks/FVG إن لم تكن مرئية بوضوح. "
        "إذا كانت الدقة أو الوقت أو الرمز غير مقروءة فاذكر ذلك في uncertainties واختر CONDITIONAL أو NO_TRADE. "
        "لا تعطِ أمراً للتداول ولا نسبة نجاح. الإطار الذي اختاره المستخدم في المنصة هو: " + requested_timeframe
    )
    try:
        vision_mime_type, encoded = chart_image_for_vision(image)
    except ValueError:
        return _ai_unavailable(image, "تعذر تهيئة الصورة لتحليل الرؤية؛ لم تُستبدل النتيجة بتخمين.")
    payload = {
        "model": provider["model"],
        "messages": [{
            "role": "system",
            "content": "أنت محلل بصري منضبط للرسوم. لا تتجاوز الأدلة المرئية ولا تقدّم نصيحة تنفيذية.",
        }, {
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": f"data:{vision_mime_type};base64,{encoded}", "detail": "high"}},
            ],
        }],
        "response_format": {"type": "json_schema", "json_schema": schema},
    }
    if str(provider["model"]).startswith("gpt-"):
        payload["max_completion_tokens"] = 1600
    else:
        payload["max_tokens"] = 1600
    try:
        response = requests.post(
            f"{api_base.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=45,
        )
        response.raise_for_status()
        result = json.loads(response.json()["choices"][0]["message"]["content"])
    except (requests.RequestException, KeyError, IndexError, TypeError, ValueError, json.JSONDecodeError):
        return _ai_unavailable(image, "تعذر الحصول على تحليل الصورة المنظم؛ لم تُستبدل النتيجة بتخمين.")
    if result.get("status") == "insufficient":
        result["scenario"] = "NO_TRADE"
        result["visible_levels"] = []
        result["visible_tools"] = []
        result["uncertainties"] = list(dict.fromkeys([
            *(result.get("uncertainties") or []),
            "لا تكفي الأدلة المرئية لإصدار سيناريو اتجاهي؛ فُرضت نتيجة NO_TRADE.",
        ]))
    result.update({
        "mode": "ai",
        "provider": {key: provider[key] for key in ("id", "label", "model", "kind")},
        "image": image.public_metadata(),
        "limitations": [
            "هذه قراءة بصرية من صورة ثابتة، وليست فحصاً لبيانات OHLC أو تغذية سوق حي.",
            "لا تمثل المستويات المقروءة من الصورة Bid/Ask أو سعراً تنفيذياً؛ طابقها مع وسيطك قبل أي قرار.",
            "لا توجد معايرة احتمالية؛ السيناريو ليس تقديراً لاحتمال النجاح.",
        ],
    })
    return result


def _scenario_direction(scenario: object) -> str | None:
    value = str(scenario or "")
    if "BULLISH" in value:
        return "صاعد"
    if "BEARISH" in value:
        return "هابط"
    return None


def build_combined_chart_image_analysis(
    *,
    platform: dict[str, Any],
    visual: dict[str, Any],
) -> dict[str, Any]:
    """يدمج نتيجتين مع قاعدة veto: التعارض أو نقص أي طرف يعني عدم تقديم توصية اتجاهية."""
    platform_bias = str((platform.get("evidence") or {}).get("bias") or "محايد")
    visual_direction = _scenario_direction(visual.get("scenario"))
    platform_qualified = platform.get("scenario") == "CONDITIONAL" and platform_bias in {"صاعد", "هابط"}
    visual_qualified = visual.get("status") == "observed" and visual_direction in {"صاعد", "هابط"}
    if not platform_qualified or not visual_qualified:
        scenario = "NO_TRADE"
        agreement = "أدلة غير مكتملة"
        summary = "حُجبت التوصية الموحدة لأن تحليل المنصة أو قراءة الصورة لم يثبتا اتجاهاً مشروطاً كافياً."
    elif platform_bias != visual_direction:
        scenario = "NO_TRADE"
        agreement = "متعارض"
        summary = "حُجبت التوصية الموحدة لأن اتجاه قواعد المنصة لا يطابق الاتجاه المرئي في الصورة."
    else:
        scenario = "CONDITIONAL"
        agreement = "متفق"
        summary = f"يتفق تحليل المنصة وقراءة الصورة على ميل {platform_bias} مشروط. لا تُنشأ مستويات دخول أو وقف أو هدف من الصورة."
    limitations = list(dict.fromkeys([
        *(platform.get("limitations") or []),
        *(visual.get("limitations") or []),
        "الدمج لا يرفع قوة الأدلة إلى احتمال نجاح ولا يحول السعر المرجعي إلى Bid/Ask تنفيذي.",
    ]))
    return {
        "mode": "combined",
        "status": "قراءة موحدة منضبطة" if scenario == "CONDITIONAL" else "محجوب / انتظار",
        "title": "التوصية الموحدة: المنصة + تحليل المرفق",
        "scenario": scenario,
        "summary": summary,
        "agreement": {
            "status": agreement,
            "platform_bias": platform_bias,
            "visual_direction": visual_direction or "غير حاسم",
            "rule": "لا تمر توصية اتجاهية إلا عند اتفاق الطرفين؛ أي تعارض أو نقص أدلة ينتج NO_TRADE.",
        },
        "platform": platform,
        "visual": visual,
        "limitations": limitations,
    }
