# نتائج أولية لبحث API لبيانات XAUUSD

**تاريخ التحقق:** 2026-08-27. هذه الملاحظات تقنية أولية وليست توصية بفتح حساب أو تقييم ملاءمة تنظيمية في بلد المستخدم.

> **تحديث إقليمي — اليمن:** لا يوجد مرشح مثبت القبول للمقيم في اليمن من صفحات رسمية تم التحقق منها. **Capital.com مستبعد صراحةً** لأن صفحة التوفر تدرج Yemen ضمن البلدان غير المتاحة. OANDA يتطلب تحققاً خاصاً: قسم الحساب يتحدد بحسب بلد الإقامة، وAPI v20 غير متاح لـ OANDA Global Markets وOANDA TMS. IG وFXCM وSaxo تبقى `UNVERIFIED` حتى يثبت الدعم كتابةً أهلية اليمن وAPI والأداة. وثيقة التفصيل: `yemen_broker_api_eligibility_research_ar.md`.

| المرشح | ما توثقه الصفحة الرسمية | التوافق المبدئي مع المنصة | القيد أو نقطة التحقق |
|---|---|---|---|
| OANDA v20 | يتطلب حساب v20 ورمز وصول شخصي؛ يدعم تسعيراً آنياً وسجل أسعار، مع تسعير streaming يعيد `bids` و`asks`، وAPI شموع يتضمن Bid/Ask/Mid وحقول اكتمال الشمعة. | قوي تقنياً فقط لحساب v20. | اليمن غير مثبت؛ وv20 غير متاح لـ OANDA Global Markets أو OANDA TMS، لذا يجب تأكيد الكيان القانوني وقابلية اليمن و`XAU_USD` كتابةً قبل التسجيل. |
| Saxo OpenAPI | يقدم InfoPrices والأسعار عبر streaming؛ حقول Quote تشمل Bid/Mid/Ask و`DelayedByMinutes` وPriceType، وتختلف البيانات حسب حقوق تغذية الأسعار. | قوي تقنياً لكن يحتاج اكتشاف UIC/AssetType للأداة ثم اختبار أن `DelayedByMinutes=0`. | توفر سعر حقيقي أو عمق سوق يعتمد على حقوق السعر في حساب العميل؛ لا يُفترض أن XAUUSD متاح أو حي قبل فحص الحساب. |
| Capital.com API | وثائق الدعم تؤكد REST وWebSocket، مع تحديثات أسعار حية حتى 40 أداة. | غير مناسب للمقيم في اليمن. | صفحة التوفر الرسمية تدرج Yemen ضمن البلدان/الأقاليم غير المتاحة؛ لا يُقترح الالتفاف على هذا القيد. |
| cTrader Open API | يوفر شموعاً تاريخية وبارزات حية وطلبات اشتراك على Bid/Ask وعمق سوق Level II؛ قيمة الأسعار تحول بحسب scale/digits للرمز. | قوي إذا اختير وسيط يقدم cTrader ويعرض رمز الذهب في حسابه. | ليس وسيطاً بحد ذاته؛ الرمز والتغطية وBid/Ask/DOM تعتمد على وسيط cTrader والحساب. |
| FXCM APIs | يوفر FIX وJava وForexConnect؛ وثائقه تذكر أسعاراً حية متدفقة، سجل أسعار، وREST/SDK وفق المسار. | مرشح قوي تقنياً وقد لا يحتاج MT5. | FIX يتطلب حسب الوثائق حد رصيد $5,000؛ يلزم التحقق من توفر XAUUSD والأهلية البلدية/الحساب قبل التسجيل. |
| IG APIs | وثائق رسمية تذكر REST وstreaming وبيانات سوق حية وسجل أسعار، مع إمكانية حساب تجريبي؛ الصفحة تسوق Spot Gold ضمن منتجاتها. | مرشح تقني قوي إذا كان التسجيل متاحاً في بلد المستخدم. | يجب فحص EPIC الذهب المتاح للحساب، صلاحية API والقيود التنظيمية والرسوم في بلد المستخدم. |

## مصادر رسمية

1. OANDA Introduction — https://developer.oanda.com/rest-live-v20/introduction/
2. OANDA Pricing Endpoints — https://developer.oanda.com/rest-live-v20/pricing-ep/
3. OANDA Instrument Definitions — https://developer.oanda.com/rest-live-v20/instrument-df/
4. OANDA XAU/USD product page — https://www.oanda.com/bvi-en/cfds/instruments/xau-usd/
5. Saxo OpenAPI Pricing — https://developer.saxobank.com/openapi/learn/pricing
6. Saxo API overview — https://www.home.saxo/platforms/api
7. Capital.com API support — https://help.capital.com/hc/en-us/articles/6630762294418-Which-kind-of-APIs-do-you-have
8. cTrader Open API — https://openapi.ctrader.com/
9. cTrader Symbol Data — https://help.ctrader.com/open-api/symbol-data/
10. FXCM API Trading — https://www.fxcm.com/markets/algorithmic-trading/api-trading/
11. IG Trading APIs — https://www.ig.com/en/trading-platforms/trading-apis
12. Capital.com country availability — https://help.capital.com/hc/en-us/articles/27040372144274-Is-Capital-com-available-in-my-country
13. OANDA account division — https://help.oanda.com/sg/en/faqs/oanda-division.htm
