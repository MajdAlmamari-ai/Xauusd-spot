"""اختبار قياس تفاعل الزخم والسيولة والأخبار دون بيانات تنفيذ أو أخبار مصطنعة."""

from production_server import momentum_liquidity_news_analysis


def technical(momentum_bias: str = "صاعد") -> dict:
    histogram = 1.3 if momentum_bias == "صاعد" else -1.3
    roc = 0.8 if momentum_bias == "صاعد" else -0.8
    return {
        "rsi": 61.0 if momentum_bias == "صاعد" else 39.0,
        "macd_histogram": histogram,
        "indicators": [
            {"name": "ROC", "value": roc},
            {"name": "ADX(14)", "value": 29.0},
        ],
        "advanced_tools": {"confluence": {"bias": "توافق صاعد", "qualified_tools": 4}},
    }


def main() -> None:
    liquidity = {"liquidity_score": 75, "trap_detected": False}
    calendar_only = {"status": "calendar_ready_no_live_release_feed", "pending_event": False, "message": "التقويم وصفي فقط"}
    aligned = momentum_liquidity_news_analysis(technical("صاعد"), liquidity, calendar_only)
    assert aligned["status"] == "تأكيد مشروط", aligned
    assert aligned["confidence_adjustment"] == 1.0, aligned

    blocked = momentum_liquidity_news_analysis(technical("صاعد"), liquidity, {"pending_event": True, "message": "فلتر اختبار خبر"})
    assert blocked["decision_effect"] == "منع دخول جديد", blocked

    conflicting = momentum_liquidity_news_analysis(technical("هابط"), liquidity, {"pending_event": False, "message": "لا فلتر"})
    assert conflicting["decision_effect"] == "تحويل إلى حياد", conflicting
    print("نجحت اختبارات تفاعل الزخم والسيولة وفلتر الأخبار.")


if __name__ == "__main__":
    main()
