"""قياس محدود لطلبات ملفات Tick من Dukascopy؛ لا يغيّر بيانات الاختبار."""

from __future__ import annotations

import concurrent.futures
import argparse
from datetime import datetime, timedelta, timezone
from time import perf_counter
from urllib.error import HTTPError
from urllib.request import Request, urlopen


def url(moment: datetime) -> str:
    return f"https://datafeed.dukascopy.com/datafeed/XAUUSD/{moment.year}/{moment.month - 1:02d}/{moment.day:02d}/{moment.hour:02d}h_ticks.bi5"


def fetch(moment: datetime) -> int:
    try:
        with urlopen(Request(url(moment), headers={"User-Agent": "XAUUSD-Research/1.0"}), timeout=10) as response:
            return len(response.read())
    except HTTPError as error:
        return 0 if error.code == 404 else -1
    except Exception:
        return -1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", default="2026-01-05T00:00:00+00:00")
    parser.add_argument("--hours", default=48, type=int)
    args = parser.parse_args()
    start = datetime.fromisoformat(args.start.replace("Z", "+00:00")).astimezone(timezone.utc)
    samples = [start + timedelta(hours=index) for index in range(args.hours)]
    began = perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        sizes = list(executor.map(fetch, samples))
    elapsed = perf_counter() - began
    print({"start": start.isoformat(), "requests": len(samples), "success": sum(size > 0 for size in sizes), "empty": sum(size == 0 for size in sizes), "failed": sum(size < 0 for size in sizes), "seconds": round(elapsed, 2)})


if __name__ == "__main__":
    main()
