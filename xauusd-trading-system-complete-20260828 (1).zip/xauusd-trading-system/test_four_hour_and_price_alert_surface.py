from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = [
        'DEFAULT_TIMEFRAME_ID = "1d"',
        "timeframe_cards_with_fallback",
        '"action": "جارِ التحليل"',
        "xauusd-selected-timeframe",
        "TIMEFRAME_ASCENDING=['1m','5m','10m','15m','30m','1h','2h','4h','1d','1wk','1mo']",
        "sortTimeframesAscending(rows)",
        "neutralizeFourHourChrome",
        'button[data-chart-timeframe="4h"]{min-width:47px!important',
        "قوة المنطقة التاريخية",
        'data-strength="unavailable"',
        "historical_strength",
        "xauusd-price-alerts-v1",
        "LIMIT=10",
        "اختراق صعودي",
        "كسر هبوطي",
        "window.evaluatePriceAlerts",
        "Gold API المرجعي الحديث",
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    print("PASS: four-hour neutral treatment, zone-strength surface, and ten local price-alert controls are present")


if __name__ == "__main__":
    main()
