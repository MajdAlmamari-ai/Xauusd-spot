"""اختبار تكاملي لواجهة تحليل الأطر الزمنية.

شغّل الخادم أولاً على المنفذ 5000 ثم نفّذ:
python3 test_timeframe_api.py
"""

from __future__ import annotations

import json
import sys
import time
from urllib.error import HTTPError
from urllib.request import urlopen


BASE_URL = "http://127.0.0.1:5000"
EXPECTED_TIMEFRAMES = {"1m", "5m", "10m", "15m", "30m", "1h", "2h", "4h", "1d", "1wk", "1mo"}


def get(path: str) -> tuple[int, dict]:
    try:
        with urlopen(f"{BASE_URL}{path}", timeout=30) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        return error.code, json.loads(error.read().decode("utf-8"))


def check_frame(timeframe_id: str) -> tuple[dict, dict]:
    status, payload = get(f"/api/timeframe/{timeframe_id}")
    assert status == 200, payload
    frame = payload["timeframe"]
    snapshot = frame["technical"]
    assert frame["id"] == timeframe_id
    assert frame["error"] is None
    assert snapshot is not None
    assert snapshot["bars"] >= 200
    assert snapshot["last_candle_time"]
    assert len(snapshot["moving_averages"]) == 6
    assert len(snapshot["indicators"]) == 12
    assert set(snapshot["pivots"]) == {"traditional", "fibonacci"}
    return frame, snapshot


def wait_for_timeframes() -> dict | None:
    """تنتظر التحميل، وتفصل تعذر مصدر الشموع الخارجي عن فشل API محلي."""
    last = {}
    for _ in range(20):
        status, system = get("/api/system-status")
        assert status == 200, system
        last = system
        cards = system.get("timeframes", [])
        if {card.get("id") for card in cards} == EXPECTED_TIMEFRAMES:
            return system
        time.sleep(3)
    # حين يبقى التحليل فارغاً مع عدم وجود آخر تحديث، تكون Yahoo غير متاحة في بيئة الاختبار.
    # لا يصح أن يحوّل اختبار عقد محلي ذلك إلى نجاح وهمي أو إلى فشل غير قابل لإعادة الإنتاج.
    if not last.get("timeframes") and last.get("last_refresh") is None:
        print("تخطي تحقق الأطر: مصدر شموع Yahoo الخارجي لم يسلّم بيانات بعد مهلة البدء.")
        return None
    raise AssertionError(f"لم تكتمل بطاقات الأطر بعد مهلة البدء: {last}")


def main() -> None:
    system = wait_for_timeframes()
    if system is None:
        return
    cards = system["timeframes"]
    assert {card["id"] for card in cards} == EXPECTED_TIMEFRAMES

    one_minute_frame, one_minute = check_frame("1m")
    ten_minute_frame, ten_minute = check_frame("10m")
    two_hour_frame, two_hour = check_frame("2h")
    daily_frame, daily = check_frame("1d")
    weekly_frame, weekly = check_frame("1wk")
    assert one_minute["last_candle_time"] != daily["last_candle_time"]
    # في عطلة السوق قد تبدأ أحدث شمعة يومية وأسبوعية عند الطابع نفسه؛ ما يثبت
    # الفصل الصحيح هو إعداد المصدر المستقل لكل إطار لا اختلاف ختم زمني عرضي.
    assert daily_frame["interval"] != weekly_frame["interval"]
    assert daily_frame["period"] != weekly_frame["period"]
    assert one_minute_frame["interval"] != daily_frame["interval"]
    assert ten_minute_frame["interval"] == "10m"
    assert two_hour_frame["interval"] == "2h"
    assert ten_minute["last_candle_time"] != one_minute["last_candle_time"]

    invalid_status, invalid = get("/api/timeframe/not-a-timeframe")
    assert invalid_status == 400
    assert "error" in invalid
    print("نجح اختبار API للأطر الزمنية: 1m و10m و2h و1d و1wk وتحقيق رفض الإطار غير المدعوم.")


if __name__ == "__main__":
    try:
        main()
    except AssertionError as error:
        print(f"فشل الاختبار: {error}", file=sys.stderr)
        raise
