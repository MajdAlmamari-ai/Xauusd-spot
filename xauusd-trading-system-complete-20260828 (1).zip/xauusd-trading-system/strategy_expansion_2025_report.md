# مقارنة استراتيجية XAUUSD الموسعة — مشاهدات 2025 المتاحة

اُختبرت تسع قواعد ثابتة مسبقاً ومحرك OB+FVG على الساعة وأربع ساعات. أُجري اختيار القواعد قبل قراءة المخرجات، ويقاس الترتيب على H2 المرصود فقط. يوجد انقطاع طويل في ملف المصدر بين 12 سبتمبر و15 أكتوبر؛ لا تتجاوزه أي صفقة، ويعاد تسخين المؤشرات بعده. لذلك لا يمثل التقرير «سنة كاملة بلا فجوات» ولا سعراً تنفيذياً لدى وسيط.

| القاعدة | مؤهلة للترشيح؟ | صفقات H2 المرصودة | صافي H2 (R) | معامل الربح H2 | أقصى سحب H2 (R) |
| --- | --- | ---: | ---: | ---: | ---: |
| 1h:donchian_adx | مرشح | 76 | 16.26 | 1.57 | 5.05 |
| 1h:rsi_bollinger | مرشح | 74 | 15.06 | 1.48 | 6.92 |
| 4h:keltner_breakout | مرشح | 21 | 6.9 | 1.92 | 4.15 |
| 1h:ema_pullback | غير مؤهل | 103 | 7.95 | 1.15 | 8.69 |
| 4h:donchian_breakout | غير مؤهل | 19 | 6.24 | 1.99 | 2.24 |
| 4h:donchian_adx | غير مؤهل | 16 | 5.62 | 2.07 | 2.63 |
| 1h:donchian_breakout | غير مؤهل | 97 | 5.27 | 1.12 | 8.31 |
| 1h:ob_fvg | غير مؤهل | 10 | 4.92 | 2.18 | 2.0 |
| 1h:nr7_trend_breakout | غير مؤهل | 76 | 4.68 | 1.13 | 7.54 |
| 4h:ob_fvg | غير مؤهل | 4 | 3.85 | 4.85 | 0.0 |
| 1h:ema_adx_pullback | غير مؤهل | 50 | 3.65 | 1.15 | 4.89 |
| 1h:rsi2_ema200 | غير مؤهل | 146 | 3.55 | 1.05 | 11.29 |
| 4h:squeeze_breakout | غير مؤهل | 5 | 2.0 | 2.0 | 1.0 |
| 4h:rsi2_ema200 | غير مؤهل | 28 | 1.98 | 1.13 | 3.0 |
| 4h:ema_pullback | غير مؤهل | 15 | 0.05 | 1.01 | 3.0 |
| 1h:squeeze_breakout | غير مؤهل | 25 | -2.03 | 0.86 | 6.0 |
| 4h:ema_adx_pullback | غير مؤهل | 7 | -2.52 | 0.4 | 3.18 |
| 1h:keltner_breakout | غير مؤهل | 110 | -3.35 | 0.94 | 12.16 |
| 4h:rsi_bollinger | غير مؤهل | 16 | -4.49 | 0.54 | 7.19 |
| 4h:nr7_trend_breakout | غير مؤهل | 10 | -7.0 | 0.22 | 6.0 |

## قاعدة الترشيح

لا يرشح أي نظام للإضافة إلا إذا جمع 20 صفقة H2 على الأقل، وصافي R موجباً بعد حساسية تكلفة 0.10R لكل صفقة، ومعامل ربح لا يقل عن 1.10. هذه بوابة متانة وليست دليلاً على الربحية المستقبلية أو ملاءمة وسيط معين.

## القيود

يستعمل الاختبار OHLC وحجم Tick مرجعيين. لا يدخل Bid/Ask أو العمولة أو الانزلاق أو Order Flow أو أحداث الأخبار الفعلية. الأداء التاريخي لا يضمن الأداء المستقبلي.

[1]: https://www.aqr.com/Insights/Research/Journal-Article/A-Century-of-Evidence-on-Trend-Following-Investing "AQR — A Century of Evidence on Trend-Following Investing"
[2]: https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/bollinger-bands "Fidelity — Bollinger Bands"
[3]: https://academy.ftmo.com/lesson/keltner-channels-technical-indicator/ "FTMO Academy — Keltner Channels"
