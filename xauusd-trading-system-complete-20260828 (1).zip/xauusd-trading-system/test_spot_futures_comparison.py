from __future__ import annotations

from unittest.mock import patch

import pandas as pd

from mt5_price_connector import MT5PriceConnector


def _frame() -> pd.DataFrame:
    index = pd.date_range("2026-08-20 00:00", periods=8, freq="12h", tz="UTC")
    return pd.DataFrame({"Open": [3300, 3310, 3320, 3330, 3340, 3350, 3360, 3370], "High": [3310, 3320, 3330, 3340, 3350, 3360, 3370, 3380], "Low": [3290, 3300, 3310, 3320, 3330, 3340, 3350, 3360], "Close": [3305, 3315, 3325, 3335, 3345, 3355, 3365, 3375], "Volume": [1] * 8}, index=index)


def main() -> None:
    frames = {"GC=F": _frame().assign(Open=lambda x: x.Open + 8, High=lambda x: x.High + 8, Low=lambda x: x.Low + 8, Close=lambda x: x.Close + 8)}
    market = {"last_price": 3370.0, "utc_time": "2026-08-20 12:00:00 UTC"}
    requested: list[str] = []
    with patch("mt5_price_connector.yf.Ticker") as ticker, patch.object(MT5PriceConnector, "_fetch_gold_api_reference", return_value=market):
        def make_ticker(symbol: str):
            requested.append(symbol)
            return type("Ticker", (), {"history": lambda self, **kwargs: frames[symbol]})()
        ticker.side_effect = make_ticker
        result = MT5PriceConnector().fetch_spot_futures_comparison()
    assert result["status"] == "success"
    assert requested == ["GC=F"]
    assert "XAUUSD=X" not in requested
    assert result["spot"]["symbol"] == "XAU/USD"
    assert result["spot"]["days"] == []
    assert len(result["futures"]["days"]) == 2
    assert result["synchronized"]["timestamp_utc"] is None
    assert result["synchronized"]["basis"] == 13.0
    assert result["recommendation"]["signal"] == "محايد / انتظار"
    assert result["execution_price_available"] is False
    print("نجح اختبار عقد مقارنة الفوري والآجل دون طلب XAUUSD=X أو ادعاء توقيت مشترك.")


if __name__ == "__main__":
    main()

