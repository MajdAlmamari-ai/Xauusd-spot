"""يفحص المتغيرات القريبة للمرشحين، ولا يسمح لنتيجة نقطة معلمة وحيدة بالترقية."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from run_strategy_expansion_2026_4h import MIN_TRADES, add_indicators, load, metrics, signals, simulate, split_segments


OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_robustness_2026_4h_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_robustness_2026_4h_report.md")


def signal_variant(frame: pd.DataFrame, key: str) -> pd.Series:
    up, down = frame.EMA20 > frame.EMA50, frame.EMA20 < frame.EMA50
    prior = frame.shift(1)
    if key == "supertrend_base":
        return signals(frame, "supertrend_pullback")
    if key == "supertrend_rsi_tight":
        long = up & (frame.Close > frame.SUPERTREND) & (frame.Close <= frame.EMA20) & frame.RSI14.between(48, 58)
        short = down & (frame.Close < frame.SUPERTREND) & (frame.Close >= frame.EMA20) & frame.RSI14.between(42, 52)
    elif key == "supertrend_adx":
        long = up & (frame.Close > frame.SUPERTREND) & (frame.Close <= frame.EMA20) & (frame.ADX >= 20)
        short = down & (frame.Close < frame.SUPERTREND) & (frame.Close >= frame.EMA20) & (frame.ADX >= 20)
    elif key == "nr7_base":
        return signals(frame, "nr7_trend_breakout")
    elif key == "nr7_adx25":
        long, short = prior.NR7 & (frame.Close > prior.High) & up & (frame.ADX >= 25), prior.NR7 & (frame.Close < prior.Low) & down & (frame.ADX >= 25)
    elif key == "nr5_adx20":
        nr5 = frame.RANGE.eq(frame.RANGE.rolling(5, min_periods=5).min())
        long, short = nr5.shift(1) & (frame.Close > prior.High) & up & (frame.ADX >= 20), nr5.shift(1) & (frame.Close < prior.Low) & down & (frame.ADX >= 20)
    elif key == "rsi2_base":
        return signals(frame, "rsi2_ema200")
    elif key == "rsi2_5_95":
        long, short = (frame.Close > frame.EMA200) & (frame.RSI2 < 5), (frame.Close < frame.EMA200) & (frame.RSI2 > 95)
    elif key == "rsi2_15_85":
        long, short = (frame.Close > frame.EMA200) & (frame.RSI2 < 15), (frame.Close < frame.EMA200) & (frame.RSI2 > 85)
    elif key == "keltner_base":
        return signals(frame, "keltner_breakout")
    elif key == "keltner_2atr":
        upper, lower = frame.EMA20 + 2.0 * frame.ATR, frame.EMA20 - 2.0 * frame.ATR
        long, short = (frame.Close > upper) & up, (frame.Close < lower) & down
    elif key == "keltner_adx22":
        long, short = (frame.Close > frame.KC_UPPER) & up & (frame.ADX >= 22), (frame.Close < frame.KC_LOWER) & down & (frame.ADX >= 22)
    else:
        raise ValueError(key)
    return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=frame.index)


def oos_pass(metric: dict) -> bool:
    return bool(metric["filled_trades"] >= MIN_TRADES and metric["cost_sensitivity_r"]["0.10_per_trade"] > 0 and (metric["profit_factor"] or 0) >= 1.10)


def development_support(metric: dict) -> bool:
    """عتبة منخفضة معلنة لأن الإحماء يترك H1 قصيراً في نافذة 2026 الجزئية."""
    return bool(metric["filled_trades"] >= 3 and metric["cost_sensitivity_r"]["0.10_per_trade"] > 0 and (metric["profit_factor"] or 0) >= 1.0)


def score(frame: pd.DataFrame, key: str, stop_atr: float, target_r: float) -> dict:
    signal = signal_variant(frame, key)
    split = int(len(frame) * 0.40)
    h1 = metrics([simulate(frame, signal, stop_atr, target_r, 0, split)])
    h2 = metrics([simulate(frame, signal, stop_atr, target_r, split + 1, len(frame) - 1)])
    return {"h1_development": h1, "h2_observed_oos": h2, "h1_support": development_support(h1), "h2_pass": oos_pass(h2)}


FAMILIES = {
    "supertrend_pullback": {"stop_atr": 1.5, "target_r": 2.0, "variants": ("supertrend_base", "supertrend_rsi_tight", "supertrend_adx")},
    "nr7_trend_breakout": {"stop_atr": 1.5, "target_r": 2.0, "variants": ("nr7_base", "nr7_adx25", "nr5_adx20")},
    "rsi2_ema200": {"stop_atr": 1.25, "target_r": 1.5, "variants": ("rsi2_base", "rsi2_5_95", "rsi2_15_85")},
    "keltner_breakout": {"stop_atr": 1.75, "target_r": 2.0, "variants": ("keltner_base", "keltner_2atr", "keltner_adx22")},
}


def main() -> None:
    segments = [add_indicators(part) for part in split_segments(load())]
    if len(segments) != 1:
        raise RuntimeError("تتطلب الدراسة الحالية مقطع 2026 متصلاً واحداً بعد تدقيق الفجوات.")
    frame = segments[0]
    results: dict[str, dict] = {}
    for family, spec in FAMILIES.items():
        variants = {key: score(frame, key, spec["stop_atr"], spec["target_r"]) for key in spec["variants"]}
        oos_count = sum(row["h2_pass"] for row in variants.values())
        h1_count = sum(row["h1_support"] for row in variants.values())
        results[family] = {"variants": variants, "oos_passing_variant_count": oos_count, "development_supported_variant_count": h1_count, "stable_for_watchlist": bool(oos_count >= 2 and h1_count >= 1), "live_decision_integration": False}
    OUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = []
    for family, group in results.items():
        for key, record in group["variants"].items():
            h1, h2 = record["h1_development"], record["h2_observed_oos"]
            rows.append(f"| {family} | {key} | {h1['filled_trades']} | {h1['cost_sensitivity_r']['0.10_per_trade']} | {h2['filled_trades']} | {h2['cost_sensitivity_r']['0.10_per_trade']} | {h2['profit_factor']} | {'نعم' if record['h2_pass'] else 'لا'} |")
    OUT_MD.write_text(f"""# فحص متانة مرشحي XAUUSD — 2026، أربع ساعات

يفحص هذا التقرير ثلاثة متغيرات محددة مسبقاً لكل مرشح. تتطلب بوابة H2 12 صفقة على الأقل وصافي R موجباً بعد حساسية 0.10R ومعامل ربح 1.10. وبسبب أن H1 يبدأ بعد إحماء 220 شمعة ضمن نافذة 2026 الجزئية، لا يعد دعماً إلا بحد أدنى ثلاثة صفقات موجبة بعد التكلفة ومعامل ربح 1.00؛ هذه عتبة مساندة وليست دليلاً مستقلاً على المتانة.

| العائلة | المتغير | صفقات H1 | H1 بعد 0.10R | صفقات H2 | H2 بعد 0.10R | PF H2 | يجتاز H2؟ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
{"\n".join(rows)}

لا يسمح أي صف هنا بإضافة وزن لبطاقة القرار الحي. تتطلب الترقية على الأقل متغيرين ناجحين في H2 ودعماً في H1، ثم تحققاً مستقلاً أطول بتكاليف وسيط حقيقية.
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for family, group in results.items():
        print(family, {key: group[key] for key in ("oos_passing_variant_count", "development_supported_variant_count", "stable_for_watchlist")})


if __name__ == "__main__":
    main()
