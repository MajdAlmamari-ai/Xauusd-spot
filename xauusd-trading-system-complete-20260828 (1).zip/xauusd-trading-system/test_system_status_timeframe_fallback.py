from copy import deepcopy

import production_server as app_module


def main() -> None:
    original_state = deepcopy(app_module.state)
    original_cache = deepcopy(app_module.timeframe_cache)
    try:
        with app_module.state_lock:
            app_module.state["timeframes"] = []
            app_module.state["technical"] = None
        with app_module.timeframe_cache_lock:
            app_module.timeframe_cache.clear()
            app_module.timeframe_cache["1d"] = {
                "cached_at_epoch": 1.0,
                "payload": {
                    "id": "1d",
                    "label": "يومي",
                    "technical": None,
                    "error": None,
                },
            }
        client = app_module.app.test_client()
        response = client.get("/api/system-status")
        assert response.status_code == 200
        payload = response.get_json()
        cards = payload["timeframes"]
        assert len(cards) == len(app_module.TIMEFRAME_IDS)
        assert payload["default_timeframe_id"] == "1d"
        assert any(card["id"] == "4h" and card["label"] == "4 ساعات" for card in cards)
        assert any(card["id"] == "15m" for card in cards)
        print("PASS: system status returns every timeframe, including 4h, before background analysis completes")
    finally:
        with app_module.state_lock:
            app_module.state.clear()
            app_module.state.update(original_state)
        with app_module.timeframe_cache_lock:
            app_module.timeframe_cache.clear()
            app_module.timeframe_cache.update(original_cache)


if __name__ == "__main__":
    main()
