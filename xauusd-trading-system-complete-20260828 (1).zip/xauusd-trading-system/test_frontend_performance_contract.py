"""حارس عقد الأداء للواجهة المضمنة؛ يتحقق من الحواجز لا من سرعة شبكة خارجية متغيرة."""

from production_server import app


def main() -> None:
    client = app.test_client()
    page = client.get("/").get_data(as_text=True)
    assert "new EventSource('/api/quote-stream')" in page
    assert "Date.now()-statusCache.at<15000" in page
    assert "xauusd-chart-preferences-v2" in page
    assert "navigator.serviceWorker.register('/sw.js')" in page
    worker = client.get("/sw.js").get_data(as_text=True)
    assert "url.pathname.startsWith('/api/')" in worker
    assert "caches.open(CACHE_NAME)" in worker
    quote = client.get("/api/quote").get_json()
    assert quote["refresh_policy"]["minimum_refresh_seconds"] == 30
    print("PASS: frontend uses SSE, a 15-second status cache, saved chart preferences, and API-excluding static cache")


if __name__ == "__main__":
    main()
