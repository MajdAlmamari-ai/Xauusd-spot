"""استراتيجية تحليلية مركبة بين Order Block وFair Value Gap واختبارها التاريخي.

لا تتصل هذه الوحدة بوسيط ولا تنفذ أوامر. تعتمد فقط على شموع OHLC المكتملة.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from technical_indicators import calculate_snapshot
from reproducible_backtest import CostModel


def _number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _direction_from_bias(bias: str) -> str:
    return "شراء" if bias == "صاعد" else "بيع" if bias == "هابط" else "محايد"


def unavailable_setup(reason: str, *, status: str = "غير مؤهلة") -> dict[str, Any]:
    return {
        "status": status,
        "qualified": False,
        "direction": "محايد",
        "entry_zone": None,
        "entry": None,
        "stop_loss": None,
        "take_profit": None,
        "risk_reward": None,
        "confidence": 0.0,
        "reason": reason,
        "evidence": [],
        "warnings": ["لا يفتح هذا المحرك أمراً ولا يحول شموع OHLC إلى Order Flow."],
        "data_basis": "شموع OHLC مكتملة فقط",
        "historical_strength": {
            "available": False,
            "test_count": None,
            "score": None,
            "label": "غير متاح",
            "basis": "لا توجد منطقة Order Block متداخلة مكتملة لعد الاختبارات التاريخية.",
        },
    }


def historical_zone_strength(touches: Any) -> dict[str, Any]:
    """يصف حداثة منطقة Order Block بحسب الزيارات اللاحقة لنطاقها.

    تتناقص الدرجة مع إعادة اختبار النطاق؛ فالمنطقة البكر ليست "أفضل صفقة"، بل
    منطقة لم تُستنزف بزيارات لاحقة ضمن بيانات OHLC المتاحة. لا تستخدم هذه
    الدرجة لرفع احتمال نجاح أو توليد أمر تداول.
    """
    try:
        test_count = max(0, int(touches))
    except (TypeError, ValueError):
        test_count = 0
    if test_count == 0:
        score, label = 100, "بكر — بلا اختبار لاحق"
    elif test_count == 1:
        score, label = 72, "اختبار تاريخي واحد"
    elif test_count == 2:
        score, label = 48, "اختباران تاريخيان"
    else:
        score, label = max(12, 48 - (test_count - 2) * 12), "اختبارات متكررة — منطقة مستهلكة نسبياً"
    return {
        "available": True,
        "test_count": test_count,
        "score": score,
        "label": label,
        "basis": "عدد الشموع اللاحقة التي لامست نطاق Order Block بعد BOS من شموع OHLC المكتملة.",
        "interpretation": "زيادة الاختبارات تخفّض حداثة المنطقة؛ لا تقيس الدرجة نجاح الارتداد ولا احتمال ربح.",
    }


def _filter_description(filter_mode: str) -> str:
    descriptions = {
        "none": "بدون مرشح إضافي",
        "rsi": "RSI(14): شراء بين 50 و70 أو بيع بين 30 و50.",
        "ma": "اتجاه EMA20/EMA50: السعر والمتوسطان في اتجاه الإعداد.",
        "rsi_ma": "RSI الاتجاهي + توافق السعر مع EMA20 وEMA50.",
    }
    if filter_mode not in descriptions:
        raise ValueError(f"مرشح اختبار غير مدعوم: {filter_mode}")
    return descriptions[filter_mode]


def _ema_value(snapshot: dict[str, Any], period: int) -> float | None:
    for row in snapshot.get("moving_averages", []):
        if row.get("name") == f"MA{period}" and row.get("exponential") is not None:
            return _number(row["exponential"])
    return None


def filter_ob_fvg_setup(setup: dict[str, Any], snapshot: dict[str, Any], filter_mode: str) -> tuple[bool, str]:
    """يطبق المرشح على لقطة نقطة القرار فقط، ولا يقرأ أي شمعة لاحقة."""
    description = _filter_description(filter_mode)
    if filter_mode == "none":
        return True, description
    direction = setup.get("direction")
    rsi_value = _number(snapshot.get("rsi"), 50.0)
    latest = _number(snapshot.get("latest"))
    ema20, ema50 = _ema_value(snapshot, 20), _ema_value(snapshot, 50)
    rsi_pass = (
        (direction == "شراء" and 50.0 <= rsi_value < 70.0)
        or (direction == "بيع" and 30.0 < rsi_value <= 50.0)
    )
    ma_pass = (
        (direction == "شراء" and ema20 is not None and ema50 is not None and latest > ema20 > ema50)
        or (direction == "بيع" and ema20 is not None and ema50 is not None and latest < ema20 < ema50)
    )
    if filter_mode == "rsi":
        return rsi_pass, description
    if filter_mode == "ma":
        return ma_pass, description
    return rsi_pass and ma_pass, description


def build_ob_fvg_setup(frame: pd.DataFrame, snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    """يستخرج منطقة دخول شرطية من تقاطع OB حديث وFVG مؤهل في الاتجاه نفسه.

    لا يعلن الإعداد مؤهلاً إلا إذا كان التقاطع غير صفري، والمنطقة بكر، والإشارة
    الفنية وتوافق البنية في اتجاه المنطقة. مستوى الدخول هو منتصف منطقة التقاطع؛
    والإبطال خارج أبعد حد للمنطقتين مع هامش ATR.
    """

    if frame is None or len(frame) < 60:
        return unavailable_setup("الشموع غير كافية لتأكيد Order Block وFVG مع ATR.", status="بيانات غير كافية")
    snapshot = snapshot or calculate_snapshot(frame)
    advanced = snapshot.get("advanced_tools", {})
    tools = advanced.get("tools", {})
    fvg = tools.get("fair_value_gap", {})
    blocks = tools.get("order_blocks", {})
    atr_value = _number(snapshot.get("atr"))
    latest = _number(snapshot.get("latest"))
    fvg_bias = str(fvg.get("bias", "محايد"))
    if not fvg.get("qualified") or fvg_bias not in {"صاعد", "هابط"}:
        return unavailable_setup("لا توجد Fair Value Gap مؤهلة في اتجاه واضح؛ لا تُصنع منطقة من فجوة ضعيفة أو محايدة.")
    if not blocks.get("qualified"):
        return unavailable_setup("لا توجد Order Block مؤهلة وبكر؛ لا تُصنع منطقة من كتلة ضعيفة أو ملغاة.")
    levels = fvg.get("levels", {})
    fvg_lower, fvg_upper = _number(levels.get("الحد الأدنى")), _number(levels.get("الحد الأعلى"))
    if fvg_upper <= fvg_lower or atr_value <= 0:
        return unavailable_setup("حدود FVG أو ATR غير صالحة لاشتقاق الإبطال.")

    candidates: list[dict[str, Any]] = []
    for block in blocks.get("zones", []):
        if not (block.get("qualified") and block.get("fresh") and block.get("bias") == fvg_bias):
            continue
        block_lower, block_upper = _number(block.get("lower")), _number(block.get("upper"))
        lower, upper = max(block_lower, fvg_lower), min(block_upper, fvg_upper)
        overlap = upper - lower
        if overlap < 0.05 * atr_value:
            continue
        candidates.append({
            "block": block,
            "lower": lower,
            "upper": upper,
            "overlap_atr": overlap / atr_value,
            "quality": (_number(block.get("quality_score")) + _number(fvg.get("quality_score"))) / 2,
        })
    if not candidates:
        return unavailable_setup("لا يوجد تداخل سعري كافٍ بين Order Block حديث وFVG مؤهلة في الاتجاه نفسه.")

    candidate = max(candidates, key=lambda row: (row["quality"], row["overlap_atr"], row["block"].get("start_time", 0)))
    direction = _direction_from_bias(fvg_bias)
    technical_signal = str(snapshot.get("technical_signal", "متعادلة"))
    confluence_bias = str(advanced.get("confluence", {}).get("bias", "توافق محدود / مختلط"))
    structural_alignment = (fvg_bias == "صاعد" and confluence_bias == "توافق صاعد") or (fvg_bias == "هابط" and confluence_bias == "توافق هابط")
    technical_alignment = technical_signal == direction
    entry = (candidate["lower"] + candidate["upper"]) / 2
    outer_lower = min(_number(candidate["block"].get("lower")), fvg_lower)
    outer_upper = max(_number(candidate["block"].get("upper")), fvg_upper)
    buffer = 0.25 * atr_value
    if direction == "شراء":
        stop, target = outer_lower - buffer, entry + 2.0 * (entry - (outer_lower - buffer))
        activation = "جاهزة داخل منطقة الدخول" if candidate["lower"] <= latest <= candidate["upper"] else "معلّقة حتى عودة السعر إلى منطقة الدخول"
    else:
        stop, target = outer_upper + buffer, entry - 2.0 * ((outer_upper + buffer) - entry)
        activation = "جاهزة داخل منطقة الدخول" if candidate["lower"] <= latest <= candidate["upper"] else "معلّقة حتى عودة السعر إلى منطقة الدخول"
    risk = abs(entry - stop)
    reward = abs(target - entry)
    if risk <= 0 or reward <= 0:
        return unavailable_setup("فشل اشتقاق وقف الإبطال أو الهدف من نطاق المنطقة وATR.")
    qualified = technical_alignment and structural_alignment
    confidence = min(88.0, 25.0 + candidate["quality"] * 0.55 + (7.0 if technical_alignment else 0.0) + (8.0 if structural_alignment else 0.0)) if qualified else 0.0
    evidence = [
        f"FVG {fvg_bias} مؤهلة بدرجة {_number(fvg.get('quality_score')):.0f}/100.",
        f"Order Block {fvg_bias} بكر ومؤهل بدرجة {_number(candidate['block'].get('quality_score')):.0f}/100.",
        f"تداخل المنطقة: {candidate['overlap_atr']:.2f} ATR.",
        f"الإشارة الفنية: {technical_signal} · توافق البنية: {confluence_bias}.",
    ]
    warnings = [
        "الدخول مشروط بملامسة منطقة التقاطع؛ لا يُطارد السعر بعيداً عنها.",
        "وقف الخسارة هو مستوى إبطال تحليلي خارج حدود المنطقة، وليس سعراً تنفيذياً مضموناً.",
        "لا يشمل النموذج السبريد أو الانزلاق أو فروق تسعير الوسيط.",
    ]
    if not qualified:
        warnings.append("تعارض الاتجاه الفني أو توافق البنية مع المنطقة؛ النتيجة انتظار حتى يتوافق الشرطان.")
    historical_strength = historical_zone_strength(candidate["block"].get("touches"))
    return {
        "status": "منطقة مؤهلة" if qualified else "منطقة مرصودة غير مؤهلة",
        "qualified": qualified,
        "direction": direction,
        "activation": activation,
        "entry_zone": {"lower": round(candidate["lower"], 2), "upper": round(candidate["upper"], 2)},
        "entry": round(entry, 2),
        "stop_loss": round(stop, 2),
        "take_profit": round(target, 2),
        "risk_reward": round(reward / risk, 2),
        "confidence": round(confidence, 1),
        "reason": "تقاطع Order Block بكر وFVG مؤهلة في اتجاه واحد، مع إبطال خارج المنطقة وهامش ATR.",
        "evidence": evidence,
        "warnings": warnings,
        "order_block": candidate["block"],
        "fair_value_gap": {"lower": round(fvg_lower, 2), "upper": round(fvg_upper, 2), "formed_at": fvg.get("formed_at"), "quality_score": fvg.get("quality_score")},
        "historical_strength": historical_strength,
        "data_basis": "شموع OHLC مكتملة + ATR + pivots + حجم شموع عند توفره؛ ليس DOM أو Time & Sales",
    }


def backtest_ob_fvg_strategy(
    frame: pd.DataFrame,
    *,
    warmup_bars: int = 180,
    horizon_bars: int = 12,
    censor_gap_bars: int = 1,
    evaluation_stride: int = 5,
    max_evaluation_points: int = 24,
    signal_lookback_bars: int = 600,
    trade_output_limit: int | None = 12,
    filter_mode: str = "none",
    costs: CostModel = CostModel(),
) -> dict[str, Any]:
    """اختبار walk-forward للاستراتيجية مع فجوة رقابة وفصل صارم للمستقبل.

    قرار كل نقطة يعتمد على `frame.iloc[:decision_index + 1]` فقط. يبدأ فحص
    ملامسة الدخول بعد `censor_gap_bars` ويستعمل High/Low اللاحقين فقط. إذا مس
    الشريط نفسه الوقف والهدف، يُسجّل كخسارة محافظة لأن ترتيب الحركة داخل الشمعة
    مجهول.
    """

    if frame is None or len(frame) < warmup_bars + horizon_bars + censor_gap_bars + 1:
        return {
            "status": "بيانات غير كافية",
            "message": "لا توجد شموع كافية بعد نافذة الإحماء وأفق التقييم لإجراء اختبار تاريخي منضبط.",
            "metrics": {},
            "trades": [],
            "methodology": {"warmup_bars": warmup_bars, "horizon_bars": horizon_bars, "censor_gap_bars": censor_gap_bars},
        }
    frame = frame.copy().dropna(subset=["Open", "High", "Low", "Close"])
    _filter_description(filter_mode)
    candidates, filtered_out, filled, outcomes = 0, 0, 0, []
    samples: list[dict[str, Any]] = []
    cooldown_until = warmup_bars
    last_decision = len(frame) - horizon_bars - censor_gap_bars
    available_decisions = max(0, last_decision - warmup_bars)
    max_evaluation_points = max(1, int(max_evaluation_points))
    dynamic_stride = (available_decisions + max_evaluation_points - 1) // max_evaluation_points
    evaluation_stride = max(1, int(evaluation_stride), dynamic_stride)
    decision_indices = range(warmup_bars, last_decision, evaluation_stride)
    for decision_index in decision_indices:
        if decision_index < cooldown_until:
            continue
        signal_lookback_bars = max(warmup_bars, int(signal_lookback_bars))
        available_start = max(0, decision_index + 1 - signal_lookback_bars)
        available = frame.iloc[available_start:decision_index + 1].copy()
        snapshot = calculate_snapshot(available)
        setup = build_ob_fvg_setup(available, snapshot)
        if not setup.get("qualified"):
            continue
        candidates += 1
        passed_filter, _ = filter_ob_fvg_setup(setup, snapshot, filter_mode)
        if not passed_filter:
            filtered_out += 1
            continue
        start = decision_index + censor_gap_bars
        end = min(len(frame) - 1, start + horizon_bars - 1)
        entry_index = None
        zone = setup["entry_zone"]
        for index in range(start, end + 1):
            bar = frame.iloc[index]
            if float(bar["Low"]) <= float(zone["upper"]) and float(bar["High"]) >= float(zone["lower"]):
                entry_index = index
                break
        if entry_index is None:
            continue
        filled += 1
        entry_mid, stop, target = _number(setup["entry"]), _number(setup["stop_loss"]), _number(setup["take_profit"])
        direction = setup["direction"]
        execution_drag = costs.spread_price / 2 + costs.slippage_price_each_side
        entry = entry_mid + execution_drag if direction == "شراء" else entry_mid - execution_drag
        risk = abs(entry - stop)
        if risk <= 0:
            continue
        outcome, exit_price, exit_index = "انتهت المدة", _number(frame.iloc[end]["Close"]), end
        for index in range(entry_index, end + 1):
            high, low = _number(frame.iloc[index]["High"]), _number(frame.iloc[index]["Low"])
            if direction == "شراء":
                hit_stop, hit_target = low <= stop, high >= target
            else:
                hit_stop, hit_target = high >= stop, low <= target
            if hit_stop and hit_target:
                outcome, exit_price, exit_index = "غموض داخل الشمعة — وقف محافظ", stop, index
                break
            if hit_stop:
                outcome, exit_price, exit_index = "وقف", stop, index
                break
            if hit_target:
                outcome, exit_price, exit_index = "هدف", target, index
                break
        exit_fill = exit_price - execution_drag if direction == "شراء" else exit_price + execution_drag
        gross_r = ((exit_fill - entry) / risk) if direction == "شراء" else ((entry - exit_fill) / risk)
        net_r = gross_r - costs.commission_price_round_turn / risk
        outcomes.append(net_r)
        samples.append({
            "decision_time": str(frame.index[decision_index]),
            "entry_time": str(frame.index[entry_index]),
            "exit_time": str(frame.index[exit_index]),
            "direction": direction,
            "entry": round(entry, 2),
            "entry_mid": round(entry_mid, 2),
            "stop_loss": round(stop, 2),
            "take_profit": round(target, 2),
            "outcome": outcome,
            "exit": round(exit_fill, 2),
            "gross_r_multiple": round(gross_r, 2),
            "r_multiple": round(net_r, 2),
        })
        cooldown_until = exit_index + 1
    wins = [result for result in outcomes if result > 0]
    losses = [result for result in outcomes if result < 0]
    gross_profit, gross_loss = sum(wins), abs(sum(losses))
    profit_factor: float | None = round(gross_profit / gross_loss, 2) if gross_loss > 0 else None
    minimum_sample = 20
    sample_adequate = filled >= minimum_sample
    metrics = {
        "decision_points": len(range(warmup_bars, last_decision, evaluation_stride)),
        "eligible_setups": candidates,
        "filtered_out_setups": filtered_out,
        "post_filter_setups": candidates - filtered_out,
        "filled_trades": filled,
        "wins": len(wins),
        "losses": len(losses),
        "gross_profit_r": round(gross_profit, 2),
        "gross_loss_r": round(gross_loss, 2),
        "win_rate_pct": round(100 * len(wins) / filled, 1) if filled else None,
        "average_r": round(sum(outcomes) / filled, 2) if filled else None,
        "total_r": round(sum(outcomes), 2) if filled else None,
        "profit_factor": profit_factor,
        "sample_adequate": sample_adequate,
        "minimum_sample": minimum_sample,
    }
    return {
        "status": "مكتمل" if sample_adequate else "مكتمل — عينة غير كافية" if filled else "مكتمل — لا توجد صفقات مملوءة",
        "message": "اختبار walk-forward على شموع تاريخية: الإشارة من الماضي فقط، والتقييم يبدأ بعد فجوة رقابة. طبّق نموذج تكلفة معلناً للسبريد والانزلاق والعمولة؛ لا يمثل Bid/Ask تاريخياً من الوسيط." + (" عدد الصفقات المملوءة أقل من الحد الأدنى الإرشادي (20)، فلا يُفسر كمقياس أداء مثبت." if not sample_adequate else ""),
        "metrics": metrics,
        "trades": samples if trade_output_limit is None else samples[-max(0, int(trade_output_limit)):],
        "methodology": {
            "warmup_bars": warmup_bars,
            "horizon_bars": horizon_bars,
            "censor_gap_bars": censor_gap_bars,
            "evaluation_stride": evaluation_stride,
            "max_evaluation_points": max_evaluation_points,
            "signal_lookback_bars": signal_lookback_bars,
            "filter_mode": filter_mode,
            "filter_rule": _filter_description(filter_mode),
            "evaluation_frequency": "تباعد قرار متكيف لتقييد اختبار الواجهة إلى 24 نقطة كحد أقصى؛ لا يغير قاعدة فصل المستقبل.",
            "signal_window": "تُستخدم آخر 600 شمعة متاحة عند كل قرار لتقليل الحمل؛ لا تدخل شموع بعد القرار في الإشارة.",
            "signal_data": "الشموع حتى نقطة القرار فقط",
            "evaluation_data": "High/Low اللاحقان بعد فجوة الرقابة",
            "same_bar_policy": "يُحتسب وقفاً محافظاً إذا لُمس الهدف والوقف في الشمعة نفسها",
            "costs": costs.as_dict(),
        },
    }
