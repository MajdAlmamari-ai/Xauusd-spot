"""يشغل حراس التدقيق من الكود الحالي ويكتب سجل PASS/FAIL قابل للإرفاق."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


TESTS = (
    "test_audit_data_contracts.py",
    "test_backtest_integrity.py",
    "test_evidence_family_guard.py",
    "test_audit_scenario_and_security.py",
    "test_ai_analysis.py",
    "test_recommendation_risk_reward_gate.py",
    "test_advanced_tools.py",
    "test_advanced_quality.py",
    "test_minute_candle_integrity.py",
    "test_reference_ohlc_sanitization.py",
    "test_mt5_quote_validation.py",
    "test_real_order_flow.py",
    "test_timeframe_api.py",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    environment = {**os.environ, "PYTHONHASHSEED": "0", "TZ": "UTC"}
    results = []
    for test in TESTS:
        process = subprocess.run([sys.executable, test], cwd=root, env=environment, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
        results.append({"test": test, "result": "PASS" if process.returncode == 0 else "FAIL", "returncode": process.returncode, "output": process.stdout.strip()})
    payload = {
        "created_at_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "runtime": sys.version,
        "tests": results,
        "passed": sum(item["result"] == "PASS" for item in results),
        "failed": sum(item["result"] == "FAIL" for item in results),
        "evidence_scope": "اختبارات كود وقواعد مباشرة؛ لا تتعامل مع ملفات نتائج استراتيجية محفوظة كدليل نجاح.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.output), "passed": payload["passed"], "failed": payload["failed"]}, ensure_ascii=False))
    if payload["failed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
