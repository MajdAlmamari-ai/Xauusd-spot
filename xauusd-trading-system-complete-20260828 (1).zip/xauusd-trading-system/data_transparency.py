"""عرض شفاف لمصدر السعر والشموع دون تحويل فرق المراجع إلى إشارة تداول."""

from __future__ import annotations

from typing import Any

from analysis_contracts import decision_data_context_from_contract


def _finite_number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number else None


def build_data_transparency(quote: dict[str, Any] | None, technical: dict[str, Any] | None) -> dict[str, Any]:
    """يبني حالة واجهة تفسيرية؛ لا يغير قرار التحليل ولا ينشئ مستويات."""
    quote = dict(quote or {})
    technical = dict(technical or {})
    contract = dict(technical.get("data_contract") or {})
    quality = dict(technical.get("data_quality") or {})
    context = decision_data_context_from_contract(quote, contract, quality)
    quote_price = _finite_number(quote.get("last_price"))
    candle_close = _finite_number(technical.get("latest"))
    if context["compatible_for_price_levels"] and quote_price is not None and candle_close is not None:
        difference = quote_price - candle_close
        difference_pct = difference / candle_close * 100 if candle_close else None
        comparison = {
            "status": "diagnostic_only",
            "difference": round(difference, 4),
            "difference_pct": round(difference_pct, 4) if difference_pct is not None else None,
            "message": "فرق مرجعي بين السعر الحالي وآخر إغلاق من المصدر المتوافق؛ ليس إشارة تداول ولا سعراً تنفيذياً.",
        }
    else:
        comparison = {
            "status": "blocked",
            "difference": None,
            "difference_pct": None,
            "message": "حُجب فرق السعر: السعر والشموع مختلفان في الأداة أو أساس السعر، أو لا تجتاز البيانات بوابة الحداثة والجودة.",
        }
    candle_basis = contract.get("price_basis")
    candle_instrument = contract.get("instrument") or contract.get("source_symbol")
    if candle_basis == "futures_reference" or str(contract.get("source_symbol", "")).upper() == "GC=F":
        chart_label = "عقود آجلة مرجعية — ليست شموع XAU/USD Spot"
    elif candle_basis == "spot_reference":
        chart_label = "شموع XAU/USD Spot مرجعية"
    else:
        chart_label = "شموع مرجعية — أساس السعر يحتاج تحققاً"
    return {
        "quote": {
            "source": quote.get("source"),
            "symbol": quote.get("source_symbol") or quote.get("symbol"),
            "price_basis": quote.get("price_basis"),
            "source_timestamp": quote.get("source_timestamp") or quote.get("utc_time"),
            "age_seconds": quote.get("age_seconds"),
            "stale": bool(quote.get("stale")),
            "execution_classification": quote.get("execution_classification", "public_market_reference_not_executable"),
        },
        "candles": {
            "source": contract.get("source"),
            "symbol": contract.get("source_symbol"),
            "instrument": candle_instrument,
            "price_basis": candle_basis,
            "source_kind": contract.get("source_kind"),
            "last_candle_time": technical.get("last_candle_time"),
            "chart_label": chart_label,
        },
        "decision_guard": context,
        "price_close_diagnostic": comparison,
        "wait_explanation": context["reason"],
    }
