"""يدقق مشاهدات Myfxbook العامة ذات الأربع ساعات لعام 2026 ويحفظ نسخة تطبيع بحثية."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


SOURCE = Path("/home/ubuntu/Downloads/myfxbook_xauusd_4h_2026-03-11_to_2026-08-25.csv")
NORMALIZED = Path("/tmp/xauusd_2026_myfxbook_4h.csv")
REPORT = Path("/home/ubuntu/xauusd-trading-system/xauusd_2026_myfxbook_4h_audit.json")
EXPECTED = pd.Timedelta(hours=4)


def main() -> None:
    frame = pd.read_csv(SOURCE)
    frame["Date"] = pd.to_datetime(frame["Date"], format="%b %d, %Y %H:%M", errors="coerce", utc=True)
    frame = frame.dropna(subset=["Date"]).set_index("Date").sort_index()
    for column in ("Open", "High", "Low", "Close"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    invalid = frame[["Open", "High", "Low", "Close"]].isna().any(axis=1)
    gaps = frame.index.to_series().diff().dropna()
    material = gaps[gaps > pd.Timedelta(days=4)]
    normalized = frame.loc[~invalid, ["Open", "High", "Low", "Close"]].reset_index()
    normalized.to_csv(NORMALIZED, index=False)
    payload = {
        "source": "Myfxbook public historical-data page, XAUUSD, 4h, retrieved 2026-08-25",
        "source_file": str(SOURCE),
        "normalized_file": str(NORMALIZED),
        "rows": int(len(frame)),
        "first_timestamp_utc": str(frame.index.min()),
        "last_timestamp_utc": str(frame.index.max()),
        "duplicates": int(frame.index.duplicated().sum()),
        "invalid_ohlc": int(invalid.sum()),
        "gaps_over_nominal_4h": int((gaps > EXPECTED).sum()),
        "gaps_over_4_days": [
            {"previous_bar_utc": str(timestamp - gap), "next_bar_utc": str(timestamp), "hours": round(float(gap.total_seconds() / 3600), 2)}
            for timestamp, gap in material.sort_values(ascending=False).items()
        ],
        "handling": "لا تُملأ الفجوات؛ تعاد تهيئة المؤشرات بعد أي فجوة أكبر من أربعة أيام.",
        "execution_status": "OHLC مرجعي فقط؛ لا يحتوي Bid/Ask أو سبريد أو عمولة أو حجم صفقات موثق.",
    }
    REPORT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
