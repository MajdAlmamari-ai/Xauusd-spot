"""جسر MT5 محلي للقراءة فقط.

يشغل بجانب MetaTrader 5 على جهاز المستخدم. لا يستورد ولا يستدعي أي دالة
لإرسال الأوامر أو قراءة الحساب؛ ويعرض فقط quote وOHLC لرمز واحد محدد.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import MetaTrader5 as mt5


HOST = os.getenv("MT5_BRIDGE_HOST", "127.0.0.1")
PORT = int(os.getenv("MT5_BRIDGE_PORT", "8443"))
TOKEN = os.getenv("MT5_BRIDGE_TOKEN", "")
DEFAULT_SYMBOL = os.getenv("MT5_SYMBOL", "XAUUSD")
STALE_AFTER_SECONDS = int(os.getenv("MT5_STALE_AFTER_SECONDS", "15"))
READ_ONLY_ENDPOINTS = frozenset({"/health", "/quote", "/ohlc", "/order-flow"})

TIMEFRAMES = {
    "1m": mt5.TIMEFRAME_M1,
    "5m": mt5.TIMEFRAME_M5,
    "10m": mt5.TIMEFRAME_M10,
    "15m": mt5.TIMEFRAME_M15,
    "30m": mt5.TIMEFRAME_M30,
    "1h": mt5.TIMEFRAME_H1,
    "2h": mt5.TIMEFRAME_H2,
    "4h": mt5.TIMEFRAME_H4,
    "1d": mt5.TIMEFRAME_D1,
    "1wk": mt5.TIMEFRAME_W1,
    "1mo": mt5.TIMEFRAME_MN1,
}
BAR_COUNTS = {
    "5d": 7000,
    "60d": 15000,
    "730d": 15000,
    "2y": 600,
    "10y": 600,
    "max": 400,
}


def connect_terminal() -> None:
    if not TOKEN:
        raise RuntimeError("عيّن MT5_BRIDGE_TOKEN قبل تشغيل الجسر")
    if not mt5.initialize():
        raise RuntimeError(f"تعذر الاتصال بـ MT5: {mt5.last_error()}")


def require_symbol(symbol: str) -> None:
    if symbol != DEFAULT_SYMBOL:
        raise ValueError("هذا الجسر مقيد برمز الذهب المحدد في MT5_SYMBOL")
    if not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"الرمز غير متاح في MT5: {symbol}")


def quote(symbol: str) -> dict:
    require_symbol(symbol)
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        raise RuntimeError("لا توجد tick صالحة")
    bid = float(tick.bid)
    ask = float(tick.ask)
    last = (bid + ask) / 2 if bid and ask else float(tick.last)
    tick_time = datetime.fromtimestamp(tick.time, tz=timezone.utc)
    tick_age_seconds = max(0.0, (datetime.now(timezone.utc) - tick_time).total_seconds())
    return {
        "status": "success",
        "symbol": symbol,
        "broker": mt5.terminal_info().company if mt5.terminal_info() else "MT5",
        "bid": bid,
        "ask": ask,
        "last_price": last,
        "spread": ask - bid if bid and ask else None,
        "utc_time": tick_time.strftime("%Y-%m-%d %H:%M:%S UTC"),
        "tick_age_seconds": round(tick_age_seconds, 2),
        "stale": tick_age_seconds > STALE_AFTER_SECONDS,
    }


def ohlc(symbol: str, interval: str, period: str) -> dict:
    if interval not in TIMEFRAMES:
        raise ValueError("إطار زمني غير مدعوم")
    require_symbol(symbol)
    rates = mt5.copy_rates_from_pos(symbol, TIMEFRAMES[interval], 0, BAR_COUNTS.get(period, 1000))
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"لا توجد شموع متاحة: {mt5.last_error()}")
    return {
        "status": "success",
        "symbol": symbol,
        "interval": interval,
        "period": period,
        "bars": [{
            "time": int(rate["time"]),
            "open": float(rate["open"]),
            "high": float(rate["high"]),
            "low": float(rate["low"]),
            "close": float(rate["close"]),
            "tick_volume": int(rate["tick_volume"]),
        } for rate in rates],
    }


def order_flow(symbol: str) -> dict:
    """يعيد DOM وصفقاتاً حديثة للقراءة فقط؛ يرفض الادعاء عند غيابها."""
    require_symbol(symbol)
    quote_data = quote(symbol)
    if not mt5.market_book_add(symbol):
        raise RuntimeError("الوسيط لا يتيح Depth of Market لهذا الرمز")
    try:
        book = mt5.market_book_get(symbol)
    finally:
        mt5.market_book_release(symbol)
    if not book:
        raise RuntimeError("لم يرجع الوسيط مستويات DOM لهذا الرمز")
    buy_types = {getattr(mt5, "BOOK_TYPE_BUY", None), getattr(mt5, "BOOK_TYPE_BUY_MARKET", None)}
    sell_types = {getattr(mt5, "BOOK_TYPE_SELL", None), getattr(mt5, "BOOK_TYPE_SELL_MARKET", None)}
    dom = []
    for level in book:
        side = "bid" if level.type in buy_types else "ask" if level.type in sell_types else None
        if side and float(level.volume) > 0:
            dom.append({"side": side, "price": float(level.price), "volume": float(level.volume)})
    if len(dom) < 2:
        raise RuntimeError("مستويات DOM صالحة غير كافية")
    since = datetime.now(timezone.utc) - timedelta(seconds=30)
    ticks = mt5.copy_ticks_from(symbol, since, 1000, mt5.COPY_TICKS_TRADE)
    if ticks is None or len(ticks) == 0:
        raise RuntimeError("الوسيط لا يوفر صفقات حديثة لهذا الرمز")
    buy_flag = getattr(mt5, "TICK_FLAG_BUY", 0)
    sell_flag = getattr(mt5, "TICK_FLAG_SELL", 0)
    trades = []
    for tick in ticks:
        flags = int(tick["flags"])
        side = "buy" if buy_flag and flags & buy_flag else "sell" if sell_flag and flags & sell_flag else None
        volume = float(tick["volume_real"] or tick["volume"])
        if side and volume > 0:
            trades.append({"side": side, "volume": volume, "price": float(tick["last"]), "time": int(tick["time"])})
    if not trades:
        raise RuntimeError("الوسيط لم يصنف صفقات شراء/بيع حديثة يمكن تدقيقها")
    return {
        "status": "success",
        "symbol": symbol,
        "bid": quote_data["bid"],
        "ask": quote_data["ask"],
        "age_seconds": quote_data["tick_age_seconds"],
        "utc_time": quote_data["utc_time"],
        "dom": dom,
        "trades": trades,
        "mode": "read_only",
    }


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, body: dict) -> None:
        encoded = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self) -> None:
        if self.headers.get("Authorization") != f"Bearer {TOKEN}":
            self._send(401, {"status": "error", "message": "غير مصرح"})
            return
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        symbol = query.get("symbol", [DEFAULT_SYMBOL])[0]
        try:
            if parsed.path == "/health":
                self._send(200, {"status": "success", "mode": "read_only", "symbol": DEFAULT_SYMBOL})
            elif parsed.path == "/quote":
                self._send(200, quote(symbol))
            elif parsed.path == "/ohlc":
                self._send(200, ohlc(symbol, query.get("interval", ["1d"])[0], query.get("period", ["2y"])[0]))
            elif parsed.path == "/order-flow":
                self._send(200, order_flow(symbol))
            else:
                self._send(404, {"status": "error", "message": "المسار غير موجود"})
        except Exception as error:
            self._send(502, {"status": "error", "message": str(error)})

    def do_POST(self) -> None:
        self._send(405, {"status": "error", "message": "الجسر للقراءة فقط؛ POST غير مسموح"})

    def do_PUT(self) -> None:
        self._send(405, {"status": "error", "message": "الجسر للقراءة فقط؛ PUT غير مسموح"})

    def do_DELETE(self) -> None:
        self._send(405, {"status": "error", "message": "الجسر للقراءة فقط؛ DELETE غير مسموح"})

    def log_message(self, *_args) -> None:
        return


if __name__ == "__main__":
    connect_terminal()
    if HOST not in {"127.0.0.1", "localhost", "::1"}:
        raise RuntimeError("استخدم عنوان loopback فقط؛ وفّر HTTPS عبر نفق آمن ولا تكشف المنفذ مباشرة")
    print(f"MT5 read-only bridge listening on http://{HOST}:{PORT} for {DEFAULT_SYMBOL}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
