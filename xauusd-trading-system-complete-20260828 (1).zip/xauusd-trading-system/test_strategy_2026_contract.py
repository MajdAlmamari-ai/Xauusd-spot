import json
from pathlib import Path

from run_strategy_cross_year_check import accepts
from run_strategy_robustness_2026_4h import development_support, oos_pass


def metric(trades: int, after_cost: float, pf: float | None) -> dict:
    return {"filled_trades": trades, "profit_factor": pf, "cost_sensitivity_r": {"0.10_per_trade": after_cost}}


def main() -> None:
    assert oos_pass(metric(12, 0.01, 1.10))
    assert not oos_pass(metric(11, 2.0, 2.0))
    assert not oos_pass(metric(12, -0.01, 2.0))
    assert not oos_pass(metric(12, 2.0, 1.09))
    assert development_support(metric(3, 0.01, 1.00))
    assert not development_support(metric(2, 1.0, 2.0))
    assert accepts(metric(20, 0.01, 1.10))
    assert not accepts(metric(19, 2.0, 2.0))
    policy = json.loads(Path(__file__).with_name("strategy_candidate_policy_2026.json").read_text(encoding="utf-8"))
    assert policy["live_decision_integration"] is False
    assert policy["new_strategy_added_to_live_engine"] is False
    expansion = json.loads(Path(__file__).with_name("strategy_expansion_2026_4h_results.json").read_text(encoding="utf-8"))
    assert expansion["data_contract"]["reference_only"] is True
    assert "Bid/Ask" in expansion["data_contract"]["not_available"]
    assert expansion["results"]["supertrend_pullback"]["oos_h2_observed"]["filled_trades"] >= 12
    cross_year = json.loads(Path(__file__).with_name("strategy_cross_year_check_results.json").read_text(encoding="utf-8"))
    assert cross_year["keltner_breakout"]["cross_year_durable_variant_count"] == 1
    assert all(cross_year[name]["cross_year_durable_variant_count"] == 0 for name in ("supertrend_pullback", "nr7_trend_breakout", "rsi2_ema200"))
    print("PASS: 2026 gates, cross-year contract, and zero-weight policy prevent premature live integration")


if __name__ == "__main__":
    main()
