"""حارس واجهة: الوضع الواسع لا يعرض شبكة أطر ضخمة فوق الرسم، والأعداد الإجمالية موجودة."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SERVER = (ROOT / "production_server.py").read_text(encoding="utf-8")


def main() -> None:
    assert 'id="proTimeframeOpen"' in SERVER
    assert 'class="proTimeframeMenu"' in SERVER
    assert "proTfDropdown.open .proTimeframeMenu" in SERVER
    landscape_start = SERVER.find("@media(orientation:landscape)")
    landscape_end = SERVER.find("</style>", landscape_start)
    landscape_css = SERVER[landscape_start:landscape_end]
    assert "flex:0 0 100%" not in landscape_css
    assert 'id="maTotals"' in SERVER
    assert 'id="indicatorTotals"' in SERVER
    assert "renderSignalTotals('maTotals'" in SERVER
    assert "renderSignalTotals('indicatorTotals'" in SERVER
    assert "signalTotal buy" in SERVER and "signalTotal sell" in SERVER and "signalTotal neutral" in SERVER
    print("نجح اختبار شريط الوضع الأفقي المضغوط وعدادات شراء/بيع/حياد.")


if __name__ == "__main__":
    main()
