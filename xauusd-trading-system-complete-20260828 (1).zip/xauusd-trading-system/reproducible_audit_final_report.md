# التدقيق القابل لإعادة الإنتاج لمنصة XAUUSD

**تاريخ التشغيل:** 25 أغسطس 2026 UTC  
**نطاق الحكم:** كود المنصة الفعلي، عقود البيانات، محرك السيناريو، اختبارات السلامة، ومصفوفة اختبار تاريخية أعيد بناؤها من بيانات خام جديدة.  
**الحكم التنفيذي:** **لا توجد استراتيجية Approved.** جميع صفوف المصفوفة البالغ عددها 110 موسومة صراحةً `NOT_APPROVED`.

> لا يثبت نجاح Backtest على OHLC العامة قابلية التنفيذ على وسيط. لا تتضمن البيانات المستخدمة Bid/Ask تاريخياً للوسيط أو تكاليف متغيرة حسب الجلسة أو عمق سوق؛ لذلك تبقى أي نتيجة موجبة **Research Only** وليست توصية دخول أو اعتماداً للاستراتيجية.

## دليل التشغيل القابل لإعادة الإنتاج

أعيد تنزيل البيانات من مجموعة XAUUSD العامة المنشورة في مستودع البيانات [1] إلى مساحة نظيفة، ثم سُجلت نسخة الكتالوج، وتجزئات SHA-256 للملفات، وتجزئات الكود، وإصدار الاستراتيجية والمعلمات وبيئة التنفيذ في `audit_manifest.json`. سجل التشغيل الأخير يؤكد **13 PASS / 0 FAIL** في اختبارات مستقلة، بينما تحتوي `strategy_timeframe_matrix.json` على مصفوفة كل استراتيجية × كل إطار بكل المقاييس المطلوبة.

| عنصر الإثبات | النتيجة المسجلة | مكان الدليل |
| --- | --- | --- |
| بيئة التشغيل | `PYTHONHASHSEED=0` و`TZ=UTC`، Python 3.12.3 | `audit_manifest.json` |
| مصدر البيانات | XAUUSD OHLC عام، وليس Bid/Ask وسيط | `audit_manifest.json` |
| فترة العينة | 2025-01-01 حتى 2025-10-01 05:30 UTC، وفق توفر كل ملف | `audit_manifest.json` |
| إصدار المحرك | `audit-v1.0.0` | `audit_manifest.json` |
| تجزئات الكود | الخادم والموصل وAI وعقود البيانات ومحرك الاختبار | `audit_manifest.json` |
| حزمة الحراس | 13/13 ناجح، 0 فشل | `verification_results.json` |
| مصفوفة الأداء | 110 صفاً، وكل صف `NOT_APPROVED` | `strategy_timeframe_matrix.json` |

## ISSUE → ROOT CAUSE → FIX → TEST → RESULT

| ISSUE | ROOT CAUSE | FIX | TEST | RESULT | هل أثرت في النتائج السابقة؟ |
| --- | --- | --- | --- | --- | --- |
| خلط مستويات XAU/USD الفورية مع شموع GC=F الآجلة | كان السعر المرجعي العام وOHLC المرجعية يدخلان مسار توصية واحداً من دون عقد تطابق إلزامي | أضيف `DataContext` في `analysis_contracts.py`، ووُسمت الأسعار والشموع بالأداة وأساس السعر، ويحجب `production_server.py` و`ai_analysis.py` المستويات عند عدم التطابق | `test_audit_data_contracts.py` و`test_ai_analysis.py` | **PASS:** النتيجة `NO_TRADE` عند Spot/Futures mismatch؛ لا Entry/SL/TP | **نعم.** المستويات السابقة المتولدة من مصدرين مختلفين لا تعد قابلة للمقارنة أو التنفيذ |
| شموع 10m/2h/4h قد تكتمل جزئياً أثناء التجميع | استخدام `resample().agg()` كان يقبل سلالاً ناقصة، ومنها ذيل الجلسة أو انقطاع المصدر | `resample_complete_ohlc()` يقبل السلة فقط إذا احتوت كل مكونات المصدر بطوابع متصلة؛ يسجل عدد السلال المرفوضة | `test_audit_data_contracts.py` | **PASS:** يرفض سلة 10m أو 2h الناقصة ولا يصنع بديلًا | **نعم.** قد تؤثر شمعة جزئية في RSI/ATR/EMA والإشارات متعددة الأطر |
| درجة ثقة ظاهرية ناتجة من عد RSI/MACD/Stochastic/ROC كأنها أدلة مستقلة | كانت الإشارات المترابطة من OHLC تُجمع رقمياً ثم تُعرض كنسبة | استبدلت بعائلات أدلة: اتجاه، زخم، بنية، سياق حجم، وتدفق أوامر؛ `evidence_strength.is_probability=false` وProbability=`null` | `test_evidence_family_guard.py` و`test_audit_scenario_and_security.py` | **PASS:** لا يوجد `technical_confidence` في اللقطة الجديدة، ولا يعامل Strength كاحتمال نجاح | **نعم.** النسب السابقة ليست Probability Calibration ولا تصلح لاحتمال فوز |
| التوصية لم تكن عقد سيناريو موحداً كاملاً | مخرجات BUY/SELL/Neutral لم تحمل دائماً HTF/Regime/Structure/News/Data Quality بشكل موحد | أضيف `scenario_contract` إلزامي: `BULLISH_SCENARIO`، `BEARISH_SCENARIO`، `CONDITIONAL`، `NO_TRADE` مع الحقول المطلوبة | `test_audit_scenario_and_security.py` | **PASS:** يتحقق الاختبار من الحالات الأربع وحقول HTF Bias وRegime وStructure وLocation وTrigger وInvalidation وTargets وR:R وEvidence وData Quality وNews Risk | **نعم جزئياً.** المخرجات القديمة لا توفر أساس تدقيق كامل لكل قرار |
| Look-Ahead / Repainting / execution assumptions غير مثبتة باستقلال | الدراسات القديمة كانت متفرقة ولا تسجل دائماً أن القرار عند الإغلاق والتنفيذ في الشمعة التالية | محرك `reproducible_backtest.py`: القرار عند `close[i]`، والدخول عند `open[i+1]`، ووقف محافظ إذا لُمس الهدف والوقف في الشمعة نفسها | `test_backtest_integrity.py`، `test_advanced_quality.py`، `test_reference_ohlc_sanitization.py` | **PASS:** عزل المستقبل، pivots مؤكدة، دخول الشمعة التالية، وسياسة same-bar المحافظة | **نعم.** لا تستخدم نتائج سابقة كإثبات خلوها من الانحياز الزمني |
| Backtest بلا تكلفة تنفيذ كاملة وبلا MFE/MAE وثبات واضح | المحركات القديمة، ولاسيما OB+FVG، لم تسجل spread/slippage/commission ومقاييس الخروج الكاملة | محرك جديد يسجل PF، Expectancy، DD، MFE، MAE، زمن الاحتفاظ، نتائج صافية بعد نموذج تكلفة، IS/OOS/WF/Stability/Regime | `test_backtest_integrity.py` ثم `run_reproducible_audit_matrix.py` | **PASS للمحرك الجديد.** كل صف يظل `NOT_APPROVED`. وOB+FVG موسوم `NOT_TESTED_COST_AWARE_ENGINE_REQUIRED` | **نعم.** لا تعتمد ربحية Backtest القديمة كدليل أداء صافٍ |
| CORS مفتوح للنشر العام | `CORS(app)` بلا قائمة سماح | أصبح CORS اختيارياً عبر `ALLOWED_CORS_ORIGINS` ومحصوراً في `/api/*` عند ضبط القائمة | `test_audit_scenario_and_security.py` | **PASS:** لا يوجد `CORS(app)` مفتوح في الخادم الفعلي | **لا على النتائج الكمية؛ نعم على أمن النشر** |
| أخبار/تدفقات مؤسسية/Order Flow لا تكفي كتأكيد حي | لا توجد Actual/Forecast موثقة لحظياً ولا Bid/Ask+DOM+Time&Sales فعلياً في المسار الافتراضي | لم تدمج ضمن عائلات القرار كدليل مستقل؛ Order Flow يبقى `غير متاح` حتى تكتمل تغذية موثقة، ومخاطر الأخبار وسم منفصل | `test_advanced_tools.py` و`test_real_order_flow.py` | **PASS:** لا يتحول OHLC أو Volume Profile إلى Order Flow؛ والتدفق المعاكس الموثق يحجب القرار | **نعم إذا قُرئت النتائج القديمة كتدفق مؤسسي أو مفاجأة خبرية حية** |

## مصفوفة الاستراتيجية × الإطار

المصفوفة الكاملة المرفقة ليست وصفاً؛ هي JSON قابل للفحص. يحمل كل صف: `number_of_trades`، `win_rate_pct`، `profit_factor`، `expectancy_r`، `max_drawdown_r`، `average_mfe_r`، `average_mae_r`، `average_holding_seconds`، النتيجة الصافية بعد spread/slippage/commission، IS، OOS، Walk-forward، Parameter stability، Market-regime performance، والتصنيف النهائي.

| التصنيف النهائي | عدد الصفوف | الحكم |
| --- | ---: | --- |
| `RESEARCH_ONLY` | 5 | بعض شروط العينة وOOS/WF/الثبات اجتازت، لكن لا يوجد Bid/Ask تاريخي للوسيط أو تحقق خارجي؛ **ليست معتمدة** |
| `REJECTED` | 67 | فشل في واحد أو أكثر من OOS أو الثبات أو الأداء الكمي |
| `NOT_TESTED_INSUFFICIENT_BARS` | 30 | لا توجد شموع كافية بعد الإحماء؛ لم تُحوّل إلى صفر أو حكم اصطناعي |
| `NOT_TESTED_COST_AWARE_ENGINE_REQUIRED` | 8 | OB+FVG لا يملك بعد محركاً متكاملاً للتكلفة وMFE/MAE والثبات؛ لا تستخدم نتائج المحرك القديم |
| `APPROVED` | **0** | **صفر** |

> حتى صفوف `RESEARCH_ONLY` لا تعني «أفضل استراتيجية» أو توصية تداول. هي فقط نتائج تستحق بحثاً إضافياً تحت قيود بيانات OHLC ونموذج التكلفة المعلن.

## حالة الإطار الزمني: Native أم Resampled

يعكس الجدول التالي تكوين المنصة الحالي. الشموع المرجعية الحية هي GC=F من Yahoo Finance ما لم يُختَر جسر وسيط متوافق صراحة؛ وهذا **مرجع آجل** وليس XAUUSD Spot ولا Bid/Ask.

| الإطار المدعوم | الحالة | التكوين والتحقق |
| --- | --- | --- |
| 1m، 5m، 15m، 30m، 1h، 1d، 1wk، 1mo | `NATIVE_DATA` | شموع كما يرجعها المزود؛ يتحقق العقد من OHLC والرتيب والتكرار ويسجل الفجوات دون ملئها |
| 10m | `RESAMPLED_DATA` | من 5m؛ يتطلب كل bucket شمعتين 5m متصلتين بالضبط |
| 2h | `RESAMPLED_DATA` | من 1h؛ يتطلب كل bucket شمعتين 1h متصلتين بالضبط |
| 4h | `RESAMPLED_DATA` | من 1h؛ يتطلب كل bucket أربع شموع 1h متصلة بالضبط |

تظهر التغطية الفعلية، أول وآخر طابع، وعدد الفجوات الأطول من الفاصل المتوقع، وعدد الصفوف لكل إطار داخل `audit_manifest.json`. الفجوات تسجل كمعلومة جودة ولا تعالج ببيانات اصطناعية؛ لذلك قد تكون بعض الأطر، خصوصاً اليومية والأسبوعية والشهرية، **غير مختبرة بسبب عدم كفاية الصفوف**.

## مراجعة المكونات المطلوبة

| المكوّن | الحكم بعد التدقيق | حد الاستخدام المفروض |
| --- | --- | --- |
| XAUUSD data source وSpot vs Futures | محكوم بعقد صريح | يمنع خلط سعر Spot العام مع GC=F في Entry/SL/TP؛ عند عدم التطابق `NO_TRADE` |
| RSI، ATR، EMA، MACD، ADX | موحد في `technical_indicators.py` للمحرك الجديد | عائلات مترابطة من OHLC، لا Probability مستقلة |
| VWAP وVolume Profile | سياق حجم تقريبي | لا يمثل Volume-at-Price أو تدفق شراء/بيع فعلي |
| FVG وOrder Blocks وLiquidity Sweeps وBOS/CHOCH/MSS | بنية سعرية وصفية | لا تثبت نشاطاً مؤسسياً؛ لا اعتماد OB+FVG حتى محرك تكلفة كامل |
| Fibonacci وPivot | مستويات مشروطة | pivots مؤكدة فقط بعد شموع اليمين؛ لا Repainting مقبول |
| Market Regime وMTF | موجودان كمرشحين | محاذاة التجميع واكتمال الشموع محروسان؛ لا بديل من إطار آخر عند الفشل |
| News | News Risk فقط في المسار غير الموثق | لا يفسر كتأثير Actual–Forecast حي بلا مصدر وطابع زمني موثوقين |
| Order Flow | غير متاح افتراضياً | لا وزن إلا مع Bid/Ask + DOM + Time&Sales حديثة وموثقة |
| Backtesting وStrategies | أعيدت من بيانات خام | لا تستخدم أي نتيجة قديمة وحدها؛ المصفوفة الجديدة هي المرجع الوحيد ضمن هذا النطاق |

## ما لم يُصلح ولماذا

لا يعني هذا التدقيق أن المنصة أصبحت محرك تنفيذ. ما زالت فجوات الاعتماد المقصودة قائمة: عدم وجود Bid/Ask تاريخي من وسيط محدد، عدم وجود نموذج انزلاق متغير حسب الجلسة/السيولة، غياب سجل Actual/Forecast موثق، وعدم وجود OOS مستقل كافٍ على مزود آخر. كذلك لا يزال OB+FVG خارج المحرك الجديد للتكاليف، ولذلك وُسم «غير مختبر» بدلاً من تجميل النتيجة.

## الاستنتاج النهائي

التصحيح الذي ثبت بالاختبار هو **تضييق الادعاء** لا تصنيع ربحية: عند اختلاف السياق أو نقص الشموع أو غياب تغذية تدفق موثقة، ينتج النظام `NO_TRADE` أو `CONDITIONAL` بدلاً من مستوى دخول وهمي. مصفوفة الأداء الآن قابلة لإعادة الإنتاج، لكن نتيجتها الصحيحة حالياً هي: **0 Approved، و5 Research Only، و105 صفوف غير صالحة للاعتماد أو غير مختبرة.**

## المراجع

[1]: https://huggingface.co/datasets/ZombitX64/xauusd-gold-price-historical-data-2004-2025 "XAUUSD historical data repository used for the clean-run manifest"
