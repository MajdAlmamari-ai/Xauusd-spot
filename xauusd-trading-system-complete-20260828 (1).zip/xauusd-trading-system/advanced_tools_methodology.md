# منهجية أدوات السيولة وبنية السوق

| الأداة | النتيجة المعروضة | مصدر البيانات والحد |
|---|---|---|
| Liquidity Sweep | اختراق pivot مؤكد ثم عودة الإغلاق، مع عمق اختراق مقيس بـ ATR ورفض سعري | شموع OHLC؛ لا يثبت وجود أوامر مخفية |
| دعم ومقاومة | تجميع pivots المؤكدة المتقاربة ضمن عرض ATR، مع عدد اللمسات والحداثة | شموع OHLC؛ منطقة مراقبة وليست ضمان ارتداد أو كسر |
| Fair Value Gap | فجوة ثلاث شموع نشطة مع حجم فجوة/ATR وdisplacement للشمعة الوسطى | شموع OHLC؛ تبطل عند تجاوز الحد المقابل بالكامل |
| Anchored VWAP | VWAP من pivot مؤكد، مع مسافة عن VWAP مقيسة بـ ATR وجودة حجم الشموع | حجم شموع المصدر؛ ليس حجم صفقات عند Bid/Ask |
| Volume Profile | POC وVAL وVAH (70%) إضافة إلى HVN وLVN | توزيع تقريبي لحجم الشمعة على نطاقها السعري؛ لا يمثل Volume-at-Price الفعلي |
| Fibonacci | مستويات 23.6% و38.2% و50% و61.8% و78.6% من آخر موجة pivot مؤكدة وبمدى ATR أدنى | شموع OHLC؛ مناطق مراقبة وليست أهدافاً مضمونة |
| Order Flow | حالة التوفر فقط | يتطلب Tick-by-tick عند Bid/Ask مع DOM أو Time & Sales؛ لا يستنتج من OHLC |

## نطاق البيانات المعتمد

بناءً على قرار المستخدم، تعتمد المنصة في هذه المرحلة على شموع **OHLC** وحجم الشموع الذي يورده المصدر فقط. لذلك يبقى Order Flow معلناً «غير متاح»، ولا تُفسر مناطق السيولة أو Volume Profile أو Order Blocks على أنها دفتر أوامر أو صفقات منفذة أو نوايا جهات كبيرة. يمكن إعادة فتح مسار الربط الخارجي لاحقاً فقط عند طلب المستخدم وتوفير تغذية مرخّصة مناسبة.

## مراجع

- TradingView, *Volume Profile indicators: basic concepts* — يوضح أن Volume Profile يعرض نشاط التداول بحسب مستوى السعر، وأن بيانات الفوركس/CFD قد تكون tick volume وأن up/down لا يساوي buy/sell. https://www.tradingview.com/support/solutions/43000502040-volume-profile-indicators-basic-concepts/
- TradingView, *Anchored volume profile drawing tool* — يوضح الاعتماد على نقطة ارتكاز ومدى زمني محدد. https://www.tradingview.com/support/solutions/43000707989-anchored-volume-profile-drawing-tool/
- Flux Charts, *Fair Value Gaps (FVG) Explained* — تعريف عملي لنمط الثلاث شمعات وحدود الفجوة. https://www.fluxcharts.com/articles/fair-value-gaps-fvg-explained
- Charles Schwab, *Fibonacci Retracement and Extension Levels Explained* — نسب الارتداد كمناطق دعم/مقاومة محتملة وليست ضماناً. https://www.schwab.com/learn/story/using-fibonacci-retracement-levels-on-thinkorswim

## قواعد القبول

تعرض كل أداة **درجة قاعدة** من 100 ووسماً «مؤهل» أو «ضعيف» أو «غير متاح». ولا يدخل في التوافق إلا الميل الصادر عن أدوات مؤهلة. يضيف النظام كذلك سياق الإطار الأعلى، لكنه لا يفتح صفقة ولا يحول التوافق إلى توصية تنفيذية.
