"""حارس عقد SSE لسعر gold-api.com المرجعي؛ لا يختبر أو يدعي بيانات Tick تنفيذية."""

from production_server import app, quote_stream_event, state, state_lock


def main() -> None:
    with state_lock:
        state["quote"] = {
            "status": "success", "source": "gold-api.com XAU/USD live market reference",
            "instrument": "XAU/USD", "price_basis": "spot_reference", "last_price": 2500.0,
            "stale": False, "live_for_analysis": True, "tradable": False, "bid": None, "ask": None,
        }
        state["last_quote_refresh"] = "2026-08-25 22:10:00 UTC"
        state["quote_revision"] = 7
    payload = quote_stream_event()
    assert payload["revision"] == 7
    assert payload["quote"]["tradable"] is False
    assert payload["quote"]["bid"] is None and payload["quote"]["ask"] is None
    assert payload["refresh_policy"]["minimum_refresh_seconds"] == 30
    assert payload["refresh_policy"]["is_tick_feed"] is False
    client = app.test_client()
    response = client.get("/api/quote")
    assert response.status_code == 200
    assert response.get_json()["quote"]["source"].startswith("gold-api.com")
    stream = client.get("/api/quote-stream", buffered=False)
    first = next(stream.response).decode("utf-8")
    second = next(stream.response).decode("utf-8")
    stream.close()
    assert first.startswith("retry:")
    assert "event: quote" in second and '"revision":7' in second
    worker = client.get("/sw.js")
    assert worker.status_code == 200
    worker_text = worker.get_data(as_text=True)
    assert "url.pathname.startsWith('/api/')" in worker_text
    assert "CACHE_NAME" in worker_text
    print("PASS: gold-api SSE publishes cached reference revisions and Service Worker excludes API data")


if __name__ == "__main__":
    main()
