from __future__ import annotations

from copy import deepcopy

import production_server as server


def quote(price: float, *, stale: bool = False) -> dict:
    return {
        "status": "success",
        "source": "gold-api.com XAU/USD live market reference",
        "last_price": price,
        "stale": stale,
        "live_for_analysis": not stale,
        "tradable": False,
        "symbol": "XAUUSD",
    }


class SequenceConnector:
    def __init__(self, values: list[dict]):
        self.values = iter(values)

    def fetch_live_quote(self) -> dict:
        return deepcopy(next(self.values))


def main() -> None:
    original_connector = server.connector
    original_state = deepcopy(server.state)
    server.connector = SequenceConnector([quote(4670.00), quote(4672.50), quote(4669.75), quote(4669.75, stale=True)])
    try:
        with server.state_lock:
            server.state["quote"] = {"status": "pending", "symbol": "XAUUSD"}
            server.state["last_valid_goldapi_quote"] = None
        first = server.refresh_quote_state()
        assert first["price_direction"] == "neutral"
        assert first["tick_change"] is None

        rising = server.refresh_quote_state()
        assert rising["price_direction"] == "up"
        assert rising["previous_price"] == 4670.00
        assert rising["tick_change"] == 2.50
        assert rising["tick_change_pct"] > 0

        falling = server.refresh_quote_state()
        assert falling["price_direction"] == "down"
        assert falling["previous_price"] == 4672.50
        assert falling["tick_change"] == -2.75
        assert falling["tick_change_pct"] < 0

        stale = server.refresh_quote_state()
        assert stale["price_direction"] == "neutral"
        assert stale["tick_change"] is None
        assert stale["live_for_analysis"] is False
        print("PASS: gold-api.com price direction covers first quote, up, down, and stale states")
    finally:
        server.connector = original_connector
        with server.state_lock:
            server.state.clear()
            server.state.update(original_state)


if __name__ == "__main__":
    main()
