# تشغيل جامع XAUUSD المرجعي بصورة دائمة

## نطاق الخدمة

هذه الخدمة تجمع **السعر المرجعي العام XAU/USD من gold-api.com فقط** كل 30 ثانية كحد أدنى، وتحفظه في SQLite على الخادم. لا ترسل أوامر، ولا تتصل بحساب تداول، ولا تنتج Bid/Ask أو Spread أو Order Flow. إغلاق الصفحة أو الهاتف لا يؤثر في الجامع بعد تشغيله كخدمة.

> قاعدة الدقة: السجل هو لقطات وصلتنا من المصدر بالفعل. لا تعالج الخدمة فجوة انقطاع أو توقف سوق بإضافة صفوف سعر أو شموع اصطناعية.

| كيان التخزين | الغرض | مفتاح منع التكرار |
|---|---|---|
| `quote_observations` | لقطة السعر الخام مع وقت المصدر ووقت الاستلام والحالة | المصدر + الرمز + وقت المصدر + بصمة السعر |
| `ingestion_state` | آخر لقطة سليمة، فشل المصدر، ونقطة الاستئناف | المصدر + الرمز |
| `derived_candles` | OHLC مشتق من اللقطات الحية بعد اكتمال الفترة | المصدر + الرمز + الإطار + بداية الفترة |
| `collection_gaps` | أثر زمني لانقطاع جمع مرصود | المصدر + الرمز + طرفا الفجوة |

## متطلبات الخادم

ينبغي أن يعمل المشروع من `/opt/xauusd-trading-system` وأن يكون Python والاعتماديات في virtual environment داخل `.venv`. يبقى مسار البيانات خارج الكود في `/var/lib/xauusd-analysis` كي لا تضيع قاعدة الأرشيف عند تحديث الملفات.

```bash
sudo install -d -o ubuntu -g ubuntu -m 700 /var/lib/xauusd-analysis
sudo install -d -o root -g ubuntu -m 750 /etc/xauusd-analysis
sudo tee /etc/xauusd-analysis/collector.env >/dev/null <<'EOF'
MARKET_ARCHIVE_DB_PATH=/var/lib/xauusd-analysis/xauusd_market_archive.sqlite3
MARKET_ARCHIVE_POLL_SECONDS=30
MARKET_ARCHIVE_LOG_LEVEL=INFO
MARKET_PRICE_STALE_SECONDS=45
USE_PERSISTENT_MARKET_ARCHIVE=true
EOF
sudo chmod 640 /etc/xauusd-analysis/collector.env
sudo cp /opt/xauusd-trading-system/deploy/xauusd-market-collector.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now xauusd-market-collector.service
```

لا تحتاج خدمة الجمع إلى فتح أي منفذ شبكي؛ فهي تتصل بالمصدر خارجياً فقط. لا تضف مفتاح API أو كلمة مرور وسيط إلى هذه الخدمة.

يجب أن يستخدم **خادم Flask نفسه** ملف البيئة أعلاه أو القيم الأربع نفسها، وبالأخص `MARKET_ARCHIVE_DB_PATH` و`USE_PERSISTENT_MARKET_ARCHIVE=true`. عندها تعرض المنصة آخر لقطة كتبها الجامع، بدلاً من إرسال طلب Gold API إضافي لكل تحديث واجهة.

## فحص التشغيل والاستعادة

```bash
sudo systemctl status xauusd-market-collector.service --no-pager
sudo journalctl -u xauusd-market-collector.service -n 60 --no-pager
sudo systemctl restart xauusd-market-collector.service
```

إعداد `Restart=always` و`enable` يجعل الخدمة تعود بعد إعادة تشغيل الخادم. عند العودة، تفتح SQLite وتقرأ حالة آخر لقطة؛ لا تعيد تنزيل البيانات التاريخية ولا تمسح الأرشيف.

## تفسير الجودة

| القيمة | المعنى |
|---|---|
| `LIVE` | لقطة مرجعية حديثة وردت من المصدر وحُفظت. |
| `STALE` | لقطة وردت لكنها متأخرة؛ تحفظ للتدقيق ولا تدخل في OHLC المشتقة. |
| `ERROR` | فشل طلب المصدر؛ لا يعاد استخدام آخر سعر كسعر حي. |
| `COMPLETE` | شمعة مكتملة وفيها لقطتان حيّتان أو أكثر. |
| `COMPLETE_SPARSE` | شمعة مكتملة زمنياً لكن فيها لقطة واحدة فقط؛ لا تعتبر بديلاً عن Tick feed. |
| `PARTIAL` | الفترة ما زالت مفتوحة. |

يمكن فحص حالة الأرشيف من مسار Flask الآمن: `GET /api/market-archive-status`. تعرض الحالة المصدر والوقت وعدد اللقطات والفجوات والجودة، ولا تكشف أي أسرار.
