"""فحص بنية Tick عامة من Dukascopy لرمز XAUUSD؛ لا ينفذ أي تداول."""

from __future__ import annotations

import lzma
import struct
from pathlib import Path
from urllib.request import Request, urlopen


URL = "https://datafeed.dukascopy.com/datafeed/XAUUSD/2025/00/02/00h_ticks.bi5"
LOCAL_SAMPLE = Path("/tmp/xauusd_tick_sample.bi5")


def main() -> None:
    if LOCAL_SAMPLE.exists():
        compressed = LOCAL_SAMPLE.read_bytes()
    else:
        request = Request(URL, headers={"User-Agent": "XAUUSD-Research/1.0"})
        with urlopen(request, timeout=60) as response:
            compressed = response.read()
    assert compressed[:5] == bytes.fromhex("5d00004000"), "ترويسة LZMA غير متوقعة لملف Dukascopy"
    decoder = lzma.LZMADecompressor(
        format=lzma.FORMAT_RAW,
        filters=[{"id": lzma.FILTER_LZMA1, "dict_size": 1 << 22, "lc": 3, "lp": 0, "pb": 2}],
    )
    raw = decoder.decompress(compressed[13:])
    assert len(raw) >= 20 and len(raw) % 20 == 0, "ملف ticks لا يتطابق مع سجل Dukascopy المتوقع بطول 20 بايت"
    offset_ms, ask_raw, bid_raw, ask_volume, bid_volume = struct.unpack(
        ">IIIff", raw[:20]
    )
    print({
        "url": URL,
        "compressed_bytes": len(compressed),
        "raw_bytes": len(raw),
        "ticks": len(raw) // 20,
        "first_offset_ms": offset_ms,
        "first_ask_raw": ask_raw,
        "first_bid_raw": bid_raw,
        "first_ask_if_scale_1000": ask_raw / 1000,
        "first_bid_if_scale_1000": bid_raw / 1000,
        "first_ask_volume": ask_volume,
        "first_bid_volume": bid_volume,
    })


if __name__ == "__main__":
    main()
