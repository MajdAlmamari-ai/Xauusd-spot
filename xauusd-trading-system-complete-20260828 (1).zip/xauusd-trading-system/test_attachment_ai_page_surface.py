from __future__ import annotations

import io

import production_server
from PIL import Image


def image_file() -> io.BytesIO:
    output = io.BytesIO()
    Image.new("RGB", (640, 400), color=(10, 22, 32)).save(output, format="PNG")
    output.seek(0)
    return output


def main() -> None:
    with production_server.app.test_client() as client:
        page = client.get("/attachment-ai")
        assert page.status_code == 200
        html = page.get_data(as_text=True)
        assert "تحليل مرفق AI" in html
        assert 'data-mode="combined"' in html
        assert "/api/chart-ai-providers" in html
        provider_response = client.get("/api/chart-ai-providers")
        providers = provider_response.get_json()["providers"]
        assert {item["id"] for item in providers} == {"manus", "gemini", "claude", "deepseek", "perplexity"}
        assert all("available" in item and "status" in item for item in providers)
        combined = client.post(
            "/api/chart-image-analysis",
            data={"mode": "combined", "provider": "claude", "timeframe": "4h", "image": (image_file(), "chart.png")},
            content_type="multipart/form-data",
        )
        assert combined.status_code == 200
        payload = combined.get_json()
        assert payload["mode"] == "combined"
        assert payload["scenario"] == "NO_TRADE"
        assert payload["visual"]["status"] == "غير متاح"
    assert 'href="/attachment-ai"' in production_server.index()
    print("PASS: attachment AI screen lists provider status and combined mode rejects an unconfigured provider safely")


if __name__ == "__main__":
    main()
