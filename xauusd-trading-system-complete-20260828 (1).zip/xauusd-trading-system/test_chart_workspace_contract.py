"""حارس سطح مساحة عمل الرسم: إعدادات محلية وشفافية الشموع دون تغيير مسارات الرسم."""

from pathlib import Path


source = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")

required = (
    '"chart_data_quality": chart_data_quality',
    '"data_mode_label"',
    'id="chartWorkspaceBand"',
    'id="chartWorkspaceSettings"',
    'xauusd-chart-workspace-v1',
    'data-chart-timeframe',
    "['4h','4 ساعات']",
    'data-chart-timeframe="4h"',
    'فاصل آخر شمعتين',
    'لا تغير OHLC أو المؤشرات أو مصدر الشموع',
)

missing = [item for item in required if item not in source]
assert not missing, f"عناصر مساحة عمل الرسم مفقودة: {missing}"
assert '@app.get("/api/chart/<timeframe_id>")' in source
assert "async function loadChart" in source

print("PASS: chart workspace exposes persisted view settings and candle-quality metadata without changing chart routes")
