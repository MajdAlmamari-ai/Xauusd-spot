"""يتحقق من أن تحليل AI يميز القراءة المرجعية عن سيناريو التنفيذ."""

from ai_analysis import build_ai_analysis


def main() -> None:
    quote = {"status": "success", "source": "Gold API", "tradable": False, "live_for_analysis": True, "stale": False, "age_seconds": 12, "instrument": "XAU/USD", "price_basis": "spot_reference"}
    technical = {
        "latest": 4500.0,
        "data_contract": {"instrument": "GC=F", "price_basis": "futures_reference"},
        "data_quality": {"valid": True},
    }
    result = build_ai_analysis(quote, technical, {"pending_event": False}, {"id": "1d", "label": "يومي"})
    assert result["status"] == "محجوب"
    assert result["scenario"] == "NO_TRADE"
    assert result["entry"] is None and result["stop_loss"] is None and result["take_profit"] is None
    assert result["data_scope"]["tradable"] is False
    assert result["data_scope"]["data_context"]["compatible_for_price_levels"] is False
    assert result["risks"]
    print("نجح حارس تحليل AI: حجب مستويات السيناريو عند خلط الفوري بالآجل.")


if __name__ == "__main__":
    main()
