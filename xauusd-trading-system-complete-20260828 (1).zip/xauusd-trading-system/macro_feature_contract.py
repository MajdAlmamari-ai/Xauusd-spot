"""محاذاة ميزات اقتصادية لنماذج XAU/USD دون تسرب وقت النشر."""

from __future__ import annotations

import pandas as pd


class MacroFeatureError(ValueError):
    pass


# نسبة السعر إلى الربح تخص الأسهم ولا تمثل عاملاً أساسياً للذهب الفوري.
ALLOWED_GOLD_MACRO_SERIES = {
    "usd_index_return",
    "real_yield_change",
    "nominal_yield_change",
    "fed_funds_rate",
    "cpi_surprise",
    "nfp_surprise",
}


def align_point_in_time_macro(candles: pd.DataFrame, releases: pd.DataFrame) -> pd.DataFrame:
    """يلحق كل شمعة بآخر معلومة منشورة فعلاً فقط.

    لا يستخدم observation_date وحده، لأن القراءة الاقتصادية قد تنشر بعد فترة
    الرصد بساعات أو أيام. الحقل الإلزامي هو available_at بالـUTC.
    """
    required_candles = {"timestamp"}
    required_releases = {"available_at", "series", "value"}
    if not required_candles.issubset(candles.columns):
        raise MacroFeatureError("شموع بلا timestamp")
    if not required_releases.issubset(releases.columns):
        raise MacroFeatureError("البيانات الاقتصادية تحتاج available_at وseries وvalue")
    unknown = set(releases["series"].dropna()) - ALLOWED_GOLD_MACRO_SERIES
    if unknown:
        raise MacroFeatureError(f"سلاسل غير مسموحة للذهب الفوري: {sorted(unknown)}")

    left = candles.copy()
    left["timestamp"] = pd.to_datetime(left["timestamp"], utc=True)
    output = left.sort_values("timestamp")
    for series in sorted(ALLOWED_GOLD_MACRO_SERIES.intersection(releases["series"].unique())):
        right = releases.loc[releases["series"] == series, ["available_at", "value"]].copy()
        right["available_at"] = pd.to_datetime(right["available_at"], utc=True)
        right = right.sort_values("available_at").rename(columns={"value": f"macro_{series}"})
        output = pd.merge_asof(
            output,
            right,
            left_on="timestamp",
            right_on="available_at",
            direction="backward",
            allow_exact_matches=True,
        ).drop(columns=["available_at"])
    return output
