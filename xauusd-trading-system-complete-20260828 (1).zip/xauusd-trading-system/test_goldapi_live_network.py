from __future__ import annotations

import os

from mt5_price_connector import MT5PriceConnector


def main() -> None:
    os.environ.pop("LIVE_PRICE_SOURCE", None)
    quote = MT5PriceConnector(symbol="XAUUSD").fetch_live_quote()
    assert quote["source"] == "gold-api.com XAU/USD live market reference"
    if quote["status"] != "success":
        assert quote.get("stale") is True
        assert "تعذر الوصول" in quote.get("message", "")
        print("SKIP: gold-api.com live network is temporarily unavailable; contract tests remain separate.")
        return
    assert quote["last_price"] > 0
    assert quote["utc_time"]
    assert quote["age_seconds"] >= 0
    assert quote["tradable"] is False
    assert quote["bid"] is None and quote["ask"] is None
    print(f"PASS: gold-api.com live network price={quote['last_price']:.2f}, age={quote['age_seconds']:.1f}s, reference-only")


if __name__ == "__main__":
    main()
