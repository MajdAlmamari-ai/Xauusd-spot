"""تحقق من نتائج اختبار 2025 بعد تشغيل المشغّل المرجعي."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


RESULTS = Path(__file__).with_name("ob_fvg_2025_backtest_results.json")


def main() -> None:
    assert RESULTS.exists(), "شغّل run_ob_fvg_2025_backtest.py أولاً لتوليد نتائج 2025."
    payload = json.loads(RESULTS.read_text(encoding="utf-8"))
    assert set(payload) == {"1h", "4h"}
    for timeframe, result in payload.items():
        contract, metrics, trades = result["data_contract"], result["metrics"], result["trades"]
        assert contract["period"] == "2025-01-01 inclusive إلى 2026-01-01 exclusive"
        assert contract["timeframe"] == timeframe
        assert contract["bars"] > 365
        assert metrics["filled_trades"] == metrics["wins"] + metrics["losses"]
        assert metrics["gross_profit_r"] >= 0 and metrics["gross_loss_r"] >= 0
        assert len(trades) == metrics["filled_trades"]
        for trade in trades:
            decision = pd.Timestamp(trade["decision_time"])
            entry = pd.Timestamp(trade["entry_time"])
            exit_time = pd.Timestamp(trade["exit_time"])
            assert decision < entry <= exit_time, f"تسرب زمني في {timeframe}: {trade}"
            assert pd.Timestamp("2025-01-01", tz="UTC") <= decision < pd.Timestamp("2026-01-01", tz="UTC")
    print("نجح تحقق نتائج 2025: النطاق زمني صحيح، والمقاييس متسقة، ولا تدخل قبل القرار.")


if __name__ == "__main__":
    main()
