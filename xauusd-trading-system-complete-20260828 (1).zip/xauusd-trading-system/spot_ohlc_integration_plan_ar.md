# خطة دمج شموع XAU/USD الفورية داخل طبقة البيانات الحالية

## القرار المعماري

لا يحتاج المشروع إلى إعادة بناء الواجهة أو محرك التحليل. نقطة الاستبدال الوحيدة هي الحقل `historical_data_provider` داخل `MarketDataService` في `market_data.py`. يبقى `GoldApiLivePriceProvider` كما هو، إذ دوره **سعر سوق مرجعي حالي فقط** ولا يدّعي توفير OHLC أو Bid/Ask. يستبدل `YahooFinanceHistoricalDataProvider` بمزود جديد صريح اسمه `TwelveDataSpotHistoricalDataProvider` بعد اجتياز اختبارات القبول.

المزود المرشح هو Twelve Data لأن صفحة أداته تعرّف `XAU/USD` باسم **Gold Spot / US Dollar** وبنوع **Commodity**، وتعرض مساراً رسمياً لبياناته عبر API.[1] كما يوثق مزود البيانات أن endpoint `/time_series` يعيد metadata وOpen/High/Low/Close، ويدعم الأطر من دقيقة إلى شهر.[2]

> **قاعدة انتقال غير قابلة للتفاوض:** عند اختيار مسار Spot، لا يوجد fallback صامت إلى `GC=F`. إذا غاب المفتاح، رُفض الرمز، أو لم تجتز metadata التحقق، تكون النتيجة `TIMEFRAME DATA UNAVAILABLE` ويستمر حاجز القرار في منع مستويات XAU/USD Spot.

## عقد المزود الجديد

| البند | القيمة الإلزامية |
|---|---|
| المزود | `Twelve Data` |
| endpoint | `GET https://api.twelvedata.com/time_series` |
| الرمز المطلوب | `XAU/USD` حرفياً |
| المصادقة | ترويسة خادمية `Authorization: apikey <TWELVE_DATA_API_KEY>`؛ لا يصل المفتاح إلى JavaScript أو المتصفح.[2] |
| أساس السعر | `spot_reference` |
| الأداة الداخلية | `XAU/USD` |
| التوقيت الداخلي | UTC؛ تحفظ المنطقة الأصلية في metadata لأغراض التدقيق |
| الأعمدة النهائية | `Open`, `High`, `Low`, `Close`, `Volume` عند توفره؛ لا يُختلق حجم مفقود |
| المصدر الظاهر | `Twelve Data XAU/USD Spot OHLC` |
| الدور | `historical_data_provider` فقط |

## ترجمة الأطر الزمنية

| إطار المنصة | طلب Twelve Data | التصنيف |
|---|---|---|
| `1m`, `5m`, `15m`, `30m` | `1min`, `5min`, `15min`, `30min` | Native |
| `10m` | `5min` ثم تجميع شمعتين مكتملتين فقط | Resampled وموسوم بذلك |
| `1h`, `2h`, `4h` | `1h`, `2h`, `4h` | Native |
| `1d`, `1wk`, `1mo` | `1day`, `1week`, `1month` | Native؛ يطبع المزود الأطر غير اللحظية بتوقيت سوقه، لذا يجب تطبيع الطابع إلى UTC بعد قراءة metadata المنطقة الزمنية.[2] |

لا تُملأ أي فجوة زمنية صناعياً. وعند تجميع `10m` لا تُنشأ الشمعة إلا إذا كانت كل شموع المصدر التابعة لها موجودة ومكتملة، وفق عقد التجميع الموجود في المشروع.

## شكل التنفيذ المقترح

ينشأ صنف جديد داخل `market_data.py` فقط. يتصل خادم Python بالمزود، يفحص الاستجابة، ثم يعيد DataFrame بالعقد الحالي حتى يبقى كل من `production_server.py` والرسم والتحليل ومختبر الاستراتيجيات مستهلكين غير معدلين.

```python
@dataclass
class TwelveDataSpotHistoricalDataProvider:
    api_key: str
    name: str = "Twelve Data"

    def get_ohlc(self, *, period: str, timeframe: str) -> pd.DataFrame:
        interval = INTERVAL_MAP[timeframe]
        payload = request_time_series(
            symbol="XAU/USD",
            interval=interval,
            timezone="UTC",
            period=period,
            api_key=self.api_key,
        )
        validate_spot_metadata(payload["meta"], expected_interval=interval)
        frame = normalize_twelve_values(payload["values"])
        validate_ohlc_frame(frame)
        frame.attrs.update({
            "source": "Twelve Data XAU/USD Spot OHLC",
            "instrument": "XAU/USD",
            "price_basis": "spot_reference",
            "provider_role": "historical_data_provider",
            "timeframe_kind": "native_or_complete_resample",
        })
        return frame
```

لا يقرأ الصنف المفتاح من query string مسجّل ولا من الصفحة. يوضع المفتاح تحت الاسم `TWELVE_DATA_API_KEY` عبر إدارة الأسرار فقط. توثق Twelve Data أن المفتاح مطلوب للوصول الكامل، وأن حالات `401` و`403` و`429` يجب التعامل معها صراحةً كفشل مصادقة أو صلاحية أو حد استخدام.[2]

## بوابة قبول metadata والشموع

لا تعتمد المنصة اسم endpoint أو نجاح HTTP وحدهما. تمر الاستجابة عبر هذه البوابة:

1. يجب أن تكون `status == "ok"` وألا تحتوي الاستجابة خطأ مزود.
2. يجب أن تطابق metadata الرمز `XAU/USD`، وأن يثبت نوعها `Commodity` أو تعريف مكافئ موثق من المزود؛ لا يقبل `GC=F` أو رمزاً مستعاراً.
3. يجب أن يطابق interval metadata الإطار المطلوب أو أصل التجميع المعلن.
4. تحول timestamps إلى UTC، وتُرتّب تصاعدياً وتُرفض التكرارات وترتيب الزمن العكسي وقيم OHLC غير الصالحة.
5. تسجّل الفجوات كما وردت. لا يوجد forward fill ولا توليد شموع.
6. إذا لم تتوفر شموع كافية للمؤشرات، تعرض المنصة `TIMEFRAME DATA UNAVAILABLE` بدلاً من حساب مؤشر من عينة ناقصة.
7. قبل إنشاء مستويات، يجب أن ينجح `decision_data_context`: `instrument == XAU/USD` و`price_basis == spot_reference` لكلا السعر المرجعي والشموع. يظل السعر العام غير Bid/Ask تنفيذي.

## الترحيل الآمن

| المرحلة | التغيير | شرط الانتقال |
|---|---|---|
| 1. اختبار مصادقة | طلب 15 دقيقة محدود بالمفتاح عبر الخادم | metadata تثبت `XAU/USD` وSpot |
| 2. اختبار الأطر | طلب جميع الأطر المدعومة وتسجيل coverage والفجوات | لا شموع مصطنعة ولا فشل صامت |
| 3. تفعيل قراءة Spot | إنشاء `TwelveDataSpotHistoricalDataProvider` في `MarketDataService` | حزمة الاختبارات تمر |
| 4. تبديل الرسم والتحليل | تظل الدوال والمسارات نفسها؛ المصدر الجديد يعيد DataFrame بالعقد القديم | بطاقة المصدر تقول Spot لا Futures |
| 5. مقارنة تشخيصية | مقارنة عدد محدود من إغلاقات Spot مع قراءات Gold API متقاربة زمنياً | فرق معلن كتباين مصدر/توقيت؛ لا يشترط التطابق ولا ينتج إشارة |
| 6. إيقاف المسار الآجل | يتحول `GC=F` إلى وضع legacy منفصل أو يحجب من واجهة XAU/USD | لا مستوى Spot مبني على Futures |

## الاختبارات المطلوبة قبل التفعيل

| الاختبار | ما يثبته |
|---|---|
| `test_twelve_data_spot_provider.py` | الطلب يرسل الرمز والفاصل الصحيحين، ويطبع الأعمدة وUTC وattrs الصحيحة |
| اختبار metadata خاطئة | رفض `GC=F` أو رمز غير `XAU/USD` أو أساس Futures |
| اختبار API failure | `401` و`403` و`429` وresponse فارغ تنتج حالة عدم إتاحة، لا Yahoo fallback |
| اختبار complete resample | إطار `10m` لا يتكون إلا من شمعتين `5m` مكتملتين |
| `test_market_data_layer.py` | استمرار فصل فشل السعر الحي عن فشل OHLC؛ لا كسر للمسارات الحالية |
| `test_audit_data_contracts.py` | صحة OHLC، منع الفجوات المصطنعة، وحاجز Spot/Futures |
| `test_timeframe_api.py` | الأطر المدعومة تعود بالمصدر والتصنيف Native/Resampled الصحيحين |
| اختبار تشخيص Gold API | مقارنة close المتزامن ضمن tolerance معلن للتشخيص فقط، لا بوابة مساواة ولا مستوى تنفيذي |

## المتطلب الوحيد من المستخدم

يلزم مفتاح Twelve Data فعلي ومصرح له ببيانات `XAU/USD` commodity وواجهات الأطر المطلوبة. لا يثبت توفر الرمز في الخطة من مجرد وجود الحساب؛ لذلك يكون أول تشغيل اختبار قبول محدود بالمفتاح. بعد توفيره عبر حقل الأسرار الآمن، يمكن تنفيذ المزود واختباره ثم تحويل الرسم والتحليل من `GC=F` إلى Spot ضمن الطبقة الحالية.

## المراجع

[1]: https://twelvedata.com/markets/300755/commodity/xau-usd "Twelve Data — Gold Spot / US Dollar (XAU/USD)"
[2]: https://twelvedata.com/docs "Twelve Data API Documentation — Authentication and Time Series"
