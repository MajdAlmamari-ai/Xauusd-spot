from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from io import BytesIO
from unittest.mock import patch
from urllib.request import Request

from mt5_price_connector import MT5PriceConnector


class FakeResponse(BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


def fake_urlopen(request: Request, timeout: int = 8):
    assert timeout == 8
    assert request.full_url.startswith("https://api.gold-api.com/price/XAU/USD")
    assert request.get_header("X-access-token") is None
    payload = {
        "price": 4676.15,
        "updatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    return FakeResponse(json.dumps(payload).encode("utf-8"))


def main() -> None:
    os.environ.pop("LIVE_PRICE_SOURCE", None)
    with patch("mt5_price_connector.urlopen", side_effect=fake_urlopen):
        quote = MT5PriceConnector(symbol="XAUUSD").fetch_live_quote()
    assert quote["status"] == "success"
    assert quote["source"].startswith("gold-api.com")
    assert quote["last_price"] == 4676.15
    assert quote["reference_bid"] is None and quote["reference_ask"] is None
    assert quote["bid"] is None and quote["ask"] is None
    assert quote["tradable"] is False
    assert quote["live_for_analysis"] is True
    print("PASS: gold-api.com live quote is public and reference-only")


def test_gold_api_is_default_over_bridge() -> None:
    os.environ.pop("LIVE_PRICE_SOURCE", None)
    connector = MT5PriceConnector(symbol="XAUUSD", bridge_url="http://bridge.invalid")
    with patch("mt5_price_connector.urlopen", side_effect=fake_urlopen), patch.object(connector, "_fetch_mt5_bridge") as bridge:
        quote = connector.fetch_live_quote()
    assert quote["source"].startswith("gold-api.com")
    bridge.assert_not_called()


if __name__ == "__main__":
    main()
