#!/usr/bin/env python3
"""
محرك إدارة المخاطر وتوليد الإشارات الاحتمالية بدون ادعاء يقين
"""

class RiskEngine:
    def __init__(self, account_balance=10000.0, max_risk_pct=1.0):
        self.account_balance = account_balance
        self.max_risk_pct = max_risk_pct  # 1% مخاطرة لكل صفقة
        
    def evaluate_signal(self, current_price, rsi, macd, high_impact_news=False):
        """
        تقييم السوق وتوليد إشارة احتمالية مع تحديد وقف الخسارة وجني الأرباح بناءً على التقلب
        """
        if high_impact_news:
            return {
                "signal": "HOLD / NO TRADE",
                "confidence": 0.0,
                "reason": "قفل أمان الأخبار: توجد بيانات اقتصادية عالية التأثير قريبة؛ يمنع التداول.",
                "entry": current_price,
                "stop_loss": 0.0,
                "take_profit": 0.0,
                "risk_reward_ratio": 0.0,
                "lot_size": 0.0
            }
            
        # منطق تقييم احتمالي
        reasons = []
        buy_score = 0
        sell_score = 0
        
        if rsi < 35:
            buy_score += 2
            reasons.append(f"مؤشر RSI عند {rsi:.1f} (منطقة تشبع بيعي محتملة)")
        elif rsi > 65:
            sell_score += 2
            reasons.append(f"مؤشر RSI عند {rsi:.1f} (منطقة تشبع شرائي محتملة)")
        else:
            reasons.append(f"مؤشر RSI عند {rsi:.1f} (منطقة حيادية)")
            
        if macd > 0:
            buy_score += 1
            reasons.append("خط MACD إيجابي (زخم صعودي تدريجي)")
        else:
            sell_score += 1
            reasons.append("خط MACD سالب (زخم هبوطي تدريجي)")
            
        total_score = buy_score + sell_score
        if total_score == 0:
            confidence = 50.0
            signal = "NEUTRAL"
        elif buy_score > sell_score:
            confidence = round((buy_score / total_score) * 100, 1)
            signal = "BUY (احتمالي)"
        elif sell_score > buy_score:
            confidence = round((sell_score / total_score) * 100, 1)
            signal = "SELL (احتمالي)"
        else:
            confidence = 50.0
            signal = "NEUTRAL"
            
        # حساب إدارة المخاطر (وقف خسارة ديناميكي بناء على 12 دولار تقلب نموذجي)
        atr_buffer = 12.0
        if "BUY" in signal:
            entry = current_price
            stop_loss = round(entry - atr_buffer, 2)
            take_profit = round(entry + (atr_buffer * 2.5), 2)  # نسبة 1:2.5
        elif "SELL" in signal:
            entry = current_price
            stop_loss = round(entry + atr_buffer, 2)
            take_profit = round(entry - (atr_buffer * 2.5), 2)
        else:
            entry = current_price
            stop_loss = round(entry - 10, 2)
            take_profit = round(entry + 10, 2)
            
        risk_amount = self.account_balance * (self.max_risk_pct / 100.0)
        risk_per_unit = abs(entry - stop_loss)
        lot_size = round(risk_amount / (risk_per_unit * 100), 2) if risk_per_unit > 0 else 0.01
        
        return {
            "signal": signal,
            "confidence": confidence,
            "reasons": reasons,
            "entry": entry,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "risk_reward_ratio": "1 : 2.5",
            "suggested_lot_size": max(0.01, lot_size),
            "circuit_breaker_active": False
        }

if __name__ == "__main__":
    engine = RiskEngine()
    print(engine.evaluate_signal(4319.50, 32.5, -4.2, False))
