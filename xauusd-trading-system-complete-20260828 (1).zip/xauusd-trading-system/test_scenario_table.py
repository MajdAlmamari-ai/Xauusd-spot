from __future__ import annotations

from production_server import HTML, build_scenario_rows


def quote(*, broker: bool, stale: bool = False) -> dict:
    return {
        "status": "success",
        "stale": stale,
        "live_for_analysis": not stale,
        "broker_quote_eligible": broker,
        "last_price": 4630.0,
        "bid": 4629.8 if broker else None,
        "ask": 4630.2 if broker else None,
    }


def result(*, rr: float = 2.0) -> dict:
    return {
        "signal": "شراء مشروط",
        "decision_state": "signal",
        "entry": 4630.0,
        "stop_loss": 4620.0,
        "take_profit": 4650.0,
        "risk_reward": rr,
        "confidence": 64.0,
    }


def neutral_result() -> dict:
    return {"signal": "انتظار / حياد", "decision_state": "neutral", "reason": "لا يوجد اتجاه نهائي."}


def pivot_technical() -> dict:
    return {
        "latest": 4630.0,
        "pivots": {"traditional": {"S1": 4610.0, "S2": 4550.0, "R1": 4650.0, "R2": 4710.0}},
    }


def main() -> None:
    reference = build_scenario_rows(result(), quote(broker=False))
    assert reference["status"] == "مرجعي مؤهل"
    assert len(reference["rows"]) == 1
    assert reference["rows"][0]["source_mode"] == "شموع مرجعية + سعر سوق عام"

    qualified = build_scenario_rows(result(), quote(broker=True))
    assert qualified["status"] == "مؤهل للتقييم"
    assert len(qualified["rows"]) == 1
    assert qualified["rows"][0]["entry"] == 4630.0
    assert qualified["rows"][0]["risk_reward"] == 2.0

    weak = build_scenario_rows(result(rr=1.1), quote(broker=False))
    assert weak["status"] == "انتظار"
    assert weak["rows"] == []

    stale = build_scenario_rows(result(), quote(broker=False, stale=True))
    assert stale["status"] == "محجوب"
    assert stale["rows"] == []

    watch = build_scenario_rows(neutral_result(), quote(broker=False), pivot_technical())
    assert watch["status"] == "مراقبة مرجعية"
    assert {row["direction"] for row in watch["rows"]} == {"شراء مشروط", "بيع مشروط"}
    assert all(row["source_mode"] == "شموع مرجعية + سعر سوق عام" for row in watch["rows"])

    for fragment in (
        'id="scenarioTable"',
        'renderScenarioTable',
        'scenarioTableWrap',
        'نقطة التفعيل',
        'الإبطال / الوقف',
        'العائد/المخاطرة',
        'اسحب الجدول أفقياً',
        'السيناريوهات التحليلية المرجعية',
        'timeframeId:selectedTimeframe',
        'cached.timeframeId===selectedTimeframe',
        'xauusd:timeframe-selected',
        'Object.keys(latestSystem.technical).length>0',
    ):
        assert fragment in HTML, fragment
    print("PASS: scenario table shows fresh reference and pivot-watch rows, blocks stale prices, and remains phone-scrollable")


if __name__ == "__main__":
    main()
