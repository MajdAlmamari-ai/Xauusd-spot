from ob_fvg_strategy import historical_zone_strength


def main() -> None:
    fresh = historical_zone_strength(0)
    once = historical_zone_strength(1)
    exhausted = historical_zone_strength(4)
    assert fresh["available"] is True
    assert fresh["test_count"] == 0
    assert fresh["score"] == 100
    assert once["score"] < fresh["score"]
    assert exhausted["test_count"] == 4
    assert exhausted["score"] < once["score"]
    assert "لا تقيس الدرجة نجاح الارتداد" in exhausted["interpretation"]
    print("PASS: historical zone strength decreases as post-formation tests accumulate")


if __name__ == "__main__":
    main()
