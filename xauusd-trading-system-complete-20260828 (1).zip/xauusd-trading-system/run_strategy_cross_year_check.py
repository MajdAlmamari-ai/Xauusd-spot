"""يتحقق من مرشحي 2026 على 2025 مستقلة زمنياً باستخدام نفس قواعد الأربع ساعات."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from run_strategy_expansion_2026_4h import add_indicators, metrics, simulate, split_segments
from run_strategy_robustness_2026_4h import FAMILIES, signal_variant


SOURCE = Path("/tmp/XAU_15m_data.csv")
OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_cross_year_check_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_cross_year_check_report.md")
H1_START = pd.Timestamp("2025-01-01", tz="UTC")
SPLIT = pd.Timestamp("2025-07-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")
MIN_TRADES = 20


def load_2025_4h() -> list[pd.DataFrame]:
    raw = pd.read_csv(SOURCE, sep=";")
    index = pd.to_datetime(raw.pop("Date"), format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    raw.columns = [str(column).title() for column in raw.columns]
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = index
    base = raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index().loc[H1_START:END - pd.Timedelta(nanoseconds=1)]
    bars = base.resample("4h", label="left", closed="left").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last"}).dropna()
    return [add_indicators(part) for part in split_segments(bars)]


def period_score(segments: list[pd.DataFrame], key: str, stop_atr: float, target_r: float, start: pd.Timestamp, end: pd.Timestamp) -> dict:
    parts = []
    for frame in segments:
        signal = signal_variant(frame, key)
        first = int(frame.index.searchsorted(start, side="left"))
        last = min(len(frame) - 1, int(frame.index.searchsorted(end, side="left")))
        if last - first < 3 or first >= len(frame) - 1:
            continue
        parts.append(simulate(frame, signal, stop_atr, target_r, first, last))
    return metrics(parts)


def accepts(metric: dict) -> bool:
    return bool(metric["filled_trades"] >= MIN_TRADES and metric["cost_sensitivity_r"]["0.10_per_trade"] > 0 and (metric["profit_factor"] or 0) >= 1.10)


def main() -> None:
    segments = load_2025_4h()
    results: dict[str, dict] = {}
    for family, spec in FAMILIES.items():
        variants = {}
        for key in spec["variants"]:
            h1 = period_score(segments, key, spec["stop_atr"], spec["target_r"], H1_START, SPLIT)
            h2 = period_score(segments, key, spec["stop_atr"], spec["target_r"], SPLIT, END)
            variants[key] = {"h1_2025": h1, "h2_2025": h2, "passes_both_2025_halves": accepts(h1) and accepts(h2)}
        results[family] = {"variants": variants, "cross_year_durable_variant_count": sum(row["passes_both_2025_halves"] for row in variants.values())}
    OUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = []
    for family, group in results.items():
        for key, item in group["variants"].items():
            h1, h2 = item["h1_2025"], item["h2_2025"]
            rows.append(f"| {family} | {key} | {h1['filled_trades']} | {h1['cost_sensitivity_r']['0.10_per_trade']} | {h1['profit_factor']} | {h2['filled_trades']} | {h2['cost_sensitivity_r']['0.10_per_trade']} | {h2['profit_factor']} | {'نعم' if item['passes_both_2025_halves'] else 'لا'} |")
    OUT_MD.write_text(f"""# تحقق عبر سنة 2025 لمرشحي 2026

يطبق التقرير قواعد الأربع ساعات نفسها التي ظهرت في نافذة 2026 على بيانات 2025 مستقلة زمنياً. يستبعد فترات الانقطاع الطويلة ولا يعبرها. لا يعد هذا تحققاً مستقلاً للمصدر، لأن بيانات 2025 مصدرها المرجعي المحلي مختلف عن مصدر 2026؛ لكنه حاجز إضافي ضد اختيار قاعدة بسبب نظام 2026 الواحد فقط.

| العائلة | المتغير | صفقات H1 2025 | H1 بعد 0.10R | PF H1 | صفقات H2 2025 | H2 بعد 0.10R | PF H2 | يجتاز النصفين؟ |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
{"\n".join(rows)}

لا يرفع هذا التقرير أي قاعدة إلى تنفيذ حي. يبقى شرط الجسر أو المصدر التاريخي للوسيط وتكاليف التنفيذ الفعلية قائماً.
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for family, group in results.items():
        print(family, group["cross_year_durable_variant_count"])


if __name__ == "__main__":
    main()
