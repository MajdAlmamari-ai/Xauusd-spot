"""يشخّص طلباً واحداً من مصدر Dukascopy دون تشغيل أو تنزيل بيانات اختبار واسعة."""
from __future__ import annotations

from datetime import datetime, timezone
from urllib.request import Request, urlopen

from benchmark_dukascopy_xauusd_fetch import url


def main() -> None:
    moment = datetime(2026, 1, 5, tzinfo=timezone.utc)
    target = url(moment)
    try:
        with urlopen(Request(target, headers={"User-Agent": "XAUUSD-Research/1.0"}), timeout=20) as response:
            print({"url": target, "status": response.status, "bytes": len(response.read())})
    except Exception as error:
        print({"url": target, "error_type": type(error).__name__, "error": str(error)})


if __name__ == "__main__":
    main()
