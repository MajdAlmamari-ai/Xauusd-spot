"""يتحقق من شموع الدقيقة المرجعية: ترتيب، تكرار، وآخر شمعتين دون ملء فجوات مزعومة."""

from production_server import get_timeframe_candles


def main() -> None:
    frame = get_timeframe_candles("1m", force=True)
    assert len(frame) >= 2, "المصدر لم يرجع شمعتين على الأقل لإطار الدقيقة"
    assert frame.index.is_monotonic_increasing, "طوابع شموع الدقيقة غير مرتبة"
    assert not frame.index.has_duplicates, "المصدر رجع شموع دقيقة مكررة"
    last_two = frame.iloc[-2:]
    assert last_two[["Open", "High", "Low", "Close"]].notna().all().all(), "إحدى آخر شمعتين ناقصة OHLC"
    assert (last_two["High"] >= last_two["Low"]).all(), "مدى إحدى آخر شمعتين غير صالح"
    gap_seconds = (frame.index[-1] - frame.index[-2]).total_seconds()
    print(f"شموع الدقيقة صالحة: {len(frame)} شمعة؛ آخر اثنتين: {frame.index[-2]} ثم {frame.index[-1]}؛ الفاصل={gap_seconds:.0f} ثانية.")
    if gap_seconds > 90:
        print("تنبيه مصدر: الفاصل بين آخر شمعتين أكبر من دقيقة؛ لا تمتلئ الفجوة بشمعة مصطنعة.")


if __name__ == "__main__":
    main()
