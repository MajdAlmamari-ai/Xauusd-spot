#!/usr/bin/env python3
"""
نظام متكامل: الأسعار الحية + نموذج ML + التوصيات الذكية
"""

from flask import Flask, jsonify
from flask_cors import CORS
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import threading
import time
import json

app = Flask(__name__)
CORS(app)

# متغيرات عامة
live_data = {
    'price': 0,
    'change': 0,
    'change_percent': 0,
    'timestamp': '',
    'high_52w': 0,
    'low_52w': 0,
    'volume': 0,
    'status': 'جاري التحديث...',
    'rsi': 0,
    'macd': 0,
    'ma20': 0,
    'ma50': 0,
    'ma200': 0,
    'signal': 'NEUTRAL',
    'confidence': 0,
    'predicted_price': 0,
    'entry_price': 0,
    'stop_loss': 0,
    'take_profit': 0,
    'reasons': []
}

def calculate_technical_indicators(df):
    """حساب المؤشرات الفنية"""
    try:
        # RSI
        delta = df['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        # MACD
        ema12 = df['Close'].ewm(span=12).mean()
        ema26 = df['Close'].ewm(span=26).mean()
        macd = ema12 - ema26
        signal_line = macd.ewm(span=9).mean()
        macd_diff = macd - signal_line
        
        # Moving Averages
        ma20 = df['Close'].rolling(window=20).mean()
        ma50 = df['Close'].rolling(window=50).mean()
        ma200 = df['Close'].rolling(window=200).mean()
        
        return {
            'rsi': rsi.iloc[-1],
            'macd': macd_diff.iloc[-1],
            'ma20': ma20.iloc[-1],
            'ma50': ma50.iloc[-1],
            'ma200': ma200.iloc[-1]
        }
    except Exception as e:
        print(f"خطأ في حساب المؤشرات: {e}")
        return None

def generate_signal(indicators, current_price):
    """توليد الإشارة والتوصيات"""
    try:
        if not indicators:
            return None
        
        rsi = indicators['rsi']
        macd = indicators['macd']
        ma20 = indicators['ma20']
        ma50 = indicators['ma50']
        ma200 = indicators['ma200']
        
        # حساب الإشارة
        buy_signals = 0
        sell_signals = 0
        reasons = []
        
        # RSI
        if rsi < 30:
            buy_signals += 2
            reasons.append("RSI منخفض جداً - إشارة شراء قوية")
        elif rsi < 40:
            buy_signals += 1
            reasons.append("RSI منخفض - إشارة شراء")
        elif rsi > 70:
            sell_signals += 2
            reasons.append("RSI مرتفع جداً - إشارة بيع قوية")
        elif rsi > 60:
            sell_signals += 1
            reasons.append("RSI مرتفع - إشارة بيع")
        
        # MACD
        if macd > 0:
            buy_signals += 1
            reasons.append("MACD موجب - زخم صعودي")
        else:
            sell_signals += 1
            reasons.append("MACD سالب - زخم هبوطي")
        
        # Moving Averages
        if current_price > ma20 > ma50 > ma200:
            buy_signals += 2
            reasons.append("المتوسطات المتحركة في ترتيب صعودي - اتجاه صعودي قوي")
        elif current_price < ma20 < ma50 < ma200:
            sell_signals += 2
            reasons.append("المتوسطات المتحركة في ترتيب هبوطي - اتجاه هبوطي قوي")
        
        # تحديد الإشارة
        if buy_signals > sell_signals:
            signal = 'BUY'
            confidence = min(100, (buy_signals / (buy_signals + sell_signals)) * 100)
        elif sell_signals > buy_signals:
            signal = 'SELL'
            confidence = min(100, (sell_signals / (buy_signals + sell_signals)) * 100)
        else:
            signal = 'NEUTRAL'
            confidence = 50
        
        # حساب نقاط الدخول والخروج
        atr = (indicators['ma50'] - indicators['ma200']) / indicators['ma200'] * 100
        volatility = abs(atr)
        
        if signal == 'BUY':
            entry_price = current_price * 0.98  # 2% تحت السعر الحالي
            stop_loss = entry_price * 0.97  # 3% وقف خسارة
            take_profit = entry_price * 1.05  # 5% جني أرباح
        elif signal == 'SELL':
            entry_price = current_price * 1.02  # 2% فوق السعر الحالي
            stop_loss = entry_price * 1.03  # 3% وقف خسارة
            take_profit = entry_price * 0.95  # 5% جني أرباح
        else:
            entry_price = current_price
            stop_loss = current_price * 0.97
            take_profit = current_price * 1.03
        
        return {
            'signal': signal,
            'confidence': confidence,
            'entry_price': entry_price,
            'stop_loss': stop_loss,
            'take_profit': take_profit,
            'reasons': reasons,
            'volatility': volatility
        }
    except Exception as e:
        print(f"خطأ في توليد الإشارة: {e}")
        return None

def fetch_live_data():
    """جلب البيانات الحية والتنبؤات"""
    global live_data
    
    while True:
        try:
            print("🔄 جاري جلب البيانات من Yahoo Finance...")
            
            # جلب البيانات
            ticker = yf.Ticker('GC=F')
            
            # آخر سعر
            hist = ticker.history(period='1d')
            if hist.empty:
                print("✗ لا توجد بيانات حالية")
                time.sleep(60)
                continue
            
            current_price = hist['Close'].iloc[-1]
            
            # البيانات التاريخية (سنة واحدة)
            yearly_data = ticker.history(period='1y')
            
            if yearly_data.empty:
                print("✗ لا توجد بيانات تاريخية")
                time.sleep(60)
                continue
            
            # حساب المؤشرات
            indicators = calculate_technical_indicators(yearly_data)
            
            if not indicators:
                print("✗ فشل حساب المؤشرات")
                time.sleep(60)
                continue
            
            # توليد الإشارة
            signal_data = generate_signal(indicators, current_price)
            
            if not signal_data:
                print("✗ فشل توليد الإشارة")
                time.sleep(60)
                continue
            
            # السعر السابق
            previous_close = ticker.info.get('previousClose', current_price)
            change = current_price - previous_close
            change_percent = (change / previous_close * 100) if previous_close != 0 else 0
            
            # تحديث البيانات
            live_data.update({
                'price': round(current_price, 2),
                'change': round(change, 2),
                'change_percent': round(change_percent, 2),
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'high_52w': round(ticker.info.get('fiftyTwoWeekHigh', 0), 2),
                'low_52w': round(ticker.info.get('fiftyTwoWeekLow', 0), 2),
                'volume': ticker.info.get('volume', 0),
                'status': 'متصل ✓',
                'rsi': round(indicators['rsi'], 2),
                'macd': round(indicators['macd'], 2),
                'ma20': round(indicators['ma20'], 2),
                'ma50': round(indicators['ma50'], 2),
                'ma200': round(indicators['ma200'], 2),
                'signal': signal_data['signal'],
                'confidence': round(signal_data['confidence'], 1),
                'predicted_price': round(current_price * (1 + (signal_data['confidence'] - 50) / 500), 2),
                'entry_price': round(signal_data['entry_price'], 2),
                'stop_loss': round(signal_data['stop_loss'], 2),
                'take_profit': round(signal_data['take_profit'], 2),
                'reasons': signal_data['reasons']
            })
            
            print(f"✓ تم التحديث: السعر ${live_data['price']} - الإشارة: {live_data['signal']} - الثقة: {live_data['confidence']}%")
            
        except Exception as e:
            live_data['status'] = f'خطأ: {str(e)}'
            print(f"✗ خطأ في جلب البيانات: {e}")
        
        # الانتظار 60 ثانية قبل التحديث التالي
        time.sleep(60)

@app.route('/api/live-data', methods=['GET'])
def get_live_data():
    """API endpoint لجلب البيانات الحية والتنبؤات"""
    return jsonify(live_data)

@app.route('/')
def index():
    """الصفحة الرئيسية المتكاملة"""
    return '''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نظام التنبؤ الذكي المتكامل - XAUUSD</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js"></script>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                color: #333;
                min-height: 100vh;
                padding: 20px;
            }
            
            .container {
                max-width: 1400px;
                margin: 0 auto;
            }
            
            header {
                text-align: center;
                color: white;
                margin-bottom: 30px;
                padding: 30px 0;
            }
            
            header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
            }
            
            .status-bar {
                background: white;
                padding: 15px 25px;
                border-radius: 10px;
                margin-bottom: 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            
            .status-bar .status {
                font-weight: bold;
            }
            
            .status-bar .status.connected {
                color: #4ade80;
            }
            
            .status-bar .status.error {
                color: #f87171;
            }
            
            .main-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin-bottom: 30px;
            }
            
            .card {
                background: white;
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                transition: transform 0.3s;
            }
            
            .card:hover {
                transform: translateY(-5px);
            }
            
            .price-card {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                text-align: center;
            }
            
            .price-card .price {
                font-size: 3em;
                font-weight: bold;
                margin: 20px 0;
            }
            
            .price-card .change {
                font-size: 1.3em;
            }
            
            .change.positive {
                color: #4ade80;
            }
            
            .change.negative {
                color: #f87171;
            }
            
            .signal-card {
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                color: white;
                text-align: center;
            }
            
            .signal-card .signal {
                font-size: 2.5em;
                font-weight: bold;
                margin: 20px 0;
                padding: 15px;
                background: rgba(255,255,255,0.2);
                border-radius: 10px;
            }
            
            .indicators-card h3 {
                color: #667eea;
                margin-bottom: 15px;
            }
            
            .indicator-row {
                display: flex;
                justify-content: space-between;
                padding: 10px 0;
                border-bottom: 1px solid #eee;
            }
            
            .indicator-row:last-child {
                border-bottom: none;
            }
            
            .indicator-label {
                font-weight: 600;
                color: #667eea;
            }
            
            .indicator-value {
                font-weight: bold;
            }
            
            .entry-exit-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                gap: 15px;
                margin-top: 20px;
            }
            
            .entry-exit-item {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 20px;
                border-radius: 10px;
                text-align: center;
            }
            
            .entry-exit-item h4 {
                font-size: 0.85em;
                opacity: 0.9;
                margin-bottom: 10px;
            }
            
            .entry-exit-item .value {
                font-size: 1.5em;
                font-weight: bold;
            }
            
            .reasons {
                background: white;
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                margin-bottom: 30px;
            }
            
            .reasons h3 {
                color: #667eea;
                margin-bottom: 15px;
            }
            
            .reason-item {
                padding: 12px;
                background: #f8f9fa;
                border-right: 4px solid #667eea;
                margin-bottom: 8px;
                border-radius: 5px;
            }
            
            .chart-container {
                background: white;
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                margin-bottom: 30px;
            }
            
            .chart-container h3 {
                color: #667eea;
                margin-bottom: 20px;
            }
            
            @media (max-width: 768px) {
                header h1 {
                    font-size: 1.8em;
                }
                
                .price-card .price {
                    font-size: 2em;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>🏆 نظام التنبؤ الذكي المتكامل</h1>
                <p>XAUUSD - أسعار حية + تحليل ML + توصيات ذكية</p>
            </header>
            
            <div class="status-bar">
                <div>
                    الحالة: <span class="status connected" id="status">جاري الاتصال...</span>
                </div>
                <div>
                    آخر تحديث: <span id="timestamp">جاري التحديث...</span>
                </div>
            </div>
            
            <div class="main-grid">
                <!-- السعر الحالي -->
                <div class="card price-card">
                    <h2>💰 السعر الحالي</h2>
                    <div class="price" id="price">$0.00</div>
                    <div class="change" id="change">↑ +0.00 (+0.00%)</div>
                </div>
                
                <!-- الإشارة -->
                <div class="card signal-card">
                    <h2>📊 الإشارة</h2>
                    <div class="signal" id="signal">NEUTRAL</div>
                    <div>الثقة: <span id="confidence">0</span>%</div>
                </div>
                
                <!-- السعر المتنبأ به -->
                <div class="card price-card">
                    <h2>🎯 السعر المتنبأ به</h2>
                    <div class="price" id="predictedPrice">$0.00</div>
                    <div style="font-size: 0.9em; opacity: 0.9;">بناءً على نموذج ML</div>
                </div>
            </div>
            
            <!-- المؤشرات الفنية -->
            <div class="main-grid">
                <div class="card indicators-card">
                    <h3>📈 المؤشرات الفنية</h3>
                    <div class="indicator-row">
                        <span class="indicator-label">RSI:</span>
                        <span class="indicator-value" id="rsi">0.00</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-label">MACD:</span>
                        <span class="indicator-value" id="macd">0.00</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-label">MA 20:</span>
                        <span class="indicator-value" id="ma20">$0.00</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-label">MA 50:</span>
                        <span class="indicator-value" id="ma50">$0.00</span>
                    </div>
                    <div class="indicator-row">
                        <span class="indicator-label">MA 200:</span>
                        <span class="indicator-value" id="ma200">$0.00</span>
                    </div>
                </div>
            </div>
            
            <!-- نقاط الدخول والخروج -->
            <div class="card">
                <h3 style="color: #667eea; margin-bottom: 20px;">🎯 نقاط الدخول والخروج</h3>
                <div class="entry-exit-grid">
                    <div class="entry-exit-item">
                        <h4>نقطة الدخول</h4>
                        <div class="value" id="entryPrice">$0.00</div>
                    </div>
                    <div class="entry-exit-item">
                        <h4>وقف الخسارة</h4>
                        <div class="value" id="stopLoss">$0.00</div>
                    </div>
                    <div class="entry-exit-item">
                        <h4>جني الأرباح</h4>
                        <div class="value" id="takeProfit">$0.00</div>
                    </div>
                </div>
            </div>
            
            <!-- الأسباب -->
            <div class="reasons">
                <h3>📝 أسباب الإشارة</h3>
                <div id="reasonsList">
                    <div class="reason-item">جاري تحميل الأسباب...</div>
                </div>
            </div>
        </div>
        
        <script>
            async function updateData() {
                try {
                    const response = await fetch('/api/live-data');
                    const data = await response.json();
                    
                    // تحديث السعر
                    document.getElementById('price').textContent = '$' + data.price.toFixed(2);
                    
                    // تحديث التغير
                    const changeElement = document.getElementById('change');
                    const changeText = (data.change >= 0 ? '↑ +' : '↓ ') + 
                                      data.change.toFixed(2) + ' (' + 
                                      (data.change_percent >= 0 ? '+' : '') + 
                                      data.change_percent.toFixed(2) + '%)';
                    changeElement.textContent = changeText;
                    changeElement.className = 'change ' + (data.change >= 0 ? 'positive' : 'negative');
                    
                    // تحديث المؤشرات
                    document.getElementById('rsi').textContent = data.rsi.toFixed(2);
                    document.getElementById('macd').textContent = data.macd.toFixed(2);
                    document.getElementById('ma20').textContent = '$' + data.ma20.toFixed(2);
                    document.getElementById('ma50').textContent = '$' + data.ma50.toFixed(2);
                    document.getElementById('ma200').textContent = '$' + data.ma200.toFixed(2);
                    
                    // تحديث الإشارة
                    document.getElementById('signal').textContent = data.signal;
                    document.getElementById('confidence').textContent = data.confidence;
                    document.getElementById('predictedPrice').textContent = '$' + data.predicted_price.toFixed(2);
                    
                    // تحديث نقاط الدخول والخروج
                    document.getElementById('entryPrice').textContent = '$' + data.entry_price.toFixed(2);
                    document.getElementById('stopLoss').textContent = '$' + data.stop_loss.toFixed(2);
                    document.getElementById('takeProfit').textContent = '$' + data.take_profit.toFixed(2);
                    
                    // تحديث الأسباب
                    const reasonsList = document.getElementById('reasonsList');
                    if (data.reasons && data.reasons.length > 0) {
                        reasonsList.innerHTML = data.reasons.map(r => 
                            '<div class="reason-item">• ' + r + '</div>'
                        ).join('');
                    }
                    
                    // تحديث الحالة والوقت
                    document.getElementById('status').textContent = data.status;
                    document.getElementById('status').className = 'status ' + (data.status.includes('متصل') ? 'connected' : 'error');
                    document.getElementById('timestamp').textContent = data.timestamp;
                    
                } catch (error) {
                    console.error('خطأ:', error);
                    document.getElementById('status').textContent = 'خطأ في الاتصال';
                    document.getElementById('status').className = 'status error';
                }
            }
            
            // تحديث البيانات كل 5 ثوانٍ
            updateData();
            setInterval(updateData, 5000);
        </script>
    </body>
    </html>
    '''

if __name__ == '__main__':
    # بدء خيط لجلب البيانات
    data_thread = threading.Thread(target=fetch_live_data, daemon=True)
    data_thread.start()
    
    print("🚀 النظام المتكامل يعمل على http://localhost:5000")
    print("📊 جاري جلب البيانات الحية والتنبؤات...")
    
    # تشغيل الخادم
    app.run(host='0.0.0.0', port=5000, debug=False)
