"""اختبارات مستقلة لسلامة محرك الاختبار؛ لا تقرأ ملفات النتائج السابقة."""

from __future__ import annotations

import pandas as pd

from reproducible_backtest import CostModel, prepare_indicators, signal_series, simulate
from technical_indicators import _confirmed_pivots


def candles(rows: int = 540) -> pd.DataFrame:
    index = pd.date_range("2025-01-06 00:00:00", periods=rows, freq="1h", tz="UTC")
    close = []
    for row in range(rows):
        cycle = (row % 31) - 15
        close.append(2500.0 + row * 0.08 + cycle * 0.13)
    return pd.DataFrame({
        "Open": [price - 0.1 for price in close],
        "High": [price + 0.35 for price in close],
        "Low": [price - 0.4 for price in close],
        "Close": close,
        "Volume": [100.0] * rows,
    }, index=index)


def test_no_future_data_leakage() -> None:
    raw = candles()
    cutoff = 400
    prefix = prepare_indicators(raw.iloc[:cutoff])
    whole = prepare_indicators(raw)
    for strategy in ("ema_pullback", "donchian_breakout", "rsi_bollinger"):
        assert signal_series(prefix, strategy).equals(signal_series(whole, strategy).iloc[:cutoff])


def test_confirmed_pivots_never_use_unavailable_right_bars() -> None:
    raw = candles(120)
    pivots = _confirmed_pivots(raw, left=2, right=2)
    assert all(point["index"] <= len(raw) - 3 for point in pivots)


def test_execution_is_next_open_and_costs_reduce_result() -> None:
    raw = candles()
    free = simulate(raw, "ema_pullback", costs=CostModel(0.0, 0.0, 0.0))
    costed = simulate(raw, "ema_pullback", costs=CostModel(0.50, 0.10, 0.05))
    assert free and costed and len(free) == len(costed)
    assert all(pd.Timestamp(trade["entry_time"]) > pd.Timestamp(trade["decision_time"]) for trade in costed)
    assert sum(trade["net_r"] for trade in costed) < sum(trade["net_r"] for trade in free)
    assert all(trade["outcome"] in {"target", "stop", "same_bar_conservative_stop", "time_exit"} for trade in costed)


def main() -> None:
    test_no_future_data_leakage()
    test_confirmed_pivots_never_use_unavailable_right_bars()
    test_execution_is_next_open_and_costs_reduce_result()
    print("PASS: no future leakage, confirmed pivots, next-open execution, and cost handling")


if __name__ == "__main__":
    main()
