"""اختبارات استراتيجية Order Block + Fair Value Gap واختبارها الزمني."""

from mt5_price_connector import MT5PriceConnector
from ob_fvg_strategy import backtest_ob_fvg_strategy, build_ob_fvg_setup
from technical_indicators import calculate_snapshot


def main() -> None:
    candles = MT5PriceConnector().fetch_ohlc(period="2y", interval="1d")
    assert len(candles) >= 250

    # اللقطة لا ترى إلا الشموع المتاحة في نقطة القرار.
    available = candles.iloc[:-12].copy()
    setup = build_ob_fvg_setup(available, calculate_snapshot(available))
    assert {"status", "qualified", "direction", "entry_zone", "stop_loss", "take_profit", "risk_reward", "data_basis"}.issubset(setup)
    assert setup["direction"] in {"شراء", "بيع", "محايد"}
    if setup["qualified"]:
        assert setup["entry_zone"]["lower"] < setup["entry_zone"]["upper"]
        assert setup["risk_reward"] >= 1.5
        if setup["direction"] == "شراء":
            assert setup["stop_loss"] < setup["entry"] < setup["take_profit"]
        else:
            assert setup["take_profit"] < setup["entry"] < setup["stop_loss"]

    result = backtest_ob_fvg_strategy(candles, warmup_bars=180, horizon_bars=12, censor_gap_bars=1)
    assert result["status"].startswith("مكتمل")
    metrics = result["metrics"]
    assert metrics["decision_points"] > 0
    assert metrics["filled_trades"] <= metrics["eligible_setups"]
    assert metrics["gross_profit_r"] >= 0
    assert metrics["gross_loss_r"] >= 0
    assert metrics["minimum_sample"] == 20
    assert metrics["sample_adequate"] is (metrics["filled_trades"] >= metrics["minimum_sample"])
    assert result["methodology"]["evaluation_stride"] >= 5
    assert result["methodology"]["max_evaluation_points"] == 24
    assert result["methodology"]["signal_lookback_bars"] == 600
    assert result["methodology"]["censor_gap_bars"] == 1
    for trade in result["trades"]:
        assert trade["entry_time"] != trade["decision_time"]
        assert trade["outcome"] in {"هدف", "وقف", "غموض داخل الشمعة — وقف محافظ", "انتهت المدة"}

    filtered_result = backtest_ob_fvg_strategy(candles, warmup_bars=180, horizon_bars=12, censor_gap_bars=1, filter_mode="rsi_ma")
    assert filtered_result["methodology"]["filter_mode"] == "rsi_ma"
    assert filtered_result["metrics"]["filtered_out_setups"] >= 0
    assert filtered_result["metrics"]["post_filter_setups"] <= filtered_result["metrics"]["eligible_setups"]

    print(f"نجح اختبار استراتيجية OB+FVG بلا تسريب مستقبلي؛ صفقات مملوءة={metrics['filled_trades']}.")


if __name__ == "__main__":
    main()
