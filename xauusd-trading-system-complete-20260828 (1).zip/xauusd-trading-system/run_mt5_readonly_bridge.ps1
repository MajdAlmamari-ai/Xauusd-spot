# يشغّل الجسر محلياً بجانب تطبيق MetaTrader 5 على Windows.
# لا تضع كلمة مرور أي مصدر أو رقم حساب في هذا الملف.

$ErrorActionPreference = "Stop"
$env:MT5_BRIDGE_HOST = "127.0.0.1"
$env:MT5_BRIDGE_PORT = "8443"
$enteredSymbol = Read-Host "رمز الذهب في MT5 [XAUUSD]"
$env:MT5_SYMBOL = if ([string]::IsNullOrWhiteSpace($enteredSymbol)) { "XAUUSD" } else { $enteredSymbol.Trim() }
$secureToken = Read-Host "أنشئ رمزاً سرياً طويلاً لجسر القراءة فقط" -AsSecureString
$env:MT5_BRIDGE_TOKEN = [System.Net.NetworkCredential]::new('', $secureToken).Password

python -m pip install -r .\requirements-mt5-bridge.txt
python .\mt5_reference_bridge.py
