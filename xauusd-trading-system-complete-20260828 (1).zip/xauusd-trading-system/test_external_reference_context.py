"""يتحقق من عدم إخفاء غياب جسر MT5 أو أهلية تسعيره عن واجهة التدقيق."""

from __future__ import annotations

import production_server as server


def main() -> None:
    original_bridge = server.connector.bridge_url
    try:
        server.connector.bridge_url = None
        missing_bridge = server.make_external_reference_context({})
        assert missing_bridge["mt5_bridge_configured"] is False
        assert missing_bridge["broker_quote_eligible"] is False
        assert "غير مضبوط" in missing_bridge["bridge_status"]
        assert "Gold API" in missing_bridge["market_data_status"]

        server.connector.bridge_url = "http://mt5-bridge.example"
        awaiting_tick = server.make_external_reference_context({"broker_quote_eligible": False})
        assert awaiting_tick["mt5_bridge_configured"] is True
        assert awaiting_tick["broker_quote_eligible"] is False
        assert "لم يصل" in awaiting_tick["bridge_status"]

        eligible_quote = server.make_external_reference_context({"broker_quote_eligible": True})
        assert eligible_quote["mt5_bridge_configured"] is True
        assert eligible_quote["broker_quote_eligible"] is True
        assert "متصل" in eligible_quote["bridge_status"]
        assert "Bid/Ask" in eligible_quote["market_data_status"]

        assert server.quote_status_label({"status": "success", "stale": False, "live_for_analysis": True, "broker_quote_eligible": True}) == "يعمل — سعر وسيط MT5 حديث للقراءة والتحليل فقط"
        assert server.quote_status_label({"status": "success", "stale": False, "live_for_analysis": True, "broker_quote_eligible": False}) == "يعمل — سعر سوق عام حديث للتحليل والرسم البياني"
        assert server.quote_status_label({"status": "success", "stale": True, "live_for_analysis": False}) == "السوق مغلق أو السعر المرجعي متأخر — لا يوجد سعر حي"
        print("نجح اختبار سياق المصدر: غياب الجسر، الجسر بانتظار Tick، والجسر المؤهل موسومة بوضوح.")
    finally:
        server.connector.bridge_url = original_bridge


if __name__ == "__main__":
    main()
