import pandas as pd

from market_data import MarketDataService


class FailingLiveProvider:
    def get_current_price(self):
        raise RuntimeError("source unavailable")


class RecordingHistoricalProvider:
    def __init__(self):
        self.calls = []

    def get_ohlc(self, *, period: str, timeframe: str):
        self.calls.append((period, timeframe))
        return pd.DataFrame(
            {"Open": [1.0], "High": [2.0], "Low": [0.5], "Close": [1.5], "Volume": [10]},
            index=pd.to_datetime(["2026-01-01T00:00:00Z"]),
        )


def main() -> None:
    historical = RecordingHistoricalProvider()
    service = MarketDataService(FailingLiveProvider(), historical)
    quote = service.live_price()
    assert quote["status"] == "error"
    assert quote["source"].startswith("gold-api.com")
    assert quote["stale"] is True and quote["tradable"] is False
    candles = service.historical_ohlc(period="60d", timeframe="1h")
    assert historical.calls == [("60d", "1h")]
    assert list(candles.columns) == ["Open", "High", "Low", "Close", "Volume"]
    inventory = service.source_inventory()
    assert inventory["live_price_provider"]["name"] == "gold-api.com"
    assert inventory["historical_data_provider"]["name"] == "Yahoo Finance"
    assert "OHLC" in inventory["live_price_provider"]["does_not_provide"]
    print("PASS: MarketDataService separates gold-api live price failures from Yahoo historical OHLC")


if __name__ == "__main__":
    main()
