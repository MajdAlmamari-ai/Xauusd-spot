import json
from pathlib import Path


def main() -> None:
    result = json.loads(Path(__file__).with_name("strategy_expansion_2026_intraday_results.json").read_text(encoding="utf-8"))
    contract = result["data_contract"]
    assert contract["reference_only"] is True
    assert contract["cost_sensitivity_r"] == [0.15, 0.25]
    assert "Bid/Ask" in contract["not_available"]
    assert set(result["segments"]) == {"5m", "15m", "30m"}
    assert len(result["results"]) == 33
    assert all(not item["eligible_for_exploratory_watchlist"] for item in result["results"].values())
    failed_breakout = result["results"]["5m:failed_breakout_reversal"]["oos_h2"]
    assert failed_breakout["total_r"] > 0
    assert failed_breakout["cost_sensitivity_r"]["0.25_per_trade"] < 0
    assert result["segments"]["5m"]["end"].startswith("2026-01-13")
    policy = json.loads(Path(__file__).with_name("strategy_candidate_policy_2026_intraday.json").read_text(encoding="utf-8"))
    assert policy["live_decision_integration"] is False
    assert policy["new_strategy_added_to_live_engine"] is False
    assert policy["basis"]["tested_configurations"] == 33
    print("PASS: intraday 2026 contract preserves source limits, cost gate, and no-live-candidate policy")


if __name__ == "__main__":
    main()
