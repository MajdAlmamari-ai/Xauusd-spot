"""فحص إعداد جسر XAUUSD ومعيار حداثة الـ tick."""

from pathlib import Path


SOURCE = Path(__file__).with_name("mt5_reference_bridge.py").read_text(encoding="utf-8")
RUNNER = Path(__file__).with_name("run_mt5_readonly_bridge.ps1").read_text(encoding="utf-8")


def main() -> None:
    assert 'DEFAULT_SYMBOL = os.getenv("MT5_SYMBOL", "XAUUSD")' in SOURCE
    assert 'STALE_AFTER_SECONDS = int(os.getenv("MT5_STALE_AFTER_SECONDS", "15"))' in SOURCE
    assert '"tick_age_seconds"' in SOURCE
    assert '"stale": tick_age_seconds > STALE_AFTER_SECONDS' in SOURCE
    assert '"10m": mt5.TIMEFRAME_M10' in SOURCE
    assert '"2h": mt5.TIMEFRAME_H2' in SOURCE
    assert '"4h": mt5.TIMEFRAME_H4' in SOURCE
    assert '"XAUUSD"' in RUNNER
    print("نجح فحص XAUUSD: الرمز الافتراضي ومعيار حداثة السعر مضبوطَان.")


if __name__ == "__main__":
    main()
