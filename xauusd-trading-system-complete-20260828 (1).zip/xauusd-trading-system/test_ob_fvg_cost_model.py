"""يثبت تطبيق تكاليف التنفيذ المعلنة على OB+FVG دون استخدام أي سعر وسيط مصطنع."""

import numpy as np
import pandas as pd

import ob_fvg_strategy as strategy
from reproducible_backtest import CostModel


def frame() -> pd.DataFrame:
    index = pd.date_range("2025-01-01", periods=48, freq="h", tz="UTC")
    return pd.DataFrame({"Open": np.full(48, 100.0), "High": np.full(48, 101.0), "Low": np.full(48, 99.0), "Close": np.full(48, 100.0)}, index=index)


def main() -> None:
    original = strategy.build_ob_fvg_setup
    try:
        strategy.build_ob_fvg_setup = lambda *_args, **_kwargs: {
            "qualified": True, "direction": "شراء", "entry_zone": {"lower": 99.5, "upper": 100.5},
            "entry": 100.0, "stop_loss": 90.0, "take_profit": 120.0,
        }
        zero = strategy.backtest_ob_fvg_strategy(frame(), warmup_bars=20, horizon_bars=2, censor_gap_bars=1, evaluation_stride=99, max_evaluation_points=1, costs=CostModel(0, 0, 0))
        costly = strategy.backtest_ob_fvg_strategy(frame(), warmup_bars=20, horizon_bars=2, censor_gap_bars=1, evaluation_stride=99, max_evaluation_points=1, costs=CostModel(0.4, 0.1, 0.2))
        assert zero["metrics"]["filled_trades"] == costly["metrics"]["filled_trades"] == 1
        assert costly["metrics"]["total_r"] < zero["metrics"]["total_r"]
        assert costly["methodology"]["costs"]["spread_price"] == 0.4
        assert costly["trades"][0]["r_multiple"] < costly["trades"][0]["gross_r_multiple"]
    finally:
        strategy.build_ob_fvg_setup = original
    print("PASS: OB+FVG applies spread, slippage, and commission to net R while preserving candle timing")


if __name__ == "__main__":
    main()
