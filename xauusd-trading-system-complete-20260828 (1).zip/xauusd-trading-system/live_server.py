#!/usr/bin/env python3
"""
خادم الأسعار الحية - يجلب أسعار XAUUSD من Yahoo Finance بشكل مباشر
"""

from flask import Flask, jsonify, render_template_string
from flask_cors import CORS
import yfinance as yf
import threading
import time
from datetime import datetime
import json

app = Flask(__name__)
CORS(app)

# متغيرات عامة لتخزين البيانات الحية
live_data = {
    'price': 0,
    'change': 0,
    'change_percent': 0,
    'timestamp': '',
    'high_52w': 0,
    'low_52w': 0,
    'volume': 0,
    'status': 'جاري التحديث...'
}

def fetch_live_price():
    """جلب السعر الحي من Yahoo Finance بشكل مستمر"""
    global live_data
    
    while True:
        try:
            # جلب بيانات XAUUSD من Yahoo Finance
            ticker = yf.Ticker('GC=F')  # Gold Futures
            
            # الحصول على آخر بيانات
            data = ticker.history(period='1d')
            
            if not data.empty:
                current_price = data['Close'].iloc[-1]
                previous_close = ticker.info.get('previousClose', current_price)
                
                change = current_price - previous_close
                change_percent = (change / previous_close * 100) if previous_close != 0 else 0
                
                # تحديث البيانات
                live_data['price'] = round(current_price, 2)
                live_data['change'] = round(change, 2)
                live_data['change_percent'] = round(change_percent, 2)
                live_data['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                live_data['high_52w'] = round(ticker.info.get('fiftyTwoWeekHigh', 0), 2)
                live_data['low_52w'] = round(ticker.info.get('fiftyTwoWeekLow', 0), 2)
                live_data['volume'] = ticker.info.get('volume', 0)
                live_data['status'] = 'متصل'
                
                print(f"✓ تم تحديث السعر: ${live_data['price']} في {live_data['timestamp']}")
            else:
                live_data['status'] = 'خطأ في جلب البيانات'
                print("✗ فشل جلب البيانات من Yahoo Finance")
                
        except Exception as e:
            live_data['status'] = f'خطأ: {str(e)}'
            print(f"✗ خطأ في جلب الأسعار: {e}")
        
        # الانتظار 60 ثانية قبل التحديث التالي
        time.sleep(60)

@app.route('/api/live-price', methods=['GET'])
def get_live_price():
    """API endpoint لجلب السعر الحي"""
    return jsonify(live_data)

@app.route('/api/historical', methods=['GET'])
def get_historical():
    """API endpoint لجلب البيانات التاريخية"""
    try:
        ticker = yf.Ticker('GC=F')
        data = ticker.history(period='1y')
        
        # تحويل البيانات إلى صيغة JSON
        result = {
            'dates': data.index.strftime('%Y-%m-%d').tolist(),
            'closes': data['Close'].round(2).tolist(),
            'highs': data['High'].round(2).tolist(),
            'lows': data['Low'].round(2).tolist(),
            'volumes': data['Volume'].tolist()
        }
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/')
def index():
    """الصفحة الرئيسية"""
    return '''
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نظام الأسعار الحية - XAUUSD</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js"></script>
        <style>
            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
                color: #333;
                min-height: 100vh;
                padding: 20px;
            }
            
            .container {
                max-width: 1200px;
                margin: 0 auto;
            }
            
            header {
                text-align: center;
                color: white;
                margin-bottom: 30px;
                padding: 30px 0;
            }
            
            header h1 {
                font-size: 2.5em;
                margin-bottom: 10px;
            }
            
            .card {
                background: white;
                border-radius: 15px;
                padding: 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                margin-bottom: 20px;
            }
            
            .price-display {
                text-align: center;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 40px;
                border-radius: 15px;
                margin-bottom: 20px;
            }
            
            .price-display .price {
                font-size: 3em;
                font-weight: bold;
                margin: 20px 0;
            }
            
            .price-display .change {
                font-size: 1.5em;
            }
            
            .change.positive {
                color: #4ade80;
            }
            
            .change.negative {
                color: #f87171;
            }
            
            .status {
                text-align: center;
                color: white;
                margin-bottom: 20px;
                font-size: 1.1em;
            }
            
            .status.connected {
                color: #4ade80;
            }
            
            .status.error {
                color: #f87171;
            }
            
            .info-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 20px;
                margin-bottom: 20px;
            }
            
            .info-item {
                background: white;
                padding: 20px;
                border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            }
            
            .info-item h3 {
                color: #667eea;
                margin-bottom: 10px;
                font-size: 0.9em;
            }
            
            .info-item .value {
                font-size: 1.8em;
                font-weight: bold;
                color: #333;
            }
            
            .chart-container {
                background: white;
                padding: 25px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            }
            
            .chart-container h2 {
                color: #667eea;
                margin-bottom: 20px;
            }
            
            .update-info {
                text-align: center;
                color: white;
                margin-bottom: 20px;
                font-size: 0.95em;
            }
            
            .loading {
                display: inline-block;
                width: 10px;
                height: 10px;
                background: #4ade80;
                border-radius: 50%;
                animation: pulse 1.5s infinite;
            }
            
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>🏆 نظام الأسعار الحية للذهب</h1>
                <p>XAUUSD - تحديث فوري من السوق</p>
            </header>
            
            <div class="update-info">
                الحالة: <span class="loading"></span> <span id="status">جاري الاتصال...</span>
            </div>
            
            <div class="price-display">
                <h2>💰 السعر الحالي</h2>
                <div class="price" id="price">$0.00</div>
                <div class="change" id="change">↑ +0.00 (+0.00%)</div>
                <div style="margin-top: 15px; font-size: 0.9em; opacity: 0.9;">
                    آخر تحديث: <span id="timestamp">جاري التحديث...</span>
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-item">
                    <h3>📈 أعلى 52 أسبوع</h3>
                    <div class="value" id="high52w">$0.00</div>
                </div>
                <div class="info-item">
                    <h3>📉 أدنى 52 أسبوع</h3>
                    <div class="value" id="low52w">$0.00</div>
                </div>
                <div class="info-item">
                    <h3>📊 الحجم</h3>
                    <div class="value" id="volume">0</div>
                </div>
            </div>
            
            <div class="chart-container">
                <h2>📈 تطور السعر (آخر سنة)</h2>
                <canvas id="priceChart"></canvas>
            </div>
        </div>
        
        <script>
            let chart = null;
            
            async function updateLivePrice() {
                try {
                    const response = await fetch('/api/live-price');
                    const data = await response.json();
                    
                    // تحديث السعر
                    document.getElementById('price').textContent = '$' + data.price.toFixed(2);
                    
                    // تحديث التغير
                    const changeElement = document.getElementById('change');
                    const changeText = (data.change >= 0 ? '↑ +' : '↓ ') + 
                                      data.change.toFixed(2) + ' (' + 
                                      (data.change_percent >= 0 ? '+' : '') + 
                                      data.change_percent.toFixed(2) + '%)';
                    changeElement.textContent = changeText;
                    changeElement.className = 'change ' + (data.change >= 0 ? 'positive' : 'negative');
                    
                    // تحديث البيانات الأخرى
                    document.getElementById('high52w').textContent = '$' + data.high_52w.toFixed(2);
                    document.getElementById('low52w').textContent = '$' + data.low_52w.toFixed(2);
                    document.getElementById('volume').textContent = (data.volume / 1000000).toFixed(2) + 'M';
                    document.getElementById('timestamp').textContent = data.timestamp;
                    
                    // تحديث الحالة
                    const statusElement = document.getElementById('status');
                    statusElement.textContent = data.status;
                    statusElement.className = 'status ' + (data.status === 'متصل' ? 'connected' : 'error');
                    
                } catch (error) {
                    console.error('خطأ في جلب البيانات:', error);
                    document.getElementById('status').textContent = 'خطأ في الاتصال';
                    document.getElementById('status').className = 'status error';
                }
            }
            
            async function updateChart() {
                try {
                    const response = await fetch('/api/historical');
                    const data = await response.json();
                    
                    if (chart) {
                        chart.destroy();
                    }
                    
                    const ctx = document.getElementById('priceChart').getContext('2d');
                    chart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.dates,
                            datasets: [{
                                label: 'سعر الإغلاق',
                                data: data.closes,
                                borderColor: '#667eea',
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                borderWidth: 2,
                                fill: true,
                                tension: 0.4,
                                pointRadius: 0,
                                pointHoverRadius: 5
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: true,
                                    position: 'top'
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: false
                                }
                            }
                        }
                    });
                } catch (error) {
                    console.error('خطأ في تحديث الرسم البياني:', error);
                }
            }
            
            // تحديث الأسعار كل 10 ثوان
            updateLivePrice();
            updateChart();
            setInterval(updateLivePrice, 10000);
            setInterval(updateChart, 300000); // تحديث الرسم البياني كل 5 دقائق
        </script>
    </body>
    </html>
    '''

if __name__ == '__main__':
    # بدء خيط لجلب الأسعار الحية
    price_thread = threading.Thread(target=fetch_live_price, daemon=True)
    price_thread.start()
    
    print("🚀 خادم الأسعار الحية يعمل على http://localhost:5000")
    print("📊 جاري جلب الأسعار من Yahoo Finance...")
    
    # تشغيل الخادم
    app.run(host='0.0.0.0', port=5000, debug=False)
