"""بحث زمني محافظ لتوقع اتجاه XAU/USD من OHLC Spot موثق.

هذا الملف لا يرسل أوامر ولا ينتج BUY/SELL. ولا يقبل التدريب عندما تكون
الشموع ناقصة أو مصدرها غير معلن. مخرجه يصلح فقط كدليل إضافي داخل سيناريو
مشروط بعد اجتياز اختبارات خارج العينة.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from hashlib import sha256
from typing import Iterable

import numpy as np
import pandas as pd


REQUIRED_COLUMNS = ("timestamp", "open", "high", "low", "close")


class MLDataQualityError(ValueError):
    """بيانات غير كافية أو غير متصلة بصورة تجعل التدريب مضللاً."""


@dataclass(frozen=True)
class ResearchSpec:
    symbol: str = "XAU/USD"
    source: str = "UNSPECIFIED"
    timeframe_minutes: int = 15
    horizon_bars: int = 4
    train_bars_minimum: int = 10_000
    max_non_session_gap_minutes: int = 120
    model_version: str = "spot-ml-research-v1"


def dataframe_hash(frame: pd.DataFrame) -> str:
    """تجزئة قابلة لإعادة التشغيل للبيانات الداخلة بعد ترتيبها زمنياً."""
    stable = frame.loc[:, [c for c in REQUIRED_COLUMNS if c in frame]].copy()
    stable["timestamp"] = pd.to_datetime(stable["timestamp"], utc=True).astype(str)
    return sha256(stable.to_csv(index=False, lineterminator="\n").encode()).hexdigest()


def validate_spot_ohlc(frame: pd.DataFrame, spec: ResearchSpec) -> pd.DataFrame:
    """يرفض صفوفاً ناقصة، ترتيباً زمنياً خاطئاً، أو فجوات تداول غير معلنة."""
    missing = [column for column in REQUIRED_COLUMNS if column not in frame.columns]
    if missing:
        raise MLDataQualityError(f"حقول OHLC المطلوبة غير موجودة: {missing}")
    if spec.symbol != "XAU/USD":
        raise MLDataQualityError("هذا الباحث مخصص لعقد XAU/USD Spot فقط")
    if not spec.source or spec.source == "UNSPECIFIED":
        raise MLDataQualityError("يجب توثيق مصدر بيانات Spot قبل التدريب")

    checked = frame.loc[:, REQUIRED_COLUMNS].copy()
    checked["timestamp"] = pd.to_datetime(checked["timestamp"], utc=True, errors="coerce")
    for column in ("open", "high", "low", "close"):
        checked[column] = pd.to_numeric(checked[column], errors="coerce")
    checked = checked.dropna().sort_values("timestamp").reset_index(drop=True)
    if checked["timestamp"].duplicated().any():
        raise MLDataQualityError("طوابع زمنية مكررة؛ لا يمكن بناء هدف زمني آمن")
    if (checked[["open", "high", "low", "close"]] <= 0).any().any():
        raise MLDataQualityError("قيم OHLC غير موجبة")
    if (checked["high"] < checked[["open", "close", "low"]].max(axis=1)).any() or (
        checked["low"] > checked[["open", "close", "high"]].min(axis=1)
    ).any():
        raise MLDataQualityError("صفوف OHLC غير صالحة")

    gaps = checked["timestamp"].diff().dt.total_seconds().div(60)
    # لا نملأ الفجوات ولا نرفض التاريخ كاملاً بسببها: نقسمه إلى مقاطع مستقلة.
    # هذا يمنع كل مؤشر أو هدف مستقبلي من عبور توقف سوق أو فقد في المصدر.
    checked["segment_id"] = (gaps > spec.timeframe_minutes * 1.5).cumsum().astype(int)
    checked.attrs["gap_count"] = int((gaps > spec.timeframe_minutes * 1.5).sum())
    checked.attrs["largest_gap_minutes"] = float(gaps.max()) if gaps.notna().any() else 0.0
    if len(checked) < spec.train_bars_minimum:
        raise MLDataQualityError(
            f"العينة {len(checked)} أصغر من الحد الأدنى {spec.train_bars_minimum} شمعة"
        )
    return checked


def wilder_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    return 100 - (100 / (1 + gain.div(loss.replace(0, np.nan))))


def make_feature_frame(ohlc: pd.DataFrame, spec: ResearchSpec) -> pd.DataFrame:
    """يبني ميزات من الماضي فقط. لا توجد أي قيمة t+h في أعمدة الميزات."""
    frame = ohlc.copy()
    segment = frame["segment_id"]
    close = frame["close"]
    high, low = frame["high"], frame["low"]
    by_segment = frame.groupby("segment_id", group_keys=False)
    ema_fast = by_segment["close"].transform(lambda s: s.ewm(span=12, adjust=False, min_periods=12).mean())
    ema_slow = by_segment["close"].transform(lambda s: s.ewm(span=26, adjust=False, min_periods=26).mean())
    macd = ema_fast - ema_slow
    # يعاد بدء signal عند كل مقطع حتى لا تنتقل حالة المؤشر فوق فجوة بيانات.
    macd_signal = macd.groupby(segment, group_keys=False).transform(
        lambda s: s.ewm(span=9, adjust=False, min_periods=9).mean()
    )
    previous_close = by_segment["close"].shift(1)
    true_range = pd.concat(
        [high - low, (high - previous_close).abs(), (low - previous_close).abs()], axis=1
    ).max(axis=1)
    atr = true_range.groupby(segment, group_keys=False).transform(
        lambda s: s.ewm(alpha=1 / 14, adjust=False, min_periods=14).mean()
    )

    features = pd.DataFrame(
        {
            "timestamp": frame["timestamp"],
            "segment_id": segment,
            "ret_1": by_segment["close"].pct_change(1),
            "ret_4": by_segment["close"].pct_change(4),
            "ret_16": by_segment["close"].pct_change(16),
            "rsi_14": by_segment["close"].transform(wilder_rsi),
            "macd_hist": macd - macd_signal,
            "ema_gap_atr": (ema_fast - ema_slow).div(atr.replace(0, np.nan)),
            "atr_pct": atr.div(close),
            "range_atr": (high - low).div(atr.replace(0, np.nan)),
        }
    )
    # الهدف هو العائد اللاحق فقط؛ يعزل بوضوح عن الميزات السابقة.
    features["future_return"] = by_segment["close"].transform(
        lambda s: s.shift(-spec.horizon_bars).div(s).sub(1)
    )
    features["target_up"] = (features["future_return"] > 0).astype("float")
    return features.replace([np.inf, -np.inf], np.nan).dropna().reset_index(drop=True)


def chronological_splits(index: Iterable[int], folds: int = 3, purge_bars: int = 4):
    """تقسيم Walk-Forward مع purge يمنع هدف التدريب من ملامسة نافذة التقييم."""
    values = np.asarray(list(index))
    if len(values) < 100:
        raise MLDataQualityError("العينة بعد بناء الميزات أصغر من 100 صف")
    fold_size = len(values) // (folds + 1)
    for fold in range(folds):
        train_end = fold_size * (fold + 1)
        test_start = train_end + purge_bars
        test_end = min(test_start + fold_size, len(values))
        if test_end <= test_start:
            continue
        yield values[:train_end], values[test_start:test_end]


def summarize_oos_stability(folds: list[dict]) -> dict:
    """يلخص تباين النتائج بين طيات OOS؛ لا يساويه بثبات المعلمات النهائي."""
    summary = {}
    for metric in ("accuracy", "brier", "roc_auc"):
        values = [row[metric] for row in folds if row.get(metric) is not None]
        if values:
            summary[metric] = {
                "mean": float(np.mean(values)),
                "std": float(np.std(values, ddof=0)),
                "min": float(np.min(values)),
                "max": float(np.max(values)),
            }
    return summary


def _evaluate_model_across_folds(dataset: pd.DataFrame, feature_columns: list[str], prototype, spec: ResearchSpec) -> list[dict]:
    from sklearn.metrics import accuracy_score, brier_score_loss, roc_auc_score

    fold_rows = []
    for train_idx, test_idx in chronological_splits(dataset.index, purge_bars=spec.horizon_bars):
        train, test = dataset.iloc[train_idx], dataset.iloc[test_idx]
        model = prototype.__class__(**prototype.get_params())
        model.fit(train[feature_columns], train["target_up"].astype(int))
        probability = model.predict_proba(test[feature_columns])[:, 1]
        labels = test["target_up"].astype(int).to_numpy()
        prediction = (probability >= 0.5).astype(int)
        fold_rows.append(
            {
                "accuracy": float(accuracy_score(labels, prediction)),
                "brier": float(brier_score_loss(labels, probability)),
                "roc_auc": float(roc_auc_score(labels, probability)) if len(np.unique(labels)) == 2 else None,
                "observations": int(len(labels)),
            }
        )
    return fold_rows


def run_parameter_sensitivity(dataset: pd.DataFrame, feature_columns: list[str], spec: ResearchSpec) -> list[dict]:
    """يقارن نطاقاً صغيراً مثبتاً من المعاملات، لا بحثاً شاملاً ملائماً للماضي."""
    from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier

    candidates = [
        ("hist_gradient_depth_2", HistGradientBoostingClassifier(max_depth=2, learning_rate=0.05, random_state=7)),
        ("hist_gradient_depth_3", HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, random_state=7)),
        ("hist_gradient_depth_4", HistGradientBoostingClassifier(max_depth=4, learning_rate=0.05, random_state=7)),
        ("extra_trees_leaf_20", ExtraTreesClassifier(n_estimators=150, min_samples_leaf=20, max_features="sqrt", random_state=7, n_jobs=-1)),
        ("extra_trees_leaf_40", ExtraTreesClassifier(n_estimators=150, min_samples_leaf=40, max_features="sqrt", random_state=7, n_jobs=-1)),
        ("extra_trees_leaf_80", ExtraTreesClassifier(n_estimators=150, min_samples_leaf=80, max_features="sqrt", random_state=7, n_jobs=-1)),
    ]
    results = []
    for name, prototype in candidates:
        folds = _evaluate_model_across_folds(dataset, feature_columns, prototype, spec)
        results.append(
            {
                "candidate": name,
                "parameters": prototype.get_params(),
                "folds": folds,
                "oos_stability": summarize_oos_stability(folds),
            }
        )
    return results


def run_tree_benchmark(ohlc: pd.DataFrame, spec: ResearchSpec, include_parameter_sensitivity: bool = False) -> dict:
    """يقارن خط أساس ونموذجين شجريين؛ لا يدعي فوز نموذج قبل OOS كامل."""
    from sklearn.ensemble import ExtraTreesClassifier, HistGradientBoostingClassifier
    from sklearn.metrics import accuracy_score, brier_score_loss, roc_auc_score

    checked = validate_spot_ohlc(ohlc, spec)
    dataset = make_feature_frame(checked, spec)
    feature_columns = [c for c in dataset.columns if c not in ("timestamp", "segment_id", "future_return", "target_up")]
    results = []
    models = {
        "baseline_persistence": None,
        "hist_gradient_boosting": HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, random_state=7),
        "extra_trees": ExtraTreesClassifier(
            n_estimators=300, min_samples_leaf=40, max_features="sqrt", random_state=7, n_jobs=-1
        ),
    }
    for name, prototype in models.items():
        fold_rows = []
        for train_idx, test_idx in chronological_splits(dataset.index, purge_bars=spec.horizon_bars):
            train, test = dataset.iloc[train_idx], dataset.iloc[test_idx]
            if prototype is None:
                # خط أساس معلوم: اتجاه آخر عائد فقط، لا تعلم أو تسرب.
                probability = (test["ret_1"] > 0).astype(float).clip(0.05, 0.95).to_numpy()
            else:
                model = prototype.__class__(**prototype.get_params())
                model.fit(train[feature_columns], train["target_up"].astype(int))
                probability = model.predict_proba(test[feature_columns])[:, 1]
            labels = test["target_up"].astype(int).to_numpy()
            prediction = (probability >= 0.5).astype(int)
            fold_rows.append(
                {
                    "accuracy": float(accuracy_score(labels, prediction)),
                    "brier": float(brier_score_loss(labels, probability)),
                    "roc_auc": float(roc_auc_score(labels, probability)) if len(np.unique(labels)) == 2 else None,
                    "observations": int(len(labels)),
                }
            )
        results.append({"model": name, "folds": fold_rows, "oos_stability": summarize_oos_stability(fold_rows)})
    result = {
        "research_spec": asdict(spec),
        "data_hash": dataframe_hash(checked),
        "rows_after_features": int(len(dataset)),
        "data_gaps": {
            "segment_count": int(checked["segment_id"].nunique()),
            "gap_count": checked.attrs["gap_count"],
            "largest_gap_minutes": checked.attrs["largest_gap_minutes"],
            "policy": "لا تُملأ الفجوات؛ الميزات والأهداف لا تعبر المقاطع",
        },
        "feature_columns": feature_columns,
        "models": results,
        "classification": "RESEARCH_ONLY — لا توجد معايرة احتمالات أو تكاليف أو بيانات وسيط تنفيذية بعد",
    }
    if include_parameter_sensitivity:
        result["parameter_sensitivity"] = run_parameter_sensitivity(dataset, feature_columns, spec)
    return result
