"""مقارنة مرشحات RSI وEMA20/EMA50 لاستراتيجية OB+FVG على 4 ساعات في 2025.

كل المتغيرات تستخدم نسخة الشموع نفسها ونفس الإحماء والأفق وفجوة الرقابة ونقاط القرار.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from mt5_price_connector import MT5PriceConnector
from ob_fvg_strategy import backtest_ob_fvg_strategy


YEAR_START = pd.Timestamp("2025-01-01", tz="UTC")
YEAR_END = pd.Timestamp("2026-01-01", tz="UTC")
FILTERS = {
    "none": "الأساس — دون مرشح إضافي",
    "rsi": "RSI(14) اتجاهي",
    "ma": "اتجاه EMA20/EMA50",
    "rsi_ma": "RSI + EMA20/EMA50",
}
OUTPUT_JSON = Path(__file__).with_name("ob_fvg_2025_4h_filter_comparison.json")
OUTPUT_MD = Path(__file__).with_name("ob_fvg_2025_4h_filter_comparison.md")


def ensure_utc(frame: pd.DataFrame) -> pd.DataFrame:
    clean = frame.copy()
    if clean.index.tz is None:
        clean.index = clean.index.tz_localize("UTC")
    else:
        clean.index = clean.index.tz_convert("UTC")
    return clean.sort_index()


def value(item: object, suffix: str = "") -> str:
    return "—" if item is None else f"{item}{suffix}"


def report(results: dict[str, dict], frame: pd.DataFrame) -> str:
    lines = [
        "# مقارنة مرشحات RSI والمتوسطات — OB+FVG على إطار 4 ساعات، سنة 2025",
        "",
        "## عقد المقارنة",
        "",
        "استُخدمت شموع Yahoo Finance المرجعية للرمز GC=F للفترة من 2025-01-01 (شامل) إلى 2026-01-01 (غير شامل). كل الصفوف أدناه تعتمد على نسخة الشموع نفسها وعدد شموع الإحماء 180، وفجوة رقابة شمعة واحدة، وأفق 12 شمعة، و500 نقطة قرار كحد أقصى. لا يسمح المرشح بأي شموع بعد نقطة القرار.",
        "",
        "| المتغير | القاعدة الإضافية | الإعدادات المؤهلة | استُبعدت بالمرشح | صفقات مملوءة | رابحة | خاسرة | نسبة النجاح | إجمالي الربح (R) | إجمالي الخسارة (R) | الصافي (R) | معامل الربح |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for mode, label in FILTERS.items():
        item = results[mode]
        metrics = item["metrics"]
        lines.append(
            "| {label} | {rule} | {eligible} | {filtered} | {filled} | {wins} | {losses} | {win_rate} | {gross_profit} | {gross_loss} | {total} | {profit_factor} |".format(
                label=label,
                rule=item["methodology"]["filter_rule"],
                eligible=metrics["eligible_setups"],
                filtered=metrics["filtered_out_setups"],
                filled=metrics["filled_trades"],
                wins=metrics["wins"],
                losses=metrics["losses"],
                win_rate=value(metrics["win_rate_pct"], "%"),
                gross_profit=value(metrics["gross_profit_r"]),
                gross_loss=value(metrics["gross_loss_r"]),
                total=value(metrics["total_r"]),
                profit_factor=value(metrics["profit_factor"]),
            )
        )
    lines.extend([
        "",
        "## تعريف المرشحات",
        "",
        "مرشح RSI يقبل الشراء عندما يكون RSI(14) بين 50 و70، والبيع عندما يكون بين 30 و50؛ ويستبعد المطاردة في التشبع. مرشح المتوسطات يقبل الشراء فقط عندما يكون السعر أعلى EMA20 وأعلى EMA50 مع EMA20 أعلى EMA50، والعكس للبيع. المرشح المركب يطلب الشرطين معاً.",
        "",
        "## القيود والإفصاح",
        "",
        f"بلغ عدد شموع 4 ساعات المستخدمة {len(frame)}، وأولها {frame.index.min()} وآخرها {frame.index.max()}. كل النتائج بوحدة R وليست دولاراً؛ ولا تشمل السبريد أو الانزلاق أو العمولة أو حجم العقد أو أي تدفق أوامر حقيقي. هذا اختبار استكشافي لأربعة متغيرات على سنة واحدة، لذلك لا يصلح اختيار أفضل متغير منه وحده كدليل أداء مثبت؛ يلزم اختبار خارج العينة قبل الاعتماد عليه. هذه نتائج بحث وتحليل فقط وليست نصيحة مالية شخصية.",
        "",
        "[1]: https://finance.yahoo.com/quote/GC%3DF/history/ \"Yahoo Finance — GC=F historical data\"",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    connector = MT5PriceConnector()
    frame = ensure_utc(connector.fetch_ohlc_between(YEAR_START, YEAR_END, interval="4h"))
    frame = frame.loc[(frame.index >= YEAR_START) & (frame.index < YEAR_END)].copy()
    if frame.empty or frame.index.min() > YEAR_START + pd.Timedelta(days=7) or frame.index.max() < YEAR_END - pd.Timedelta(days=7):
        raise RuntimeError("مصدر الشموع المرجعية لا يغطي سنة 2025 كاملة لإطار 4 ساعات؛ أوقف المقارنة بدلاً من استخدام نطاق ناقص.")
    results = {
        mode: backtest_ob_fvg_strategy(
            frame,
            warmup_bars=180,
            horizon_bars=12,
            censor_gap_bars=1,
            evaluation_stride=1,
            max_evaluation_points=500,
            signal_lookback_bars=600,
            trade_output_limit=None,
            filter_mode=mode,
        )
        for mode in FILTERS
    }
    payload = {
        "data_contract": {
            "source": "Yahoo Finance GC=F reference candles",
            "source_symbol": "GC=F",
            "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive",
            "timeframe": "4h",
            "bars": len(frame),
            "first_candle": str(frame.index.min()),
            "last_candle": str(frame.index.max()),
            "reference_only": True,
        },
        "results": results,
    }
    OUTPUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    OUTPUT_MD.write_text(report(results, frame), encoding="utf-8")
    for mode, result in results.items():
        metrics = result["metrics"]
        print(f"{mode}: filled={metrics['filled_trades']} wins={metrics['wins']} losses={metrics['losses']} total_r={metrics['total_r']}")
    print(f"JSON={OUTPUT_JSON}")
    print(f"REPORT={OUTPUT_MD}")


if __name__ == "__main__":
    main()
