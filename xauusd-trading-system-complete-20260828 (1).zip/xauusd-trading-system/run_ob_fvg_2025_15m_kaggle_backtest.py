"""اختبار OB+FVG على بيانات XAUUSD العامة ذات 15 دقيقة لعام 2025.

يقرأ ملفاً تاريخياً خاماً كاملاً؛ لا يركب شموعاً من أسعار أخرى ولا ينفذ تداولاً.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy


SOURCE_CSV = Path("/tmp/XAU_15m_data.csv")
OUTPUT_JSON = Path(__file__).with_name("ob_fvg_2025_15m_backtest_results.json")
OUTPUT_MD = Path(__file__).with_name("ob_fvg_2025_15m_backtest_report.md")
START = pd.Timestamp("2025-01-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")


def load_2025_frame() -> pd.DataFrame:
    if not SOURCE_CSV.exists():
        raise RuntimeError("ملف XAUUSD بدقة 15 دقيقة غير موجود محلياً؛ لا يبدأ الاختبار ببيانات بديلة أو ناقصة.")
    raw = pd.read_csv(SOURCE_CSV, sep=";")
    required = {"Date", "Open", "High", "Low", "Close", "Volume"}
    missing = required.difference(raw.columns)
    if missing:
        raise RuntimeError(f"ملف 15 دقيقة يفتقد الحقول: {', '.join(sorted(missing))}")
    index = pd.to_datetime(raw["Date"], format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    frame = raw.loc[:, ["Open", "High", "Low", "Close", "Volume"]].apply(pd.to_numeric, errors="coerce")
    frame.index = index
    frame = frame.dropna(subset=["Open", "High", "Low", "Close"]).sort_index()
    frame = frame.loc[(frame.index >= START) & (frame.index < END)].copy()
    if frame.empty or frame.index.min() > START + pd.Timedelta(days=5) or frame.index.max() < END - pd.Timedelta(days=5):
        raise RuntimeError("ملف 15 دقيقة لا يغطي سنة 2025 كاملة بما يكفي للاختبار؛ لا تستخدم نافذة جزئية كأنها سنة كاملة.")
    return frame


def report(result: dict, frame: pd.DataFrame) -> str:
    metrics, methodology = result["metrics"], result["methodology"]
    return f"""# اختبار تاريخي لاستراتيجية Order Block + Fair Value Gap — 15 دقيقة، سنة 2025

## النطاق والمنهجية

استُخدمت شموع XAUUSD التاريخية ذات 15 دقيقة للفترة من 2025-01-01 (شامل) إلى 2026-01-01 (غير شامل). قرار كل إشارة يعتمد فقط على الشموع المتاحة حتى نقطة القرار؛ يبدأ تقييم ملامسة منطقة الدخول بعد فجوة رقابة شمعة واحدة. أفق التقييم 12 شمعة، أي 3 ساعات. إذا لمس السعر الوقف والهدف في الشمعة نفسها، تُسجل الخسارة بصورة تحفظية لغياب ترتيب الحركة داخل الشمعة.

| الشموع | نقاط القرار | إعدادات مؤهلة | صفقات مملوءة | رابحة | خاسرة | نسبة النجاح | إجمالي الربح (R) | إجمالي الخسارة (R) | الصافي (R) | متوسط R | معامل الربح |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| {len(frame)} | {metrics.get('decision_points')} | {metrics.get('eligible_setups')} | {metrics.get('filled_trades')} | {metrics.get('wins')} | {metrics.get('losses')} | {metrics.get('win_rate_pct')}% | {metrics.get('gross_profit_r')} | {metrics.get('gross_loss_r')} | {metrics.get('total_r')} | {metrics.get('average_r')} | {metrics.get('profit_factor')} |

## عقد المصدر

| الحقل | القيمة |
| --- | --- |
| المصدر | مجموعة Kaggle عامة: XAU/USD Gold Price Historical Data (الإصدار 11) |
| الأصل | XAUUSD التاريخي، 15 دقيقة |
| أول شمعة مستخدمة | {frame.index.min()} |
| آخر شمعة مستخدمة | {frame.index.max()} |
| المنطقة الزمنية | طُبّعت إلى UTC للفصل الزمني؛ منطقة الملف الأصلية غير موثقة |
| نوع الحجم | Volume كما يورده الملف؛ لا يُفسر كـ Order Flow أو حجم تداول حقيقي |

## القيود والإفصاح

النتائج بوحدة R، لا بالدولار ولا تمثل أداء حساب تداول. لا تشمل السبريد أو الانزلاق أو العمولة أو حجم العقد أو فروق الوسيط. حد الاختبار إلى {methodology.get('max_evaluation_points')} نقطة قرار موزعة عبر السنة، لذا فهو عينة زمنية منضبطة لا مسحاً لكل إشارة. لا تعتبر النتيجة دليلاً على أداء مثبت ما لم تتجاوز العينة 20 صفقة مملوءة ثم تُختبر خارج العينة. هذه نتائج بحث وتحليل فقط وليست نصيحة مالية شخصية.

[1]: https://www.kaggle.com/datasets/novandraanugrah/xauusd-gold-price-historical-data-2004-2024 "Kaggle — XAU/USD Gold Price Historical Data"
"""


def main() -> None:
    frame = load_2025_frame()
    result = backtest_ob_fvg_strategy(
        frame,
        warmup_bars=180,
        horizon_bars=12,
        censor_gap_bars=1,
        evaluation_stride=1,
        max_evaluation_points=500,
        signal_lookback_bars=600,
        trade_output_limit=None,
    )
    payload = {
        "data_contract": {
            "source": "Kaggle public XAU/USD historical dataset, version 11",
            "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive",
            "timeframe": "15m",
            "bars": len(frame),
            "first_candle": str(frame.index.min()),
            "last_candle": str(frame.index.max()),
            "source_timezone": "undocumented; normalized to UTC for time slicing",
            "reference_only": True,
        },
        "result": result,
    }
    OUTPUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    OUTPUT_MD.write_text(report(result, frame), encoding="utf-8")
    metrics = result["metrics"]
    print(f"filled={metrics.get('filled_trades')} wins={metrics.get('wins')} losses={metrics.get('losses')} win_rate={metrics.get('win_rate_pct')} total_r={metrics.get('total_r')}")
    print(f"JSON={OUTPUT_JSON}")
    print(f"REPORT={OUTPUT_MD}")


if __name__ == "__main__":
    main()
