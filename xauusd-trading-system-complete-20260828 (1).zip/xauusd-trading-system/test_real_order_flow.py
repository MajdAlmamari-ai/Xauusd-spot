"""اختبار أن تدفق السيولة الحقيقي لا يُنشأ من الشموع ولا يسمح بإشارة مخالفة لتدفق موثق."""

from mt5_price_connector import MT5PriceConnector
from production_server import integrated_recommendation


def technical_fixture() -> dict:
    return {
        "technical_signal": "شراء",
        "evidence_strength": {"score": 72.0, "label": "قوة أدلة متوسطة", "is_probability": False},
        "latest": 100.0,
        "atr": 2.0,
        "rsi": 58.0,
        "macd_histogram": 1.0,
        "data_contract": {"instrument": "XAUUSD", "price_basis": "broker_spot"},
        "data_quality": {"valid": True},
        "indicators": [{"name": "ROC", "value": 1.0}, {"name": "ADX(14)", "value": 30.0}],
        "advanced_tools": {
            "confluence": {"bias": "توافق صاعد", "qualified_tools": 4},
            "multi_timeframe": {"status": "متوافق"},
            "tools": {"support_resistance": {"qualified": True, "levels": {"دعم 1": 96.0, "مقاومة 1": 108.0}}},
        },
    }


def main() -> None:
    missing = MT5PriceConnector(bridge_url="").fetch_order_flow()
    assert missing["eligible_for_decision"] is False
    assert missing["status"] == "غير متاح"

    bridge = MT5PriceConnector(bridge_url="http://verified-bridge.example")
    bridge._bridge_request = lambda path, params: {
        "status": "success", "bid": 2300.0, "ask": 2300.2, "age_seconds": 1.5,
        "dom": [{"side": "bid", "price": 2300.0, "volume": 140}, {"side": "ask", "price": 2300.2, "volume": 80}],
        "trades": [{"side": "buy", "volume": 95}, {"side": "sell", "volume": 45}], "utc_time": "2026-08-23T21:00:00Z",
    }
    verified = bridge.fetch_order_flow()
    assert verified["eligible_for_decision"] is True, verified
    assert verified["bias"] == "شراء", verified

    quote = {"status": "success", "stale": False, "live_for_analysis": True, "tradable": False, "instrument": "XAUUSD", "price_basis": "broker_spot"}
    liquidity = {"liquidity_score": 70, "trap_detected": False}
    news = {"status": "ok", "pending_event": False, "message": "لا فلتر"}
    valid_opposing_flow = {"status": "متاح ومتحقق", "eligible_for_decision": True, "bias": "بيع", "confidence": 75.0}
    result = integrated_recommendation(quote, technical_fixture(), liquidity, news, valid_opposing_flow)
    assert result["signal"] == "انتظار / حياد", result
    assert result["real_order_flow"]["eligible_for_decision"] is True
    print("نجحت اختبارات تدفق السيولة الحقيقي وحجب التدفق المعاكس.")


if __name__ == "__main__":
    main()
