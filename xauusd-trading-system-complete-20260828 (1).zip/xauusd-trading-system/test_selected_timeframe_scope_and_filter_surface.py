from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = (
        "selectedFramePayload=null",
        "function renderSelectedFrameAnalysis(payload)",
        "renderTechnical(frame.technical,frame)",
        "renderSignalLayers(frame.signal_layers)",
        "window.renderObFvgStrategy?.(frame.ob_fvg_strategy,frame)",
        "renderRecommendation(recommendation)",
        "renderSelectedFrameContext(frame,recommendation)",
        "selectedFramePayload.timeframe?.id!==selectedTimeframe",
        "TIMEFRAME_FILTER_KEY='xauusd-evaluation-timeframes-v1'",
        "TIMEFRAME_FILTER_LIMIT=9",
        "function readTimeframeFilter(rows)",
        "اختر تسعة أطر بالضبط قبل الحفظ.",
        "id=\"timeframeFilterToggle\"",
        "id=\"selectedFrameContext\"",
        "filter=overview.querySelector('#timeframeFilterPanel')",
    )
    for item in required:
        assert item in SOURCE, item
    print("PASS: selected timeframe owns the analysis pipeline and the evaluation filter persists exactly nine frames")


if __name__ == "__main__":
    main()
