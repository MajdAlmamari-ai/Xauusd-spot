"""اختبار عقد مناطق السيولة وOrder Blocks من شموع تاريخية فعلية."""

from market_structure_tools import liquidity_zones, order_blocks
from mt5_price_connector import MT5PriceConnector


def validate_zones(result: dict) -> None:
    assert {"status", "bias", "details", "zones", "quality_score", "qualified"}.issubset(result)
    for zone in result["zones"]:
        assert zone["lower"] < zone["upper"]
        assert zone["start_time"] <= zone["end_time"]
        assert 0 <= zone["quality_score"] <= 100
        assert isinstance(zone["qualified"], bool)


def main() -> None:
    frame = MT5PriceConnector().fetch_ohlc(period="2y", interval="1d")
    assert len(frame) >= 100
    liquidity = liquidity_zones(frame)
    blocks = order_blocks(frame)
    validate_zones(liquidity)
    validate_zones(blocks)
    print(f"نجح اختبار مناطق السيولة ({len(liquidity['zones'])}) وOrder Blocks ({len(blocks['zones'])}) من بيانات تاريخية.")


if __name__ == "__main__":
    main()
