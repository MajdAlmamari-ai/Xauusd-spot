#!/usr/bin/env python3
"""
محرك التحليل متعدد المدارس (Multi-School Synthesis Engine) لزوج XAUUSD
"""

class MultiSchoolEngine:
    def __init__(self):
        # أوزان المدارس التحليلية
        self.weights = {
            "price_action": 0.25,
            "momentum": 0.20,
            "volatility": 0.20,
            "macro": 0.20,
            "institutional": 0.15
        }

    def analyze_market(self, current_price, rsi, macd, dxy_trend="Neutral", cot_net=147200, high_impact_news=False):
        """
        دمج إشارات المدارس الخمس وإصدار التوصية النهائية مع درجة الثقة والأسباب
        """
        if high_impact_news:
            return {
                "consensus_signal": "NO TRADE (أخبار عالية التأثير)",
                "confidence": 0.0,
                "school_breakdown": {},
                "reasons": ["قفل أمان الأخبار: توجد بيانات اقتصادية حساسة حالياً."]
            }

        scores = {"BUY": 0.0, "SELL": 0.0, "NEUTRAL": 0.0}
        reasons = []

        # 1. مدرسة السعر والسيولة (Price Action)
        if current_price > 4300:
            scores["BUY"] += self.weights["price_action"] * 0.7
            scores["SELL"] += self.weights["price_action"] * 0.3
            reasons.append("مدرسة السعر والسيولة: السعر فوق مستويات الدعم المحورية، مع وجود سيولة شرائية تدعم الارتداد.")
        else:
            scores["SELL"] += self.weights["price_action"] * 0.6
            scores["BUY"] += self.weights["price_action"] * 0.4
            reasons.append("مدرسة السعر والسيولة: ضغط بيعي قرب المقاومات الرئيسية واختبار لمناطق سيولة سفلية.")

        # 2. مدرسة الزخم والاتجاه (Momentum)
        if rsi < 40:
            scores["BUY"] += self.weights["momentum"] * 0.8
            reasons.append(f"مدرسة الزخم (RSI={rsi:.1f}): تشبع بيعي ملحوظ يزيد من احتمالية الارتداد الصعودي.")
        elif rsi > 60:
            scores["SELL"] += self.weights["momentum"] * 0.8
            reasons.append(f"مدرسة الزخم (RSI={rsi:.1f}): تشبع شرائي ملحوظ يزيد من احتمالية التصحيح.")
        else:
            scores["NEUTRAL"] += self.weights["momentum"] * 0.5
            reasons.append(f"مدرسة الزخم (RSI={rsi:.1f}): الزخم في نطاق حيادي متوازن.")

        # 3. مدرسة التقلب وبنية السوق (Volatility)
        scores["BUY"] += self.weights["volatility"] * 0.5
        scores["SELL"] += self.weights["volatility"] * 0.5
        reasons.append("مدرسة التقلب: نطاق التذبذب اليومي (ATR) ضمن المستويات الطبيعية، مع مناسبة الأهداف مع وقف الخسارة.")

        # 4. مدرسة الاقتصاد الكلي والأخبار (Macro)
        if dxy_trend == "Weak":
            scores["BUY"] += self.weights["macro"] * 0.9
            reasons.append("مدرسة الاقتصاد الكلي: مؤشر الدولار (DXY) في مسار ضعيف، وهو ما يدعم عادة ارتفاع الذهب.")
        else:
            scores["SELL"] += self.weights["macro"] * 0.6
            reasons.append("مدرسة الاقتصاد الكلي: بيئة أسعار الفائدة والتقلبات الكلية تحافظ على جاذبية الأصول المقومة بالدولار نسبياً.")

        # 5. مدرسة التدفقات المؤسسية (Institutional Flows)
        if cot_net > 0:
            scores["BUY"] += self.weights["institutional"] * 0.8
            reasons.append(f"مدرسة التدفقات المؤسسية: صافي مراكز الصناديق الكبرى (COT) إيجابي بمقدار +{cot_net} عقد.")
        else:
            scores["SELL"] += self.weights["institutional"] * 0.7
            reasons.append("مدرسة التدفقات المؤسسية: مراكز الصناديق تميل نحو تقليص المخاطر أو التحوط السلبي.")

        # تحديد التوصية النهائية بالإجماع
        max_score_key = max(scores, key=scores.get)
        total_weight_sum = sum(scores.values())
        confidence = round((scores[max_score_key] / total_weight_sum) * 100, 1) if total_weight_sum > 0 else 50.0

        if confidence < 55.0:
            final_signal = "NEUTRAL / HOLD (تعارض أو حياد المدارس)"
        elif max_score_key == "BUY":
            final_signal = "BUY (إجماع متعدد المدارس)"
        elif max_score_key == "SELL":
            final_signal = "SELL (إجماع متعدد المدارس)"
        else:
            final_signal = "NEUTRAL"

        return {
            "consensus_signal": final_signal,
            "confidence": confidence,
            "school_scores": {k: round(v * 100, 1) for k, v in scores.items()},
            "reasons": reasons
        }

if __name__ == "__main__":
    engine = MultiSchoolEngine()
    print(engine.analyze_market(4319.50, 38.5, 1.2, "Weak", 147200, False))
