# نتيجة بحث مصدر OHLC للذهب الفوري XAU/USD

## النتيجة

لا يصح استخدام Yahoo Finance `GC=F` لرسم **XAU/USD Spot** لأنه عقد آجِل. كما أن `gold-api.com` المستخدم حالياً يقدّم سعر سوق عام حالياً فقط ولا يقدّم شموع OHLC متعددة الأطر.

المصدر المرشح هو **Twelve Data**: صفحة الأداة تسميه صراحةً **Gold Spot / US Dollar — XAU/USD** وتعرض أطر 1m و5m و15m و30m و1h و2h و4h ويومي وأسبوعي وشهري. توثيقه يذكر أن `/time_series` يعيد OHLC ويقبل أطر 1min و5min و15min و30min و1h و2h و4h و1day و1week و1month، لكنه يتطلب مفتاح API؛ صفحة الأداة تقول إن الوصول للـAPI يبدأ من Basic plan.[1][2]

## القرار الهندسي

1. يبقى `gold-api.com` في `LivePriceProvider` فقط، ولا يُستخدم لبناء شمعة أو اختبار تاريخي.
2. يستبدل `YahooFinanceHistoricalDataProvider` بـ`TwelveDataSpotHistoricalDataProvider` بعد توفر مفتاح صالح وتحقق أولي من رمز `XAU/USD` وتغطية الخطة.
3. في حالة فشل Twelve Data أو رفض الخطة لإطار ما، تعرض المنصة `TIMEFRAME DATA UNAVAILABLE` ولا تعود إلى `GC=F` بصمت ولا تصنع شموعاً.
4. لا يعدّل التحليل أو الرسم قبل نجاح اختبار OHLC الفعلي، والتحقق من الطوابع والتغطية والسعر المرجعي.

## ملاحظة حول GoldAPI.io

تعلن GoldAPI.io عن بيانات تاريخية يومية وأسعار Spot حية، ولكنها ليست `gold-api.com` المربوط حالياً ولا تثبت وحدها توافر OHLC داخل اليوم المجاني المطلوب للرسم متعدد الأطر.[3]

## المراجع

[1] [Twelve Data — Gold Spot / US Dollar (XAU/USD)](https://twelvedata.com/markets/300755/commodity/xau-usd/historical-data)

[2] [Twelve Data — Time Series API](https://twelvedata.com/docs)

[3] [GoldAPI.io — Historical XAU/USD](https://www.goldapi.io/price/XAU/USD/historical)
