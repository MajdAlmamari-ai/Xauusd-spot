#!/usr/bin/env python3
"""Deterministic audit for HistData ASCII XAUUSD M1 files."""
from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
FILES = sorted(BASE.glob("*/DAT_ASCII_XAUUSD_M1_*.csv"), key=lambda p: p.stem)


def parse_dt(date_text: str, time_text: str) -> datetime:
    source_tz = timezone(timedelta(hours=-5), name="HistData-EST-no-DST")
    return datetime.strptime(date_text + time_text, "%Y%m%d%H%M%S").replace(tzinfo=source_tz).astimezone(timezone.utc)


def audit(path: Path) -> dict:
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    rows = []
    bad = []
    with path.open("r", newline="", encoding="utf-8") as fh:
        for line_no, line in enumerate(fh, 1):
            parts = line.rstrip("\r\n").split(";")
            if len(parts) != 6:
                bad.append({"line": line_no, "reason": "column_count", "raw": line[:160]})
                continue
            try:
                dt = parse_dt(parts[0][:8], parts[0][9:])
                o, h, l, c = (float(x) for x in parts[1:5])
                volume = int(float(parts[5]))
            except Exception as exc:
                bad.append({"line": line_no, "reason": type(exc).__name__, "raw": line[:160]})
                continue
            rows.append({"dt": dt, "o": o, "h": h, "l": l, "c": c, "volume": volume})

    source_timestamps = [r["dt"] for r in rows]
    timestamps = sorted(source_timestamps)
    diffs = [int((b - a).total_seconds()) for a, b in zip(timestamps, timestamps[1:])]
    duplicates = sum(count - 1 for count in Counter(timestamps).values() if count > 1)
    chronology_violations = sum(1 for d in diffs if d <= 0)
    exact_m1 = sum(1 for d in diffs if d == 60)
    gaps = [d for d in diffs if d > 60]
    negative_or_zero = [d for d in diffs if d <= 0]
    ohlc_bad = [r for r in rows if not (r["h"] >= max(r["o"], r["c"]) and r["l"] <= min(r["o"], r["c"]) and r["h"] >= r["l"])]
    zero_volume = sum(1 for r in rows if r["volume"] == 0)
    report_file = path.with_suffix(".txt")
    return {
        "file": str(path),
        "sha256": sha,
        "rows": len(rows),
        "bad_rows": len(bad),
        "first_timestamp_utc": timestamps[0].isoformat() if timestamps else None,
        "last_timestamp_utc": timestamps[-1].isoformat() if timestamps else None,
        "unique_days": len({x.date().isoformat() for x in timestamps}),
        "duplicate_timestamps": duplicates,
        "chronology_violations_in_file_order": sum(1 for a, b in zip(source_timestamps, source_timestamps[1:]) if b <= a),
        "chronology_violations": chronology_violations,
        "exact_60_second_intervals": exact_m1,
        "gaps_over_60_seconds": len(gaps),
        "max_gap_seconds": max(gaps) if gaps else 0,
        "missing_one_minute_slots_from_gaps": sum(max(0, (d // 60) - 1) for d in gaps),
        "non_positive_intervals": negative_or_zero[:10],
        "ohlc_integrity_errors": len(ohlc_bad),
        "zero_volume_rows": zero_volume,
        "volume_values": sorted({r["volume"] for r in rows})[:20],
        "status_report": report_file.read_text(encoding="utf-8", errors="replace") if report_file.exists() else "",
        "first_rows": [{k: (v.isoformat() if k == "dt" else v) for k, v in r.items()} for r in sorted(rows, key=lambda x: x["dt"])[:2]],
        "last_rows": [{k: (v.isoformat() if k == "dt" else v) for k, v in r.items()} for r in sorted(rows, key=lambda x: x["dt"])[-2:]],
    }


def main() -> None:
    results = [audit(path) for path in FILES]
    all_paths = [path for path in FILES]
    boundary = {}
    for left, right in zip(results, results[1:]):
        left_last = datetime.fromisoformat(left["last_timestamp_utc"])
        right_first = datetime.fromisoformat(right["first_timestamp_utc"])
        boundary[f"{Path(left['file']).parent.name}_to_{Path(right['file']).parent.name}"] = {
            "last_to_first_seconds": int((right_first - left_last).total_seconds()),
            "last_file_timestamp": left["last_timestamp_utc"],
            "next_file_timestamp": right["first_timestamp_utc"],
        }
    output = {"files": results, "month_boundaries": boundary, "file_count": len(all_paths)}
    out = BASE / "audit_result.json"
    out.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"file_count": len(results), "month_boundaries": boundary, "output": str(out)}, ensure_ascii=False))
    for item in results:
        print(json.dumps({k: item[k] for k in ("file", "sha256", "rows", "bad_rows", "first_timestamp_utc", "last_timestamp_utc", "duplicate_timestamps", "chronology_violations_in_file_order", "chronology_violations", "exact_60_second_intervals", "gaps_over_60_seconds", "max_gap_seconds", "missing_one_minute_slots_from_gaps", "ohlc_integrity_errors", "zero_volume_rows")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
