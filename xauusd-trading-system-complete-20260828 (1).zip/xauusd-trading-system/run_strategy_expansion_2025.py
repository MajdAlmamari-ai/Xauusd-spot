"""مقارنة موسعة قابلة لإعادة الإنتاج لاستراتيجيات XAUUSD على مشاهدات 2025 المتاحة.

الدخول في افتتاح الشمعة التالية، والوقف المحافظ يحكم حالة لمس الهدف والوقف في الشمعة ذاتها.
لا تعبر أي صفقة فجوة بيانات تتجاوز سبعة أيام، ولا تستخدم نتائج H2 لاختيار معلمات جديدة.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy


SOURCE = Path("/tmp/XAU_15m_data.csv")
OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2025_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_expansion_2025_report.md")
START = pd.Timestamp("2025-01-01", tz="UTC")
SPLIT = pd.Timestamp("2025-07-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")
HORIZON_BARS = 12
MAX_GAP = pd.Timedelta(days=7)
MIN_TRADES = 20
WARMUP_BARS = 220


def load_base() -> pd.DataFrame:
    raw = pd.read_csv(SOURCE, sep=";")
    index = pd.to_datetime(raw.pop("Date"), format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    raw.columns = [str(column).title() for column in raw.columns]
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = index
    return raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index().loc[START:END - pd.Timedelta(nanoseconds=1)]


def resample(frame: pd.DataFrame, rule: str) -> pd.DataFrame:
    return frame.resample(rule, label="left", closed="left").agg({"Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"}).dropna()


def split_segments(frame: pd.DataFrame) -> list[pd.DataFrame]:
    boundaries = frame.index.to_series().diff().gt(MAX_GAP).cumsum()
    return [part.copy() for _, part in frame.groupby(boundaries) if len(part) > WARMUP_BARS + HORIZON_BARS]


def add_indicators(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    previous = out["Close"].shift(1)
    true_range = pd.concat([out["High"] - out["Low"], (out["High"] - previous).abs(), (out["Low"] - previous).abs()], axis=1).max(axis=1)
    out["ATR"] = true_range.rolling(14, min_periods=14).mean()
    out["EMA20"] = out["Close"].ewm(span=20, adjust=False, min_periods=20).mean()
    out["EMA50"] = out["Close"].ewm(span=50, adjust=False, min_periods=50).mean()
    out["EMA200"] = out["Close"].ewm(span=200, adjust=False, min_periods=200).mean()
    delta = out["Close"].diff()
    for period, key in ((14, "RSI14"), (2, "RSI2")):
        gain = delta.clip(lower=0).rolling(period, min_periods=period).mean()
        loss = (-delta.clip(upper=0)).rolling(period, min_periods=period).mean().replace(0, np.nan)
        out[key] = 100 - (100 / (1 + gain / loss))
    mid = out["Close"].rolling(20, min_periods=20).mean()
    deviation = out["Close"].rolling(20, min_periods=20).std(ddof=0)
    out["BB_UPPER"], out["BB_LOWER"] = mid + 2 * deviation, mid - 2 * deviation
    out["KC_UPPER"], out["KC_LOWER"] = out["EMA20"] + 1.5 * out["ATR"], out["EMA20"] - 1.5 * out["ATR"]
    out["DONCHIAN_HIGH"] = out["High"].shift(1).rolling(20, min_periods=20).max()
    out["DONCHIAN_LOW"] = out["Low"].shift(1).rolling(20, min_periods=20).min()
    out["RANGE"] = out["High"] - out["Low"]
    out["NR7"] = out["RANGE"].eq(out["RANGE"].rolling(7, min_periods=7).min())
    up_move, down_move = out["High"].diff(), -out["Low"].diff()
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    atr_sum = true_range.rolling(14, min_periods=14).sum().replace(0, np.nan)
    plus_di = 100 * pd.Series(plus_dm, index=out.index).rolling(14, min_periods=14).sum() / atr_sum
    minus_di = 100 * pd.Series(minus_dm, index=out.index).rolling(14, min_periods=14).sum() / atr_sum
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    out["ADX"] = dx.rolling(14, min_periods=14).mean()
    return out


def signals(frame: pd.DataFrame, name: str) -> pd.Series:
    current, prior = frame, frame.shift(1)
    up_trend, down_trend = current.EMA20 > current.EMA50, current.EMA20 < current.EMA50
    if name == "ema_pullback":
        long = up_trend & (current.Close <= current.EMA20) & (current.Close > current.EMA50)
        short = down_trend & (current.Close >= current.EMA20) & (current.Close < current.EMA50)
    elif name == "ema_adx_pullback":
        long = up_trend & (current.ADX >= 25) & (current.Close <= current.EMA20) & (current.Close > current.EMA50) & current.RSI14.between(45, 62)
        short = down_trend & (current.ADX >= 25) & (current.Close >= current.EMA20) & (current.Close < current.EMA50) & current.RSI14.between(38, 55)
    elif name == "donchian_breakout":
        long, short = current.Close > current.DONCHIAN_HIGH, current.Close < current.DONCHIAN_LOW
    elif name == "donchian_adx":
        long, short = (current.Close > current.DONCHIAN_HIGH) & (current.ADX >= 22), (current.Close < current.DONCHIAN_LOW) & (current.ADX >= 22)
    elif name == "rsi_bollinger":
        long, short = (current.RSI14 < 30) & (current.Close < current.BB_LOWER), (current.RSI14 > 70) & (current.Close > current.BB_UPPER)
    elif name == "rsi2_ema200":
        long, short = (current.Close > current.EMA200) & (current.RSI2 < 10), (current.Close < current.EMA200) & (current.RSI2 > 90)
    elif name == "keltner_breakout":
        long, short = (current.Close > current.KC_UPPER) & up_trend, (current.Close < current.KC_LOWER) & down_trend
    elif name == "squeeze_breakout":
        was_squeezed = (prior.BB_UPPER < prior.KC_UPPER) & (prior.BB_LOWER > prior.KC_LOWER)
        long, short = was_squeezed & (current.Close > current.BB_UPPER) & up_trend, was_squeezed & (current.Close < current.BB_LOWER) & down_trend
    elif name == "nr7_trend_breakout":
        long = prior.NR7 & (current.Close > prior.High) & up_trend & (current.ADX >= 20)
        short = prior.NR7 & (current.Close < prior.Low) & down_trend & (current.ADX >= 20)
    else:
        raise ValueError(name)
    return pd.Series(np.where(long, 1, np.where(short, -1, 0)), index=frame.index)


def simulate_segment(frame: pd.DataFrame, signal: pd.Series, stop_atr: float, target_r: float, start_at: pd.Timestamp | None, end_at: pd.Timestamp | None) -> dict:
    outcomes: list[float] = []
    trades: list[dict] = []
    first = max(WARMUP_BARS, int(frame.index.searchsorted(start_at))) if start_at is not None else WARMUP_BARS
    last = len(frame) - 1 if end_at is None else min(len(frame) - 1, int(frame.index.searchsorted(end_at, side="left")))
    i = first
    while i < last - 1:
        side, atr = int(signal.iloc[i]), float(frame.ATR.iloc[i]) if pd.notna(frame.ATR.iloc[i]) else 0.0
        if side == 0 or atr <= 0:
            i += 1
            continue
        entry_i, entry, risk = i + 1, float(frame.Open.iloc[i + 1]), stop_atr * atr
        stop = entry - risk if side == 1 else entry + risk
        target = entry + target_r * risk if side == 1 else entry - target_r * risk
        end_i = min(last, entry_i + HORIZON_BARS - 1)
        exit_i, exit_price, outcome = end_i, float(frame.Close.iloc[end_i]), "انتهت المدة"
        for j in range(entry_i, end_i + 1):
            high, low = float(frame.High.iloc[j]), float(frame.Low.iloc[j])
            hit_stop = low <= stop if side == 1 else high >= stop
            hit_target = high >= target if side == 1 else low <= target
            if hit_stop and hit_target:
                exit_i, exit_price, outcome = j, stop, "غموض داخل الشمعة — وقف محافظ"
                break
            if hit_stop:
                exit_i, exit_price, outcome = j, stop, "وقف"
                break
            if hit_target:
                exit_i, exit_price, outcome = j, target, "هدف"
                break
        outcome_r = ((exit_price - entry) / risk) if side == 1 else ((entry - exit_price) / risk)
        outcomes.append(outcome_r)
        trades.append({"decision_time": str(frame.index[i]), "entry_time": str(frame.index[entry_i]), "exit_time": str(frame.index[exit_i]), "direction": "شراء" if side == 1 else "بيع", "outcome": outcome, "r_multiple": round(outcome_r, 4)})
        i = exit_i + 1
    return {"outcomes": outcomes, "trades": trades, "signals": int((signal != 0).sum())}


def metrics(parts: list[dict]) -> dict:
    outcomes = [value for part in parts for value in part["outcomes"]]
    trades = [trade for part in parts for trade in part["trades"]]
    wins, losses = [x for x in outcomes if x > 0], [x for x in outcomes if x < 0]
    curve = np.cumsum(outcomes) if outcomes else np.array([])
    drawdown = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0.0
    gross_profit, gross_loss = sum(wins), abs(sum(losses))
    total = sum(outcomes)
    return {
        "signals": sum(part["signals"] for part in parts), "filled_trades": len(outcomes), "wins": len(wins), "losses": len(losses),
        "win_rate_pct": round(100 * len(wins) / len(outcomes), 1) if outcomes else None, "total_r": round(total, 2),
        "average_r": round(total / len(outcomes), 3) if outcomes else None, "profit_factor": round(gross_profit / gross_loss, 2) if gross_loss else None,
        "max_drawdown_r": round(drawdown, 2), "sample_adequate": len(outcomes) >= MIN_TRADES,
        "cost_sensitivity_r": {"0.05_per_trade": round(total - 0.05 * len(outcomes), 2), "0.10_per_trade": round(total - 0.10 * len(outcomes), 2)}, "trades": trades,
    }


def evaluate_rule(segments: list[pd.DataFrame], name: str, stop_atr: float, target_r: float) -> dict:
    prepared = [(segment, signals(segment, name)) for segment in segments]
    full = metrics([simulate_segment(segment, signal, stop_atr, target_r, None, None) for segment, signal in prepared])
    oos = metrics([simulate_segment(segment, signal, stop_atr, target_r, SPLIT, END) for segment, signal in prepared])
    eligible = bool(oos["filled_trades"] >= MIN_TRADES and (oos["total_r"] or 0) > 0 and (oos["profit_factor"] or 0) >= 1.1 and oos["cost_sensitivity_r"]["0.10_per_trade"] > 0)
    return {"metrics": full, "oos_h2_2025_observed": oos, "eligible_for_platform_candidate": eligible}


def evaluate_ob_fvg(segments: list[pd.DataFrame]) -> dict:
    def run(start: pd.Timestamp | None, end: pd.Timestamp | None) -> dict:
        outputs = []
        for segment in segments:
            scoped = segment.loc[(segment.index >= start) if start is not None else pd.Series(True, index=segment.index)] if start is not None else segment
            if end is not None:
                scoped = scoped.loc[scoped.index < end]
            if len(scoped) <= WARMUP_BARS + HORIZON_BARS:
                continue
            response = backtest_ob_fvg_strategy(scoped, warmup_bars=180, horizon_bars=HORIZON_BARS, censor_gap_bars=1, evaluation_stride=1, max_evaluation_points=500, signal_lookback_bars=600, trade_output_limit=None)
            outputs.append({"outcomes": [float(trade.get("r_multiple", 0)) for trade in response.get("trades", [])], "trades": response.get("trades", []), "signals": int(response.get("metrics", {}).get("decision_points", 0))})
        return metrics(outputs)
    full, oos = run(None, None), run(SPLIT, END)
    eligible = bool(oos["filled_trades"] >= MIN_TRADES and (oos["total_r"] or 0) > 0 and (oos["profit_factor"] or 0) >= 1.1 and oos["cost_sensitivity_r"]["0.10_per_trade"] > 0)
    return {"metrics": full, "oos_h2_2025_observed": oos, "eligible_for_platform_candidate": eligible}


RULES: tuple[tuple[str, float, float, str], ...] = (
    ("ema_pullback", 1.5, 2.0, "اتجاه — خط أساس"),
    ("ema_adx_pullback", 1.5, 2.0, "اتجاه — EMA + ADX + RSI"),
    ("donchian_breakout", 2.0, 2.0, "اختراق نطاق"),
    ("donchian_adx", 2.0, 2.0, "اختراق نطاق مع ADX"),
    ("rsi_bollinger", 1.5, 1.5, "ارتداد متوسط"),
    ("rsi2_ema200", 1.25, 1.5, "ارتداد قصير داخل اتجاه أعلى"),
    ("keltner_breakout", 1.75, 2.0, "قناة ATR"),
    ("squeeze_breakout", 1.5, 2.0, "انكماش Bollinger–Keltner"),
    ("nr7_trend_breakout", 1.5, 2.0, "ضغط نطاق NR7 مع اتجاه"),
)


def main() -> None:
    base = load_base()
    results: dict[str, dict] = {}
    segment_contract: dict[str, list[dict]] = {}
    for timeframe, rule in (("1h", "1h"), ("4h", "4h")):
        segments = [add_indicators(segment) for segment in split_segments(resample(base, rule))]
        segment_contract[timeframe] = [{"start": str(segment.index.min()), "end": str(segment.index.max()), "bars": len(segment)} for segment in segments]
        for name, stop_atr, target_r, family in RULES:
            result = evaluate_rule(segments, name, stop_atr, target_r)
            result.update({"timeframe": timeframe, "strategy": name, "family": family, "rules": {"stop_atr": stop_atr, "target_r": target_r, "horizon_bars": HORIZON_BARS}})
            results[f"{timeframe}:{name}"] = result
        ob = evaluate_ob_fvg(segments)
        ob.update({"timeframe": timeframe, "strategy": "ob_fvg", "family": "منطقة بنيوية", "rules": {"source_engine": "ob_fvg_strategy.py", "horizon_bars": HORIZON_BARS}})
        results[f"{timeframe}:ob_fvg"] = ob
    ranking = sorted(
        ({"key": key, "timeframe": value["timeframe"], "strategy": value["strategy"], "family": value["family"], "eligible": value["eligible_for_platform_candidate"], **{field: value["oos_h2_2025_observed"].get(field) for field in ("filled_trades", "total_r", "profit_factor", "max_drawdown_r")}} for key, value in results.items()),
        key=lambda item: (item["eligible"], item["total_r"] if item["total_r"] is not None else -9999, item["profit_factor"] if item["profit_factor"] is not None else -9999), reverse=True,
    )
    payload = {
        "data_contract": {"source": "Local XAU_15m_data.csv, public OHLC/tick-volume reference", "period": "مشاهدات 2025 المتاحة؛ فجوة 2025-09-12 إلى 2025-10-15 مستبعدة ولا تُملأ", "entry": "افتتاح الشمعة التالية", "same_bar_policy": "وقف محافظ عند لمس الهدف والوقف معاً", "costs": "حساسية مجردة 0.05R و0.10R لكل صفقة؛ ليست تكاليف وسيط", "oos": "H2 2025 observed فقط، بقواعد ثابتة محددة قبل تشغيلها", "minimum_sample": MIN_TRADES, "reference_only": True},
        "segments": segment_contract, "results": results, "oos_ranking": ranking,
    }
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = "\n".join(f"| {item['key']} | {'مرشح' if item['eligible'] else 'غير مؤهل'} | {item['filled_trades']} | {item['total_r']} | {item['profit_factor']} | {item['max_drawdown_r']} |" for item in ranking)
    OUT_MD.write_text(f"""# مقارنة استراتيجية XAUUSD الموسعة — مشاهدات 2025 المتاحة

اُختبرت تسع قواعد ثابتة مسبقاً ومحرك OB+FVG على الساعة وأربع ساعات. أُجري اختيار القواعد قبل قراءة المخرجات، ويقاس الترتيب على H2 المرصود فقط. يوجد انقطاع طويل في ملف المصدر بين 12 سبتمبر و15 أكتوبر؛ لا تتجاوزه أي صفقة، ويعاد تسخين المؤشرات بعده. لذلك لا يمثل التقرير «سنة كاملة بلا فجوات» ولا سعراً تنفيذياً لدى وسيط.

| القاعدة | مؤهلة للترشيح؟ | صفقات H2 المرصودة | صافي H2 (R) | معامل الربح H2 | أقصى سحب H2 (R) |
| --- | --- | ---: | ---: | ---: | ---: |
{rows}

## قاعدة الترشيح

لا يرشح أي نظام للإضافة إلا إذا جمع 20 صفقة H2 على الأقل، وصافي R موجباً بعد حساسية تكلفة 0.10R لكل صفقة، ومعامل ربح لا يقل عن 1.10. هذه بوابة متانة وليست دليلاً على الربحية المستقبلية أو ملاءمة وسيط معين.

## القيود

يستعمل الاختبار OHLC وحجم Tick مرجعيين. لا يدخل Bid/Ask أو العمولة أو الانزلاق أو Order Flow أو أحداث الأخبار الفعلية. الأداء التاريخي لا يضمن الأداء المستقبلي.

[1]: https://www.aqr.com/Insights/Research/Journal-Article/A-Century-of-Evidence-on-Trend-Following-Investing "AQR — A Century of Evidence on Trend-Following Investing"
[2]: https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/bollinger-bands "Fidelity — Bollinger Bands"
[3]: https://academy.ftmo.com/lesson/keltner-channels-technical-indicator/ "FTMO Academy — Keltner Channels"
""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for item in ranking:
        print(item)


if __name__ == "__main__":
    main()
