"""مناطق سيولة وOrder Blocks مرشحة من OHLC؛ لا تدّعي رؤية أوامر أو تدفق مؤسسي فعلي."""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def _s(frame: pd.DataFrame, name: str) -> pd.Series:
    return pd.to_numeric(frame[name], errors="coerce").astype(float)


def _atr(frame: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = _s(frame, "High"), _s(frame, "Low"), _s(frame, "Close")
    prev = close.shift(1)
    tr = pd.concat([high - low, (high - prev).abs(), (low - prev).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()


def _pivots(frame: pd.DataFrame, left: int = 2, right: int = 2) -> list[dict[str, Any]]:
    high, low = _s(frame, "High"), _s(frame, "Low")
    points: list[dict[str, Any]] = []
    for idx in range(left, len(frame) - right):
        highs, lows = high.iloc[idx - left:idx + right + 1], low.iloc[idx - left:idx + right + 1]
        if float(high.iloc[idx]) == float(highs.max()) and int((highs == high.iloc[idx]).sum()) == 1:
            points.append({"kind": "high", "index": idx, "price": float(high.iloc[idx])})
        if float(low.iloc[idx]) == float(lows.min()) and int((lows == low.iloc[idx]).sum()) == 1:
            points.append({"kind": "low", "index": idx, "price": float(low.iloc[idx])})
    return sorted(points, key=lambda point: point["index"])


def _epoch(frame: pd.DataFrame, idx: int) -> int:
    return int(pd.Timestamp(frame.index[idx]).timestamp())


def _fvg_after(frame: pd.DataFrame, start: int, end: int, direction: str, atr_series: pd.Series) -> bool:
    high, low = _s(frame, "High"), _s(frame, "Low")
    for idx in range(max(2, start), min(len(frame), end + 3)):
        value = float(atr_series.iloc[idx - 1]) if not pd.isna(atr_series.iloc[idx - 1]) else 0.0
        if value <= 0:
            continue
        if direction == "صاعد" and float(low.iloc[idx]) > float(high.iloc[idx - 2]):
            return (float(low.iloc[idx]) - float(high.iloc[idx - 2])) / value >= 0.12
        if direction == "هابط" and float(high.iloc[idx]) < float(low.iloc[idx - 2]):
            return (float(low.iloc[idx - 2]) - float(high.iloc[idx])) / value >= 0.12
    return False


def liquidity_zones(frame: pd.DataFrame, lookback: int = 140, limit: int = 6) -> dict[str, Any]:
    if len(frame) < 32:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لاستخراج تجمعات pivots مؤكدة.", "levels": {}, "zones": [], "quality": "بيانات غير كافية", "quality_score": 0, "qualified": False}
    atr_now = float(_atr(frame).dropna().iloc[-1]) if not _atr(frame).dropna().empty else 0.0
    tolerance = max(atr_now * 0.18, 1e-9)
    high, low, close = _s(frame, "High"), _s(frame, "Low"), _s(frame, "Close")
    points = [point for point in _pivots(frame) if point["index"] >= max(0, len(frame) - lookback)]
    zones: list[dict[str, Any]] = []
    for kind, zone_kind, label in (("high", "buy_side_liquidity", "سيولة فوق القمم"), ("low", "sell_side_liquidity", "سيولة تحت القيعان")):
        cluster: list[dict[str, Any]] = []
        for point in [item for item in points if item["kind"] == kind]:
            center = float(np.mean([item["price"] for item in cluster])) if cluster else point["price"]
            if cluster and abs(point["price"] - center) > tolerance:
                if len(cluster) >= 2:
                    zones.append(_liquidity_zone(frame, cluster, kind, zone_kind, label, tolerance, high, low, close, atr_now))
                cluster = []
            cluster.append(point)
        if len(cluster) >= 2:
            zones.append(_liquidity_zone(frame, cluster, kind, zone_kind, label, tolerance, high, low, close, atr_now))
    zones = sorted(zones, key=lambda zone: (zone["swept"], zone["quality_score"], zone["start_time"]), reverse=True)[:limit]
    swept = [zone for zone in zones if zone["swept"]]
    return {
        "status": "مناطق مرصودة" if zones else "غير مكتشف",
        "bias": swept[0]["bias"] if swept else "محايد",
        "details": "عناقيد pivots متقاربة تمثل سيولة محتملة؛ «السحب» يعني اختراقاً وعودة إغلاق ولا يثبت تدفق أوامر حقيقياً.",
        "levels": {"المناطق": len(zones), "المناطق المسحوبة": len(swept)},
        "zones": zones,
        "quality": "OHLC + pivots مؤكدة + ATR",
        "quality_score": round(sum(zone["quality_score"] for zone in zones) / len(zones)) if zones else 0,
        "qualified": bool(zones),
    }




def support_resistance(frame: pd.DataFrame, lookback: int = 180, limit: int = 3) -> dict[str, Any]:
    """يستخرج مستويات رئيسية من pivots المتقاربة ضمن عرض ATR، لا من قمم/قيعان عشوائية."""
    if len(frame) < 36:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لتجميع مستويات دعم ومقاومة مؤكدة.", "levels": {}, "zones": [], "quality": "بيانات غير كافية", "quality_score": 0, "qualified": False}
    high, low, close = _s(frame, "High"), _s(frame, "Low"), _s(frame, "Close")
    atr_series = _atr(frame).dropna()
    atr_now = float(atr_series.iloc[-1]) if not atr_series.empty else 0.0
    if atr_now <= 0:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "ATR غير صالح لتحديد عرض المستوى.", "levels": {}, "zones": [], "quality": "ATR غير صالح", "quality_score": 0, "qualified": False}
    current = float(close.iloc[-1])
    tolerance = max(atr_now * 0.22, 1e-9)
    pivots = [point for point in _pivots(frame) if point["index"] >= max(0, len(frame) - lookback)]
    clusters: list[list[dict[str, Any]]] = []
    for point in sorted(pivots, key=lambda item: item["price"]):
        if not clusters:
            clusters.append([point]); continue
        center = float(np.mean([item["price"] for item in clusters[-1]]))
        if abs(point["price"] - center) <= tolerance:
            clusters[-1].append(point)
        else:
            clusters.append([point])
    zones: list[dict[str, Any]] = []
    for cluster in clusters:
        level = float(np.mean([item["price"] for item in cluster]))
        side = "support" if level < current else "resistance"
        touches = len(cluster)
        last_index = max(item["index"] for item in cluster)
        age = len(frame) - 1 - last_index
        quality = min(92, round(34 + min(36, touches * 14) + min(15, max(0, 90 - age) * .16) + (7 if len({item["kind"] for item in cluster}) > 1 else 0)))
        zones.append({
            "kind": side, "label": "دعم رئيسي" if side == "support" else "مقاومة رئيسية",
            "price": round(level, 4), "lower": round(level - tolerance, 4), "upper": round(level + tolerance, 4),
            "start_time": _epoch(frame, min(item["index"] for item in cluster)), "end_time": _epoch(frame, len(frame) - 1),
            "touches": touches, "distance_atr": round(abs(current - level) / atr_now, 2), "quality_score": quality,
            "qualified": touches >= 2 and quality >= 60,
            "details": f"{touches} pivot ضمن عرض {round(tolerance, 2)}؛ المسافة الحالية {round(abs(current - level) / atr_now, 2)} ATR.",
        })
    supports = sorted([zone for zone in zones if zone["kind"] == "support"], key=lambda zone: current - zone["price"])[:limit]
    resistances = sorted([zone for zone in zones if zone["kind"] == "resistance"], key=lambda zone: zone["price"] - current)[:limit]
    selected = supports + resistances
    levels: dict[str, float] = {}
    for index, zone in enumerate(supports, start=1):
        levels[f"دعم {index}"] = round(zone["price"], 2)
    for index, zone in enumerate(resistances, start=1):
        levels[f"مقاومة {index}"] = round(zone["price"], 2)
    qualified = [zone for zone in selected if zone["qualified"]]
    return {
        "status": "مستويات رئيسية" if qualified else "مستويات مرصودة" if selected else "غير مكتشف",
        "bias": "محايد",
        "details": "مستويات مجمعة من pivots مؤكدة ضمن عرض ATR؛ هي مناطق مراقبة وليست ضمان ارتداد أو كسر.",
        "levels": levels, "zones": selected, "quality": "OHLC + pivots مؤكدة + ATR",
        "quality_score": round(sum(zone["quality_score"] for zone in qualified) / len(qualified)) if qualified else 0,
        "qualified": bool(qualified),
    }


def _liquidity_zone(frame: pd.DataFrame, cluster: list[dict[str, Any]], kind: str, zone_kind: str, label: str, tolerance: float, high: pd.Series, low: pd.Series, close: pd.Series, atr_now: float) -> dict[str, Any]:
    level = float(np.mean([point["price"] for point in cluster]))
    last = cluster[-1]["index"]
    sweep_index = None
    for idx in range(last + 1, len(frame)):
        if kind == "high" and float(high.iloc[idx]) > level + .12 * atr_now and float(close.iloc[idx]) < level:
            sweep_index = idx; break
        if kind == "low" and float(low.iloc[idx]) < level - .12 * atr_now and float(close.iloc[idx]) > level:
            sweep_index = idx; break
    count = len(cluster)
    quality = min(85, round(35 + min(30, count * 12) + min(15, (len(frame) - last) * .3)))
    return {
        "kind": zone_kind, "label": label, "bias": "هابط" if kind == "high" and sweep_index is not None else "صاعد" if kind == "low" and sweep_index is not None else "محايد",
        "lower": round(level - tolerance, 4), "upper": round(level + tolerance, 4), "start_time": _epoch(frame, cluster[0]["index"]),
        "end_time": _epoch(frame, sweep_index if sweep_index is not None else len(frame) - 1), "pivot_count": count, "swept": sweep_index is not None,
        "swept_at": str(frame.index[sweep_index]) if sweep_index is not None else None, "quality_score": quality, "qualified": quality >= 55,
        "details": "تجمع pivots متقاربة" + (" مع سحب وعودة إغلاق." if sweep_index is not None else "؛ لم يُسحب بعد."),
    }


def order_blocks(frame: pd.DataFrame, lookback: int = 180, limit: int = 6) -> dict[str, Any]:
    if len(frame) < 40:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لتأكيد BOS وFVG وحداثة المنطقة.", "levels": {}, "zones": [], "quality": "بيانات غير كافية", "quality_score": 0, "qualified": False}
    open_, high, low, close = (_s(frame, name) for name in ("Open", "High", "Low", "Close"))
    atr_series, volume = _atr(frame), _s(frame, "Volume") if "Volume" in frame else None
    pivots = _pivots(frame)
    zones: list[dict[str, Any]] = []
    for idx in range(max(16, len(frame) - lookback), len(frame) - 5):
        value = float(atr_series.iloc[idx]) if not pd.isna(atr_series.iloc[idx]) else 0.0
        if value <= 0:
            continue
        for direction, is_candidate in (("صاعد", float(close.iloc[idx]) < float(open_.iloc[idx])), ("هابط", float(close.iloc[idx]) > float(open_.iloc[idx]))):
            if not is_candidate:
                continue
            prior = [point for point in pivots if point["kind"] == ("high" if direction == "صاعد" else "low") and point["index"] < idx]
            if not prior:
                continue
            structure = prior[-1]["price"]
            bos = next((future for future in range(idx + 1, min(len(frame), idx + 6)) if ((float(close.iloc[future]) > structure + .10 * value) if direction == "صاعد" else (float(close.iloc[future]) < structure - .10 * value))), None)
            if bos is None:
                continue
            displacement = (float(high.iloc[bos]) - float(low.iloc[idx])) if direction == "صاعد" else (float(high.iloc[idx]) - float(low.iloc[bos]))
            if displacement < 1.10 * value:
                continue
            lower, upper = float(low.iloc[idx]), float(high.iloc[idx])
            later = close.iloc[bos + 1:]
            invalidated = bool((later < lower).any()) if direction == "صاعد" else bool((later > upper).any())
            if invalidated:
                continue
            touches = sum(1 for future in range(bos + 1, len(frame)) if float(high.iloc[future]) >= lower and float(low.iloc[future]) <= upper)
            fresh = touches == 0
            fvg = _fvg_after(frame, idx + 1, bos + 1, direction, atr_series)
            vol_ok = True
            if volume is not None and bos >= 8:
                baseline = float(volume.iloc[max(0, bos - 20):bos].median())
                vol_ok = baseline <= 0 or float(volume.iloc[bos]) / baseline >= .9
            quality = min(95, round(60 + (15 if fvg else 0) + (15 if fresh else max(0, 10 - touches * 3)) + (10 if vol_ok else 0)))
            zones.append({
                "kind": "bullish_order_block" if direction == "صاعد" else "bearish_order_block", "label": "Order Block صاعد" if direction == "صاعد" else "Order Block هابط", "bias": direction,
                "lower": round(lower, 4), "upper": round(upper, 4), "start_time": _epoch(frame, idx), "end_time": _epoch(frame, len(frame) - 1),
                "formed_at": str(frame.index[idx]), "bos_at": str(frame.index[bos]), "fvg_confirmed": fvg, "touches": touches, "fresh": fresh,
                "quality_score": quality, "qualified": fvg and fresh and vol_ok and quality >= 75,
                "details": "شمعة معاكسة قبل BOS وإزاحة" + (" مع FVG مؤهل" if fvg else " دون FVG مؤهل") + ("؛ منطقة بكر." if fresh else f"؛ زيارات لاحقة: {touches}."),
            })
    zones = sorted(zones, key=lambda zone: (zone["qualified"], zone["quality_score"], zone["start_time"]), reverse=True)[:limit]
    qualified = [zone for zone in zones if zone["qualified"]]
    latest = qualified[0] if qualified else (zones[0] if zones else None)
    return {
        "status": "مناطق مؤهلة" if qualified else "مناطق ضعيفة" if zones else "غير مكتشف", "bias": latest["bias"] if latest and latest["qualified"] else "محايد",
        "details": "مناطق مرشحة من BOS وإزاحة وFVG وحداثة المنطقة؛ لا تثبت وجود أوامر مؤسسات.",
        "levels": {"مناطق مرشحة": len(zones), "مناطق مؤهلة": len(qualified)}, "zones": zones,
        "quality": "OHLC + ATR + pivots مؤكدة + حجم نسبي عند توفره", "quality_score": round(sum(zone["quality_score"] for zone in qualified) / len(qualified)) if qualified else 0,
        "qualified": bool(qualified),
    }
