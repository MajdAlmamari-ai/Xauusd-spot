"""لوحة XAU/USD مرجعية لاختبار استراتيجية MA/RSI دون تسرب زمني.

التشغيل:
    streamlit run app.py

مصدر البيانات: حمّل CSV من المستخدم يحتوي timestamp/open/high/low/close
(الأسماء العربية/الإنجليزية الشائعة مدعومة). لا يحمّل التطبيق أسعاراً حية
ولا يدّعي أن الشموع المرجعية تمثل Bid/Ask أو سعراً تنفيذياً لدى وسيط.
"""

from __future__ import annotations

import io
import os
import sys
from dataclasses import dataclass
from typing import BinaryIO

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots


APP_TITLE = "لوحة تحليل الذهب XAU/USD"
REQUIRED_COLUMNS = ("timestamp", "open", "high", "low", "close")


@dataclass(frozen=True)
class StrategySettings:
    ma_type: str
    ma_length: int
    rsi_length: int
    rsi_entry_floor: int
    capital: float
    risk_percent: float


def normalize_ohlc(raw: pd.DataFrame) -> pd.DataFrame:
    """يتحقق من شموع مرجعية مرتبة؛ لا يملأ فجوات ولا يصطنع سعراً."""
    aliases = {
        "date": "timestamp", "datetime": "timestamp", "time": "timestamp", "timestamp": "timestamp",
        "التاريخ": "timestamp", "الوقت": "timestamp",
        "open": "open", "opening": "open", "الافتتاح": "open",
        "high": "high", "أعلى": "high", "الاعلى": "high",
        "low": "low", "أدنى": "low", "الادنى": "low",
        "close": "close", "closing": "close", "الإغلاق": "close", "الاغلاق": "close",
        "volume": "volume", "الحجم": "volume",
    }
    renamed = raw.rename(columns={c: aliases.get(str(c).strip().lower(), str(c).strip().lower()) for c in raw.columns})
    missing = [column for column in REQUIRED_COLUMNS if column not in renamed.columns]
    if missing:
        raise ValueError(f"ملف CSV لا يحتوي الأعمدة المطلوبة: {', '.join(missing)}")

    data = renamed.loc[:, [c for c in (*REQUIRED_COLUMNS, "volume") if c in renamed.columns]].copy()
    data["timestamp"] = pd.to_datetime(data["timestamp"], utc=True, errors="coerce")
    for column in ("open", "high", "low", "close"):
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.dropna(subset=list(REQUIRED_COLUMNS)).sort_values("timestamp").drop_duplicates("timestamp").reset_index(drop=True)
    if len(data) < 60:
        raise ValueError("يلزم 60 شمعة مكتملة على الأقل لعرض المؤشرات واختبارها.")
    if (data[["open", "high", "low", "close"]] <= 0).any().any():
        raise ValueError("توجد قيم OHLC غير موجبة.")
    invalid = (data["high"] < data[["open", "close", "low"]].max(axis=1)) | (
        data["low"] > data[["open", "close", "high"]].min(axis=1)
    )
    if invalid.any():
        raise ValueError("توجد شموع OHLC غير منطقية؛ صحح الملف قبل التحليل.")
    return data


def read_csv(source: str | BinaryIO) -> pd.DataFrame:
    if isinstance(source, str):
        raw = pd.read_csv(source, sep=None, engine="python")
    else:
        payload = source.read()
        source.seek(0)
        raw = pd.read_csv(io.BytesIO(payload), sep=None, engine="python")
    return normalize_ohlc(raw)


def rsi(close: pd.Series, length: int) -> pd.Series:
    delta = close.diff()
    gains = delta.clip(lower=0).ewm(alpha=1 / length, adjust=False, min_periods=length).mean()
    losses = (-delta.clip(upper=0)).ewm(alpha=1 / length, adjust=False, min_periods=length).mean()
    relative_strength = gains / losses.replace(0, np.nan)
    return 100 - (100 / (1 + relative_strength))


def add_indicators(data: pd.DataFrame, settings: StrategySettings) -> pd.DataFrame:
    result = data.copy()
    if settings.ma_type == "SMA":
        result["ma"] = result["close"].rolling(settings.ma_length, min_periods=settings.ma_length).mean()
    elif settings.ma_type == "EMA":
        result["ma"] = result["close"].ewm(span=settings.ma_length, adjust=False, min_periods=settings.ma_length).mean()
    else:
        result["ma"] = np.nan
    result["rsi"] = rsi(result["close"], settings.rsi_length)
    return result


def simulate_long_trades(data: pd.DataFrame, settings: StrategySettings) -> tuple[pd.DataFrame, pd.DataFrame, list[dict]]:
    """يحاكي تداولاً طويلاً فقط؛ قرار i من إغلاق i-1 وتنفيذ i عند الافتتاح.

    لا يُغلق المركز المفتوح اصطناعياً بآخر إغلاق، ولذلك لا يدخل في تقرير الربح.
    """
    if settings.ma_type == "بدون متوسط":
        return pd.DataFrame(), pd.DataFrame(), []

    entries: list[dict] = []
    exits: list[dict] = []
    ignored: list[dict] = []
    trades: list[dict] = []
    position: dict | None = None

    for index in range(2, len(data)):
        prev = data.iloc[index - 1]
        before_prev = data.iloc[index - 2]
        execution = data.iloc[index]
        if pd.isna(prev["ma"]) or pd.isna(before_prev["ma"]) or pd.isna(prev["rsi"]):
            continue

        bullish_cross = prev["close"] > prev["ma"] and before_prev["close"] <= before_prev["ma"]
        bearish_cross = prev["close"] < prev["ma"] and before_prev["close"] >= before_prev["ma"]

        if position is None and bullish_cross:
            if prev["rsi"] < settings.rsi_entry_floor:
                ignored.append(
                    {"date": prev["timestamp"], "reason": f"RSI السابق ({prev['rsi']:.1f}) دون حد الدخول ({settings.rsi_entry_floor})"}
                )
                continue
            position = {"entry_date": execution["timestamp"], "entry_price": float(execution["open"])}
            entries.append({"timestamp": execution["timestamp"], "price": float(execution["low"])})

        elif position is not None and bearish_cross:
            exit_price = float(execution["open"])
            points = exit_price - position["entry_price"]
            return_pct = (points / position["entry_price"]) * 100
            trades.append(
                {
                    "رقم الصفقة": len(trades) + 1,
                    "التاريخ": f"دخول: {position['entry_date']:%Y-%m-%d %H:%M} | خروج: {execution['timestamp']:%Y-%m-%d %H:%M}",
                    "سعر الدخول": position["entry_price"],
                    "سعر الخروج": exit_price,
                    "الربح/الخسارة بالنقاط": points,
                    "نسبة الربح %": return_pct,
                    "_entry_time": position["entry_date"],
                    "_exit_time": execution["timestamp"],
                }
            )
            exits.append({"timestamp": execution["timestamp"], "price": float(execution["high"])})
            position = None

    # هذا الحدث يوثق الإشارة الحالية التي لا يمكن تنفيذها بعد من دون افتتاح شمعة لاحقة.
    last = data.iloc[-1]
    penultimate = data.iloc[-2]
    if not pd.isna(last["ma"]) and not pd.isna(penultimate["ma"]):
        current_cross = (last["close"] > last["ma"] and penultimate["close"] <= penultimate["ma"]) or (
            last["close"] < last["ma"] and penultimate["close"] >= penultimate["ma"]
        )
        if current_cross:
            ignored.append(
                {"date": last["timestamp"], "reason": "تُجاهل: لا يوجد افتتاح شمعة لاحقة لتنفيذ إشارة إغلاق الشمعة الحالية"}
            )

    return pd.DataFrame(trades), pd.DataFrame(entries), ignored + [{"date": row["timestamp"], "reason": "خروج منفذ"} for row in exits]


def performance_metrics(trades: pd.DataFrame) -> dict[str, float | str]:
    if trades.empty:
        return {"profit": 0.0, "loss": 0.0, "ratio": "—", "drawdown": 0.0, "win_rate": 0.0}
    points = trades["الربح/الخسارة بالنقاط"].astype(float)
    profit = float(points[points > 0].sum())
    loss = float(abs(points[points < 0].sum()))
    equity = points.cumsum()
    drawdown = float((equity.cummax() - equity).max())
    ratio: float | str = "∞" if loss == 0 and profit > 0 else (round(profit / loss, 2) if loss > 0 else "—")
    return {"profit": profit, "loss": loss, "ratio": ratio, "drawdown": drawdown, "win_rate": float((points > 0).mean() * 100)}


def build_chart(view: pd.DataFrame, entries: pd.DataFrame, trades: pd.DataFrame, show_ma: bool) -> go.Figure:
    chart = make_subplots(
        rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.035, row_heights=[0.74, 0.26],
        subplot_titles=("الشموع المرجعية", "مؤشر القوة النسبية RSI"),
    )
    chart.add_trace(
        go.Candlestick(
            x=view["timestamp"], open=view["open"], high=view["high"], low=view["low"], close=view["close"],
            name="XAU/USD", increasing_line_color="#21c58b", decreasing_line_color="#f05252",
            increasing_fillcolor="#21c58b", decreasing_fillcolor="#f05252",
        ), row=1, col=1,
    )
    if show_ma:
        chart.add_trace(go.Scatter(x=view["timestamp"], y=view["ma"], mode="lines", name="MA", line=dict(color="#f6c85f", width=2)), row=1, col=1)

    visible_entries = entries[entries["timestamp"].isin(view["timestamp"])] if not entries.empty else entries
    if not visible_entries.empty:
        chart.add_trace(
            go.Scatter(x=visible_entries["timestamp"], y=visible_entries["price"], mode="markers", name="دخول منفذ",
                       marker=dict(symbol="triangle-up", size=13, color="#39e58c", line=dict(color="#0b1f17", width=1))), row=1, col=1,
        )
    if not trades.empty:
        exits = trades[trades["_exit_time"].isin(view["timestamp"])]
        if not exits.empty:
            exit_prices = view.set_index("timestamp").loc[exits["_exit_time"], "high"].to_numpy()
            chart.add_trace(
                go.Scatter(x=exits["_exit_time"], y=exit_prices, mode="markers", name="خروج منفذ",
                           marker=dict(symbol="triangle-down", size=13, color="#ff5c5c", line=dict(color="#301010", width=1))), row=1, col=1,
            )
    chart.add_trace(go.Scatter(x=view["timestamp"], y=view["rsi"], mode="lines", name="RSI", line=dict(color="#a78bfa", width=2)), row=2, col=1)
    chart.add_hline(y=70, line_dash="dot", line_color="#f05252", opacity=0.55, row=2, col=1)
    chart.add_hline(y=30, line_dash="dot", line_color="#21c58b", opacity=0.55, row=2, col=1)
    chart.update_layout(
        template="plotly_dark", height=760, margin=dict(l=20, r=20, t=55, b=20), paper_bgcolor="#0b1020", plot_bgcolor="#10182b",
        font=dict(color="#e7edf7"), hovermode="x unified", xaxis_rangeslider_visible=False,
        legend=dict(orientation="h", yanchor="bottom", y=1.01, xanchor="left", x=0),
    )
    chart.update_yaxes(gridcolor="#25314a", row=1, col=1)
    chart.update_yaxes(gridcolor="#25314a", range=[0, 100], row=2, col=1)
    chart.update_xaxes(gridcolor="#25314a")
    return chart


def render_metrics(metrics: dict[str, float | str], settings: StrategySettings) -> None:
    columns = st.columns(5)
    columns[0].metric("إجمالي الربح", f"{metrics['profit']:,.2f} نقطة")
    columns[1].metric("إجمالي الخسارة", f"{metrics['loss']:,.2f} نقطة")
    columns[2].metric("نسبة الربح/الخسارة", metrics["ratio"])
    columns[3].metric("أقصى تراجع", f"{metrics['drawdown']:,.2f} نقطة")
    columns[4].metric("نسبة الفوز", f"{metrics['win_rate']:.1f}%")
    st.caption(f"رأس المال: {settings.capital:,.0f} | حد المخاطرة النظري: {settings.capital * settings.risk_percent / 100:,.2f}. لا تدخل هذه القيم في الربح/الخسارة بالنقاط لعدم وجود وقف خسارة في هذه الاستراتيجية البسيطة.")


def run_self_test() -> None:
    """اختبار منطقي داخلي: لا يمكن أن يبدأ دخول في شمعة التقاطع نفسها."""
    data = pd.DataFrame(
        {
            "timestamp": pd.date_range("2026-01-01", periods=12, freq="h", tz="UTC"),
            "open": [10, 10, 10, 10, 10, 10, 10, 10, 11, 12, 11, 10],
            "high": [10.5, 10.5, 10.5, 10.5, 10.5, 10.5, 10.5, 10.5, 11.5, 12.5, 11.5, 10.5],
            "low": [9.5] * 12,
            "close": [10, 10, 10, 10, 10, 9, 9, 10, 11, 11, 10, 9],
        }
    )
    settings = StrategySettings("SMA", 3, 2, 0, 10_000, 1.0)
    tested = add_indicators(data, settings)
    trades, entries, _ = simulate_long_trades(tested, settings)
    assert not entries.empty, "يجب ظهور دخول منفذ في بيانات الاختبار"
    entry_time = entries.iloc[0]["timestamp"]
    entry_position = int(tested.index[tested["timestamp"] == entry_time][0])
    signal_time = tested.iloc[entry_position - 1]["timestamp"]
    assert entry_time > signal_time, "الدخول يجب أن يأتي بعد إغلاق شمعة الإشارة"
    assert list(trades.columns[:6]) == ["رقم الصفقة", "التاريخ", "سعر الدخول", "سعر الخروج", "الربح/الخسارة بالنقاط", "نسبة الربح %"]
    print("PASS: self-test confirms previous-close signal and next-open execution")


def main() -> None:
    st.set_page_config(page_title=APP_TITLE, page_icon="◆", layout="wide", initial_sidebar_state="expanded")
    st.markdown(
        """<style>
        .stApp { background: #070b16; color: #e7edf7; }
        [data-testid='stSidebar'] { background: #0d1425; border-right: 1px solid #22304a; }
        [data-testid='stMetric'] { background: #101a2e; border: 1px solid #243552; border-radius: 12px; padding: 14px; }
        .block-container { padding-top: 1.4rem; padding-bottom: 2.5rem; }
        h1, h2, h3 { color: #f4f7fb; }
        .source-box { border-right: 4px solid #f6c85f; background: #101a2e; padding: 12px 16px; border-radius: 8px; }
        </style>""", unsafe_allow_html=True,
    )

    st.sidebar.header("لوحة الإعدادات")
    upload = st.sidebar.file_uploader("ملف CSV للشموع المرجعية", type=["csv"])
    local_path = st.sidebar.text_input("أو مسار CSV محلي", value=os.environ.get("XAUUSD_CSV_PATH", ""))
    st.sidebar.selectbox("الإطار الزمني المعروض", ["تلقائي من الملف", "1 دقيقة", "5 دقائق", "15 دقيقة", "ساعة", "4 ساعات", "يومي"], index=0, disabled=True, help="يعرض التطبيق الإطار الأصلي للملف؛ لا يعيد التجميع كي لا يخفي شموعاً ناقصة.")
    ma_type = st.sidebar.selectbox("نوع المتوسط المتحرك", ["SMA", "EMA", "بدون متوسط"])
    ma_length = st.sidebar.slider("فترة المتوسط", min_value=5, max_value=200, value=20, step=1, disabled=ma_type == "بدون متوسط")
    rsi_length = st.sidebar.slider("فترة RSI", min_value=5, max_value=50, value=14, step=1)
    rsi_floor = st.sidebar.slider("حد RSI لتأكيد الدخول", min_value=0, max_value=70, value=50, step=1)
    capital = st.sidebar.number_input("حجم رأس المال", min_value=100.0, value=10_000.0, step=100.0)
    risk_percent = st.sidebar.slider("نسبة المخاطرة لكل صفقة %", min_value=0.1, max_value=5.0, value=1.0, step=0.1)
    analysis_bars = st.sidebar.select_slider("عدد شموع الاختبار التاريخي", options=[1_000, 5_000, 10_000, 20_000], value=10_000, help="يحصر حساب الصفقات في أحدث نافذة تاريخية لتبقى اللوحة متجاوبة؛ لا يغير الشموع داخل النافذة.")
    bars = st.sidebar.select_slider("عدد الشموع المعروضة", options=[100, 250, 500, 1000], value=500)

    st.title(APP_TITLE)
    st.caption("محاكاة مرجعية تاريخية فقط — لا أسعار حية، ولا Bid/Ask، ولا أوامر تداول.")

    if upload is None and not local_path:
        st.info("حمّل ملف CSV يحتوي timestamp, open, high, low, close لعرض الرسم وحساب الصفقات. لا توجد بيانات افتراضية مصطنعة داخل التطبيق.")
        st.code("timestamp,open,high,low,close\n2026-01-01T00:00:00Z,2600,2605,2598,2603", language="csv")
        return

    try:
        data = read_csv(upload if upload is not None else local_path)
    except Exception as exc:
        st.error(f"تعذر قراءة البيانات: {exc}")
        return

    settings = StrategySettings(ma_type, ma_length, rsi_length, rsi_floor, float(capital), float(risk_percent))
    data = data.tail(int(analysis_bars)).reset_index(drop=True)
    analysed = add_indicators(data, settings)
    trades, entries, ignored = simulate_long_trades(analysed, settings)
    view = analysed.tail(int(bars)).copy()
    last_update = data["timestamp"].iloc[-1].strftime("%Y-%m-%d %H:%M UTC")

    st.markdown(f"<div class='source-box'><b>مصدر الشموع:</b> ملف CSV يرفعه المستخدم — شموع مرجعية. <b>نافذة الاختبار:</b> {len(data):,} شمعة. <b>آخر تحديث داخل الملف:</b> {last_update}</div>", unsafe_allow_html=True)
    st.plotly_chart(build_chart(view, entries, trades, show_ma=ma_type != "بدون متوسط"), width="stretch", config={"scrollZoom": True, "displaylogo": False})

    st.subheader("نتائج الصفقات المكتملة")
    render_metrics(performance_metrics(trades), settings)
    result_columns = ["رقم الصفقة", "التاريخ", "سعر الدخول", "سعر الخروج", "الربح/الخسارة بالنقاط", "نسبة الربح %"]
    if trades.empty:
        st.warning("لا توجد صفقات مكتملة وفق الإعدادات الحالية. لا يُحسب مركز مفتوح ضمن النتائج.")
    else:
        display = trades.loc[:, result_columns].copy()
        display["سعر الدخول"] = display["سعر الدخول"].map(lambda value: f"{value:,.2f}")
        display["سعر الخروج"] = display["سعر الخروج"].map(lambda value: f"{value:,.2f}")
        display["الربح/الخسارة بالنقاط"] = display["الربح/الخسارة بالنقاط"].map(lambda value: f"{value:,.2f}")
        display["نسبة الربح %"] = display["نسبة الربح %"].map(lambda value: f"{value:.2f}%")
        st.dataframe(display, width="stretch", hide_index=True)

    st.subheader("تقرير نزاهة الإشارات")
    st.write("تُحتسب إشارة الشراء أو الخروج من إغلاق الشمعة السابقة فقط، ويكون التنفيذ الافتراضي على افتتاح الشمعة التالية. لذلك لا توجد إشارة تدخل في الشمعة التي صنعتها.")
    ignored_rows = [row for row in ignored if "تُجاهل" in row["reason"] or "دون حد الدخول" in row["reason"]]
    if ignored_rows:
        ignored_frame = pd.DataFrame(ignored_rows).rename(columns={"date": "التاريخ", "reason": "سبب التجاهل"})
        ignored_frame["التاريخ"] = pd.to_datetime(ignored_frame["التاريخ"], utc=True).dt.strftime("%Y-%m-%d %H:%M UTC")
        st.dataframe(ignored_frame, width="stretch", hide_index=True)
    else:
        st.success("لا توجد إشارات مستوفية تم تجاهلها بسبب عدم وجود شمعة تنفيذ لاحقة ضمن النافذة الحالية.")
    st.caption("تنبيه: هذه أداة بحث وتعليم فقط وليست نصيحة مالية شخصية أو ضماناً للأداء.")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        run_self_test()
    else:
        main()
