from pathlib import Path


source = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def test_four_hour_has_no_special_priority_and_default_is_daily():
    assert 'DEFAULT_TIMEFRAME_ID = "1d"' in source
    assert "tfPriority" not in source[source.index("function renderTimeframes"):source.index("function renderPivots")]
    assert "r.id==='4h'?'★ '" not in source


def test_evidence_surface_reads_selected_payload_and_shows_reasoning():
    assert "selectedFramePayload?.timeframe?.technical?.evidence_strength" in source
    assert 'id="evidenceExplanation"' in source
    assert "neutral_reasons" in source
    assert "أساس ${num(evidence.score,0)}/100 للإطار" in source
    assert "const baseUpdate=update;update=async function()" in source
    assert "لا تغيّر قرار الإطار المختار أو قوة أدلته" in source


if __name__ == "__main__":
    test_four_hour_has_no_special_priority_and_default_is_daily()
    test_evidence_surface_reads_selected_payload_and_shows_reasoning()
    print("PASS: selected timeframe owns evidence strength and 4h has no priority treatment")
