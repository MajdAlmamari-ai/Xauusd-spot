from __future__ import annotations

import io

from PIL import Image

from chart_image_analysis import build_combined_chart_image_analysis, validate_chart_image


def sample_image():
    output = io.BytesIO()
    Image.new("RGB", (640, 400), color=(8, 22, 33)).save(output, format="PNG")
    return validate_chart_image(output.getvalue())


def main() -> None:
    image = sample_image()
    platform = {
        "mode": "platform", "scenario": "CONDITIONAL", "summary": "قواعد المنصة صاعدة مشروطة.",
        "evidence": {"bias": "صاعد", "strength": 78}, "limitations": ["الصورة ليست OHLC."],
    }
    visual_agree = {
        "mode": "ai", "status": "observed", "scenario": "BULLISH_SCENARIO", "summary": "ميل صاعد ظاهر.",
        "image": image.public_metadata(), "limitations": ["الصورة قراءة مرئية."],
    }
    merged = build_combined_chart_image_analysis(platform=platform, visual=visual_agree)
    assert merged["scenario"] == "CONDITIONAL"
    assert merged["agreement"]["status"] == "متفق"
    assert merged["agreement"]["platform_bias"] == "صاعد"
    assert merged["agreement"]["visual_direction"] == "صاعد"
    assert any("Bid/Ask" in value for value in merged["limitations"])

    visual_conflict = {**visual_agree, "scenario": "BEARISH_SCENARIO"}
    conflict = build_combined_chart_image_analysis(platform=platform, visual=visual_conflict)
    assert conflict["scenario"] == "NO_TRADE"
    assert conflict["agreement"]["status"] == "متعارض"

    incomplete = build_combined_chart_image_analysis(platform=platform, visual={**visual_agree, "status": "insufficient", "scenario": "NO_TRADE"})
    assert incomplete["scenario"] == "NO_TRADE"
    assert incomplete["agreement"]["status"] == "أدلة غير مكتملة"
    print("PASS: combined attachment analysis requires agreement and vetoes conflicts or incomplete evidence")


if __name__ == "__main__":
    main()
