"""يشغل مقارنة النماذج فقط على ملف XAU/USD Spot مكتمل وموسوم بالمصدر."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from ml_xauusd_research import MLDataQualityError, ResearchSpec, run_tree_benchmark


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--timeframe-minutes", type=int, default=15)
    parser.add_argument("--minimum-bars", type=int, default=10_000)
    parser.add_argument("--parameter-sensitivity", action="store_true")
    args = parser.parse_args()

    output = Path(args.output)
    # يدعم ملفات المصدر ذات الفاصل المنقوط وأسماء الأعمدة القياسية الشائعة.
    frame = pd.read_csv(args.csv, sep=None, engine="python")
    rename_map = {
        "Date": "timestamp",
        "Datetime": "timestamp",
        "Time": "timestamp",
        "Open": "open",
        "High": "high",
        "Low": "low",
        "Close": "close",
    }
    frame = frame.rename(columns={key: value for key, value in rename_map.items() if key in frame.columns})
    spec = ResearchSpec(
        source=args.source,
        timeframe_minutes=args.timeframe_minutes,
        train_bars_minimum=args.minimum_bars,
    )
    try:
        result = run_tree_benchmark(frame, spec, include_parameter_sensitivity=args.parameter_sensitivity)
    except MLDataQualityError as error:
        result = {
            "classification": "BLOCKED_DATA_QUALITY",
            "reason": str(error),
            "rows_read": int(len(frame)),
            "source": args.source,
        }
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
