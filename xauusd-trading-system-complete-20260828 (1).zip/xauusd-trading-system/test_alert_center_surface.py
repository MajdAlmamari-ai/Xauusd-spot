from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    for token in (
        'id="alertBell"',
        'id="alertBellCount"',
        "xauusd-alert-history-v1",
        "سجل التنبيهات",
        "توافق عائلات الأدلة",
        "اقتراب منطقة سعرية مهمة",
        "اقتراب دعم/مقاومة تاريخية",
        "اقتراب دعم يومي مرجعي",
        "daily-pivot:",
        "window.addXauusdAlertHistory",
    ):
        assert token in SOURCE, token
    print("PASS: bell alert center, local timestamped history, and analytical zone/support alerts are wired")


if __name__ == "__main__":
    main()
