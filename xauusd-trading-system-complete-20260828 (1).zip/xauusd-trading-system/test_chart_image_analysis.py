from __future__ import annotations

import io
import os

from PIL import Image

from chart_image_analysis import analyze_chart_image_ai, build_platform_image_analysis, chart_image_for_vision, validate_chart_image


def image_bytes(image_format: str = "PNG") -> bytes:
    image = Image.new("RGB", (640, 400), color=(12, 25, 36))
    output = io.BytesIO()
    image.save(output, format=image_format)
    return output.getvalue()


def main() -> None:
    image = validate_chart_image(image_bytes())
    assert image.mime_type == "image/png"
    assert image.width == 640 and image.height == 400
    vision_mime, vision_encoded = chart_image_for_vision(validate_chart_image(image_bytes("WEBP")))
    assert vision_mime == "image/png"
    assert vision_encoded
    try:
        validate_chart_image(b"not an image")
        raise AssertionError("invalid image must fail")
    except ValueError:
        pass

    platform = build_platform_image_analysis(
        image=image,
        quote={"status": "success", "stale": False, "live_for_analysis": True, "source": "gold-api.com", "tradable": False},
        news={"pending_event": False},
        timeframe={
            "id": "4h",
            "label": "4 ساعات",
            "technical": {
                "data_contract": {"price_basis": "futures_reference"},
                "evidence_families": {
                    "decision_bias": "صاعد",
                    "evidence_strength": {"score": 80},
                    "trend": {"qualified": True, "direction": "صاعد"},
                    "momentum": {"qualified": True, "direction": "صاعد"},
                },
                "advanced_tools": {"tools": {"order_blocks": {"status": "مرصود"}}},
            },
        },
    )
    assert platform["mode"] == "platform"
    assert platform["scenario"] == "CONDITIONAL"
    assert platform["evidence"]["is_probability"] is False
    assert platform["source_scope"]["image_role"].startswith("مرجع بصري")
    assert any(item["name"] == "Order Blocks" for item in platform["tools"])

    saved_base, saved_key = os.environ.pop("OPENAI_API_BASE", None), os.environ.pop("OPENAI_API_KEY", None)
    unavailable = analyze_chart_image_ai(image=image, user_timeframe="4 ساعات")
    assert unavailable["status"] == "غير متاح"
    assert unavailable["scenario"] == "NO_TRADE"
    if saved_base is not None:
        os.environ["OPENAI_API_BASE"] = saved_base
    if saved_key is not None:
        os.environ["OPENAI_API_KEY"] = saved_key
    print("PASS: chart image validation and separate platform/AI safety contracts are enforced")


if __name__ == "__main__":
    main()
