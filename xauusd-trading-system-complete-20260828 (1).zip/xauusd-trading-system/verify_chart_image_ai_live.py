from __future__ import annotations

import io

from PIL import Image

from chart_image_analysis import analyze_chart_image_ai, available_chart_ai_providers, validate_chart_image


def main() -> None:
    # صورة فارغة مقصودة: المطلوب من النموذج التصريح بنقص الأدلة، لا إنشاء قراءة سوق مختلقة.
    canvas = Image.new("RGB", (640, 400), color=(12, 22, 32))
    buffer = io.BytesIO()
    canvas.save(buffer, format="PNG")
    image = validate_chart_image(buffer.getvalue())
    configured = {item["id"]: item for item in available_chart_ai_providers() if item["available"]}
    assert {"gemini", "manus"}.issubset(configured)
    for provider_id in ("gemini", "manus"):
        result = analyze_chart_image_ai(image=image, user_timeframe="4 ساعات", provider_id=provider_id)
        assert result["mode"] == "ai"
        assert result["status"] != "غير متاح"
        if result["status"] == "insufficient":
            assert result["scenario"] == "NO_TRADE"
        assert result["provider"]["id"] == provider_id
        assert result["scenario"] in {"BULLISH_SCENARIO", "BEARISH_SCENARIO", "CONDITIONAL", "NO_TRADE"}
        assert result["image"]["storage"] == "temporary_in_memory_only"
        assert result["limitations"]
        print(f"PASS: provider={provider_id} status={result['status']} scenario={result['scenario']} returned without persisting the image")


if __name__ == "__main__":
    main()
