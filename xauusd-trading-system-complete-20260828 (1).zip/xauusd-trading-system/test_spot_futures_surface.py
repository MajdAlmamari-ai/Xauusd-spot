from pathlib import Path


PROJECT = Path(__file__).parent
SOURCE = (PROJECT / "production_server.py").read_text(encoding="utf-8")
CONNECTOR = (PROJECT / "mt5_price_connector.py").read_text(encoding="utf-8")


def main() -> None:
    required_backend = [
        "fetch_spot_futures_comparison",
        "spot_futures_comparison",
        "YAHOO_FUTURES_SYMBOL",
        "gold-api.com XAU/USD current + Yahoo Finance GC=F",
        "basis_pct",
        "لا شراء ولا بيع من الفارق وحده",
    ]
    required_ui = [
        "مقارنة الذهب الفوري والآجل",
        "افتتاح آجل",
        "إغلاق آجل",
        "الفارق (الآجل − الفوري)",
        "لا يوجد توقيت مشترك أو تاريخ فوري يومي في هذا المسار",
        "لا يمثلان Bid/Ask أو سعراً تنفيذياً لدى MT5",
    ]
    for marker in required_ui:
        assert marker in SOURCE or marker in CONNECTOR, marker
    for marker in required_backend:
        assert marker in SOURCE or marker in CONNECTOR, marker
    assert "fetch_spot_futures_comparison()" in SOURCE
    assert "execution_price_available" in SOURCE or "execution_price_available" in CONNECTOR
    assert 'history(spot_symbol)' not in CONNECTOR
    print("نجح اختبار سطح مقارنة الفوري والآجل: مسار فوري عام صريح، فارق، وحاجز عدم التنفيذ.")


if __name__ == "__main__":
    main()
