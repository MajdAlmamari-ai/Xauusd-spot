from data_transparency import build_data_transparency


def test_blocks_futures_vs_spot_price_difference() -> None:
    result = build_data_transparency(
        {
            "status": "success", "stale": False, "live_for_analysis": True,
            "last_price": 2400.0, "source_symbol": "XAU/USD", "price_basis": "spot_reference",
        },
        {
            "latest": 2398.0,
            "data_contract": {"source": "Yahoo Finance", "source_symbol": "GC=F", "instrument": "GC=F", "price_basis": "futures_reference"},
            "data_quality": {"valid": True},
        },
    )
    assert result["candles"]["chart_label"].startswith("عقود آجلة")
    assert result["decision_guard"]["compatible_for_price_levels"] is False
    assert result["price_close_diagnostic"]["status"] == "blocked"
    assert result["price_close_diagnostic"]["difference"] is None


def test_shows_diagnostic_only_for_compatible_spot_sources() -> None:
    result = build_data_transparency(
        {
            "status": "success", "stale": False, "live_for_analysis": True,
            "last_price": 2401.0, "source_symbol": "XAU/USD", "price_basis": "spot_reference",
        },
        {
            "latest": 2400.0,
            "data_contract": {"source": "Spot provider", "source_symbol": "XAU/USD", "instrument": "XAU/USD", "price_basis": "spot_reference"},
            "data_quality": {"valid": True},
        },
    )
    assert result["decision_guard"]["compatible_for_price_levels"] is True
    assert result["price_close_diagnostic"]["status"] == "diagnostic_only"
    assert result["price_close_diagnostic"]["difference"] == 1.0


if __name__ == "__main__":
    test_blocks_futures_vs_spot_price_difference()
    test_shows_diagnostic_only_for_compatible_spot_sources()
    print("PASS: data transparency blocks mixed-basis diagnostic and labels compatible comparison")
