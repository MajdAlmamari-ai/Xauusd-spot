"""فحوص القواعد المحسنة: pivots مؤكدة، رفض FVG الضعيفة، واختبار walk-forward بلا تسريب مستقبلي."""

import pandas as pd

from mt5_price_connector import MT5PriceConnector
from technical_indicators import advanced_tools, fair_value_gap, liquidity_sweep


def main() -> None:
    candles = MT5PriceConnector().fetch_ohlc(period="2y", interval="1d")
    assert len(candles) >= 250

    # لا تمرّر الأداة إلا البيانات المتاحة حتى نهاية كل نافذة؛ المستقبل لا يدخل في الإشارة.
    checks, eligible = 0, 0
    for end in range(180, len(candles) - 10, 20):
        available = candles.iloc[:end].copy()
        future = candles.iloc[end:end + 10].copy()
        tools = advanced_tools(available)
        assert str(available.index[-1]) not in str(future.index.tolist())
        for name in ("liquidity_sweep", "fair_value_gap", "anchored_vwap", "volume_profile", "fibonacci"):
            assert "quality_score" in tools["tools"][name]
            assert 0 <= tools["tools"][name]["quality_score"] <= 100
        checks += 1
        eligible += tools["confluence"]["qualified_tools"]

    assert checks >= 5
    # Order Flow لا يتحول إلى بديل اصطناعي عن DOM في أي نافذة.
    assert advanced_tools(candles)["tools"]["order_flow"]["status"] == "غير متاح"
    # الدالتان تبقيان قابلتين للتنفيذ على البيانات التاريخية الحقيقية حتى لو لم تتأهل إشارة.
    assert liquidity_sweep(candles)["status"] in {"مُكتشف (مؤهل)", "مُكتشف (ضعيف)", "غير مكتشف", "غير متاح"}
    assert fair_value_gap(candles)["status"] in {"مُكتشف (مؤهل)", "مُكتشف (ضعيف)", "غير مكتشف", "غير متاح"}
    print(f"نجح walk-forward الوصفي على {checks} نوافذ تاريخية دون تسريب مستقبلي؛ مجموع الأدوات المؤهلة={eligible}.")


if __name__ == "__main__":
    main()
