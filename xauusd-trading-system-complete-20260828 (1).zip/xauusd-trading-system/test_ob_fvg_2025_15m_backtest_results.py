"""تحقق من مخرجات اختبار OB+FVG لإطار 15 دقيقة في سنة 2025."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


RESULTS = Path(__file__).with_name("ob_fvg_2025_15m_backtest_results.json")


def main() -> None:
    assert RESULTS.exists(), "شغّل run_ob_fvg_2025_15m_kaggle_backtest.py أولاً."
    payload = json.loads(RESULTS.read_text(encoding="utf-8"))
    contract, result = payload["data_contract"], payload["result"]
    metrics, trades = result["metrics"], result["trades"]
    assert contract["timeframe"] == "15m"
    assert contract["period"] == "2025-01-01 inclusive إلى 2026-01-01 exclusive"
    assert contract["bars"] > 20_000
    assert metrics["decision_points"] > 0
    assert metrics["filled_trades"] == metrics["wins"] + metrics["losses"]
    assert len(trades) == metrics["filled_trades"]
    for trade in trades:
        decision = pd.Timestamp(trade["decision_time"])
        entry = pd.Timestamp(trade["entry_time"])
        exit_time = pd.Timestamp(trade["exit_time"])
        assert decision < entry <= exit_time, f"تسرب زمني في الصفقة: {trade}"
        assert pd.Timestamp("2025-01-01", tz="UTC") <= decision < pd.Timestamp("2026-01-01", tz="UTC")
    print("نجح تحقق اختبار 15 دقيقة: النطاق صحيح، والمقاييس متسقة، ولا توجد شموع مستقبلية في الإشارة.")


if __name__ == "__main__":
    main()
