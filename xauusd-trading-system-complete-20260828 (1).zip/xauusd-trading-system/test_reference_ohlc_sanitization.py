"""يتحقق من رفض tail مرجعي شاذ دون بناء شمعة من السعر العام."""

import pandas as pd

from mt5_price_connector import MT5PriceConnector


def main() -> None:
    rows = [(4600 + i * .1, 4600.4 + i * .1, 4599.8 + i * .1, 4600.1 + i * .1, 25) for i in range(30)]
    # صف tail شاذ يحاكي print مرجعياً متأخراً؛ ليس قيمة سوقية يعتمد عليها التطبيق.
    rows.append((4603.0, 4680.6, 4602.5, 4680.6, 69))
    frame = pd.DataFrame(rows, columns=["Open", "High", "Low", "Close", "Volume"], index=pd.date_range("2026-08-21", periods=len(rows), freq="min", tz="UTC"))
    connector = MT5PriceConnector()
    clean = connector._sanitize_reference_ohlc(frame, "1m")
    assert len(clean) == 30
    assert float(clean["Close"].iloc[-1]) < 4604
    assert connector.last_ohlc_diagnostics["removed_tail_candles"] == 1
    print("نجح حارس الشموع المرجعية: استُبعد tail الشاذ دون تركيب شمعة من السعر العام.")


if __name__ == "__main__":
    main()
