"""مثال تعليمي: تحويل مقاومة مكسورة إلى دعم مرجعي.

الفكرة: لا يتحول المستوى بسبب Tick أو ذيل شمعة واحد. ننتظر:
1) إغلاقاً مؤكداً أعلى المقاومة بهامش محسوب من ATR.
2) إعادة اختبار للمستوى مع بقاء الإغلاق فوقه.
3) نلغي الفكرة إذا أغلقت شمعة تحت المستوى بالهامش نفسه.

هذا المثال يبني حالة تحليلية مرجعية ولا يتصل بوسيط ولا يرسل أوامر تداول.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class LevelState(StrEnum):
    RESISTANCE = "مقاومة قائمة"
    BREAK_CONFIRMED = "اختراق مؤكد — انتظار إعادة الاختبار"
    NEW_SUPPORT = "دعم جديد بعد إعادة الاختبار"
    INVALIDATED = "فشل الاختراق — عادت مقاومة"


@dataclass(frozen=True)
class Candle:
    open: float
    high: float
    low: float
    close: float


@dataclass
class ResistanceToSupport:
    level: float
    atr: float
    state: LevelState = LevelState.RESISTANCE

    @property
    def confirmation_buffer(self) -> float:
        # يمنع اعتبار الاختراق الضيق ضوضاء. يمكن ضبطه بعد اختبار تاريخي.
        return self.atr * 0.15

    @property
    def retest_tolerance(self) -> float:
        # يسمح بلمس المستوى أو تجاوزه بفارق صغير أثناء إعادة الاختبار.
        return self.atr * 0.10

    def process_closed_candle(self, candle: Candle) -> dict[str, float | str]:
        """يعالج شمعة مكتملة فقط، لا سعراً لحظياً منفرداً."""
        buffer = self.confirmation_buffer

        # 1) تأكيد الاختراق بإغلاق فوق المستوى، لا بمجرد High أعلى المقاومة.
        if self.state == LevelState.RESISTANCE:
            if candle.close >= self.level + buffer:
                self.state = LevelState.BREAK_CONFIRMED

        # 2) إعادة اختبار: يهبط السعر قرب المستوى ثم يغلق فوقه.
        elif self.state == LevelState.BREAK_CONFIRMED:
            touched_level = candle.low <= self.level + self.retest_tolerance
            held_above = candle.close >= self.level
            if touched_level and held_above:
                self.state = LevelState.NEW_SUPPORT
            elif candle.close < self.level - buffer:
                self.state = LevelState.INVALIDATED

        # 3) بعد التحول إلى دعم، كسر الإغلاق تحته يعيد تقييم المستوى.
        elif self.state == LevelState.NEW_SUPPORT:
            if candle.close < self.level - buffer:
                self.state = LevelState.INVALIDATED

        return {
            "level": round(self.level, 2),
            "state": self.state,
            "confirmation_buffer": round(buffer, 2),
        }


if __name__ == "__main__":
    resistance = 4662.77
    level = ResistanceToSupport(level=resistance, atr=28.0)

    # شمعة أغلقت بوضوح فوق المقاومة: لا شراء هنا، بل انتظار إعادة الاختبار.
    breakout = Candle(open=4654.0, high=4674.0, low=4650.0, close=4669.0)
    print(level.process_closed_candle(breakout))

    # شمعة لاحقة لمست المستوى ثم أغلقت فوقه: أصبحت المقاومة دعماً مرجعياً.
    retest = Candle(open=4668.0, high=4672.0, low=4664.5, close=4667.5)
    print(level.process_closed_candle(retest))

    # مثال فشل: إغلاق تحت المستوى بهامش ATR يلغي التحول.
    failure = Candle(open=4660.0, high=4662.0, low=4652.0, close=4657.0)
    print(level.process_closed_candle(failure))
