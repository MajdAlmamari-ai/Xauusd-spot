"""أرشيف دائم لبيانات XAU/USD المرجعية من Gold API.

هذا المكوّن لا ينفذ أوامر ولا ينشئ Bid/Ask أو حجم تداول. يحفظ فقط اللقطات
التي وردت فعلياً من المصدر، ويبني OHLC بعد انتهاء الفترة من هذه اللقطات.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable


DEFAULT_SOURCE = "gold-api.com"
DEFAULT_SYMBOL = "XAU/USD"
TIMEFRAME_SECONDS = {
    "1m": 60,
    "5m": 5 * 60,
    "10m": 10 * 60,
    "15m": 15 * 60,
    "30m": 30 * 60,
    "1h": 60 * 60,
    "2h": 2 * 60 * 60,
    "4h": 4 * 60 * 60,
    "1d": 24 * 60 * 60,
}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def as_utc_timestamp(value: object) -> datetime:
    """يحول وقتاً من المصدر إلى UTC ويرفض الوقت غير القابل للتدقيق."""
    if isinstance(value, datetime):
        timestamp = value
    elif isinstance(value, (int, float)):
        timestamp = datetime.fromtimestamp(float(value), tz=timezone.utc)
    elif isinstance(value, str) and value.strip():
        timestamp = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    else:
        raise ValueError("المصدر لم يرجع source_timestamp صالحاً")
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=timezone.utc)
    return timestamp.astimezone(timezone.utc)


def iso_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _bucket_start(timestamp: datetime, seconds: int) -> datetime:
    epoch = int(timestamp.timestamp())
    return datetime.fromtimestamp(epoch - (epoch % seconds), tz=timezone.utc)


class MarketArchive:
    """طبقة SQLite صغيرة وآمنة للتشغيل من عملية الجامع وواجهة Flask معاً."""

    def __init__(self, database_path: str | Path):
        self.database_path = Path(database_path).expanduser()
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    @classmethod
    def from_environment(cls) -> "MarketArchive":
        return cls(os.getenv("MARKET_ARCHIVE_DB_PATH", "data/xauusd_market_archive.sqlite3"))

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS quote_observations (
                    id INTEGER PRIMARY KEY,
                    source TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    source_timestamp TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    price REAL NOT NULL CHECK(price > 0),
                    status TEXT NOT NULL CHECK(status IN ('LIVE', 'STALE', 'INVALID')),
                    price_hash TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    UNIQUE(source, symbol, source_timestamp, price_hash)
                )
                """
            )
            connection.execute(
                """
                CREATE INDEX IF NOT EXISTS quote_observations_lookup_idx
                ON quote_observations(source, symbol, source_timestamp)
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS ingestion_state (
                    source TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    last_source_timestamp TEXT,
                    last_received_at TEXT,
                    last_success_at TEXT,
                    last_seen_price REAL,
                    latest_status TEXT NOT NULL,
                    consecutive_errors INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(source, symbol)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS derived_candles (
                    source TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    bucket_start TEXT NOT NULL,
                    bucket_end TEXT NOT NULL,
                    open REAL NOT NULL,
                    high REAL NOT NULL,
                    low REAL NOT NULL,
                    close REAL NOT NULL,
                    observation_count INTEGER NOT NULL,
                    is_complete INTEGER NOT NULL CHECK(is_complete IN (0, 1)),
                    quality TEXT NOT NULL,
                    source_first_timestamp TEXT NOT NULL,
                    source_last_timestamp TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(source, symbol, timeframe, bucket_start)
                )
                """
            )
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS collection_gaps (
                    id INTEGER PRIMARY KEY,
                    source TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    prior_timestamp TEXT NOT NULL,
                    next_timestamp TEXT NOT NULL,
                    gap_seconds REAL NOT NULL,
                    detected_at TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    UNIQUE(source, symbol, prior_timestamp, next_timestamp)
                )
                """
            )
        try:
            os.chmod(self.database_path, 0o600)
        except OSError:
            # لا يمنع فشل chmod (مثل بيئة اختبار مقيدة) عمل الأرشيف.
            pass

    @staticmethod
    def _price_hash(source: str, symbol: str, timestamp: str, price: float) -> str:
        value = f"{source}|{symbol}|{timestamp}|{price:.10f}".encode("utf-8")
        return hashlib.sha256(value).hexdigest()

    def _upsert_state(
        self,
        connection: sqlite3.Connection,
        *,
        source: str,
        symbol: str,
        last_source_timestamp: str | None,
        last_received_at: str | None,
        last_success_at: str | None,
        last_seen_price: float | None,
        latest_status: str,
        consecutive_errors: int,
        last_error: str | None,
    ) -> None:
        connection.execute(
            """
            INSERT INTO ingestion_state (
                source, symbol, last_source_timestamp, last_received_at, last_success_at,
                last_seen_price, latest_status, consecutive_errors, last_error, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(source, symbol) DO UPDATE SET
                last_source_timestamp=excluded.last_source_timestamp,
                last_received_at=excluded.last_received_at,
                last_success_at=excluded.last_success_at,
                last_seen_price=excluded.last_seen_price,
                latest_status=excluded.latest_status,
                consecutive_errors=excluded.consecutive_errors,
                last_error=excluded.last_error,
                updated_at=excluded.updated_at
            """,
            (
                source,
                symbol,
                last_source_timestamp,
                last_received_at,
                last_success_at,
                last_seen_price,
                latest_status,
                consecutive_errors,
                last_error,
                iso_utc(utc_now()),
            ),
        )

    def _record_gap_if_needed(
        self,
        connection: sqlite3.Connection,
        *,
        source: str,
        symbol: str,
        previous_timestamp: str | None,
        source_timestamp: datetime,
    ) -> None:
        if not previous_timestamp:
            return
        try:
            previous = as_utc_timestamp(previous_timestamp)
        except ValueError:
            return
        gap_seconds = (source_timestamp - previous).total_seconds()
        expected_seconds = max(30.0, float(os.getenv("MARKET_ARCHIVE_POLL_SECONDS", "30")))
        minimum_gap = max(90.0, expected_seconds * 2.5)
        if gap_seconds <= minimum_gap:
            return
        connection.execute(
            """
            INSERT OR IGNORE INTO collection_gaps (
                source, symbol, prior_timestamp, next_timestamp, gap_seconds, detected_at, reason
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                source,
                symbol,
                iso_utc(previous),
                iso_utc(source_timestamp),
                gap_seconds,
                iso_utc(utc_now()),
                "لم تصل لقطة مرجعية في المدة المتوقعة؛ لم يُنشأ صف OHLC مصطنع.",
            ),
        )

    def ingest_gold_api_quote(self, quote: dict[str, Any]) -> dict[str, Any]:
        """يحفظ لقطة Gold API، ويعيد بناء buckets المتأثرة من اللقطات الحية فقط."""
        source_text = str(quote.get("source", ""))
        source = DEFAULT_SOURCE
        symbol = str(quote.get("source_symbol") or quote.get("instrument") or DEFAULT_SYMBOL).strip()
        if not source_text.startswith(DEFAULT_SOURCE):
            raise ValueError("الجامع يقبل فقط استجابات gold-api.com المرجعية")
        if symbol != DEFAULT_SYMBOL:
            raise ValueError(f"الجامع طلب {DEFAULT_SYMBOL} لكنه تلقى الرمز {symbol or 'غير محدد'}")
        try:
            price = float(quote["last_price"])
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError("اللقطة تفتقد last_price صالحاً") from error
        if price <= 0:
            raise ValueError("سعر Gold API غير موجب")
        source_timestamp = as_utc_timestamp(quote.get("source_timestamp") or quote.get("utc_time"))
        received_at = as_utc_timestamp(quote.get("fetched_at")) if quote.get("fetched_at") else utc_now()
        stale = bool(quote.get("stale")) or quote.get("live_for_analysis") is False
        status = "STALE" if stale else "LIVE"
        canonical_timestamp = iso_utc(source_timestamp)
        canonical_received_at = iso_utc(received_at)
        price_hash = self._price_hash(source, symbol, canonical_timestamp, price)
        payload_json = json.dumps(quote, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))

        with self._connect() as connection:
            state_row = connection.execute(
                "SELECT * FROM ingestion_state WHERE source=? AND symbol=?", (source, symbol)
            ).fetchone()
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO quote_observations (
                    source, symbol, source_timestamp, received_at, price, status, price_hash, payload_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (source, symbol, canonical_timestamp, canonical_received_at, price, status, price_hash, payload_json),
            )
            inserted = cursor.rowcount == 1
            prior_timestamp = state_row["last_source_timestamp"] if state_row else None
            prior_errors = int(state_row["consecutive_errors"] or 0) if state_row else 0
            last_timestamp = canonical_timestamp
            if prior_timestamp:
                try:
                    if as_utc_timestamp(prior_timestamp) > source_timestamp:
                        # لا نخفض high-water mark إذا أعاد المصدر لقطة قديمة.
                        last_timestamp = prior_timestamp
                except ValueError:
                    pass
            if inserted and status == "LIVE":
                self._record_gap_if_needed(
                    connection,
                    source=source,
                    symbol=symbol,
                    previous_timestamp=prior_timestamp,
                    source_timestamp=source_timestamp,
                )
            self._upsert_state(
                connection,
                source=source,
                symbol=symbol,
                last_source_timestamp=last_timestamp,
                last_received_at=canonical_received_at,
                last_success_at=canonical_received_at if status == "LIVE" else (state_row["last_success_at"] if state_row else None),
                last_seen_price=price,
                latest_status=status,
                consecutive_errors=0 if status == "LIVE" else prior_errors,
                last_error=None if status == "LIVE" else str(quote.get("message") or "لقطة مصدر متأخرة"),
            )
            if inserted and status == "LIVE":
                self._rebuild_affected_candles(connection, source, symbol, source_timestamp)

        return {
            "inserted": inserted,
            "status": status,
            "source": source,
            "symbol": symbol,
            "source_timestamp": canonical_timestamp,
            "price": price,
        }

    def record_fetch_failure(self, *, source: str = DEFAULT_SOURCE, symbol: str = DEFAULT_SYMBOL, error: Exception | str) -> None:
        """يحفظ أثر الفشل في الحالة فقط؛ لا يعيد آخر سعر باعتباره حياً."""
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM ingestion_state WHERE source=? AND symbol=?", (source, symbol)
            ).fetchone()
            errors = int(row["consecutive_errors"] or 0) + 1 if row else 1
            self._upsert_state(
                connection,
                source=source,
                symbol=symbol,
                last_source_timestamp=row["last_source_timestamp"] if row else None,
                last_received_at=iso_utc(utc_now()),
                last_success_at=row["last_success_at"] if row else None,
                last_seen_price=row["last_seen_price"] if row else None,
                latest_status="ERROR",
                consecutive_errors=errors,
                last_error=str(error)[:800],
            )

    def _rebuild_affected_candles(
        self, connection: sqlite3.Connection, source: str, symbol: str, observed_at: datetime
    ) -> None:
        buckets: set[tuple[str, datetime]] = set()
        for timeframe, seconds in TIMEFRAME_SECONDS.items():
            buckets.add((timeframe, _bucket_start(observed_at, seconds)))
        partial = connection.execute(
            """
            SELECT timeframe, bucket_start FROM derived_candles
            WHERE source=? AND symbol=? AND is_complete=0 AND bucket_end<=?
            """,
            (source, symbol, iso_utc(observed_at)),
        ).fetchall()
        for row in partial:
            timeframe = str(row["timeframe"])
            if timeframe in TIMEFRAME_SECONDS:
                buckets.add((timeframe, as_utc_timestamp(row["bucket_start"])))
        for timeframe, bucket_start in buckets:
            self._rebuild_candle(connection, source, symbol, timeframe, bucket_start, observed_at)

    def _rebuild_candle(
        self,
        connection: sqlite3.Connection,
        source: str,
        symbol: str,
        timeframe: str,
        bucket_start: datetime,
        observed_at: datetime,
    ) -> None:
        seconds = TIMEFRAME_SECONDS[timeframe]
        bucket_end = bucket_start + timedelta(seconds=seconds)
        rows = connection.execute(
            """
            SELECT source_timestamp, price FROM quote_observations
            WHERE source=? AND symbol=? AND status='LIVE' AND source_timestamp>=? AND source_timestamp<?
            ORDER BY source_timestamp ASC, id ASC
            """,
            (source, symbol, iso_utc(bucket_start), iso_utc(bucket_end)),
        ).fetchall()
        if not rows:
            return
        prices = [float(row["price"]) for row in rows]
        complete = observed_at >= bucket_end
        if complete and len(rows) >= 2:
            quality = "COMPLETE"
        elif complete:
            quality = "COMPLETE_SPARSE"
        else:
            quality = "PARTIAL"
        connection.execute(
            """
            INSERT INTO derived_candles (
                source, symbol, timeframe, bucket_start, bucket_end, open, high, low, close,
                observation_count, is_complete, quality, source_first_timestamp,
                source_last_timestamp, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(source, symbol, timeframe, bucket_start) DO UPDATE SET
                bucket_end=excluded.bucket_end,
                open=excluded.open,
                high=excluded.high,
                low=excluded.low,
                close=excluded.close,
                observation_count=excluded.observation_count,
                is_complete=excluded.is_complete,
                quality=excluded.quality,
                source_first_timestamp=excluded.source_first_timestamp,
                source_last_timestamp=excluded.source_last_timestamp,
                updated_at=excluded.updated_at
            """,
            (
                source,
                symbol,
                timeframe,
                iso_utc(bucket_start),
                iso_utc(bucket_end),
                prices[0],
                max(prices),
                min(prices),
                prices[-1],
                len(prices),
                int(complete),
                quality,
                str(rows[0]["source_timestamp"]),
                str(rows[-1]["source_timestamp"]),
                iso_utc(utc_now()),
            ),
        )

    def status(self, *, source: str = DEFAULT_SOURCE, symbol: str = DEFAULT_SYMBOL) -> dict[str, Any]:
        with self._connect() as connection:
            state = connection.execute(
                "SELECT * FROM ingestion_state WHERE source=? AND symbol=?", (source, symbol)
            ).fetchone()
            observations = int(
                connection.execute(
                    "SELECT COUNT(*) FROM quote_observations WHERE source=? AND symbol=?", (source, symbol)
                ).fetchone()[0]
            )
            gaps = int(
                connection.execute(
                    "SELECT COUNT(*) FROM collection_gaps WHERE source=? AND symbol=?", (source, symbol)
                ).fetchone()[0]
            )
            candles = {
                str(row["timeframe"]): {
                    "count": int(row["count"]),
                    "last_bucket_start": row["last_bucket_start"],
                    "last_quality": row["last_quality"],
                }
                for row in connection.execute(
                    """
                    SELECT timeframe, COUNT(*) AS count, MAX(bucket_start) AS last_bucket_start,
                           (SELECT quality FROM derived_candles c2
                            WHERE c2.source=derived_candles.source AND c2.symbol=derived_candles.symbol
                              AND c2.timeframe=derived_candles.timeframe
                            ORDER BY c2.bucket_start DESC LIMIT 1) AS last_quality
                    FROM derived_candles
                    WHERE source=? AND symbol=?
                    GROUP BY timeframe
                    """,
                    (source, symbol),
                ).fetchall()
            }
        return {
            "enabled": True,
            "source": source,
            "symbol": symbol,
            "execution_classification": "public_market_reference_not_executable",
            "database": str(self.database_path),
            "observation_count": observations,
            "gap_count": gaps,
            "state": dict(state) if state else {
                "latest_status": "NOT_STARTED",
                "message": "قاعدة الأرشيف جاهزة، لكن خدمة الجامع لم تحفظ لقطة بعد.",
            },
            "derived_candles": candles,
            "limits": {
                "does_not_provide": ["bid", "ask", "broker_spread", "execution", "order_flow"],
                "candle_basis": "OHLC مشتق من لقطات السعر المرجعي الحية الواردة فقط",
                "gap_policy": "لا تُملأ الفجوات بشموع أو أسعار مصطنعة",
            },
        }

    def latest_live_quote(self, *, source: str = DEFAULT_SOURCE, symbol: str = DEFAULT_SYMBOL) -> dict[str, Any]:
        """يعيد آخر لقطة مرجعية من الجامع فقط، ولا يبدأ طلباً جديداً إلى مصدر السوق."""
        with self._connect() as connection:
            state = connection.execute(
                "SELECT * FROM ingestion_state WHERE source=? AND symbol=?", (source, symbol)
            ).fetchone()
            if state is None:
                return {
                    "status": "error",
                    "source": f"{source} XAU/USD market archive",
                    "source_symbol": symbol,
                    "stale": True,
                    "live_for_analysis": False,
                    "tradable": False,
                    "message": "جامع السعر المرجعي لم يحفظ أي لقطة بعد.",
                }
            if str(state["latest_status"]) == "ERROR":
                return {
                    "status": "error",
                    "source": f"{source} XAU/USD market archive",
                    "source_symbol": symbol,
                    "stale": True,
                    "live_for_analysis": False,
                    "tradable": False,
                    "source_timestamp": state["last_source_timestamp"],
                    "fetched_at": state["last_received_at"],
                    "message": f"فشل جامع السعر المرجعي؛ حُجب آخر سعر محفوظ من العرض الحي. السبب: {state['last_error'] or 'غير معروف'}",
                }
            row = connection.execute(
                """
                SELECT * FROM quote_observations
                WHERE source=? AND symbol=? AND status='LIVE'
                ORDER BY source_timestamp DESC, id DESC LIMIT 1
                """,
                (source, symbol),
            ).fetchone()
        if row is None:
            return {
                "status": "error",
                "source": f"{source} XAU/USD market archive",
                "source_symbol": symbol,
                "stale": True,
                "live_for_analysis": False,
                "tradable": False,
                "message": "لا توجد لقطة حية صالحة في الأرشيف؛ لا يوجد سعر حالي للعرض.",
            }
        source_timestamp = as_utc_timestamp(row["source_timestamp"])
        age_seconds = max(0.0, (utc_now() - source_timestamp).total_seconds())
        stale_limit = float(os.getenv("MARKET_PRICE_STALE_SECONDS", "45"))
        stale = age_seconds > stale_limit
        try:
            payload = json.loads(str(row["payload_json"]))
        except (TypeError, ValueError, json.JSONDecodeError):
            payload = {}
        payload.update(
            {
                "status": "success",
                "source": "gold-api.com XAU/USD live market reference (persistent archive)",
                "source_symbol": symbol,
                "symbol": payload.get("symbol") or "XAUUSD",
                "instrument": symbol,
                "price_basis": "spot_reference",
                "source_kind": "public_market_reference",
                "last_price": round(float(row["price"]), 2),
                "source_timestamp": iso_utc(source_timestamp),
                "fetched_at": row["received_at"],
                "utc_time": source_timestamp.strftime("%Y-%m-%d %H:%M:%S UTC"),
                "age_seconds": round(age_seconds, 1),
                "stale": stale,
                "live_for_analysis": not stale,
                "tradable": False,
                "analysis_only": True,
                "bid": None,
                "ask": None,
                "spread": None,
                "data_quality": "market_reference_stale" if stale else "market_reference_current",
                "collector_backed": True,
                "message": "آخر لقطة مرجعية محفوظة من الجامع؛ ليست Bid/Ask أو سعراً تنفيذياً." if not stale else "آخر لقطة محفوظة من الجامع متأخرة؛ لا تعرض كسعر حي.",
            }
        )
        return payload

    def candles(self, *, timeframe: str, source: str = DEFAULT_SOURCE, symbol: str = DEFAULT_SYMBOL) -> list[dict[str, Any]]:
        if timeframe not in TIMEFRAME_SECONDS:
            raise ValueError(f"إطار أرشيف غير مدعوم: {timeframe}")
        with self._connect() as connection:
            rows: Iterable[sqlite3.Row] = connection.execute(
                """
                SELECT * FROM derived_candles
                WHERE source=? AND symbol=? AND timeframe=?
                ORDER BY bucket_start ASC
                """,
                (source, symbol, timeframe),
            ).fetchall()
        return [dict(row) for row in rows]
