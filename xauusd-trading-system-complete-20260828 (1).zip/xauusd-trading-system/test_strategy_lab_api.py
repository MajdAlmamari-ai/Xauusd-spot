"""يتحقق من أن مختبر الاستراتيجيات يوضح السماح والحظر والحياد دون تعديل حالة السوق."""

from production_server import app


def main() -> None:
    client = app.test_client()
    expectations = {
        "high_impact_news": "انتظار / لا دخول",
        "conflicting_evidence": "انتظار / حياد",
    }
    for test_id in ("liquidity_confluence", *expectations):
        response = client.get(f"/api/strategy-test/{test_id}/1d")
        assert response.status_code == 200, response.get_data(as_text=True)
        payload = response.get_json()
        assert payload["test_id"] == test_id
        if test_id == "liquidity_confluence":
            result = payload["result"]
            assert result["signal"] in {"شراء مشروط", "انتظار / حياد"}, result
            if result["decision_state"] == "signal":
                assert result["risk_reward"] >= 1.2
            else:
                assert result["decision_state"] == "neutral"
                assert result["entry"] is None and result["stop_loss"] is None and result["take_profit"] is None
                assert "عائداً/مخاطرة كافياً" in result["reason"]
        else:
            assert payload["result"]["signal"] == expectations[test_id], payload
        assert "لا يغير التوصية الحية" in payload["test_scope"]
    invalid = client.get("/api/strategy-test/not-real/1d")
    assert invalid.status_code == 400
    print("نجحت اختبارات مختبر السيولة والأخبار وتعـارض الأدلة.")


if __name__ == "__main__":
    main()
