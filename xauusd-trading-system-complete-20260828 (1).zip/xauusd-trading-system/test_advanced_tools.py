"""اختبارات أدوات السيولة وبنية السوق على شموع محددة؛ لا تستخدم بيانات مصطنعة في التطبيق."""

import pandas as pd

from technical_indicators import advanced_tools, calculate_snapshot, fair_value_gap, liquidity_sweep


def frame() -> pd.DataFrame:
    rows = [
        (100, 101, 99, 100, 1000), (100, 102, 99.5, 101, 1100), (101, 103, 100, 102, 1200),
        (102, 104, 101, 103, 1300), (103, 105, 102, 104, 1400), (104, 106, 103, 105, 1500),
        (105, 107, 104, 106, 1600), (106, 108, 105, 107, 1700), (107, 109, 106, 108, 1800),
        (108, 110, 107, 109, 1900), (109, 111, 108, 110, 2000), (110, 112, 109, 111, 2100),
        (111, 113, 110, 112, 2200), (112, 114, 111, 113, 2300), (113, 115, 112, 114, 2400),
        (114, 116, 113, 115, 2500), (115, 117, 114, 116, 2600), (116, 118, 115, 117, 2700),
        (117, 119, 116, 118, 2800), (118, 120, 117, 119, 2900), (119, 121, 118, 120, 3000),
        (120, 122, 119, 121, 3100), (121, 123, 120, 122, 3200), (122, 124, 121, 123, 3300),
        (123, 125, 122, 124, 3400), (124, 126, 123, 125, 3500), (125, 127, 124, 126, 3600),
        (126, 128, 125, 127, 3700), (127, 129, 126, 128, 3800), (128, 130, 127, 129, 3900),
    ]
    return pd.DataFrame(rows, columns=["Open", "High", "Low", "Close", "Volume"], index=pd.date_range("2026-01-01", periods=len(rows), freq="h"))


def main() -> None:
    candles = frame()
    snapshot = calculate_snapshot(candles)
    tools = snapshot["advanced_tools"]
    assert set(tools["tools"]) == {"liquidity_sweep", "liquidity_zones", "support_resistance", "order_blocks", "order_flow", "anchored_vwap", "volume_profile", "fibonacci", "fair_value_gap"}
    assert tools["tools"]["anchored_vwap"]["status"] in {"متاح (مؤهل)", "متاح (ضعيف)", "غير متاح"}
    assert tools["tools"]["volume_profile"]["status"].startswith("تقريبي")
    assert tools["tools"]["order_flow"]["status"] == "غير متاح"
    assert "zones" in tools["tools"]["liquidity_zones"]
    assert "zones" in tools["tools"]["support_resistance"]
    assert "zones" in tools["tools"]["order_blocks"]
    assert tools["tools"]["fibonacci"]["status"] in {"متاح (مؤهل)", "غير متاح"}
    assert "quality" in tools["tools"]["fair_value_gap"]
    assert all("quality_score" in tool for tool in tools["tools"].values())
    assert "qualified_tools" in tools["confluence"]
    assert snapshot["indicator_combinations"]
    assert {"title", "components", "caution", "context"}.issubset(snapshot["indicator_combinations"][0])
    assert liquidity_sweep(candles)["status"] in {"مُكتشف (مؤهل)", "مُكتشف (ضعيف)", "غير مكتشف", "غير متاح"}
    assert fair_value_gap(candles)["status"] in {"مُكتشف (مؤهل)", "مُكتشف (ضعيف)", "غير مكتشف", "غير متاح"}
    print("نجحت اختبارات أدوات Liquidity/FVG/AVWAP/Volume Profile/Fibonacci وحارس Order Flow.")


if __name__ == "__main__":
    main()
