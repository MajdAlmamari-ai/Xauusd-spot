"""اختبارات استراتيجية بنية السعر + RSI/MACD؛ لا تستخدم بيانات سوق خارجية أو نتائج محفوظة."""

from __future__ import annotations

import numpy as np
import pandas as pd

from reproducible_backtest import CostModel, WARMUP_BARS, prepare_indicators, signal_series, simulate


def raw_candles(rows: int = 340) -> pd.DataFrame:
    index = pd.date_range("2025-02-03 00:00:00", periods=rows, freq="1h", tz="UTC")
    base = 2500.0 + np.arange(rows) * 0.08 + np.sin(np.arange(rows) / 5.0) * 1.25
    return pd.DataFrame({
        "Open": base - 0.12,
        "High": base + 0.34,
        "Low": base - 0.41,
        "Close": base,
        "Volume": np.full(rows, 100.0),
    }, index=index)


def test_price_action_structure_is_causal_when_future_candles_are_appended() -> None:
    raw = raw_candles()
    cutoff = 270
    prefix, whole = prepare_indicators(raw.iloc[:cutoff]), prepare_indicators(raw)
    columns = [
        "CONFIRMED_PIVOT_HIGH", "CONFIRMED_PIVOT_LOW", "SUPPORT", "RESISTANCE",
        "STRUCTURE_BULL", "STRUCTURE_BEAR", "PA_LONG_LOCATION", "PA_SHORT_LOCATION",
        "PA_LONG_TRIGGER", "PA_SHORT_TRIGGER", "PA_LONG_RR_OK", "PA_SHORT_RR_OK",
    ]
    for column in columns:
        assert prefix[column].equals(whole[column].iloc[:cutoff])
    for strategy in ("price_action_sr_rsi", "price_action_sr_macd", "price_action_sr_rsi_macd"):
        assert signal_series(prefix, strategy).equals(signal_series(whole, strategy).iloc[:cutoff])


def _prepared_signal_fixture(rows: int = 4) -> pd.DataFrame:
    index = pd.date_range("2025-03-03", periods=rows, freq="1h", tz="UTC")
    frame = pd.DataFrame(index=index)
    for column, value in {
        "Open": 100.0, "High": 100.2, "Low": 99.8, "Close": 100.0, "Volume": 100.0,
        "ATR": 1.0, "EMA20": 101.0, "EMA50": 100.0, "EMA200": 99.0, "RSI14": 49.0,
        "RSI2": 50.0, "MACD_LINE": -0.1, "MACD_SIGNAL": 0.0, "MACD_HIST": 0.1,
        "ADX": 25.0, "BB_UPPER": 102.0, "BB_LOWER": 98.0, "KC_UPPER": 102.0,
        "KC_LOWER": 98.0, "DONCHIAN_HIGH": 101.0, "DONCHIAN_LOW": 99.0, "NR7": False,
        "ATR_MEDIAN": 1.0, "SUPPORT": 99.0, "RESISTANCE": 107.0, "STRUCTURE_BUFFER": 0.25,
        "STRUCTURE_BULL": False, "STRUCTURE_BEAR": False, "PA_LONG_LOCATION": False,
        "PA_SHORT_LOCATION": False, "PA_LONG_TRIGGER": False, "PA_SHORT_TRIGGER": False,
        "PA_LONG_RR_OK": False, "PA_SHORT_RR_OK": False,
    }.items():
        frame[column] = value
    return frame


def test_combined_filter_requires_price_location_rsi_and_macd() -> None:
    frame = _prepared_signal_fixture()
    row = frame.index[2]
    frame.loc[row, ["STRUCTURE_BULL", "PA_LONG_LOCATION", "PA_LONG_TRIGGER", "PA_LONG_RR_OK"]] = True
    frame.loc[row, ["RSI14", "MACD_LINE", "MACD_SIGNAL", "MACD_HIST"]] = [55.0, 0.5, 0.1, 0.3]
    assert int(signal_series(frame, "price_action_sr_rsi").loc[row]) == 1
    assert int(signal_series(frame, "price_action_sr_macd").loc[row]) == 1
    assert int(signal_series(frame, "price_action_sr_rsi_macd").loc[row]) == 1
    frame.loc[row, "MACD_HIST"] = -0.1
    assert int(signal_series(frame, "price_action_sr_rsi_macd").loc[row]) == 0


def test_price_action_trade_enters_next_open_and_uses_confirmed_zone_levels() -> None:
    frame = _prepared_signal_fixture(WARMUP_BARS + 3)
    decision, entry = frame.index[WARMUP_BARS], frame.index[WARMUP_BARS + 1]
    frame.loc[decision, ["STRUCTURE_BULL", "PA_LONG_LOCATION", "PA_LONG_TRIGGER", "PA_LONG_RR_OK"]] = True
    frame.loc[decision, ["RSI14", "MACD_LINE", "MACD_SIGNAL", "MACD_HIST"]] = [55.0, 0.5, 0.1, 0.3]
    frame.loc[entry, ["Open", "High", "Low", "Close"]] = [101.0, 107.5, 100.5, 106.5]
    trades = simulate(frame, "price_action_sr_rsi_macd", costs=CostModel(0.0, 0.0, 0.0))
    assert len(trades) == 1
    assert pd.Timestamp(trades[0]["decision_time"]) == decision
    assert pd.Timestamp(trades[0]["entry_time"]) == entry
    assert trades[0]["entry"] == 101.0
    assert trades[0]["stop_trigger"] == 98.75
    assert trades[0]["target_trigger"] == 107.0
    assert trades[0]["outcome"] == "target"


def main() -> None:
    test_price_action_structure_is_causal_when_future_candles_are_appended()
    test_combined_filter_requires_price_location_rsi_and_macd()
    test_price_action_trade_enters_next_open_and_uses_confirmed_zone_levels()
    print("PASS: causal price action structure, combined RSI/MACD filtering, next-open zone execution")


if __name__ == "__main__":
    main()
