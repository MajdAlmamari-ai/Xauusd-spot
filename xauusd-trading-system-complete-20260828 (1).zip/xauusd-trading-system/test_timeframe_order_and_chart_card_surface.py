from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    ordered = "TIMEFRAME_ASCENDING=['1m','5m','10m','15m','30m','1h','2h','4h','1d','1wk','1mo']"
    assert ordered in SOURCE
    assert "TIMEFRAME_FILTER_DEFAULT=['1m','5m','10m','15m','30m','1h','2h','4h','1d']" in SOURCE
    assert "const sortTimeframesAscending=rows=>" in SOURCE
    assert "const orderedRows=sortTimeframesAscending(rows)" in SOURCE
    assert "const visibleIds=readTimeframeFilter(rows),ordered=sortTimeframesAscending(rows)" in SOURCE
    for fragment in (
        "background:radial-gradient(85% 52%",
        ".app.studioLayout .chartShell{margin:0 12px 16px",
        ".app.studioLayout .chartCanvas{height:370px",
        "border-radius:20px",
        "الأطر مرتبة من الأصغر إلى الأكبر",
    ):
        assert fragment in SOURCE, fragment
    print("PASS: timeframe ordering is strictly ascending and the chart has a bounded professional card surface")


if __name__ == "__main__":
    main()
