from production_server import app


def main() -> None:
    client = app.test_client()
    with app.test_request_context("/api/strategy-backtest/ob-fvg/1d?spread=0.40&slippage=0.10&commission=0.25"):
        from production_server import parse_backtest_costs
        costs = parse_backtest_costs()
        assert costs.as_dict()["spread_price"] == 0.40
        assert costs.as_dict()["slippage_price_each_side"] == 0.10
        assert costs.as_dict()["commission_price_round_turn"] == 0.25
    response = client.get("/api/strategy-backtest/ob-fvg/1d?spread=-1")
    assert response.status_code == 400
    assert "بين 0" in response.get_json()["error"]
    print("PASS: OB+FVG cost options parse valid values and reject invalid execution-cost inputs")


if __name__ == "__main__":
    main()
