"""اختبار سلامة مخرجات مقارنة الاستراتيجيات لعام 2025."""
from __future__ import annotations

import json
from pathlib import Path


RESULTS = Path(__file__).with_name("strategy_comparison_2025_results.json")
EXPECTED = {"1h:ema_pullback", "1h:donchian_breakout", "1h:rsi_bollinger", "1h:ob_fvg", "4h:ema_pullback", "4h:donchian_breakout", "4h:rsi_bollinger", "4h:ob_fvg"}


def main() -> None:
    payload = json.loads(RESULTS.read_text(encoding="utf-8"))
    assert payload["data_contract"]["period"] == "2025-01-01 inclusive إلى 2026-01-01 exclusive"
    assert set(payload["results"]) == EXPECTED
    for key, value in payload["results"].items():
        metrics = value["metrics"]
        assert metrics["filled_trades"] == metrics["wins"] + metrics["losses"], key
        assert metrics["filled_trades"] >= 0, key
        assert "cost_sensitivity_r" in metrics, key
        if key.endswith(":ob_fvg"):
            assert value["oos_h2_2025"] is None, key
        else:
            oos = value["oos_h2_2025"]
            assert oos["filled_trades"] == oos["wins"] + oos["losses"], key
    print("نجح تحقق مقارنة الاستراتيجيات: جميع النوافذ والأطر والمقاييس وحالة OOS متسقة.")


if __name__ == "__main__":
    main()
