import unittest

import numpy as np
import pandas as pd

from ml_xauusd_research import MLDataQualityError, ResearchSpec, chronological_splits, make_feature_frame, validate_spot_ohlc


def fixture_ohlc(rows: int = 140):
    timestamps = pd.date_range("2026-01-05T00:00:00Z", periods=rows, freq="15min")
    close = 4500 + np.linspace(0, 20, rows) + np.sin(np.arange(rows) / 4)
    return pd.DataFrame(
        {
            "timestamp": timestamps,
            "open": close - 0.2,
            "high": close + 0.5,
            "low": close - 0.5,
            "close": close,
        }
    )


class MLXauusdResearchTests(unittest.TestCase):
    def spec(self, minimum=100):
        return ResearchSpec(source="fixture_spot", train_bars_minimum=minimum)

    def test_features_do_not_use_future_return_as_feature(self):
        dataset = make_feature_frame(validate_spot_ohlc(fixture_ohlc(), self.spec()), self.spec())
        self.assertIn("future_return", dataset.columns)
        self.assertIn("target_up", dataset.columns)
        self.assertNotIn("future_return", [c for c in dataset if c.startswith("ret_")])

    def test_midweek_gap_creates_a_separate_segment(self):
        frame = fixture_ohlc()
        frame.loc[80:, "timestamp"] = frame.loc[80:, "timestamp"] + pd.Timedelta(hours=5)
        checked = validate_spot_ohlc(frame, self.spec())
        self.assertEqual(checked["segment_id"].nunique(), 2)
        dataset = make_feature_frame(checked, self.spec())
        self.assertTrue((dataset.groupby("segment_id")["future_return"].count() > 0).all())

    def test_chronological_split_has_purge_gap(self):
        splits = list(chronological_splits(range(160), folds=3, purge_bars=4))
        self.assertEqual(len(splits), 3)
        for train, test in splits:
            self.assertGreaterEqual(test[0] - train[-1], 5)

    def test_macd_state_does_not_cross_a_data_gap(self):
        frame = fixture_ohlc(rows=180)
        frame.loc[90:, "timestamp"] = frame.loc[90:, "timestamp"] + pd.Timedelta(hours=5)
        checked = validate_spot_ohlc(frame, self.spec())
        dataset = make_feature_frame(checked, self.spec())
        second_segment_start = dataset.loc[dataset["segment_id"] == 1, "timestamp"].min()
        # لا تقبل الصفوف الأولى بعد الفجوة قبل اكتمال warm-up داخل المقطع الجديد.
        self.assertGreaterEqual(second_segment_start, checked.loc[90, "timestamp"] + pd.Timedelta(minutes=30))


if __name__ == "__main__":
    unittest.main()
