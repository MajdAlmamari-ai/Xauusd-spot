"""حارس نتائج مقارنة مرشحات RSI وEMA لاستراتيجية 4 ساعات في 2025."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


RESULTS = Path(__file__).with_name("ob_fvg_2025_4h_filter_comparison.json")
EXPECTED_MODES = {"none", "rsi", "ma", "rsi_ma"}


def main() -> None:
    assert RESULTS.exists(), "شغّل run_ob_fvg_2025_4h_filter_comparison.py أولاً."
    payload = json.loads(RESULTS.read_text(encoding="utf-8"))
    contract, results = payload["data_contract"], payload["results"]
    assert contract["timeframe"] == "4h"
    assert contract["period"] == "2025-01-01 inclusive إلى 2026-01-01 exclusive"
    assert set(results) == EXPECTED_MODES
    decision_points = {result["metrics"]["decision_points"] for result in results.values()}
    assert len(decision_points) == 1 and next(iter(decision_points)) > 0
    for mode, result in results.items():
        metrics = result["metrics"]
        assert result["methodology"]["filter_mode"] == mode
        assert metrics["filled_trades"] == metrics["wins"] + metrics["losses"]
        assert metrics["filtered_out_setups"] >= 0
        assert metrics["post_filter_setups"] <= metrics["eligible_setups"]
        for trade in result["trades"]:
            decision = pd.Timestamp(trade["decision_time"])
            entry = pd.Timestamp(trade["entry_time"])
            exit_time = pd.Timestamp(trade["exit_time"])
            assert decision < entry <= exit_time, f"تسرب مستقبلي في {mode}: {trade}"
    print("نجح تحقق مقارنة مرشحات 4 ساعات: عقد موحد، مقاييس متسقة، ولا تسرب زمني.")


if __name__ == "__main__":
    main()
