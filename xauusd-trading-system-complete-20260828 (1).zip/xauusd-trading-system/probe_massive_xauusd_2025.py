"""يفحص فقط توفر شموع Massive لرمز XAUUSD ولا يغيّر بيانات الاختبار المحلية."""
from __future__ import annotations

import json
import sys

sys.path.append("/opt/.manus/.sandbox-runtime")
from data_api import ApiClient


def main() -> None:
    client = ApiClient()
    response = client.call_api(
        "Massive/get_forex_bars",
        path_params={
            "forexTicker": "C:XAUUSD",
            "multiplier": "15",
            "timespan": "minute",
            "from": "2025-09-12",
            "to": "2025-10-16",
        },
        query={"limit": "50000", "sort": "asc"},
    )
    print(json.dumps(response, ensure_ascii=False)[:12000])


if __name__ == "__main__":
    main()
