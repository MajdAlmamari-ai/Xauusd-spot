# معايير تحسين أدوات السيولة وبنية السوق

## مبدأ التصميم

لا تُقاس «دقة» أدوات السعر والحجم بعنوان جذاب أو نتيجة ثنائية. التحسين المقبول هنا هو تقليل الإشارات الضعيفة، وإظهار سبب القبول أو الرفض، وعدم تحويل حجم الشموع أو الفجوات السعرية إلى ادعاء عن أوامر مؤسسية أو Order Flow فعلي.

| الأداة | التحسين المنهجي |
|---|---|
| Liquidity Sweep | مستوى pivot مؤكد، حد اختراق يساوي جزءاً من ATR، إغلاق راجع، رفض سعري، وحجم نسبي عند توفره |
| Fair Value Gap | تسلسل ثلاث شمعات، حد أدنى لحجم الفجوة نسبة إلى ATR، شمعة وسطى ذات displacement، وحالة لمس/تخفيف/إبطال |
| Anchored VWAP | مرساة عند pivot مؤكد بدلاً من قمة/قاع مطلق، مع جودة لحجم الشموع والمسافة عن VWAP مقيسة بـ ATR |
| Volume Profile | POC وValue Area 70% وHVN/LVN، مع وسم صريح بأنه تقدير من الشموع لا Volume-at-Price أصلياً |
| Fibonacci | زوج pivot مؤكد متعاكس بمدى أدنى نسبة إلى ATR، مع نسب الارتداد والامتدادات |
| Order Flow | يبقى غير متاح من OHLC؛ يتطلب Tick عند Bid/Ask وDOM أو Time & Sales |

## التحقق

يُطبق اختبار walk-forward على نوافذ تاريخية: لا تمرّر الأداة إلا الشموع المتاحة حتى لحظة القرار، ثم تقاس حركة مستقبلية منفصلة لأغراض المراجعة الوصفية. لا تستخدم النتائج لاختيار إعدادات بأثر رجعي أو للادعاء بميزة ربحية.

## مراجع

- TradingView, *Volume Profile indicators: basic concepts* — Volume Profile يعرض نشاطاً بحسب مستويات السعر، ويستخدم Tick Volume للفوركس وCFD؛ كما أن Up/Down ليس Buy/Sell. https://www.tradingview.com/support/solutions/43000502040-volume-profile-indicators-basic-concepts/
- TradingView, *Anchored volume profile drawing tool* — يعرّف الحساب من نقطة بداية محددة إلى نهاية البيانات المتاحة. https://www.tradingview.com/support/solutions/43000707989-anchored-volume-profile-drawing-tool/
- ACY Securities, *Fair Value Gaps Explained* — يوضح بنية ثلاث شمعات وأهمية التأكيد من إطار أدنى بدلاً من ملاحقة كل فجوة. https://acy.com/en/market-news/education/fair-value-gaps-explained-smart-money-footprints-market-j-o-143123/
- QuantInsti, *Walk-Forward Optimisation* — يشرح التحقق المتدرج خارج العينة وحدوده واحتمال الإفراط في الملاءمة. https://blog.quantinsti.com/walk-forward-optimization-introduction/
