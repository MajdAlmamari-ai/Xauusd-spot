"""عقود البيانات والتحقق قبل تحليل XAUUSD أو بناء سيناريو سعري.

هذه الوحدة تمنع خلط سعر XAU/USD المرجعي مع شموع GC=F الآجلة في مستوى
دخول أو وقف أو هدف واحد، وتوثق ما إذا كان كل إطار أصلياً أو مجمعاً.
"""

from __future__ import annotations

from typing import Any

import pandas as pd


TIMEFRAME_SOURCE_CONTRACTS: dict[str, dict[str, Any]] = {
    "1m": {"data_mode": "NATIVE_DATA", "source_interval": "1m", "price_basis": "futures_reference"},
    "5m": {"data_mode": "NATIVE_DATA", "source_interval": "5m", "price_basis": "futures_reference"},
    "10m": {"data_mode": "RESAMPLED_DATA", "source_interval": "5m", "target_rule": "10min", "expected_components": 2, "price_basis": "futures_reference"},
    "15m": {"data_mode": "NATIVE_DATA", "source_interval": "15m", "price_basis": "futures_reference"},
    "30m": {"data_mode": "NATIVE_DATA", "source_interval": "30m", "price_basis": "futures_reference"},
    "1h": {"data_mode": "NATIVE_DATA", "source_interval": "1h", "price_basis": "futures_reference"},
    "2h": {"data_mode": "RESAMPLED_DATA", "source_interval": "1h", "target_rule": "2h", "expected_components": 2, "price_basis": "futures_reference"},
    "4h": {"data_mode": "RESAMPLED_DATA", "source_interval": "1h", "target_rule": "4h", "expected_components": 4, "price_basis": "futures_reference"},
    "1d": {"data_mode": "NATIVE_DATA", "source_interval": "1d", "price_basis": "futures_reference"},
    "1wk": {"data_mode": "NATIVE_DATA", "source_interval": "1wk", "price_basis": "futures_reference"},
    "1mo": {"data_mode": "NATIVE_DATA", "source_interval": "1mo", "price_basis": "futures_reference"},
}


def normalize_instrument(value: Any) -> str:
    """يوحد تهجئة XAU/USD وXAUUSD، دون تحويل GC=F إلى فوري."""
    return str(value or "").upper().replace("/", "").replace("-", "").replace("_", "").strip()


def timeframe_source_contract(timeframe_id: str) -> dict[str, Any]:
    """يعيد نسخة آمنة من عقد مصدر الإطار المدعوم."""
    if timeframe_id not in TIMEFRAME_SOURCE_CONTRACTS:
        raise ValueError(f"إطار زمني غير مدعوم في عقد البيانات: {timeframe_id}")
    return dict(TIMEFRAME_SOURCE_CONTRACTS[timeframe_id])


def validate_ohlc_frame(frame: pd.DataFrame, expected_interval: str | None = None) -> dict[str, Any]:
    """يتحقق من OHLC كما وردت، ولا يرتب أو يملأ أو يصنع شموعاً علاجية."""
    required = ("Open", "High", "Low", "Close")
    result: dict[str, Any] = {
        "status": "blocked",
        "valid": False,
        "rows": 0,
        "missing_columns": [column for column in required if column not in getattr(frame, "columns", [])],
        "duplicate_timestamps": 0,
        "non_monotonic": False,
        "invalid_ohlc_rows": 0,
        "negative_range_rows": 0,
        "expected_interval": expected_interval,
        "largest_observed_gap_seconds": None,
        "message": "لا توجد شموع قابلة للتحقق.",
    }
    if not isinstance(frame, pd.DataFrame) or frame.empty or result["missing_columns"]:
        return result
    numeric = frame.loc[:, required].apply(pd.to_numeric, errors="coerce")
    invalid = numeric.isna().any(axis=1) | (numeric["High"] < numeric[["Open", "Close", "Low"]].max(axis=1)) | (numeric["Low"] > numeric[["Open", "Close", "High"]].min(axis=1))
    result["rows"] = int(len(frame))
    result["duplicate_timestamps"] = int(frame.index.duplicated().sum())
    result["non_monotonic"] = not bool(frame.index.is_monotonic_increasing)
    result["invalid_ohlc_rows"] = int(invalid.sum())
    result["negative_range_rows"] = int((numeric["High"] < numeric["Low"]).sum())
    if len(frame) > 1 and frame.index.is_monotonic_increasing:
        gaps = frame.index.to_series().diff().dropna()
        if not gaps.empty:
            result["largest_observed_gap_seconds"] = round(float(gaps.max().total_seconds()), 3)
    result["valid"] = not any((result["duplicate_timestamps"], result["non_monotonic"], result["invalid_ohlc_rows"], result["negative_range_rows"]))
    result["status"] = "qualified" if result["valid"] else "blocked"
    result["message"] = "شموع OHLC سليمة كما وردت؛ تسجل فجوات الجلسات ولا تملأ." if result["valid"] else "فشل تحقق OHLC: توجد تكرارات أو ترتيب زمني أو حقول سعرية غير صالحة."
    return result


def resample_complete_ohlc(frame: pd.DataFrame, *, source_interval: str, target_rule: str, timeframe_id: str) -> pd.DataFrame:
    """يجمع شموعاً كاملة فقط، ويرفض أي سلة تفتقد مكوناً مصدرياً متوقعاً.

    الشمعة غير المكتملة (مثل آخر 10m من 5m أو أول 4h بعد انقطاع) لا تُعرض
    ولا تدخل المؤشرات. لا يعالج الانقطاع بإنشاء OHLC اصطناعي.
    """
    quality = validate_ohlc_frame(frame, source_interval)
    if not quality["valid"]:
        raise RuntimeError("لا يمكن تجميع شموع مصدر غير سليمة")
    source_delta = pd.Timedelta(source_interval)
    target_delta = pd.Timedelta(target_rule)
    if target_delta <= source_delta or target_delta % source_delta != pd.Timedelta(0):
        raise ValueError("قاعدة التجميع ليست مضاعفاً صحيحاً لفاصل المصدر")
    expected_components = int(target_delta / source_delta)
    accepted: list[pd.DataFrame] = []
    rejected = 0
    for bucket_start, bucket in frame.resample(target_rule, label="left", closed="left"):
        expected_index = pd.date_range(bucket_start, periods=expected_components, freq=source_delta, tz=bucket.index.tz)
        if len(bucket) != expected_components or not bucket.index.equals(expected_index):
            rejected += 1
            continue
        values: dict[str, float] = {
            "Open": float(bucket["Open"].iloc[0]),
            "High": float(bucket["High"].max()),
            "Low": float(bucket["Low"].min()),
            "Close": float(bucket["Close"].iloc[-1]),
        }
        if "Volume" in bucket.columns:
            values["Volume"] = float(pd.to_numeric(bucket["Volume"], errors="coerce").sum())
        row = pd.DataFrame([values])
        row.index = pd.DatetimeIndex([bucket_start])
        accepted.append(row)
    if not accepted:
        raise RuntimeError(f"لا توجد سلال مكتملة لتجميع إطار {timeframe_id}")
    output = pd.concat(accepted)
    output.index = pd.to_datetime(output.index, utc=True)
    output.attrs.update({
        "data_contract": {
            "timeframe": timeframe_id,
            "data_mode": "RESAMPLED_DATA",
            "source_interval": source_interval,
            "target_rule": target_rule,
            "expected_components": expected_components,
            "rejected_incomplete_buckets": rejected,
            "completeness_policy": "كل شمعة ناتجة تتطلب جميع الشموع المصدرية المتوقعة بطوابع متصلة.",
        }
    })
    return output


def attach_candle_contract(frame: pd.DataFrame, *, timeframe_id: str, source: str, source_symbol: str, instrument: str, price_basis: str, source_kind: str) -> pd.DataFrame:
    """يلصق نسب الأصل والجودة بالشموع دون تغيير قيمها."""
    output = frame.copy()
    contract = timeframe_source_contract(timeframe_id)
    prior = dict(frame.attrs.get("data_contract", {}))
    prior.update({
        **contract,
        "timeframe": timeframe_id,
        "source": source,
        "source_symbol": source_symbol,
        "instrument": instrument,
        "price_basis": price_basis,
        "source_kind": source_kind,
    })
    output.attrs["data_contract"] = prior
    output.attrs["data_quality"] = validate_ohlc_frame(output, prior.get("source_interval"))
    return output


def decision_data_context(quote: dict[str, Any], candle_frame: pd.DataFrame | None) -> dict[str, Any]:
    """يحكم ما إذا كان السعر والشموع من نفس الأداة والأساس قبل وضع مستويات."""
    candle_contract = dict(getattr(candle_frame, "attrs", {}).get("data_contract", {}))
    candle_quality = dict(getattr(candle_frame, "attrs", {}).get("data_quality", {}))
    return decision_data_context_from_contract(quote, candle_contract, candle_quality)


def decision_data_context_from_contract(quote: dict[str, Any], candle_contract: dict[str, Any] | None, candle_quality: dict[str, Any] | None) -> dict[str, Any]:
    """نسخة تسند إلى عقد مخزن في ذاكرة التحليل أو في manifest تاريخي."""
    candle_contract = dict(candle_contract or {})
    candle_quality = dict(candle_quality or {})
    quote_instrument = normalize_instrument(quote.get("instrument") or quote.get("source_symbol") or quote.get("symbol"))
    candle_instrument = normalize_instrument(candle_contract.get("instrument") or candle_contract.get("source_symbol"))
    same_instrument = bool(quote_instrument and candle_instrument and quote_instrument == candle_instrument)
    same_basis = bool(quote.get("price_basis") and candle_contract.get("price_basis") and quote.get("price_basis") == candle_contract.get("price_basis"))
    fresh_quote = quote.get("status") == "success" and not bool(quote.get("stale")) and bool(quote.get("live_for_analysis", True))
    candle_valid = bool(candle_quality.get("valid"))
    compatible = same_instrument and same_basis
    if not fresh_quote:
        reason = "سعر المصدر غير حديث أو غير صالح للتحليل."
    elif not candle_valid:
        reason = "شموع الإطار لا تجتاز تحقق الجودة."
    elif not same_instrument:
        reason = f"اختلاف الأداة: السعر {quote_instrument or 'غير معروف'} مقابل الشموع {candle_instrument or 'غير معروف'}."
    elif not same_basis:
        reason = f"اختلاف أساس السعر: {quote.get('price_basis')} مقابل {candle_contract.get('price_basis')}."
    else:
        reason = "السعر والشموع متوافقان للتحليل المرجعي؛ تظل قابلية التنفيذ مرتبطة بوجود Bid/Ask من وسيط."
    return {
        "quote_instrument": quote_instrument or None,
        "candle_instrument": candle_instrument or None,
        "quote_price_basis": quote.get("price_basis"),
        "candle_price_basis": candle_contract.get("price_basis"),
        "same_instrument": same_instrument,
        "same_price_basis": same_basis,
        "quote_fresh": fresh_quote,
        "candle_quality": candle_quality,
        "compatible_for_price_levels": bool(fresh_quote and candle_valid and compatible),
        "reason": reason,
    }
