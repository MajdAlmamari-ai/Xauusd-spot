#!/usr/bin/env python3
"""موصل سعر XAUUSD.

الأولوية الافتراضية لسعر GoldAPI.io العام عبر `GOLDAPI_API_KEY`. لا يُستخدم جسر MT5 للسعر الحي إلا عند ضبط `LIVE_PRICE_SOURCE=mt5` صراحةً؛ Yahoo Finance مخصص للشموع المرجعية فقط، ولا ينشئ Bid/Ask أو Spread اصطناعياً.
"""

import json
import os
import time
from datetime import datetime, timezone
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import pandas as pd
import yfinance as yf

from analysis_contracts import attach_candle_contract, resample_complete_ohlc


class MT5PriceConnector:
    def __init__(self, symbol=None, broker_name=None, bridge_url=None):
        self.symbol = symbol or os.getenv("MT5_SYMBOL", "XAUUSD")
        self.broker_name = broker_name or os.getenv("MT5_BROKER_NAME", "MT5")
        explicit_bridge = (bridge_url or "").rstrip("/")
        bridge_enabled = os.getenv("USE_MARKET_DATA_BRIDGE", "").strip().lower() in {"1", "true", "yes"}
        env_bridge = os.getenv("MT5_BRIDGE_URL", "").rstrip("/") if bridge_enabled else ""
        self.bridge_url = explicit_bridge or env_bridge
        self.last_update = None
        self.last_ohlc_diagnostics: dict[str, object] = {"source": None, "removed_tail_candles": 0, "message": "لم تُفحص شموع مرجعية بعد."}
        self.ohlc_diagnostics: dict[str, dict[str, object]] = {}

    def _sanitize_reference_ohlc(self, frame: pd.DataFrame, interval: str) -> pd.DataFrame:
        """يرفض tail شاذاً من مصدر مرجعي؛ لا يصنع شمعة من السعر العام ولا يعدل شموع MT5."""
        clean = frame[["Open", "High", "Low", "Close", "Volume"]].dropna().copy()
        removed: list[str] = []
        isolated_session_tail: list[str] = []
        # لا يُطبق الحارس إلا على أطر اللحظات المرجعية؛ يحمي من tick/print متأخر شاذ في آخر صف.
        if interval not in {"1m", "2m", "5m", "15m", "30m", "60m", "90m", "1h"}:
            self.last_ohlc_diagnostics = {"source": "Yahoo Finance reference", "removed_tail_candles": 0, "message": "الإطار غير لحظي؛ لم يُطبق حارس tail."}
            self.ohlc_diagnostics[interval] = dict(self.last_ohlc_diagnostics)
            return clean
        while len(clean) >= 25:
            tail = clean.iloc[-1]
            prior = clean.iloc[-21:-1]
            prior_ranges = (prior["High"].astype(float) - prior["Low"].astype(float)).abs()
            baseline_range = float(prior_ranges.median())
            previous_close = float(prior["Close"].iloc[-1])
            tail_range = abs(float(tail["High"]) - float(tail["Low"]))
            tail_jump = abs(float(tail["Close"]) - previous_close)
            # يستلزم الحذف كِبرَ المدى والقفزة معاً؛ لا يتدخل في شمعة نشطة أو تقلب اعتيادي.
            range_outlier = baseline_range > 0 and tail_range > max(8.0 * baseline_range, 0.20)
            jump_outlier = baseline_range > 0 and tail_jump > max(6.0 * baseline_range, 0.15)
            if not (range_outlier and jump_outlier):
                break
            removed.append(str(clean.index[-1]))
            clean = clean.iloc[:-1]
        # لا يُعرض أول صف دقيق وحيد بعد عطلة/انقطاع جلسة كشمعة مؤكدة. عند وصول الدقيقة التالية
        # يصبح الصفان متصلين فيُعرضان كما وردا من المصدر؛ لا تُنشأ أي شمعة بديلة.
        if interval == "1m" and len(clean) >= 2:
            gap_seconds = (clean.index[-1] - clean.index[-2]).total_seconds()
            if gap_seconds > 90:
                isolated_session_tail.append(str(clean.index[-1]))
                clean = clean.iloc[:-1]
        self.last_ohlc_diagnostics = {
            "source": "Yahoo Finance reference",
            "removed_tail_candles": len(removed) + len(isolated_session_tail),
            "removed_times": removed,
            "isolated_session_tail": isolated_session_tail,
            "message": "استُبعد tail مرجعي شاذ أو أول شمعة دقيقة غير مؤكدة بعد انقطاع؛ لم تُنشأ شمعة من السعر العام." if (removed or isolated_session_tail) else "لا توجد شمعة tail شاذة أو غير مؤكدة مستبعدة.",
        }
        self.ohlc_diagnostics[interval] = dict(self.last_ohlc_diagnostics)
        return clean

    def _bridge_request(self, path: str, params: dict[str, str] | None = None) -> dict:
        query = f"?{urlencode(params)}" if params else ""
        url = f"{self.bridge_url}{path}{query}"
        headers = {"Accept": "application/json"}
        bridge_token = os.getenv("MT5_BRIDGE_TOKEN", "").strip()
        if bridge_token:
            headers["Authorization"] = f"Bearer {bridge_token}"
        request = Request(url, headers=headers)
        with urlopen(request, timeout=4) as response:
            return json.loads(response.read().decode("utf-8"))

    def _fetch_mt5_bridge(self):
        payload = self._bridge_request("/quote", {"symbol": self.symbol})
        if payload.get("status") != "success":
            raise RuntimeError(payload.get("message", "جسر MT5 لم يرجع تسعيراً صالحاً"))
        payload_symbol = str(payload.get("symbol", "")).strip()
        if payload_symbol != self.symbol:
            raise RuntimeError(f"جسر MT5 أعاد الرمز {payload_symbol or 'غير محدد'} بدلاً من {self.symbol}")
        if not payload.get("utc_time"):
            raise RuntimeError("جسر MT5 لم يرجع طابعاً زمنياً لآخر Tick")
        try:
            bid = float(payload["bid"])
            ask = float(payload["ask"])
            tick_age = float(payload["tick_age_seconds"])
        except (KeyError, TypeError, ValueError) as error:
            raise RuntimeError("جسر MT5 يفتقد Bid أو Ask أو tick_age_seconds قابلة للتحقق") from error
        if bid <= 0 or ask <= bid or tick_age < 0:
            raise RuntimeError("Bid/Ask أو عمر آخر Tick غير صالحين من جسر MT5")
        max_tick_age = float(os.getenv("MT5_ANALYSIS_STALE_SECONDS", "15"))
        stale = bool(payload.get("stale")) or tick_age > max_tick_age
        last_price = float(payload.get("last_price", (bid + ask) / 2))
        if last_price <= 0:
            raise RuntimeError("جسر MT5 لم يرجع آخر سعراً صالحاً")
        payload.update({
            "source": "MT5 broker read-only bridge",
            "symbol": self.symbol,
            "instrument": self.symbol,
            "price_basis": "broker_spot",
            "source_kind": "broker_read_only_quote",
            "last_price": last_price,
            "bid": bid,
            "ask": ask,
            "spread": round(ask - bid, 5),
            "age_seconds": round(tick_age, 2),
            "stale": stale,
            "broker_quote_eligible": not stale,
            "data_quality": "broker_quote_current" if not stale else "broker_quote_stale",
            "tradable": False,
            "analysis_only": True,
            "message": "سعر وسيط MT5 للقراءة والتحليل فقط؛ لا تنفذ المنصة أي أوامر." if not stale else "آخر Tick من وسيط MT5 متأخر؛ لا يُستخدم للتحليل الحالي.",
        })
        return payload

    def _fetch_mt5_ohlc(self, period: str, interval: str) -> pd.DataFrame:
        payload = self._bridge_request("/ohlc", {
            "symbol": self.symbol,
            "period": period,
            "interval": interval,
        })
        if payload.get("status") != "success":
            raise RuntimeError(payload.get("message", "جسر MT5 لم يرجع شموعاً صالحة"))
        bars = payload.get("bars")
        if not isinstance(bars, list) or not bars:
            raise RuntimeError("جسر MT5 لم يرجع قائمة شموع صالحة")
        frame = pd.DataFrame(bars)
        expected = ["Open", "High", "Low", "Close", "Volume"]
        aliases = {
            "open": "Open", "high": "High", "low": "Low", "close": "Close",
            "volume": "Volume", "tick_volume": "Volume", "real_volume": "Volume",
        }
        frame = frame.rename(columns={key: aliases.get(key, key) for key in frame.columns})
        missing = [column for column in expected if column not in frame.columns]
        if missing:
            raise RuntimeError(f"شموع MT5 تفتقد الحقول: {', '.join(missing)}")
        time_column = next((name for name in ("time", "timestamp", "datetime") if name in frame.columns), None)
        if time_column is None:
            raise RuntimeError("شموع MT5 تفتقد الطابع الزمني")
        if pd.api.types.is_numeric_dtype(frame[time_column]):
            frame.index = pd.to_datetime(frame[time_column], unit="s", utc=True)
        else:
            frame.index = pd.to_datetime(frame[time_column], utc=True)
        frame = frame[expected].apply(pd.to_numeric, errors="coerce").dropna()
        if frame.empty:
            raise RuntimeError("لا توجد شموع MT5 قابلة للاستخدام بعد التحقق")
        return attach_candle_contract(
            frame,
            timeframe_id=interval,
            source="MT5 broker read-only bridge",
            source_symbol=self.symbol,
            instrument=self.symbol,
            price_basis="broker_spot",
            source_kind="broker_read_only_ohlc",
        )

    def _fetch_yahoo_reference(self):
        yahoo_symbol = os.getenv("YAHOO_SYMBOL", "XAUUSD=X")
        ticker = yf.Ticker(yahoo_symbol)
        bars = ticker.history(period="5d", interval="1m", prepost=True, auto_adjust=False)
        if bars.empty:
            bars = ticker.history(period="1mo", interval="1d", auto_adjust=False)
        if bars.empty:
            raise RuntimeError("لم تصل بيانات من مصدر Yahoo Finance المرجعي")

        row = bars.dropna(subset=["Close"]).iloc[-1]
        price = float(row["Close"])
        previous = float(bars["Close"].dropna().iloc[-2]) if len(bars["Close"].dropna()) > 1 else price
        change = price - previous
        change_pct = (change / previous * 100) if previous else 0.0
        timestamp = bars.dropna(subset=["Close"]).index[-1]
        if getattr(timestamp, "tzinfo", None) is None:
            timestamp = timestamp.replace(tzinfo=timezone.utc)
        timestamp_utc = timestamp.astimezone(timezone.utc)
        now = datetime.now(timezone.utc)
        age_seconds = max(0.0, (now - timestamp_utc).total_seconds())
        self.last_update = now
        stale_threshold = float(os.getenv("REFERENCE_STALE_SECONDS", "90"))
        is_stale = age_seconds > stale_threshold
        return {
            "status": "success",
            "source": "Yahoo Finance XAUUSD market reference",
            "broker": None,
            "symbol": self.symbol,
            "instrument": self.symbol,
            "price_basis": "spot_reference",
            "source_kind": "public_market_reference",
            "source_symbol": yahoo_symbol,
            "last_price": round(price, 2),
            "bid": None,
            "ask": None,
            "spread": None,
            "change": round(change, 2),
            "change_pct": round(change_pct, 3),
            "high": float(row["High"]),
            "low": float(row["Low"]),
            "latency_ms": None,
            "utc_time": timestamp_utc.strftime("%Y-%m-%d %H:%M:%S UTC"),
            "age_seconds": round(age_seconds, 1),
            "data_quality": "stale_reference" if is_stale else "reference_only",
            "stale": is_stale,
            "tradable": False,
            "message": "السوق مغلق أو آخر سعر سوقي متأخر؛ لا يعرض كسعر حي." if is_stale else "سعر سوق عام قصير التأخر؛ ليس Bid/Ask لوسيط أو سعراً لتنفيذ أمر."
        }

    def _fetch_gold_api_reference(self):
        """يستدعي السعر الحالي من gold-api.com؛ لا يطلب شموعاً ولا يمثل سعراً تنفيذياً."""
        endpoint = os.getenv("GOLD_API_LIVE_URL", "https://api.gold-api.com/price/XAU/USD")
        request = Request(endpoint, headers={
            "Accept": "application/json",
            "User-Agent": "XAUUSD-Analysis-Reference/1.0",
        })
        with urlopen(request, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        price = float(payload["price"])
        if price <= 0:
            raise RuntimeError("gold-api.com أعاد سعراً غير صالح")
        raw_timestamp = payload.get("updatedAt")
        if raw_timestamp is None:
            raise RuntimeError("gold-api.com لم يُرجع updatedAt لمصدر السعر")
        if isinstance(raw_timestamp, (int, float)):
            timestamp = datetime.fromtimestamp(float(raw_timestamp), tz=timezone.utc)
        else:
            timestamp = datetime.fromisoformat(str(raw_timestamp).replace("Z", "+00:00"))
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)
            timestamp = timestamp.astimezone(timezone.utc)
        fetched_at = datetime.now(timezone.utc)
        age_seconds = max(0.0, (fetched_at - timestamp).total_seconds())
        # توصي وثائق gold-api.com بتخزين السعر 30 ثانية؛ لذلك لا يُعامل كسعر Tick للوسيط.
        stale_limit = float(os.getenv("MARKET_PRICE_STALE_SECONDS", "45"))
        stale = age_seconds > stale_limit
        return {
            "status": "success",
            "source": "gold-api.com XAU/USD live market reference",
            "source_symbol": "XAU/USD",
            "symbol": self.symbol,
            "instrument": "XAU/USD",
            "price_basis": "spot_reference",
            "source_kind": "public_market_reference",
            "broker": None,
            "last_price": round(price, 2),
            "bid": None,
            "ask": None,
            "reference_bid": None,
            "reference_ask": None,
            "reference_spread": None,
            "spread": None,
            "change": None,
            "change_pct": None,
            "high": None,
            "low": None,
            "utc_time": timestamp.strftime("%Y-%m-%d %H:%M:%S UTC"),
            "source_timestamp": timestamp.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "fetched_at": fetched_at.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "age_seconds": round(age_seconds, 1),
            "stale": stale,
            "live_for_analysis": not stale,
            "tradable": False,
            "analysis_only": True,
            "data_quality": "market_reference_stale" if stale else "market_reference_current",
            "message": "السوق مغلق أو آخر سعر gold-api.com متأخر؛ لا يعرض كسعر حي." if stale else "سعر gold-api.com عام حديث للتحليل؛ لا يتضمن Bid/Ask أو سبريد وسيط ولا يُستخدم لتنفيذ أمر.",
        }

    def fetch_spot_futures_comparison(self) -> dict:
        """يعرض الفارق المرجعي بين سعر gold-api.com الحالي وآخر إغلاق GC=F.

        لا تطلب المنصة XAUUSD=X من Yahoo لأنه غير مدعوم بصورة موثوقة هنا. لا توجد
        شموع فورية تاريخية مشتركة في هذا المسار، لذا لا تُنشأ أيام أو مزامنة مصطنعة.
        """
        spot_symbol = "XAU/USD"
        futures_symbol = os.getenv("YAHOO_FUTURES_SYMBOL", "GC=F")
        def history(symbol: str) -> pd.DataFrame:
            frame = yf.Ticker(symbol).history(period="5d", interval="1h", prepost=True, auto_adjust=False)
            frame = frame.rename(columns={column: column.title() for column in frame.columns})
            if frame.empty or not {"Open", "High", "Low", "Close"}.issubset(frame.columns):
                raise RuntimeError(f"لم تصل شموع ساعة صالحة للرمز {symbol}")
            frame.index = pd.to_datetime(frame.index, utc=True)
            return frame.dropna(subset=["Open", "High", "Low", "Close"]).sort_index()
        def daily_rows(frame: pd.DataFrame, dates: list) -> list[dict[str, object]]:
            rows = []
            for day in dates:
                part = frame[frame.index.date == day]
                if not part.empty:
                    rows.append({"date_utc": str(day), "open": round(float(part["Open"].iloc[0]), 4), "close": round(float(part["Close"].iloc[-1]), 4), "high": round(float(part["High"].max()), 4), "low": round(float(part["Low"].min()), 4), "first_timestamp_utc": part.index[0].strftime("%Y-%m-%d %H:%M:%S UTC"), "last_timestamp_utc": part.index[-1].strftime("%Y-%m-%d %H:%M:%S UTC")})
            return rows
        try:
            market = self._fetch_gold_api_reference()
            futures = history(futures_symbol)
            spot_price = float(market["last_price"])
            latest = futures.iloc[-1]
            futures_price = float(latest["Close"])
            futures_ts = futures.index[-1]
            futures_dates = sorted(set(futures.index.date))[-2:]
            spot_days, futures_days = [], daily_rows(futures, futures_dates)
            source_mode = "gold-api.com XAU/USD current + Yahoo Finance GC=F"
            message = "فارق مرجعي بين سعر فوري عام حالي وآخر إغلاق آجل؛ لا يوجد توقيت مشترك أو تاريخ فوري يومي في هذا المسار، ولا يمثلان Bid/Ask أو سعراً تنفيذياً لدى MT5."
            basis = futures_price - spot_price
            basis_pct = basis / spot_price * 100 if spot_price else None
            interpretation = "علاوة آجلة / Contango" if basis > 0 else "خصم آجل / Backwardation" if basis < 0 else "تكافؤ تقريبي"
            return {"status": "success", "source": source_mode, "spot": {"symbol": spot_symbol, "source": "gold-api.com", "days": spot_days, "timestamp_utc": market.get("utc_time")}, "futures": {"symbol": futures_symbol, "source": "GC=F", "days": futures_days, "timestamp_utc": futures_ts.strftime("%Y-%m-%d %H:%M:%S UTC")}, "synchronized": {"timestamp_utc": None, "spot_timestamp_utc": market.get("utc_time"), "futures_timestamp_utc": futures_ts.strftime("%Y-%m-%d %H:%M:%S UTC"), "age_seconds": None, "spot_close": round(spot_price, 4), "futures_close": round(futures_price, 4), "basis": round(basis, 4), "basis_pct": round(basis_pct, 4) if basis_pct is not None else None}, "interpretation": interpretation, "recommendation": {"signal": "محايد / انتظار", "spot_mt5_action": "لا شراء ولا بيع من الفارق وحده", "reason": "الفارق يعكس اختلاف العقد والتكلفة الزمنية وظروف السوق، وليس إشارة اتجاهية كافية لسعر XAUUSD الفوري في MT5. يلزم توافق السعر الفوري والتحليل الفني وحداثة سعر الوسيط."}, "reference_only": True, "execution_price_available": False, "message": message}
        except Exception as error:
            return {"status": "unavailable", "source": "Yahoo Finance public references", "spot": {"symbol": spot_symbol, "days": []}, "futures": {"symbol": futures_symbol, "days": []}, "synchronized": None, "interpretation": None, "recommendation": {"signal": "انتظار / لا قرار", "spot_mt5_action": "لا تتخذ قراراً من الفارق", "reason": "تعذر الحصول على مرجعين صالحين للمقارنة."}, "reference_only": True, "execution_price_available": False, "message": str(error)}

    def fetch_order_flow(self) -> dict:
        """يجلب تدفقاً فعلياً من الجسر فقط؛ لا يستنتجه من OHLC أو من سعر عام."""
        unavailable = lambda reason: {
            "status": "غير متاح",
            "eligible_for_decision": False,
            "source": "لا توجد تغذية تدفق موثقة",
            "message": reason,
            "requirements": ["Bid/Ask حديثان", "Depth of Market بمستويات سعر/حجم", "صفقات أو أحجام شراء/بيع فعلية"],
        }
        if not self.bridge_url:
            return unavailable("لم يُضبط جسر MT5 لقراءة Bid/Ask وDOM والصفقات؛ لا يمكن تحويل الشموع أو المناطق إلى Order Flow حقيقي.")
        try:
            payload = self._bridge_request("/order-flow", {"symbol": self.symbol})
        except Exception as error:
            return unavailable(f"تعذر الوصول إلى مسار تدفق السيولة في الجسر: {error}")
        if payload.get("status") != "success":
            return unavailable(payload.get("message", "لم يرجع جسر MT5 تدفقاً صالحاً."))
        try:
            bid, ask = float(payload["bid"]), float(payload["ask"])
            age = float(payload["age_seconds"])
        except (KeyError, TypeError, ValueError):
            return unavailable("حمولة التدفق تفتقد Bid/Ask أو age_seconds موثقاً؛ لا تقبل الطبقة حداثة غير معلنة.")
        if bid <= 0 or ask <= bid or age < 0 or age > 10:
            return unavailable("Bid/Ask غير صالحين أو تدفق السيولة أقدم من 10 ثوانٍ.")
        dom = payload.get("dom")
        if not isinstance(dom, list) or len(dom) < 2:
            return unavailable("جسر MT5 لم يرجع مستويات DOM كافية؛ لا يكفي Bid/Ask وحدهما لتأكيد تدفق السيولة.")
        bid_depth = ask_depth = 0.0
        valid_levels = 0
        for level in dom:
            try:
                side = str(level["side"]).lower()
                float(level["price"])
                volume = float(level["volume"])
            except (KeyError, TypeError, ValueError):
                continue
            if volume <= 0:
                continue
            if side in {"bid", "buy"}:
                bid_depth += volume
                valid_levels += 1
            elif side in {"ask", "sell"}:
                ask_depth += volume
                valid_levels += 1
        trades = payload.get("trades")
        buy_volume = sell_volume = 0.0
        if isinstance(trades, list):
            for trade in trades:
                try:
                    side, volume = str(trade["side"]).lower(), float(trade["volume"])
                except (KeyError, TypeError, ValueError):
                    continue
                if side in {"buy", "ask"} and volume > 0:
                    buy_volume += volume
                elif side in {"sell", "bid"} and volume > 0:
                    sell_volume += volume
        else:
            try:
                buy_volume, sell_volume = float(payload["buy_volume"]), float(payload["sell_volume"])
            except (KeyError, TypeError, ValueError):
                pass
        if valid_levels < 2 or bid_depth <= 0 or ask_depth <= 0 or buy_volume + sell_volume <= 0:
            return unavailable("DOM أو أحجام الصفقات الفعلية غير مكتملة؛ تبقى قراءة التدفق غير مؤهلة للقرار.")
        depth_imbalance = (bid_depth - ask_depth) / (bid_depth + ask_depth)
        trade_imbalance = (buy_volume - sell_volume) / (buy_volume + sell_volume)
        combined = 0.45 * depth_imbalance + 0.55 * trade_imbalance
        bias = "شراء" if combined >= 0.12 else "بيع" if combined <= -0.12 else "محايد"
        confidence = min(90.0, round(45 + abs(combined) * 45 + min(valid_levels, 20), 1))
        return {
            "status": "متاح ومتحقق",
            "eligible_for_decision": True,
            "source": "MT5 broker bridge: Bid/Ask + DOM + trades",
            "symbol": self.symbol,
            "utc_time": payload.get("utc_time") or payload.get("timestamp"),
            "age_seconds": round(age, 2),
            "bid": bid,
            "ask": ask,
            "spread": round(ask - bid, 5),
            "dom_levels": valid_levels,
            "bid_depth": round(bid_depth, 4),
            "ask_depth": round(ask_depth, 4),
            "buy_volume": round(buy_volume, 4),
            "sell_volume": round(sell_volume, 4),
            "depth_imbalance": round(depth_imbalance, 4),
            "trade_imbalance": round(trade_imbalance, 4),
            "bias": bias,
            "confidence": confidence,
            "message": "تدفق مصدره الجسر؛ لا تنفذ المنصة أوامر، وتبقى صلاحيته مشروطة بحداثة البيانات.",
            "requirements": ["Bid/Ask حديثان", "DOM بمستويات سعر/حجم", "صفقات أو أحجام شراء/بيع فعلية"],
        }

    def fetch_live_quote(self):
        started = time.perf_counter()
        try:
            # gold-api.com هو المصدر الحي الافتراضي. جسر MT5 لا يعمل إلا بطلب صريح منفصل.
            requested_source = os.getenv("LIVE_PRICE_SOURCE", "gold-api").strip().lower()
            if requested_source == "mt5" and self.bridge_url:
                quote_data = self._fetch_mt5_bridge()
                quote_data["latency_ms"] = round((time.perf_counter() - started) * 1000, 1)
                quote_data["live_for_analysis"] = not bool(quote_data.get("stale"))
                return quote_data
            quote_data = self._fetch_gold_api_reference()
            quote_data["latency_ms"] = round((time.perf_counter() - started) * 1000, 1)
            return quote_data
        except Exception as error:
            return {
                "status": "error",
                "source": "gold-api.com XAU/USD live market reference" if not (os.getenv("LIVE_PRICE_SOURCE", "gold-api").strip().lower() == "mt5" and self.bridge_url) else "MT5 broker read-only bridge",
                "symbol": self.symbol,
                "tradable": False,
                "live_for_analysis": False,
                "stale": True,
                "message": f"تعذر الوصول إلى السعر الحي من المصدر المحدد: {error}",
                "utc_time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
            }

    def _fetch_yahoo_chart_fallback(self, symbol: str, period: str, interval: str) -> pd.DataFrame:
        """يجلب نفس شموع Yahoo مباشرة إذا رجع عميل yfinance فارغاً مؤقتاً."""
        period_days = {"5d": 5, "60d": 60, "6mo": 183, "1y": 366, "730d": 730, "2y": 732, "5y": 1827, "10y": 3654}
        if period not in period_days:
            raise RuntimeError(f"لا يوجد تحويل آمن لفترة Yahoo الاحتياطية: {period}")
        end_epoch = int(time.time())
        start_epoch = end_epoch - period_days[period] * 24 * 60 * 60
        url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol)}"
               f"?period1={start_epoch}&period2={end_epoch}&interval={interval}&includePrePost=true&events=div%2Csplits")
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "XAUUSD-Analysis-Reference/1.0"})
        with urlopen(request, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        result = (payload.get("chart", {}).get("result") or [None])[0]
        if not result or not result.get("timestamp"):
            raise RuntimeError("مسار Yahoo المباشر لم يرجع طوابع شموع")
        quote_rows = ((result.get("indicators", {}).get("quote") or [None])[0])
        if not isinstance(quote_rows, dict):
            raise RuntimeError("مسار Yahoo المباشر لم يرجع OHLC")
        frame = pd.DataFrame({
            "Open": quote_rows.get("open", []), "High": quote_rows.get("high", []),
            "Low": quote_rows.get("low", []), "Close": quote_rows.get("close", []),
            "Volume": quote_rows.get("volume", []),
        }, index=pd.to_datetime(result["timestamp"], unit="s", utc=True))
        frame["Volume"] = pd.to_numeric(frame["Volume"], errors="coerce").fillna(0)
        return frame.dropna(subset=["Open", "High", "Low", "Close"])

    def _fetch_yahoo_chart_range(self, symbol: str, start: pd.Timestamp, end: pd.Timestamp, interval: str) -> pd.DataFrame:
        """يجلب نطاقاً زمنياً صريحاً من نفس مصدر Yahoo دون استبدال أو تركيب شموع."""
        start_epoch = int(pd.Timestamp(start).timestamp())
        end_epoch = int(pd.Timestamp(end).timestamp())
        url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol)}"
               f"?period1={start_epoch}&period2={end_epoch}&interval={interval}&includePrePost=true&events=div%2Csplits")
        request = Request(url, headers={"Accept": "application/json", "User-Agent": "XAUUSD-Analysis-Reference/1.0"})
        with urlopen(request, timeout=12) as response:
            payload = json.loads(response.read().decode("utf-8"))
        result = (payload.get("chart", {}).get("result") or [None])[0]
        if not result or not result.get("timestamp"):
            raise RuntimeError("مسار Yahoo الزمني المباشر لم يرجع طوابع شموع")
        quote_rows = ((result.get("indicators", {}).get("quote") or [None])[0])
        if not isinstance(quote_rows, dict):
            raise RuntimeError("مسار Yahoo الزمني المباشر لم يرجع OHLC")
        frame = pd.DataFrame({
            "Open": quote_rows.get("open", []), "High": quote_rows.get("high", []),
            "Low": quote_rows.get("low", []), "Close": quote_rows.get("close", []),
            "Volume": quote_rows.get("volume", []),
        }, index=pd.to_datetime(result["timestamp"], unit="s", utc=True))
        frame["Volume"] = pd.to_numeric(frame["Volume"], errors="coerce").fillna(0)
        return frame.dropna(subset=["Open", "High", "Low", "Close"])

    def fetch_ohlc_between(self, start: str | pd.Timestamp, end: str | pd.Timestamp, interval="1d") -> pd.DataFrame:
        """يجلب شموعاً مرجعية لنطاق معلوم، مفيد للاختبارات التاريخية القابلة لإعادة الإنتاج."""
        start_time = pd.Timestamp(start, tz="UTC") if not isinstance(start, pd.Timestamp) else start
        end_time = pd.Timestamp(end, tz="UTC") if not isinstance(end, pd.Timestamp) else end
        if start_time.tzinfo is None:
            start_time = start_time.tz_localize("UTC")
        if end_time.tzinfo is None:
            end_time = end_time.tz_localize("UTC")
        if end_time <= start_time:
            raise ValueError("يجب أن يكون نهاية نطاق الشموع بعد بدايته")
        if self.bridge_url:
            raise RuntimeError("الجسر لا يضمن نطاقاً تاريخياً محدداً؛ لا يُستبدل تاريخ 2025 ببيانات حالية.")
        yahoo_symbol = os.getenv("YAHOO_HISTORY_SYMBOL", "GC=F")
        yahoo_interval = {"10m": "5m", "2h": "1h", "4h": "1h"}.get(interval, interval)
        try:
            frame = yf.Ticker(yahoo_symbol).history(start=start_time.to_pydatetime(), end=end_time.to_pydatetime(), interval=yahoo_interval, auto_adjust=False, timeout=12)
        except Exception:
            frame = pd.DataFrame()
        if frame.empty:
            frame = self._fetch_yahoo_chart_range(yahoo_symbol, start_time, end_time, yahoo_interval)
        frame = frame.rename(columns={column: column.title() for column in frame.columns})
        required = ["Open", "High", "Low", "Close", "Volume"]
        if any(column not in frame.columns for column in required):
            raise RuntimeError("مصدر Yahoo الزمني لم يرجع جميع حقول OHLCV")
        aggregation_rule = {"10m": "10min", "2h": "2h", "4h": "4h"}.get(interval)
        if aggregation_rule:
            frame = resample_complete_ohlc(frame, source_interval=yahoo_interval, target_rule=aggregation_rule, timeframe_id=interval)
        frame = frame.loc[(frame.index >= start_time) & (frame.index < end_time)]
        if frame.empty:
            raise RuntimeError("مصدر Yahoo الزمني لم يرجع شموعاً ضمن النطاق المطلوب")
        clean = self._sanitize_reference_ohlc(frame, interval)
        return attach_candle_contract(
            clean,
            timeframe_id=interval,
            source="Yahoo Finance reference OHLC",
            source_symbol=yahoo_symbol,
            instrument=yahoo_symbol,
            price_basis="futures_reference",
            source_kind="reference_ohlc",
        )

    def fetch_ohlc(self, period="6mo", interval="1d", provider="auto"):
        # الشموع التاريخية تبقى من Yahoo Finance افتراضياً؛ لا يُسمح لـ MT5 بتجاوزها إلا باختيار صريح.
        if provider not in {"auto", "yahoo", "mt5"}:
            raise ValueError("مزود OHLC غير مدعوم؛ اختر auto أو yahoo أو mt5")
        use_mt5 = provider == "mt5" or (provider == "auto" and self.bridge_url and os.getenv("LIVE_OHLC_SOURCE", "yahoo").strip().lower() == "mt5")
        if use_mt5:
            if not self.bridge_url:
                raise RuntimeError("مصدر MT5 للشموع غير متصل")
            return self._fetch_mt5_ohlc(period=period, interval=interval)
        yahoo_symbol = os.getenv("YAHOO_HISTORY_SYMBOL", "GC=F")
        # Yahoo لا يوفّر 10m أو 2h أو 4h مباشرة. يجمع التطبيق شموع 5m أو 1h المصدرية
        # باستخدام أول/أعلى/أدنى/آخر وحجم الشموع، ولا يشتق أي شمعة من السعر العام.
        yahoo_interval = {"10m": "5m", "2h": "1h", "4h": "1h"}.get(interval, interval)
        try:
            frame = yf.Ticker(yahoo_symbol).history(period=period, interval=yahoo_interval, auto_adjust=False, timeout=8)
        except Exception:
            frame = pd.DataFrame()
        if frame.empty:
            try:
                frame = self._fetch_yahoo_chart_fallback(yahoo_symbol, period, yahoo_interval)
            except Exception:
                # Yahoo يرفض أحياناً طلب 1h على النافذة القصوى قرب حد 730 يوماً.
                # نستخدم آخر 60 يوماً فقط كمرجع معلن بدلاً من تركيب شموع أو مزج سعر عام.
                if period == "730d" and yahoo_interval == "1h":
                    frame = self._fetch_yahoo_chart_fallback(yahoo_symbol, "60d", yahoo_interval)
                else:
                    raise
        if frame.empty:
            raise RuntimeError("لا توجد شموع كافية لحساب المؤشرات")
        frame = frame.rename(columns={column: column.title() for column in frame.columns})
        aggregation_rule = {"10m": "10min", "2h": "2h", "4h": "4h"}.get(interval)
        if aggregation_rule:
            frame = resample_complete_ohlc(frame, source_interval=yahoo_interval, target_rule=aggregation_rule, timeframe_id=interval)
            if frame.empty:
                raise RuntimeError(f"لا توجد شموع مصدرية كافية لتجميع إطار {interval}")
        clean = self._sanitize_reference_ohlc(frame, interval)
        return attach_candle_contract(
            clean,
            timeframe_id=interval,
            source="Yahoo Finance reference OHLC",
            source_symbol=yahoo_symbol,
            instrument=yahoo_symbol,
            price_basis="futures_reference",
            source_kind="reference_ohlc",
        )


if __name__ == "__main__":
    print(MT5PriceConnector().fetch_live_quote())
