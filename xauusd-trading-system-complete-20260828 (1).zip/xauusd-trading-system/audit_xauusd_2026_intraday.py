"""يدقق شموع 2026 داخل اليوم، ولا يعالج أو يملأ الفجوات."""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


ROOT = Path("/tmp/xauusd-2026-intraday")
OUT = Path("/home/ubuntu/xauusd-trading-system/xauusd_2026_intraday_data_audit.json")
SPECS = {"5m": ("XAU_5m_data.csv", pd.Timedelta(minutes=5)), "15m": ("XAU_15m_data.csv", pd.Timedelta(minutes=15)), "30m": ("XAU_30m_data.csv", pd.Timedelta(minutes=30))}


def parse(path: Path) -> pd.DataFrame:
    raw = pd.read_csv(path, sep=";")
    index = pd.to_datetime(raw.pop("Date"), format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    raw.columns = [str(column).title() for column in raw.columns]
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = index
    return raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index()


def audit(frame: pd.DataFrame, expected: pd.Timedelta) -> dict:
    year = frame.loc["2026-01-01":"2026-12-31 23:59:59"]
    deltas = year.index.to_series().diff()
    gaps = deltas[deltas > expected]
    bad_ohlc = (year.High.lt(year[["Open", "Close", "Low"]].max(axis=1)) | year.Low.gt(year[["Open", "Close", "High"]].min(axis=1))).sum()
    return {
        "rows_2026": int(len(year)),
        "first": str(year.index.min()) if len(year) else None,
        "last": str(year.index.max()) if len(year) else None,
        "duplicates": int(year.index.duplicated().sum()),
        "invalid_ohlc": int(bad_ohlc),
        "gap_count": int(len(gaps)),
        "largest_gap": str(gaps.max()) if len(gaps) else None,
        "largest_gaps": [{"resumed_at": str(timestamp), "gap": str(delta)} for timestamp, delta in gaps.nlargest(10).items()],
    }


def main() -> None:
    results = {timeframe: {"file": name, "expected_interval": str(expected), **audit(parse(ROOT / name), expected)} for timeframe, (name, expected) in SPECS.items()}
    OUT.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    for timeframe, row in results.items():
        print(timeframe, row)
    print(f"AUDIT={OUT}")


if __name__ == "__main__":
    main()
