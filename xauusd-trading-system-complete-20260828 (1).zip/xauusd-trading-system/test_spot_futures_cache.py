from __future__ import annotations

from copy import deepcopy
from unittest.mock import patch

import production_server as server


class CountingConnector:
    def __init__(self) -> None:
        self.calls = 0

    def fetch_spot_futures_comparison(self) -> dict:
        self.calls += 1
        return {"status": "success", "source": "test", "calls": self.calls}


def main() -> None:
    original_connector = server.connector
    original_cache = deepcopy(server.spot_futures_cache)
    fake = CountingConnector()
    try:
        server.connector = fake
        with server.spot_futures_cache_lock:
            server.spot_futures_cache.update({"value": None, "expires_at": 0.0})
        with patch("production_server.time.monotonic", side_effect=[100.0, 101.0, 500.0]):
            first = server.get_spot_futures_comparison()
            second = server.get_spot_futures_comparison()
            third = server.get_spot_futures_comparison()
        assert first["calls"] == 1
        assert second["calls"] == 1
        assert third["calls"] == 2
        assert fake.calls == 2
        print("PASS: spot/futures comparison is cached between refresh cycles")
    finally:
        server.connector = original_connector
        with server.spot_futures_cache_lock:
            server.spot_futures_cache.clear()
            server.spot_futures_cache.update(original_cache)


if __name__ == "__main__":
    main()
