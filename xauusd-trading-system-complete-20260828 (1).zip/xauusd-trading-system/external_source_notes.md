# ملاحظات مصدر البيانات الخارجي

تم التحقق في 26 أغسطس 2026 من وثائق [Twelve Data](https://twelvedata.com/docs) وصفحة [XAU/USD](https://twelvedata.com/markets/300755/commodity/xau-usd). توثق الخدمة REST وWebSocket، وتدعم فواصل 1min و5min و15min و30min و1h و2h و4h و1day و1week و1month، كما تسجل صفحة الرمز أن XAU/USD سلعة يمكن الوصول إلى تاريخها عبر API. 

لم يُستخدم هذا المصدر في التنفيذ الحالي لأن المستخدم اختار صراحةً `gold-api.com`. يبقى `gold-api.com` سعر سوق عام مرجعي فقط؛ لا يُستنتج منه OHLC متعددة الأطر أو Bid/Ask أو سعر تنفيذ.
