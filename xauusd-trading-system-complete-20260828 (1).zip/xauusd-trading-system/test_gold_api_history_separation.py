from __future__ import annotations

import os
from unittest.mock import patch

import pandas as pd

from mt5_price_connector import MT5PriceConnector


def sample_ohlc() -> pd.DataFrame:
    index = pd.date_range("2026-08-20", periods=3, freq="1D", tz="UTC")
    return pd.DataFrame({"Open": [4600.0, 4602.0, 4604.0], "High": [4605.0, 4607.0, 4609.0], "Low": [4598.0, 4600.0, 4602.0], "Close": [4602.0, 4604.0, 4606.0], "Volume": [10, 11, 12]}, index=index)


def main() -> None:
    connector = MT5PriceConnector(bridge_url="http://bridge.invalid")
    os.environ.pop("LIVE_OHLC_SOURCE", None)
    with patch.object(connector, "_fetch_mt5_ohlc") as mt5_ohlc, patch("mt5_price_connector.yf.Ticker") as ticker:
        ticker.return_value.history.return_value = sample_ohlc()
        result = connector.fetch_ohlc(period="5d", interval="1d")
    mt5_ohlc.assert_not_called()
    assert len(result) == 3
    assert list(result.columns) == ["Open", "High", "Low", "Close", "Volume"]
    print("PASS: historical OHLC remains on Yahoo Finance even when a bridge URL exists")


if __name__ == "__main__":
    main()
