"""اختبار OB+FVG على شموع XAUUSD بدقة 15 دقيقة لعام 2025.

يجمع ticks العامة من Dukascopy إلى شموع 15 دقيقة. لا ينشئ شموعاً للأوقات الخالية
ولا يستخدم السعر العام أو شموع Yahoo كبديل. لا ينفذ أي أمر تداول.
"""

from __future__ import annotations

import concurrent.futures
import json
import lzma
import struct
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy


YEAR = 2025
START = datetime(YEAR, 1, 1, tzinfo=timezone.utc)
END = datetime(YEAR + 1, 1, 1, tzinfo=timezone.utc)
CACHE = Path(f"/tmp/dukascopy_xauusd_{YEAR}_15m.csv")
OUTPUT_JSON = Path(__file__).with_name("ob_fvg_2025_15m_backtest_results.json")
OUTPUT_MD = Path(__file__).with_name("ob_fvg_2025_15m_backtest_report.md")
SCALE = 1000.0
HOUR_URL = "https://datafeed.dukascopy.com/datafeed/XAUUSD/{year}/{month:02d}/{day:02d}/{hour:02d}h_ticks.bi5"
LZMA_FILTERS = [{"id": lzma.FILTER_LZMA1, "dict_size": 1 << 22, "lc": 3, "lp": 0, "pb": 2}]


def tick_url(moment: datetime) -> str:
    return HOUR_URL.format(year=moment.year, month=moment.month - 1, day=moment.day, hour=moment.hour)


def decompress_ticks(compressed: bytes) -> bytes:
    if len(compressed) < 13 or compressed[:5] != bytes.fromhex("5d00004000"):
        raise RuntimeError("ترويسة LZMA لملف Tick غير متوقعة من المصدر")
    decoder = lzma.LZMADecompressor(format=lzma.FORMAT_RAW, filters=LZMA_FILTERS)
    raw = decoder.decompress(compressed[13:])
    if len(raw) % 20:
        raise RuntimeError("طول Tick المفكوك لا يتوافق مع سجلات Dukascopy ذات 20 بايت")
    return raw


def fetch_hour(moment: datetime) -> list[tuple[datetime, float]]:
    request = Request(tick_url(moment), headers={"User-Agent": "XAUUSD-Research/1.0"})
    for attempt in range(3):
        try:
            with urlopen(request, timeout=30) as response:
                raw = decompress_ticks(response.read())
            rows: list[tuple[datetime, float]] = []
            for offset in range(0, len(raw), 20):
                offset_ms, ask_raw, bid_raw, _, _ = struct.unpack(">IIIff", raw[offset:offset + 20])
                timestamp = moment + timedelta(milliseconds=offset_ms)
                rows.append((timestamp, (ask_raw + bid_raw) / (2.0 * SCALE)))
            return rows
        except HTTPError as error:
            if error.code == 404:
                return []
            if attempt == 2:
                raise RuntimeError(f"فشل طلب {tick_url(moment)}: HTTP {error.code}") from error
        except (URLError, TimeoutError, OSError, lzma.LZMAError) as error:
            if attempt == 2:
                raise RuntimeError(f"فشل طلب {tick_url(moment)} بعد 3 محاولات: {error}") from error
            time.sleep(0.5 * (attempt + 1))
    return []


def source_hours() -> list[datetime]:
    hours: list[datetime] = []
    cursor = START
    while cursor < END:
        hours.append(cursor)
        cursor += timedelta(hours=1)
    return hours


def ticks_to_bars(ticks: list[tuple[datetime, float]]) -> pd.DataFrame:
    if not ticks:
        raise RuntimeError("لم تصل ticks قابلة للتجميع من المصدر.")
    rows = pd.DataFrame(ticks, columns=["time", "price"])
    rows["time"] = pd.to_datetime(rows["time"], utc=True)
    rows = rows.sort_values("time").set_index("time")
    grouped = rows["price"].resample("15min", label="left", closed="left")
    bars = pd.DataFrame({
        "Open": grouped.first(),
        "High": grouped.max(),
        "Low": grouped.min(),
        "Close": grouped.last(),
        "Volume": grouped.count(),
    }).dropna(subset=["Open", "High", "Low", "Close"])
    return bars.astype({"Open": float, "High": float, "Low": float, "Close": float, "Volume": float})


def load_or_build_bars() -> pd.DataFrame:
    if CACHE.exists():
        frame = pd.read_csv(CACHE, parse_dates=["time"]).set_index("time")
        frame.index = pd.to_datetime(frame.index, utc=True)
        return frame
    hours = source_hours()
    ticks: list[tuple[datetime, float]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(fetch_hour, moment): moment for moment in hours}
        for position, future in enumerate(concurrent.futures.as_completed(futures), start=1):
            ticks.extend(future.result())
            if position % 500 == 0:
                print(f"تمت قراءة {position}/{len(hours)} ملف ساعة من المصدر...")
    bars = ticks_to_bars(ticks)
    bars.reset_index(names="time").to_csv(CACHE, index=False)
    return bars


def render_report(result: dict, bars: pd.DataFrame) -> str:
    metrics = result["metrics"]
    method = result["methodology"]
    return f"""# اختبار تاريخي لاستراتيجية Order Block + Fair Value Gap — 15 دقيقة، سنة 2025

## النطاق والمنهجية

استُخدمت ticks عامة لرمز XAUUSD من Dukascopy وجُمعت إلى شموع 15 دقيقة من أول وآخر ومجال سعر منتصف Bid/Ask ضمن كل فترة. لم تُنشأ شموع للأوقات التي لا تحتوي ticks. قرار الاستراتيجية عند كل نقطة استخدم الشموع المتاحة حتى القرار فقط، ويبدأ البحث عن الدخول بعد فجوة رقابة شمعة واحدة. أفق التقييم 12 شمعة، أي 3 ساعات، ولمس الوقف والهدف في الشمعة نفسها يُحسب وقفاً محافظاً.

| الشموع 15 دقيقة | نقاط القرار | إعدادات مؤهلة | صفقات مملوءة | رابحة | خاسرة | نسبة النجاح | إجمالي الربح (R) | إجمالي الخسارة (R) | الصافي (R) | متوسط R | معامل الربح |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| {len(bars)} | {metrics.get('decision_points')} | {metrics.get('eligible_setups')} | {metrics.get('filled_trades')} | {metrics.get('wins')} | {metrics.get('losses')} | {metrics.get('win_rate_pct')}% | {metrics.get('gross_profit_r')} | {metrics.get('gross_loss_r')} | {metrics.get('total_r')} | {metrics.get('average_r')} | {metrics.get('profit_factor')} |

## عقد المصدر

| الحقل | القيمة |
| --- | --- |
| المصدر | Dukascopy public XAUUSD tick feed |
| الفترة | 2025-01-01 inclusive إلى 2026-01-01 exclusive |
| أول شمعة | {bars.index.min()} |
| آخر شمعة | {bars.index.max()} |
| مرجع التنفيذ | لا؛ بيانات تاريخية بحثية فقط |
| حجم الشمعة | عدد ticks، وليس حجم صفقات عند Bid/Ask |

## القيود والإفصاح

النتائج تقاس بوحدة R لا بالدولار ولا تمثل أداء حساب تداول. لا تشمل السبريد الفعلي أو الانزلاق أو العمولة أو حجم العقد؛ وسعر منتصف Bid/Ask المستخدم في التجميع ليس سعراً تنفيذياً. حد نقاط القرار هو {method.get('max_evaluation_points')} نقطة موزعة عبر السنة، لذا يعد الاختبار عينة زمنية لا دراسة كاملة لكل إشارة. نتيجة أقل من 20 صفقة لا تفسر كدليل أداء مثبت. هذه نتائج بحث وتحليل فقط وليست نصيحة مالية شخصية.

[1]: https://www.dukascopy.com/swiss/english/marketwatch/historical/ "Dukascopy Historical Data Export"
"""


def main() -> None:
    bars = load_or_build_bars()
    bars = bars.loc[(bars.index >= pd.Timestamp(START)) & (bars.index < pd.Timestamp(END))].copy()
    if bars.empty or bars.index.min() > pd.Timestamp("2025-01-03", tz="UTC") or bars.index.max() < pd.Timestamp("2025-12-30", tz="UTC"):
        raise RuntimeError("بيانات 15 دقيقة لا تغطي سنة 2025 بصورة كافية؛ أوقف الاختبار بدلاً من استخدام نطاق ناقص.")
    result = backtest_ob_fvg_strategy(
        bars,
        warmup_bars=180,
        horizon_bars=12,
        censor_gap_bars=1,
        evaluation_stride=1,
        max_evaluation_points=500,
        signal_lookback_bars=600,
        trade_output_limit=None,
    )
    payload = {
        "data_contract": {
            "source": "Dukascopy public XAUUSD tick feed",
            "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive",
            "timeframe": "15m",
            "bars": len(bars),
            "first_candle": str(bars.index.min()),
            "last_candle": str(bars.index.max()),
            "bar_price": "mid Bid/Ask per tick aggregated to OHLC",
            "volume": "tick count only; not trade volume",
            "reference_only": True,
        },
        "result": result,
    }
    OUTPUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    OUTPUT_MD.write_text(render_report(result, bars), encoding="utf-8")
    metrics = result["metrics"]
    print(f"filled={metrics.get('filled_trades')} wins={metrics.get('wins')} losses={metrics.get('losses')} win_rate={metrics.get('win_rate_pct')} total_r={metrics.get('total_r')}")
    print(f"JSON={OUTPUT_JSON}")
    print(f"REPORT={OUTPUT_MD}")


if __name__ == "__main__":
    main()
