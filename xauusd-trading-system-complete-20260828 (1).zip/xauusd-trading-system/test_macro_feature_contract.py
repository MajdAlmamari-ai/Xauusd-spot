import unittest

import pandas as pd

from macro_feature_contract import MacroFeatureError, align_point_in_time_macro


class MacroFeatureContractTests(unittest.TestCase):
    def test_release_is_not_visible_before_available_at(self):
        candles = pd.DataFrame({"timestamp": ["2026-01-08T12:00:00Z", "2026-01-08T13:00:00Z"]})
        releases = pd.DataFrame(
            {
                "available_at": ["2026-01-08T12:30:00Z"],
                "series": ["cpi_surprise"],
                "value": [0.2],
            }
        )
        result = align_point_in_time_macro(candles, releases)
        self.assertTrue(pd.isna(result.loc[0, "macro_cpi_surprise"]))
        self.assertEqual(result.loc[1, "macro_cpi_surprise"], 0.2)

    def test_pe_ratio_is_rejected_for_spot_gold(self):
        candles = pd.DataFrame({"timestamp": ["2026-01-08T12:00:00Z"]})
        releases = pd.DataFrame(
            {
                "available_at": ["2026-01-08T11:00:00Z"],
                "series": ["price_to_earnings"],
                "value": [20.0],
            }
        )
        with self.assertRaises(MacroFeatureError):
            align_point_in_time_macro(candles, releases)


if __name__ == "__main__":
    unittest.main()
