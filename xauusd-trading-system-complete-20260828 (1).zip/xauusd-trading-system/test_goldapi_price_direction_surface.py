from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = [
        'id="priceDirection"',
        'id="priceDirectionArrow"',
        'id="priceDirectionText"',
        'priceDirection.up',
        'priceDirection.down',
        'renderPriceDirection',
        'price_direction',
        'tick_change_pct',
        'last_valid_goldapi_quote',
        'Math.abs(Number(q.tick_change))',
        'Math.abs(Number(q.tick_change_pct))',
        'مقارنة gold-api.com',
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    print("PASS: gold-api.com price direction visual surface")


if __name__ == "__main__":
    main()
