#!/usr/bin/env python3
"""حساب المؤشرات الفنية من شموع OHLC حقيقية دون قيم ثابتة."""

from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd

try:
    import talib
except ImportError:  # يبقى المسار الاحتياطي قابلاً للتشغيل في بيئات التطوير المحدودة.
    talib = None

from market_structure_tools import liquidity_zones, order_blocks, support_resistance


def _series(frame: pd.DataFrame, name: str) -> pd.Series:
    return pd.to_numeric(frame[name], errors="coerce").astype(float)


def _last(series: pd.Series, digits: int = 3) -> float | None:
    clean = series.dropna()
    if clean.empty:
        return None
    return round(float(clean.iloc[-1]), digits)


def sma(close: pd.Series, period: int) -> pd.Series:
    return close.rolling(period, min_periods=period).mean()


def ema(close: pd.Series, period: int) -> pd.Series:
    """EMA بتهيئة SMA ثم تحديث أسي؛ متوافق مع أسلوب TA-Lib بدلاً من EWM الدافئ."""
    values = pd.to_numeric(close, errors="coerce").astype(float)
    if talib is not None:
        return pd.Series(talib.EMA(values.to_numpy(dtype=float), timeperiod=period), index=values.index, dtype=float)
    result = pd.Series(np.nan, index=values.index, dtype=float)
    valid_positions = np.flatnonzero(values.notna().to_numpy())
    if len(valid_positions) < period:
        return result
    start = int(valid_positions[0])
    consecutive = values.iloc[start:].dropna()
    if len(consecutive) < period:
        return result
    seed_position = start + period - 1
    result.iloc[seed_position] = float(consecutive.iloc[:period].mean())
    alpha = 2.0 / (period + 1.0)
    for position in range(seed_position + 1, len(values)):
        current = values.iloc[position]
        previous = result.iloc[position - 1]
        if pd.isna(current) or pd.isna(previous):
            continue
        result.iloc[position] = alpha * float(current) + (1.0 - alpha) * float(previous)
    return result


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """RSI Wilder القياسي: seed من أول period تغيرات، ثم متوسطات Wilder."""
    if talib is not None:
        values = pd.to_numeric(close, errors="coerce").astype(float)
        return pd.Series(talib.RSI(values.to_numpy(dtype=float), timeperiod=period), index=values.index, dtype=float)
    delta = pd.to_numeric(close, errors="coerce").astype(float).diff()
    gains, losses = delta.clip(lower=0), -delta.clip(upper=0)
    avg_gain = pd.Series(np.nan, index=close.index, dtype=float)
    avg_loss = pd.Series(np.nan, index=close.index, dtype=float)
    if len(close) <= period:
        return avg_gain
    avg_gain.iloc[period] = float(gains.iloc[1:period + 1].mean())
    avg_loss.iloc[period] = float(losses.iloc[1:period + 1].mean())
    for position in range(period + 1, len(close)):
        if pd.isna(gains.iloc[position]) or pd.isna(losses.iloc[position]):
            continue
        avg_gain.iloc[position] = (float(avg_gain.iloc[position - 1]) * (period - 1) + float(gains.iloc[position])) / period
        avg_loss.iloc[position] = (float(avg_loss.iloc[position - 1]) * (period - 1) + float(losses.iloc[position])) / period
    rs = avg_gain / avg_loss.replace(0, np.nan)
    result = 100.0 - (100.0 / (1.0 + rs))
    return result.where(avg_loss != 0, 100.0)


def true_range(frame: pd.DataFrame) -> pd.Series:
    high = _series(frame, "High")
    low = _series(frame, "Low")
    close = _series(frame, "Close")
    previous_close = close.shift(1)
    result = pd.concat(
        [high - low, (high - previous_close).abs(), (low - previous_close).abs()], axis=1
    ).max(axis=1)
    if not result.empty:
        result.iloc[0] = np.nan
    return result


def atr(frame: pd.DataFrame, period: int = 14) -> pd.Series:
    if talib is not None:
        high, low, close = (_series(frame, name).to_numpy(dtype=float) for name in ("High", "Low", "Close"))
        return pd.Series(talib.ATR(high, low, close, timeperiod=period), index=frame.index, dtype=float)
    values = true_range(frame)
    result = pd.Series(np.nan, index=frame.index, dtype=float)
    if len(values) <= period:
        return result
    result.iloc[period] = float(values.iloc[1:period + 1].mean())
    for position in range(period + 1, len(values)):
        current, previous = values.iloc[position], result.iloc[position - 1]
        if pd.isna(current) or pd.isna(previous):
            continue
        result.iloc[position] = (float(previous) * (period - 1) + float(current)) / period
    return result


def macd(close: pd.Series) -> tuple[pd.Series, pd.Series, pd.Series]:
    if talib is not None:
        values = pd.to_numeric(close, errors="coerce").astype(float)
        line, signal, histogram = talib.MACD(values.to_numpy(dtype=float), fastperiod=12, slowperiod=26, signalperiod=9)
        return tuple(pd.Series(item, index=values.index, dtype=float) for item in (line, signal, histogram))
    line = ema(close, 12) - ema(close, 26)
    signal = line.ewm(span=9, adjust=False, min_periods=9).mean()
    histogram = line - signal
    return line, signal, histogram


def stochastic(frame: pd.DataFrame, period: int = 9, smooth: int = 6) -> tuple[pd.Series, pd.Series]:
    high = _series(frame, "High")
    low = _series(frame, "Low")
    close = _series(frame, "Close")
    lowest = low.rolling(period, min_periods=period).min()
    highest = high.rolling(period, min_periods=period).max()
    k = 100 * (close - lowest) / (highest - lowest).replace(0, float("nan"))
    d = k.rolling(smooth, min_periods=smooth).mean()
    return k.fillna(50), d.fillna(50)


def stoch_rsi(close: pd.Series, period: int = 14) -> pd.Series:
    raw = rsi(close, period)
    lowest = raw.rolling(period, min_periods=period).min()
    highest = raw.rolling(period, min_periods=period).max()
    return (100 * (raw - lowest) / (highest - lowest).replace(0, float("nan"))).fillna(50)


def adx(frame: pd.DataFrame, period: int = 14) -> tuple[pd.Series, pd.Series, pd.Series]:
    if talib is not None:
        high, low, close = (_series(frame, name).to_numpy(dtype=float) for name in ("High", "Low", "Close"))
        return (
            pd.Series(talib.ADX(high, low, close, timeperiod=period), index=frame.index, dtype=float),
            pd.Series(talib.PLUS_DI(high, low, close, timeperiod=period), index=frame.index, dtype=float),
            pd.Series(talib.MINUS_DI(high, low, close, timeperiod=period), index=frame.index, dtype=float),
        )
    high = _series(frame, "High")
    low = _series(frame, "Low")
    tr = true_range(frame)
    up_move = high.diff()
    down_move = -low.diff()
    plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
    minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
    smooth_tr = pd.Series(np.nan, index=frame.index, dtype=float)
    smooth_plus = pd.Series(np.nan, index=frame.index, dtype=float)
    smooth_minus = pd.Series(np.nan, index=frame.index, dtype=float)
    if len(frame) <= period:
        blank = pd.Series(np.nan, index=frame.index, dtype=float)
        return blank, blank, blank
    smooth_tr.iloc[period] = float(tr.iloc[1:period + 1].sum())
    smooth_plus.iloc[period] = float(plus_dm.iloc[1:period + 1].sum())
    smooth_minus.iloc[period] = float(minus_dm.iloc[1:period + 1].sum())
    for position in range(period + 1, len(frame)):
        smooth_tr.iloc[position] = float(smooth_tr.iloc[position - 1]) - float(smooth_tr.iloc[position - 1]) / period + float(tr.iloc[position])
        smooth_plus.iloc[position] = float(smooth_plus.iloc[position - 1]) - float(smooth_plus.iloc[position - 1]) / period + float(plus_dm.iloc[position])
        smooth_minus.iloc[position] = float(smooth_minus.iloc[position - 1]) - float(smooth_minus.iloc[position - 1]) / period + float(minus_dm.iloc[position])
    plus_di = 100 * smooth_plus / smooth_tr.replace(0, np.nan)
    minus_di = 100 * smooth_minus / smooth_tr.replace(0, np.nan)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, float("nan"))
    adx_value = pd.Series(np.nan, index=frame.index, dtype=float)
    first_adx = 2 * period - 1
    if len(frame) > first_adx:
        adx_value.iloc[first_adx] = float(dx.iloc[period:first_adx + 1].mean())
        for position in range(first_adx + 1, len(frame)):
            adx_value.iloc[position] = (float(adx_value.iloc[position - 1]) * (period - 1) + float(dx.iloc[position])) / period
    return adx_value, plus_di, minus_di


def cci(frame: pd.DataFrame, period: int = 14) -> pd.Series:
    typical = (_series(frame, "High") + _series(frame, "Low") + _series(frame, "Close")) / 3
    mean = typical.rolling(period, min_periods=period).mean()
    deviation = typical.rolling(period, min_periods=period).apply(
        lambda values: float(abs(values - values.mean()).mean()), raw=True
    )
    return ((typical - mean) / (0.015 * deviation.replace(0, float("nan")))).fillna(0)


def ultimate_oscillator(frame: pd.DataFrame) -> pd.Series:
    high = _series(frame, "High")
    low = _series(frame, "Low")
    close = _series(frame, "Close")
    previous_close = close.shift(1)
    buying_pressure = close - pd.concat([low, previous_close], axis=1).min(axis=1)
    true_range_value = pd.concat([high, previous_close], axis=1).max(axis=1) - pd.concat(
        [low, previous_close], axis=1
    ).min(axis=1)
    ratio = buying_pressure / true_range_value.replace(0, float("nan"))
    return (
        100
        * (
            4 * ratio.rolling(7, min_periods=7).sum() / true_range_value.rolling(7, min_periods=7).sum()
            + 2 * ratio.rolling(14, min_periods=14).sum() / true_range_value.rolling(14, min_periods=14).sum()
            + ratio.rolling(28, min_periods=28).sum() / true_range_value.rolling(28, min_periods=28).sum()
        )
        / 7
    ).fillna(50)


def pivots(frame: pd.DataFrame) -> dict[str, dict[str, float | None]]:
    if len(frame) < 2:
        return {"traditional": {}, "fibonacci": {}}
    previous = frame.iloc[-2]
    high = float(previous["High"])
    low = float(previous["Low"])
    close = float(previous["Close"])
    pivot = (high + low + close) / 3
    range_value = high - low
    traditional = {
        "R3": high + 2 * (pivot - low),
        "R2": pivot + range_value,
        "R1": 2 * pivot - low,
        "Pivot": pivot,
        "S1": 2 * pivot - high,
        "S2": pivot - range_value,
        "S3": low - 2 * (high - pivot),
    }
    fibonacci = {
        "R3": pivot + 1.000 * range_value,
        "R2": pivot + 0.618 * range_value,
        "R1": pivot + 0.382 * range_value,
        "Pivot": pivot,
        "S1": pivot - 0.382 * range_value,
        "S2": pivot - 0.618 * range_value,
        "S3": pivot - 1.000 * range_value,
    }
    return {
        "traditional": {key: round(value, 2) for key, value in traditional.items()},
        "fibonacci": {key: round(value, 2) for key, value in fibonacci.items()},
    }


def _usable_volume(frame: pd.DataFrame) -> pd.Series | None:
    if "Volume" not in frame.columns:
        return None
    volume = pd.to_numeric(frame["Volume"], errors="coerce").fillna(0.0).astype(float)
    return volume if float(volume.sum()) > 0 else None


def _relative_volume(volume: pd.Series | None, period: int = 20) -> float | None:
    if volume is None or len(volume) < 3:
        return None
    baseline = float(volume.iloc[-period - 1:-1].median()) if len(volume) > period else float(volume.iloc[:-1].median())
    return None if baseline <= 0 else float(volume.iloc[-1] / baseline)


def _confirmed_pivots(frame: pd.DataFrame, left: int = 2, right: int = 2) -> list[dict[str, Any]]:
    """يعيد pivots لا يمكن معرفتها إلا بعد مرور right شموع؛ يمنع استخدام قمة/قاع مستقبلية."""
    high, low = _series(frame, "High"), _series(frame, "Low")
    pivots: list[dict[str, Any]] = []
    for index in range(left, max(left, len(frame) - right)):
        high_window = high.iloc[index - left:index + right + 1]
        low_window = low.iloc[index - left:index + right + 1]
        if float(high.iloc[index]) == float(high_window.max()) and int((high_window == high.iloc[index]).sum()) == 1:
            pivots.append({"kind": "high", "index": index, "price": float(high.iloc[index])})
        if float(low.iloc[index]) == float(low_window.min()) and int((low_window == low.iloc[index]).sum()) == 1:
            pivots.append({"kind": "low", "index": index, "price": float(low.iloc[index])})
    return sorted(pivots, key=lambda point: point["index"])


def _last_valid_swing(frame: pd.DataFrame, minimum_atr: float = 1.5) -> tuple[dict[str, Any], dict[str, Any]] | None:
    pivots = _confirmed_pivots(frame)
    atr_series = atr(frame, 14)
    for last in reversed(range(1, len(pivots))):
        second = pivots[last]
        first = pivots[last - 1]
        if first["kind"] == second["kind"]:
            continue
        atr_at_second = float(atr_series.iloc[second["index"]]) if not pd.isna(atr_series.iloc[second["index"]]) else 0.0
        if abs(second["price"] - first["price"]) >= max(atr_at_second * minimum_atr, 1e-9):
            return first, second
    return None


def liquidity_sweep(frame: pd.DataFrame, lookback: int = 60) -> dict[str, Any]:
    """يتطلب pivot مؤكداً، اختراقاً بحجم ATR، ورفضاً من شمعة الإغلاق قبل وسم sweep."""
    if len(frame) < 24:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لتأكيد pivot وقياس ATR.", "levels": {}, "quality": "بيانات غير كافية", "quality_score": 0}
    high, low, close, open_ = _series(frame, "High"), _series(frame, "Low"), _series(frame, "Close"), _series(frame, "Open")
    pivots = [point for point in _confirmed_pivots(frame) if point["index"] >= max(0, len(frame) - lookback - 3)]
    pivot_highs = [point for point in pivots if point["kind"] == "high"]
    pivot_lows = [point for point in pivots if point["kind"] == "low"]
    if not pivot_highs or not pivot_lows:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "لا توجد pivots مؤكدة كافية ضمن نافذة فحص السيولة.", "levels": {}, "quality": "OHLC مع pivots غير كافية", "quality_score": 0}
    reference_high, reference_low = pivot_highs[-1]["price"], pivot_lows[-1]["price"]
    current_atr = _last(atr(frame, 14), 6) or 0.0
    last_high, last_low, last_close, last_open = float(high.iloc[-1]), float(low.iloc[-1]), float(close.iloc[-1]), float(open_.iloc[-1])
    candle_range = max(last_high - last_low, 1e-9)
    relative_volume = _relative_volume(_usable_volume(frame))
    volume_confirmed = relative_volume is None or relative_volume >= 1.0
    if last_low < reference_low and last_close > reference_low:
        penetration = (reference_low - last_low) / max(current_atr, 1e-9)
        rejection = (last_close - last_low) / candle_range
        qualified = penetration >= 0.15 and rejection >= 0.55 and volume_confirmed
        quality_score = min(95, round(35 + min(30, penetration * 30) + rejection * 25 + (10 if volume_confirmed else 0)))
        return {
            "status": "مُكتشف (مؤهل)" if qualified else "مُكتشف (ضعيف)",
            "bias": "صاعد" if qualified else "محايد",
            "details": "سحب قاع pivot مع عودة الإغلاق فوقه؛ يتطلب الاختراق نسبة ATR ورفضاً كافياً وحجماً نسبياً عند توفره.",
            "levels": {"قاع pivot": round(reference_low, 2), "إغلاق الشمعة": round(last_close, 2), "اختراق/ATR": round(penetration, 2), "رفض الشمعة": round(rejection, 2)},
            "quality": "OHLC + ATR + حجم نسبي" if relative_volume is not None else "OHLC + ATR (الحجم غير متاح)",
            "quality_score": quality_score,
            "qualified": qualified,
        }
    if last_high > reference_high and last_close < reference_high:
        penetration = (last_high - reference_high) / max(current_atr, 1e-9)
        rejection = (last_high - last_close) / candle_range
        qualified = penetration >= 0.15 and rejection >= 0.55 and volume_confirmed
        quality_score = min(95, round(35 + min(30, penetration * 30) + rejection * 25 + (10 if volume_confirmed else 0)))
        return {
            "status": "مُكتشف (مؤهل)" if qualified else "مُكتشف (ضعيف)",
            "bias": "هابط" if qualified else "محايد",
            "details": "سحب قمة pivot مع عودة الإغلاق دونها؛ يتطلب الاختراق نسبة ATR ورفضاً كافياً وحجماً نسبياً عند توفره.",
            "levels": {"قمة pivot": round(reference_high, 2), "إغلاق الشمعة": round(last_close, 2), "اختراق/ATR": round(penetration, 2), "رفض الشمعة": round(rejection, 2)},
            "quality": "OHLC + ATR + حجم نسبي" if relative_volume is not None else "OHLC + ATR (الحجم غير متاح)",
            "quality_score": quality_score,
            "qualified": qualified,
        }
    return {
        "status": "غير مكتشف",
        "bias": "محايد",
        "details": "لا تتحقق شروط pivot المؤكد + اختراق ATR + عودة الإغلاق في آخر شمعة.",
        "levels": {"قمة pivot": round(reference_high, 2), "قاع pivot": round(reference_low, 2), "ATR(14)": round(current_atr, 2)},
        "quality": "OHLC + ATR",
        "quality_score": 0,
    }


def fair_value_gap(frame: pd.DataFrame, lookback: int = 80) -> dict[str, Any]:
    """يستخرج FVG بثلاث شمعات مع displacement وحجم أدنى، لا مجرد عدم تداخل عارض."""
    if len(frame) < 25:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لقياس displacement وATR حول نمط الثلاث شمعات.", "levels": {}, "quality": "بيانات غير كافية", "quality_score": 0}
    high, low, close, open_ = _series(frame, "High"), _series(frame, "Low"), _series(frame, "Close"), _series(frame, "Open")
    atr_series = atr(frame, 14)
    volume = _usable_volume(frame)
    active: list[dict[str, Any]] = []
    first = max(2, len(frame) - lookback)
    for index in range(first, len(frame)):
        middle = index - 1
        local_atr = float(atr_series.iloc[middle]) if not pd.isna(atr_series.iloc[middle]) else 0.0
        if local_atr <= 0:
            continue
        body_atr = abs(float(close.iloc[middle]) - float(open_.iloc[middle])) / max(local_atr, 1e-9)
        volume_ratio = None
        if volume is not None and middle >= 5:
            baseline = float(volume.iloc[max(0, middle - 20):middle].median())
            volume_ratio = float(volume.iloc[middle] / baseline) if baseline > 0 else None
        if float(low.iloc[index]) > float(high.iloc[index - 2]):
            lower, upper = float(high.iloc[index - 2]), float(low.iloc[index])
            later_low = low.iloc[index + 1:]
            if later_low.empty or float(later_low.min()) > lower:
                active.append({"bias": "صاعد", "lower": lower, "upper": upper, "index": index, "gap_atr": (upper - lower) / max(local_atr, 1e-9), "body_atr": body_atr, "volume_ratio": volume_ratio})
        elif float(high.iloc[index]) < float(low.iloc[index - 2]):
            lower, upper = float(high.iloc[index]), float(low.iloc[index - 2])
            later_high = high.iloc[index + 1:]
            if later_high.empty or float(later_high.max()) < upper:
                active.append({"bias": "هابط", "lower": lower, "upper": upper, "index": index, "gap_atr": (upper - lower) / max(local_atr, 1e-9), "body_atr": body_atr, "volume_ratio": volume_ratio})
    if not active:
        return {"status": "غير مكتشف", "bias": "محايد", "details": "لا توجد فجوة نشطة تستوفي بقاء الحدود ضمن نافذة الفحص.", "levels": {}, "quality": "OHLC + ATR", "quality_score": 0}
    gap = active[-1]
    midpoint = (gap["lower"] + gap["upper"]) / 2
    current = float(close.iloc[-1])
    position = "داخل الفجوة" if gap["lower"] <= current <= gap["upper"] else "فوق الفجوة" if current > gap["upper"] else "دون الفجوة"
    volume_ok = gap["volume_ratio"] is None or gap["volume_ratio"] >= 0.8
    qualified = gap["gap_atr"] >= 0.12 and gap["body_atr"] >= 0.75 and volume_ok
    quality_score = min(95, round(25 + min(30, gap["gap_atr"] * 80) + min(30, gap["body_atr"] * 25) + (10 if volume_ok else 0)))
    return {
        "status": "مُكتشف (مؤهل)" if qualified else "مُكتشف (ضعيف)",
        "bias": gap["bias"] if qualified else "محايد",
        "details": f"فجوة ثلاث شمعات نشطة {position}؛ تتطلب displacement وحجماً نسبياً عند توفره، وتبطل عند تجاوز الحد المقابل بالكامل.",
        "levels": {"الحد الأدنى": round(gap["lower"], 2), "المنتصف": round(midpoint, 2), "الحد الأعلى": round(gap["upper"], 2), "حجم الفجوة/ATR": round(gap["gap_atr"], 2), "جسم الوسط/ATR": round(gap["body_atr"], 2)},
        "formed_at": str(frame.index[gap["index"]]),
        "quality": "OHLC + ATR + حجم نسبي" if gap["volume_ratio"] is not None else "OHLC + ATR (الحجم غير متاح)",
        "quality_score": quality_score,
        "qualified": qualified,
    }


def anchored_vwap(frame: pd.DataFrame, lookback: int = 60) -> dict[str, Any]:
    volume = _usable_volume(frame)
    if volume is None:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "Anchored VWAP يحتاج حجم شموع صالحاً؛ المصدر الحالي لا يوفره لهذه النافذة.", "levels": {}, "quality": "لا حجم صالح"}
    close, high, low = _series(frame, "Close"), _series(frame, "High"), _series(frame, "Low")
    window = frame.iloc[-min(lookback, len(frame)):]
    swing = _last_valid_swing(window)
    if swing is None:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "لا توجد موجة pivot مؤكدة بمدى ATR كافٍ لاختيار مرساة VWAP.", "levels": {}, "quality": "Pivots غير كافية", "quality_score": 0}
    first, second = swing
    offset = len(frame) - len(window)
    anchor_index = int(first["index"] + offset)
    anchor_name = "قاع pivot مؤكد" if first["kind"] == "low" else "قمة pivot مؤكدة"
    typical = (high + low + close) / 3
    active_volume = volume.iloc[anchor_index:]
    denominator = float(active_volume.sum())
    if denominator <= 0:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "حجم الشموع بعد نقطة الارتكاز يساوي صفراً.", "levels": {}, "quality": "لا حجم صالح"}
    value = float((typical.iloc[anchor_index:] * active_volume).sum() / denominator)
    current = float(close.iloc[-1])
    atr_now = _last(atr(frame, 14), 6) or 0.0
    distance_atr = abs(current - value) / max(atr_now, 1e-9)
    nonzero_ratio = float((active_volume > 0).mean())
    qualified = len(active_volume) >= 8 and nonzero_ratio >= 0.9 and distance_atr >= 0.10
    bias = "صاعد" if current > value and qualified else "هابط" if current < value and qualified else "محايد"
    quality_score = min(90, round(40 + min(25, len(active_volume) * 1.5) + nonzero_ratio * 20 + min(10, distance_atr * 8)))
    return {
        "status": "متاح (مؤهل)" if qualified else "متاح (ضعيف)",
        "bias": bias,
        "details": f"VWAP مرساة عند {anchor_name} ضمن آخر {len(frame) - anchor_index} شمعة؛ يلزم بعد عن VWAP وحجم متصل قبل اعتبار الميل مؤهلاً.",
        "levels": {"Anchored VWAP": round(value, 2), "سعر الإغلاق": round(current, 2), "المسافة/ATR": round(distance_atr, 2)},
        "anchor_at": str(frame.index[anchor_index]),
        "quality": "حجم شموع المصدر؛ ليس حجم صفقات عند Bid/Ask",
        "quality_score": quality_score,
        "qualified": qualified,
    }


def volume_profile(frame: pd.DataFrame, lookback: int = 100, rows: int = 24) -> dict[str, Any]:
    volume = _usable_volume(frame)
    if volume is None:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "Volume Profile يحتاج حجم شموع صالحاً؛ لا يمكن بناء POC أو Value Area بصدق.", "levels": {}, "quality": "لا حجم صالح"}
    window = frame.iloc[-min(lookback, len(frame)):].copy()
    volume = volume.loc[window.index]
    low, high, close = _series(window, "Low"), _series(window, "High"), _series(window, "Close")
    floor, ceiling = float(low.min()), float(high.max())
    if ceiling <= floor:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "نطاق السعر صفري ولا يمكن تقسيمه إلى عقد حجم.", "levels": {}, "quality": "لا حجم صالح"}
    edges = np.linspace(floor, ceiling, rows + 1)
    profile = np.zeros(rows, dtype=float)
    for index in range(len(window)):
        candle_low, candle_high, candle_volume = float(low.iloc[index]), float(high.iloc[index]), float(volume.iloc[index])
        if candle_volume <= 0:
            continue
        if candle_high <= candle_low:
            bucket = min(rows - 1, max(0, int(np.searchsorted(edges, float(close.iloc[index]), side="right") - 1)))
            profile[bucket] += candle_volume
            continue
        overlaps = np.maximum(0.0, np.minimum(edges[1:], candle_high) - np.maximum(edges[:-1], candle_low))
        if float(overlaps.sum()) > 0:
            profile += candle_volume * overlaps / float(overlaps.sum())
    total = float(profile.sum())
    if total <= 0:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "تعذر توزيع حجم الشموع عبر نطاق السعر.", "levels": {}, "quality": "لا حجم صالح"}
    poc = int(np.argmax(profile))
    chosen = {poc}
    accumulated, target = float(profile[poc]), total * 0.70
    lower, upper = poc - 1, poc + 1
    while accumulated < target and (lower >= 0 or upper < rows):
        left = float(profile[lower]) if lower >= 0 else -1.0
        right = float(profile[upper]) if upper < rows else -1.0
        if right > left:
            chosen.add(upper); accumulated += right; upper += 1
        else:
            chosen.add(lower); accumulated += left; lower -= 1
    value_low, value_high = min(chosen), max(chosen)
    poc_price = (edges[poc] + edges[poc + 1]) / 2
    current = float(close.iloc[-1])
    hvr = int(np.argsort(profile)[-2]) if rows > 1 else poc
    lvr = int(np.argmin(profile))
    hvn_price = (edges[hvr] + edges[hvr + 1]) / 2
    lvn_price = (edges[lvr] + edges[lvr + 1]) / 2
    nonzero_ratio = float((volume > 0).mean())
    concentration = float(profile[poc] / total)
    qualified = len(window) >= 50 and nonzero_ratio >= 0.9
    bias = "صاعد" if current > poc_price and qualified else "هابط" if current < poc_price and qualified else "محايد"
    quality_score = min(70, round(25 + min(25, len(window) / 4) + nonzero_ratio * 15 + min(10, concentration * 100)))
    peak_volume = max(float(profile.max()), 1.0)
    bins = [
        {
            "lower": round(float(edges[index]), 4),
            "upper": round(float(edges[index + 1]), 4),
            "volume": round(float(profile[index]), 2),
            "ratio": round(float(profile[index] / peak_volume), 6),
            "in_value_area": index in chosen,
            "is_poc": index == poc,
        }
        for index in range(rows)
    ]
    return {
        "status": "تقريبي (مؤهل)" if qualified else "تقريبي (ضعيف)",
        "bias": bias,
        "details": "POC وValue Area وHVN/LVN موزعة تقريبياً من حجم الشموع على نطاقها؛ لا تمثل Volume-at-Price أو Order Flow فعلياً.",
        "levels": {"POC": round(poc_price, 2), "VAL (70%)": round(float(edges[value_low]), 2), "VAH (70%)": round(float(edges[value_high + 1]), 2), "HVN": round(hvn_price, 2), "LVN": round(lvn_price, 2)},
        "bins": bins,
        "quality": "تقريبي من حجم شموع المصدر",
        "quality_score": quality_score,
        "qualified": qualified,
    }


def fibonacci_retracement(frame: pd.DataFrame, lookback: int = 80) -> dict[str, Any]:
    window = frame.iloc[-min(lookback, len(frame)):]
    if len(window) < 12:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "الشموع غير كافية لاستخراج موجة pivot مؤكدة.", "levels": {}, "quality": "بيانات غير كافية", "quality_score": 0}
    swing = _last_valid_swing(window, minimum_atr=1.5)
    if swing is None:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "لا توجد موجة pivot مؤكدة بمدى ATR كافٍ؛ لا تُرسم Fibonacci من قمة/قاع عشوائي.", "levels": {}, "quality": "Pivots غير كافية", "quality_score": 0}
    first, second = swing
    swing_low, swing_high = (first["price"], second["price"]) if first["kind"] == "low" else (second["price"], first["price"])
    distance = swing_high - swing_low
    if distance <= 0:
        return {"status": "غير متاح", "bias": "غير متاح", "details": "نطاق الموجة المرجعية صفري.", "levels": {}, "quality": "نطاق غير صالح", "quality_score": 0}
    ratios = (0.236, 0.382, 0.5, 0.618, 0.786)
    up_leg = first["kind"] == "low"
    levels = {f"{ratio * 100:.1f}%": round(swing_high - distance * ratio if up_leg else swing_low + distance * ratio, 2) for ratio in ratios}
    atr_at_end = _last(atr(window, 14), 6) or 0.0
    swing_atr = distance / max(atr_at_end, 1e-9)
    quality_score = min(90, round(45 + min(40, swing_atr * 4)))
    return {
        "status": "متاح (مؤهل)",
        "bias": "صاعد" if up_leg else "هابط",
        "details": "مستويات ارتداد مشتقة من آخر موجة pivot مؤكدة وبمدى ATR كافٍ؛ هي مناطق مراقبة وليست أهدافاً مضمونة.",
        "levels": {"قمة الموجة": round(swing_high, 2), "قاع الموجة": round(swing_low, 2), "مدى الموجة/ATR": round(swing_atr, 2), **levels},
        "anchor_at": f"{first['kind']}: {window.index[first['index']]} | {second['kind']}: {window.index[second['index']]}",
        "quality": "شموع OHLC",
        "quality_score": quality_score,
        "qualified": True,
    }


def advanced_tools(frame: pd.DataFrame) -> dict[str, Any]:
    tools = {
        "liquidity_sweep": liquidity_sweep(frame),
        "fair_value_gap": fair_value_gap(frame),
        "anchored_vwap": anchored_vwap(frame),
        "volume_profile": volume_profile(frame),
        "fibonacci": fibonacci_retracement(frame),
        "liquidity_zones": liquidity_zones(frame),
        "support_resistance": support_resistance(frame),
        "order_blocks": order_blocks(frame),
        "order_flow": {
            "status": "غير متاح",
            "bias": "غير متاح",
            "details": "Order Flow الحقيقي يحتاج صفقات tick-by-tick عند Bid/Ask وDOM أو Time & Sales؛ شموع OHLC وحدها لا تكفي.",
            "levels": {},
            "quality": "يتطلب بيانات إضافية موثقة",
            "quality_score": 0,
            "qualified": False,
        },
    }
    weights = {"صاعد": 1, "هابط": -1}
    # لا تجتمع أدوات متفرعة من OHLC كمصادر مستقلة. يقتصر هذا التوافق على عائلة البنية
    # السعرية، وتبقى الأدوات الفرعية مرئية للتفسير لا لرفع احتمالية نجاح مفترضة.
    structural_keys = ("liquidity_sweep", "fair_value_gap", "liquidity_zones", "support_resistance", "order_blocks", "fibonacci")
    eligible = [tools[key] for key in structural_keys if tools[key].get("qualified") and tools[key].get("bias") in weights]
    weighted_score = sum(weights[tool["bias"]] * float(tool.get("quality_score", 0)) / 100 for tool in eligible)
    average_quality = round(sum(float(tool.get("quality_score", 0)) for tool in eligible) / len(eligible), 1) if eligible else 0.0
    return {
        "tools": tools,
        "confluence": {
            "score": round(weighted_score, 2),
            "qualified_tools": len(eligible),
            "average_quality": average_quality,
            "bias": "توافق صاعد" if weighted_score >= 1.25 and len(eligible) >= 2 else "توافق هابط" if weighted_score <= -1.25 and len(eligible) >= 2 else "توافق محدود / مختلط",
            "details": "التوافق يوزن الأدوات المؤهلة فقط بحسب جودة البيانات والقواعد؛ لا يتحول إلى أمر تداول.",
        },
    }


def evidence_families(
    *,
    latest: float,
    ema20_value: float | None,
    ema50_value: float | None,
    rsi_value: float,
    macd_histogram: float,
    adx_value: float,
    tools: dict[str, Any],
    structure_confluence: dict[str, Any],
) -> dict[str, Any]:
    """يبني عائلات أدلة بدلاً من عد RSI وStochastic وROC كتصويتات مستقلة.

    جميع العائلات التالية مشتقة من OHLC، ولذلك لا تحمل "احتمال نجاح" أو ثقة
    معايرة. يميز العقد بين الاتجاه والزخم والبنية والسياق الحجمي والتدفق الحقيقي.
    """
    if ema20_value is not None and ema50_value is not None and latest > ema20_value > ema50_value:
        trend = "صاعد"
    elif ema20_value is not None and ema50_value is not None and latest < ema20_value < ema50_value:
        trend = "هابط"
    else:
        trend = "محايد"
    rsi_direction = "صاعد" if rsi_value >= 52 else "هابط" if rsi_value <= 48 else "محايد"
    macd_direction = "صاعد" if macd_histogram > 0 else "هابط" if macd_histogram < 0 else "محايد"
    momentum = rsi_direction if rsi_direction == macd_direction else "محايد"
    structural_bias = structure_confluence.get("bias", "توافق محدود / مختلط")
    structure = "صاعد" if structural_bias == "توافق صاعد" else "هابط" if structural_bias == "توافق هابط" else "محايد"
    vwap = tools.get("anchored_vwap", {})
    profile = tools.get("volume_profile", {})
    volume_context = vwap.get("bias") if vwap.get("qualified") and vwap.get("bias") == profile.get("bias") and profile.get("qualified") else "محايد"
    decision_families = {
        "الاتجاه": trend,
        "الزخم": momentum,
        "بنية السوق": structure,
    }
    directions = [direction for direction in decision_families.values() if direction in {"صاعد", "هابط"}]
    bullish, bearish = directions.count("صاعد"), directions.count("هابط")
    decision_bias = "صاعد" if bullish >= 2 and bearish == 0 else "هابط" if bearish >= 2 and bullish == 0 else "محايد"
    qualified_families = len(directions)
    agreement = max(bullish, bearish)
    disagreement = bullish > 0 and bearish > 0
    neutral_reasons: list[str] = []
    if trend == "محايد":
        neutral_reasons.append("المتوسطات غير مرتبة مع آخر إغلاق على اتجاه واحد.")
    if momentum == "محايد":
        neutral_reasons.append("RSI وMACD لا يؤكدان الزخم في الاتجاه نفسه.")
    if structure == "محايد":
        neutral_reasons.append("بنية السوق لا تملك توافق مناطق/قمم/قيعان مؤهلاً في اتجاه واحد.")
    if disagreement:
        neutral_reasons.append("عائلات الأدلة المؤهلة متعارضة بين الصعود والهبوط.")
    if adx_value < 20:
        neutral_reasons.append("ADX دون 20؛ قوة الاتجاه ضعيفة.")
    if decision_bias == "محايد" and not neutral_reasons:
        neutral_reasons.append("لا توجد عائلتان مستقلتان تؤكدان الاتجاه نفسه.")

    # الدرجة وصفية لإجماع العائلات، وليست احتمالاً. لا توجد قيمة قاعدية ثابتة:
    # تتغير بحسب كل إطار من الاتجاه والزخم والبنية والسياق الحجمي وقوة ADX.
    strength_score = 0
    strength_score += 26 * agreement
    strength_score -= 16 if disagreement else 0
    strength_score += 12 if volume_context in {"صاعد", "هابط"} and volume_context == decision_bias else 0
    strength_score += 10 if adx_value >= 25 and decision_bias != "محايد" else 0
    strength_score += 6 if adx_value >= 35 and decision_bias != "محايد" else 0
    strength_score = max(0, min(100, round(strength_score)))
    return {
        "trend": {
            "direction": trend,
            "qualified": trend != "محايد",
            "members": ["EMA20", "EMA50", "آخر إغلاق"],
            "dependency": "مشتقة من OHLC؛ لا تعد دليلاً مستقلاً عن السعر.",
        },
        "momentum": {
            "direction": momentum,
            "qualified": momentum != "محايد",
            "members": ["RSI(14)", "MACD histogram"],
            "dependency": "مشتقات زخم من OHLC؛ لا يضاف Stochastic أو ROC كتصويت مستقل.",
        },
        "market_structure": {
            "direction": structure,
            "qualified": structure != "محايد",
            "members": ["FVG/Order Blocks/Liquidity/Pivots"],
            "dependency": "مرشحات بنيوية من OHLC، وليست إثباتاً لأوامر مؤسسية.",
        },
        "volume_context": {
            "direction": volume_context,
            "qualified": volume_context != "محايد",
            "members": ["Anchored VWAP", "Volume Profile"],
            "dependency": "حجم شموع تقريبي؛ لا يمثل Volume-at-Price أو Bid/Ask flow.",
        },
        "order_flow": {
            "direction": "غير متاح",
            "qualified": False,
            "members": [],
            "dependency": "يتطلب Bid/Ask وDOM وTime & Sales موثقين؛ لا يستنتج من OHLC.",
        },
        "decision_bias": decision_bias,
        "qualified_decision_families": qualified_families,
        "neutral_reasons": neutral_reasons,
        "evidence_strength": {
            "score": strength_score,
            "label": "قوة أدلة مرتفعة" if strength_score >= 75 else "قوة أدلة متوسطة" if strength_score >= 55 else "قوة أدلة محدودة",
            "is_probability": False,
            "calibration": "غير معاير؛ لا يفسر كاحتمال نجاح أو كنسبة ربح.",
            "components": [
                {"family": name, "direction": direction, "qualified": direction in {"صاعد", "هابط"}}
                for name, direction in decision_families.items()
            ] + [{"family": "سياق الحجم", "direction": volume_context, "qualified": volume_context in {"صاعد", "هابط"}}],
        },
    }


def indicator_combinations(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    """يقدم توليفات مشروطة حسب السياق، لا عدداً من الإشارات المنفصلة."""
    adx_value = float(snapshot.get("adx", 0) or 0)
    atr_value = float(snapshot.get("atr", 0) or 0)
    atr_median = float(snapshot.get("atr_median", 0) or 0)
    rsi_value = float(snapshot.get("rsi", 50) or 50)
    macd_histogram = float(snapshot.get("macd_histogram", 0) or 0)
    advanced = snapshot.get("advanced_tools", {})
    structure = advanced.get("tools", {}).get("support_resistance", {})
    confluence = advanced.get("confluence", {})
    regimes: list[dict[str, Any]] = []
    if adx_value >= 25:
        regimes.append({
            "title": "اتجاه + زخم",
            "when": "ADX أعلى من 25 مع توافق المتوسطات وMACD",
            "components": ["MA20/50", "MACD", "ADX", "Anchored VWAP"],
            "reading": "المتابعة تكون مشروطة ببقاء السعر في جهة المتوسطات وVWAP، لا بمجرد تقاطع واحد.",
            "caution": "لا تطارد السعر إذا ابتعد عن VWAP أو أقرب دعم/مقاومة بأكثر من نطاق ATR معقول.",
            "status": "ملائم للسوق الاتجاهي",
        })
    if adx_value < 22:
        regimes.append({
            "title": "نطاق + ارتداد مشروط",
            "when": "ADX أقل من 22 وقرب السعر من دعم/مقاومة مؤهل",
            "components": ["دعم/مقاومة", "RSI", "Stochastic", "Volume Profile"],
            "reading": "يُراقب تزامن التشبع مع منطقة سعرية محددة، لا التشبع وحده.",
            "caution": "إلغاء الفكرة عند إغلاق واضح خارج المنطقة أو تسارع ATR.",
            "status": "ملائم للسوق العرضي",
        })
    if atr_median > 0 and atr_value >= 1.25 * atr_median:
        regimes.append({
            "title": "اختراق + تقلب",
            "when": "ATR أعلى من متوسطه مع إغلاق بنية خارج دعم/مقاومة",
            "components": ["ATR", "دعم/مقاومة", "Fair Value Gap", "Liquidity Sweep"],
            "reading": "يلزم إغلاق مؤكد ثم إعادة اختبار أو قبول سعري؛ لا يكفي ذيل شمعة منفرد.",
            "caution": "يزداد خطر الانزلاق والفخاخ حول الأخبار أو ذروات التقلب.",
            "status": "تقلب مرتفع",
        })
    if not regimes:
        regimes.append({
            "title": "توافق محدود",
            "when": "لا يوجد نظام سوق واضح أو الأدوات غير متفقة",
            "components": ["MA20/50", "RSI", "دعم/مقاومة"],
            "reading": "الأولوية للمراقبة وانتظار توافق أفضل بدلاً من زيادة عدد المؤشرات.",
            "caution": "القراءة الحالية لا تحمل شرطاً كافياً لسيناريو عالي الجودة.",
            "status": "انتظار",
        })
    return [{
        **item,
        "context": {
            "ADX": round(adx_value, 2), "ATR/median": round(atr_value / max(atr_median, 1e-9), 2),
            "RSI": round(rsi_value, 2), "MACD histogram": round(macd_histogram, 4),
            "structure": structure.get("status", "غير متاح"), "confluence": confluence.get("bias", "غير متاح"),
        },
    } for item in regimes]


def action_for(name: str, value: float, context: dict[str, float]) -> str:
    if name == "RSI(14)":
        return "شراء" if value < 35 else "بيع" if value > 65 else "متعادلة"
    if name.startswith("STOCH"):
        return "شراء" if value < 20 else "بيع" if value > 80 else "متعادلة"
    if name.startswith("MACD"):
        return "شراء" if value > 0 else "بيع" if value < 0 else "متعادلة"
    if name.startswith("ATR"):
        return "تقلب مرتفع" if value > context.get("atr_median", value) else "أقل تقلب"
    if name.startswith("ADX"):
        return "اتجاه قوي" if value >= 25 else "متعادلة"
    if name.startswith("CCI"):
        return "شراء" if value < -100 else "بيع" if value > 100 else "متعادلة"
    if name.startswith("Highs/Lows"):
        return "شراء" if value > 0 else "بيع" if value < 0 else "متعادلة"
    if name == "UO":
        return "شراء" if value > 55 else "بيع" if value < 45 else "متعادلة"
    if name == "ROC":
        return "شراء" if value > 0 else "بيع" if value < 0 else "متعادلة"
    if name == "Williams %R":
        return "شراء" if value < -80 else "بيع" if value > -20 else "متعادلة"
    if name.startswith("Bull/Bear Power"):
        return "شراء" if value > 0 else "بيع" if value < 0 else "متعادلة"
    return "متعادلة"


def calculate_snapshot(frame: pd.DataFrame) -> dict[str, Any]:
    frame = frame.copy().dropna(subset=["Open", "High", "Low", "Close"])
    close = _series(frame, "Close")
    high = _series(frame, "High")
    low = _series(frame, "Low")
    latest = float(close.iloc[-1])
    rsi_value = _last(rsi(close, 14)) or 50.0
    macd_line, macd_signal, macd_hist = macd(close)
    macd_value = _last(macd_line) or 0.0
    atr_series = atr(frame, 14)
    atr_value = _last(atr_series) or 0.0
    atr_median = float(atr_series.dropna().median()) if not atr_series.dropna().empty else atr_value
    stoch_k, stoch_d = stochastic(frame, 9, 6)
    stoch_value = _last(stoch_k) or 50.0
    stochrsi_value = _last(stoch_rsi(close, 14)) or 50.0
    adx_series, plus_di, minus_di = adx(frame, 14)
    adx_value = _last(adx_series) or 20.0
    cci_value = _last(cci(frame, 14)) or 0.0
    highest14 = high.rolling(14, min_periods=14).max().iloc[-1] if len(frame) >= 14 else latest
    lowest14 = low.rolling(14, min_periods=14).min().iloc[-1] if len(frame) >= 14 else latest
    highs_lows = ((latest - float(lowest14)) - (float(highest14) - latest)) / max(float(highest14) - float(lowest14), 1e-9) * 100
    uo_value = _last(ultimate_oscillator(frame)) or 50.0
    roc_period = min(14, max(1, len(close) - 1))
    roc_value = float((latest / float(close.iloc[-1 - roc_period]) - 1) * 100) if len(close) > roc_period else 0.0
    williams_value = float(-100 * (float(highest14) - latest) / max(float(highest14) - float(lowest14), 1e-9))
    ema13_value = _last(ema(close, 13)) or latest
    bull_bear = latest - ema13_value
    context = {"atr_median": atr_median}

    indicator_values = [
        ("RSI(14)", rsi_value),
        ("STOCH(9,6)", stoch_value),
        ("STOCHRSI(14)", stochrsi_value),
        ("MACD(12,26)", macd_value),
        ("ATR(14)", atr_value),
        ("ADX(14)", adx_value),
        ("CCI(14)", cci_value),
        ("Highs/Lows(14)", highs_lows),
        ("UO", uo_value),
        ("ROC", roc_value),
        ("Williams %R", williams_value),
        ("Bull/Bear Power", bull_bear),
    ]
    indicators = [
        {"name": name, "value": round(float(value), 4), "action": action_for(name, float(value), context)}
        for name, value in indicator_values
    ]

    moving_average_periods = [5, 10, 20, 50, 100, 200]
    moving_averages = []
    for period in moving_average_periods:
        sma_value = _last(sma(close, period), 2)
        ema_value = _last(ema(close, period), 2)
        chosen = ema_value if ema_value is not None else sma_value
        moving_averages.append({
            "name": f"MA{period}",
            "simple": sma_value,
            "exponential": ema_value,
            "value": chosen,
            "action": "شراء" if chosen is not None and latest > chosen else "بيع" if chosen is not None else "غير متاح",
        })

    def count_actions(rows: list[dict[str, Any]]) -> dict[str, int]:
        return {
            "buy": sum(row.get("action") == "شراء" for row in rows),
            "sell": sum(row.get("action") == "بيع" for row in rows),
            "neutral": sum(row.get("action") not in {"شراء", "بيع"} for row in rows),
        }

    indicator_summary = count_actions(indicators)
    moving_average_summary = count_actions(moving_averages)
    tool_analysis = advanced_tools(frame)
    ema20_value = _last(ema(close, 20), 2)
    ema50_value = _last(ema(close, 50), 2)
    families = evidence_families(
        latest=latest,
        ema20_value=ema20_value,
        ema50_value=ema50_value,
        rsi_value=rsi_value,
        macd_histogram=_last(macd_hist) or 0.0,
        adx_value=adx_value,
        tools=tool_analysis["tools"],
        structure_confluence=tool_analysis["confluence"],
    )
    technical_signal = "شراء" if families["decision_bias"] == "صاعد" else "بيع" if families["decision_bias"] == "هابط" else "متعادلة"

    return {
        "latest": round(latest, 2),
        "rsi": rsi_value,
        "macd": macd_value,
        "macd_signal": _last(macd_signal) or 0.0,
        "macd_histogram": _last(macd_hist) or 0.0,
        "atr": atr_value,
        "atr_median": round(atr_median, 4),
        "indicators": indicators,
        "moving_averages": moving_averages,
        "indicator_summary": indicator_summary,
        "moving_average_summary": moving_average_summary,
        "technical_signal": technical_signal,
        "evidence_families": families,
        "evidence_strength": families["evidence_strength"],
        "data_contract": dict(frame.attrs.get("data_contract", {})),
        "data_quality": dict(frame.attrs.get("data_quality", {})),
        "pivots": pivots(frame),
        "advanced_tools": tool_analysis,
        "indicator_combinations": indicator_combinations({
            "adx": adx_value, "atr": atr_value, "atr_median": atr_median, "rsi": rsi_value,
            "macd_histogram": _last(macd_hist) or 0.0, "advanced_tools": tool_analysis,
        }),
        "bars": len(frame),
        "last_candle_time": str(frame.index[-1]),
    }


def timeframe_signal(snapshot: dict[str, Any], label: str) -> dict[str, Any]:
    action = "شراء" if snapshot.get("technical_signal") == "شراء" else "بيع" if snapshot.get("technical_signal") == "بيع" else "محايد"
    return {
        "label": label,
        "action": action,
        "evidence_strength": snapshot.get("evidence_strength", {"score": 0, "is_probability": False}),
    }
