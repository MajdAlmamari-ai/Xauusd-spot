from production_server import build_signal_layers


def test_direction_and_zones_are_separate_and_conditional():
    technical = {
        "latest": 2050.0,
        "rsi": 58.0,
        "moving_averages": [
            {"name": "MA20", "exponential": 2040.0},
            {"name": "MA50", "exponential": 2020.0},
        ],
        "indicators": [{"name": "ADX(14)", "value": 29.0}],
        "advanced_tools": {
            "tools": {
                "support_resistance": {
                    "zones": [{"label": "دعم مؤهل", "lower": 2035.0, "upper": 2042.0, "quality_score": 82, "bias": "صاعد"}],
                    "quality": "OHLC + pivots",
                }
            }
        },
    }
    result = build_signal_layers(technical)
    assert result["trend"]["bias"] == "صاعد"
    assert result["zones"]["status"] == "مؤهلة"
    assert result["decision"] == "شراء مشروط"


def test_conflicting_momentum_returns_wait():
    technical = {
        "latest": 2050.0,
        "rsi": 42.0,
        "moving_averages": [
            {"name": "MA20", "exponential": 2040.0},
            {"name": "MA50", "exponential": 2020.0},
        ],
        "indicators": [{"name": "ADX(14)", "value": 29.0}],
        "advanced_tools": {"tools": {"support_resistance": {"zones": [{"label": "دعم", "lower": 2035.0, "upper": 2042.0, "quality_score": 82, "bias": "صاعد"}]}}},
    }
    assert build_signal_layers(technical)["decision"] == "انتظار / حياد"


if __name__ == "__main__":
    test_direction_and_zones_are_separate_and_conditional()
    test_conflicting_momentum_returns_wait()
    print("PASS: signal layers logic")
