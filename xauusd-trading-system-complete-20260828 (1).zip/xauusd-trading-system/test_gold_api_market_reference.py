"""اختبار سعر Gold API العام، بما في ذلك قبول السعر الحديث ورفض المتأخر."""

import json
import os
from datetime import datetime, timedelta, timezone

import mt5_price_connector as connector_module
from mt5_price_connector import MT5PriceConnector


class FakeResponse:
    def __init__(self, payload: dict):
        self.payload = payload

    def read(self) -> bytes:
        return json.dumps(self.payload).encode("utf-8")

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False


def test_payload(updated_at: datetime) -> dict:
    return {"price": 4604.399902, "updatedAt": updated_at.isoformat().replace("+00:00", "Z")}


def main() -> None:
    previous_urlopen = connector_module.urlopen
    os.environ.pop("USE_MARKET_DATA_BRIDGE", None)
    os.environ.pop("MT5_BRIDGE_URL", None)
    try:
        connector_module.urlopen = lambda *_args, **_kwargs: FakeResponse(test_payload(datetime.now(timezone.utc)))
        fresh = MT5PriceConnector().fetch_live_quote()
        assert fresh["source"] == "gold-api.com XAU/USD live market reference"
        assert fresh["live_for_analysis"] is True
        assert fresh["stale"] is False
        assert fresh["tradable"] is False
        assert fresh["last_price"] == 4604.4

        connector_module.urlopen = lambda *_args, **_kwargs: FakeResponse(test_payload(datetime.now(timezone.utc) - timedelta(minutes=3)))
        stale = MT5PriceConnector().fetch_live_quote()
        assert stale["live_for_analysis"] is False
        assert stale["stale"] is True
        assert stale["last_price"] == 4604.4
        print("نجح اختبار Gold API: يقبل السعر الحديث ويرفض السعر المتأخر كسعر حي.")
    finally:
        connector_module.urlopen = previous_urlopen


if __name__ == "__main__":
    main()
