# تحقق تنفيذ مواصفة مصادر بيانات XAU/USD

**التاريخ:** 25 أغسطس 2026  
**النطاق:** طبقة البيانات الحالية للمنصة الشخصية، مع عدم تغيير التصميم أو إضافة تنفيذ أوامر.

## الحكم التنفيذي

تم فصل مسار السعر المرجعي الحي عن مسار الشموع التاريخية في طبقة واضحة اسمها `MarketDataService`. لا يستدعي محرك الرسم أو التحليل `gold-api.com` مباشرةً؛ يستقبلان OHLC من `YahooFinanceHistoricalDataProvider`، بينما تستقبل بطاقة السعر وتدفق SSE السعر العام من `GoldApiLivePriceProvider`.

> **سعر gold-api.com سعر سوق عام مرجعي فقط.** لا يحتوي على Bid/Ask أو سبريد وسيط أو OHLC أو قابلية تنفيذ. لذلك لا يُستخدم لتعديل شمعة تاريخية أو كبديل عنها.

## الملفات التي عُدلت

| الملف | التعديل |
|---|---|
| `market_data.py` | جديد: `LivePriceProvider` و`HistoricalDataProvider` و`GoldApiLivePriceProvider` و`YahooFinanceHistoricalDataProvider` و`MarketDataService`. |
| `production_server.py` | ربط تحميل الشموع عبر `market_data.historical_ohlc` وتحديث السعر عبر `market_data.live_price`. |
| `mt5_price_connector.py` | إضافة اختيار مزود OHLC صريح؛ طبقة Yahoo تستدعيه مع `provider="yahoo"` فلا يتحول مسار الرسم إلى MT5. |
| `test_market_data_layer.py` | جديد: يثبت فصل فشل gold-api عن OHLC التاريخية ويوثق مخزون المصدرين. |

## المصدران الفعليان

| طبقة البيانات | المصدر | الرمز | ما توفره | ما لا توفره |
|---|---|---|---|---|
| LivePriceProvider | `gold-api.com` | `XAU/USD` | Current Price، Source Timestamp، Age، Data Status، SSE داخلي من الحالة المخزنة | OHLC، Bid، Ask، Spread وسيط، تنفيذ |
| HistoricalDataProvider | Yahoo Finance | `GC=F` | OHLCV ووقت الشمعة للرسم والتحليل | XAU/USD Spot execution quote وBid/Ask وسيط |

رمز Yahoo الفعلي هو **`GC=F`**، أي مرجع عقود آجلة للذهب وليس XAU/USD Spot. يظهر في الواجهة كـ«شموع مرجعية»، وتمنع حواجز السياق دمجه مع السعر الفوري العام في دخول أو وقف أو هدف واحد.

## الأطر التي نجح تحميلها فعلياً

هذه الأعداد جاءت من استدعاء `/api/chart/<timeframe>` مباشرةً بعد إعادة تشغيل الخدمة، وليست أرقاماً ثابتة في التقرير.

| الإطار | النوع | أسلوب التكوين | عدد الشموع المحملة |
|---|---|---|---:|
| M1 | Native | Yahoo Finance 1m | 1,560 |
| M5 | Native | Yahoo Finance 5m | 1,560 |
| M10 | Resampled | سلال 5m مكتملة فقط إلى 10m | 1,492 |
| M15 | Native | Yahoo Finance 15m | 1,560 |
| M30 | Native | Yahoo Finance 30m | 1,560 |
| H1 | Native | Yahoo Finance 1h | 1,260 |
| H2 | Resampled | سلال 1h مكتملة فقط إلى 2h | 1,260 |
| H4 | Resampled | سلال 1h مكتملة فقط إلى 4h | 1,260 |
| D1 | Native | Yahoo Finance 1d | 1,260 |
| W1 | Native | Yahoo Finance 1wk | 1,260 |
| MN1 | Native | Yahoo Finance 1mo | 733 |

لا ينشئ التجميع أي شمعة من السعر الحي، ويرفض السلة الناقصة. إذا فشل Yahoo أو لم يرجع OHLC سليمة، يعود المسار بحالة خطأ/عدم توفر بدلاً من Mock أو Random أو شموع مصطنعة.

## تطابق الرسم والتحليل

`get_timeframe_candles` في الخادم يحصل على OHLC من `MarketDataService.historical_ohlc`. تُمرر نفس DataFrame لاحقاً إلى الرسم، المؤشرات، الطبقات، الاستراتيجيات، والتحليل. وبذلك لا توجد نسخة ثانية من OHLC للرسم أو تحليل يجلب سعراً من gold-api ويحوّله إلى شمعة.

فحص مسارات الإنتاج (`production_server.py` و`market_data.py` و`mt5_price_connector.py`) لم يجد `mock` أو `random` أو `synthetic` أو `fixed_price` في مسار السعر والشموع والرسم.

## نتائج الاختبارات الفعلية

| الاختبار | النتيجة | ما يثبته |
|---|---|---|
| `test_market_data_layer.py` | PASS | فصل فشل gold-api عن OHLC Yahoo، وتثبيت مخزون المصدرين. |
| `test_goldapi_quote_stream.py` | PASS | تدفق SSE للسعر المرجعي وحظر كاش API/السعر في Service Worker. |
| `test_timeframe_api.py` | PASS | استجابة أطر 1m و10m و2h و1d و1wk ورفض الإطار غير المدعوم. |
| `test_audit_data_contracts.py` | PASS | رفض Spot/Futures المختلط، التجميع الناقص، وتسريب المستقبل. |
| `test_backtest_integrity.py` | PASS | عدم التسريب والتنفيذ عند الافتتاح التالي والتكاليف. |

## فشل المصدر المتوقع

| الفشل | السلوك الفعلي |
|---|---|
| فشل `gold-api.com` | تعود `status=error` و`stale=true` و`live_for_analysis=false`؛ لا يُستبدل السعر بآخر إغلاق Yahoo ولا بسعر وهمي. |
| فشل Yahoo Finance | يعود مسار الرسم/الإطار بخطأ أو `TIMEFRAME DATA UNAVAILABLE`؛ لا تُركب شموع ولا تستبدل بسعر gold-api. |

## قيود متبقية

1. يحقق المشروع الفصل المطلوب بين مزودي السعر والشموع، لكنه لا يحقق «مصدر OHLC Spot واحد لـXAU/USD» لأن `gold-api.com` لا يوفر OHLC. Yahoo `GC=F` يبقى مرجعاً آجلاً منفصلاً.
2. لا يستعمل المسار الحالي MT5 أو VPS؛ يظل ما في المشروع من جسر اختياري غير مفعّل لأن `USE_MARKET_DATA_BRIDGE` غير مفعّل ومسار `MarketDataService` يجبر Yahoo للشموع.
3. لا يجوز اعتبار `gold-api.com` سعراً تنفيذياً أو استخدامه كـBid/Ask، حتى لو كان حديثاً.
4. تغير أعداد الشموع مع نافذة Yahoo وحدود الاحتفاظ والتداول؛ لذلك تُقاس عند كل تشغيل ولا تثبت كرقم دائم.
