# ملاحظات المصدر الرسمية

**تاريخ الفحص:** 28 أغسطس 2026.

- صفحة HistData الرسمية للمواصفات التفصيلية تعرّف Generic ASCII في M1 بترتيب: DateTime Stamp؛ Bar OPEN Bid Quote؛ Bar HIGH Bid Quote؛ Bar LOW Bid Quote؛ Bar CLOSE Bid Quote؛ Volume.
- صفحة المواصفات نفسها، وصفحة الأسئلة الشائعة، تحددان المنطقة الزمنية لكل البيانات بأنها Eastern Standard Time (EST) من دون تطبيق التوقيت الصيفي.
- هذا يثبت أن طوابع ملفات CSV ليست UTC كما افترض برنامج التدقيق الأولي؛ يجب تحويلها إلى UTC بمقدار ثابت قدره +5 ساعات عند تطبيعها، مع إبقاء الوقت الأصلي محفوظاً.
- الملاحظات الرسمية تحدد صيغة M1 وترتيب الأعمدة، لكنها لا تثبت أن السعر يطابق سعر وسيط المستخدم أو أن XAUUSD Spot قابل للمطابقة مع Gold API؛ لذلك يبقى المصدر سلسلة تاريخية مستقلة بوسم HistData ولا يخلط مع السعر المرجعي الحي.

المراجع الرسمية:
- https://www.histdata.com/f-a-q/data-files-detailed-specification/
- https://www.histdata.com/f-a-q/
