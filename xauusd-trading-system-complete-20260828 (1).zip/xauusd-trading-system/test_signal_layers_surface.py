"""حواجز طبقات المناطق والاتجاه الأقل تشويشاً."""
from pathlib import Path

ROOT = Path(__file__).parent
SERVER = (ROOT / "production_server.py").read_text(encoding="utf-8")


def test_signal_layers_backend_contract():
    assert "def build_signal_layers" in SERVER
    assert '"zones"' in SERVER and '"trend"' in SERVER
    assert '"decision_reason"' in SERVER
    assert "EMA20/EMA50 + ADX + RSI من OHLC" in SERVER
    assert "ليست دليلاً على أوامر مؤسسات حقيقية" in SERVER
    assert "انتظار / حياد" in SERVER


def test_signal_layers_ui_contract():
    assert 'id="signalLayers"' in SERVER
    assert "خريطة المناطق السعرية" in SERVER
    assert "اتجاه السعر" in SERVER
    assert "renderSignalLayers" in SERVER
    assert "اضغط على أي منطقة لفتح رسمها" in SERVER
    assert "signalLayerGrid" in SERVER


if __name__ == "__main__":
    test_signal_layers_backend_contract()
    test_signal_layers_ui_contract()
    print("PASS: signal layers surface")
