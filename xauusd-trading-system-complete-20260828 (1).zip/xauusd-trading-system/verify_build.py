from technical_indicators import calculate_snapshot
from mt5_price_connector import MT5PriceConnector

connector = MT5PriceConnector()
quote = connector.fetch_live_quote()
print("imports_ok")
print({"status": quote.get("status"), "source": quote.get("source"), "tradable": quote.get("tradable")})
if quote.get("status") == "success":
    frame = connector.fetch_ohlc(period="2y", interval="1d")
    snapshot = calculate_snapshot(frame)
    required = {"pivots", "moving_averages", "indicators", "technical_signal"}
    missing = sorted(required.difference(snapshot))
    if missing:
        raise RuntimeError(f"missing keys: {missing}")
    print({"bars": snapshot["bars"], "moving_averages": len(snapshot["moving_averages"]), "indicators": len(snapshot["indicators"])})
