#!/usr/bin/env python3
from __future__ import annotations
import json
from collections import defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
for path in sorted(BASE.glob("*/DAT_ASCII_XAUUSD_M1_*.csv"), key=lambda p: p.stem):
    grouped = defaultdict(list)
    prev = None
    nonmonotonic = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        parts = line.split(";")
        if len(parts) != 6:
            continue
        key = parts[0]
        row = tuple(parts[1:])
        grouped[key].append((line_no, row))
        if prev is not None and key <= prev[0]:
            nonmonotonic.append({"line": line_no, "previous": prev[0], "current": key})
        prev = (key, row)
    duplicate_groups = {k: v for k, v in grouped.items() if len(v) > 1}
    conflicting = {k: v for k, v in duplicate_groups.items() if len({row for _, row in v}) > 1}
    print(json.dumps({
        "file": str(path),
        "duplicate_groups": len(duplicate_groups),
        "duplicate_extra_rows": sum(len(v) - 1 for v in duplicate_groups.values()),
        "conflicting_duplicate_groups": len(conflicting),
        "conflicting_examples": list(conflicting.items())[:5],
        "duplicate_examples": list(duplicate_groups.items())[:3],
        "file_order_nonmonotonic_examples": nonmonotonic[:5],
    }, ensure_ascii=False))
