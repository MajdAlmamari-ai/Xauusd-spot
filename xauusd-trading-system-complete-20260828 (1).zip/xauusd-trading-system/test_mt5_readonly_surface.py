"""فحص ثابت: لا يحتوي الجسر على قدرات تداول أو مسارات كتابة."""

from pathlib import Path


BRIDGE = Path(__file__).with_name("mt5_reference_bridge.py")
SOURCE = BRIDGE.read_text(encoding="utf-8")


def main() -> None:
    forbidden = (
        "order_send", "order_check", "positions_get", "orders_get", "history_deals_get",
        "account_info", "login(", "shutdown(",
    )
    found = [token for token in forbidden if token in SOURCE]
    assert not found, f"وجدت قدرة غير مسموح بها في جسر القراءة فقط: {found}"
    for endpoint in ('"/health"', '"/quote"', '"/ohlc"', '"/order-flow"'):
        assert endpoint in SOURCE, f"المسار المطلوب مفقود: {endpoint}"
    for method in ("def do_POST", "def do_PUT", "def do_DELETE"):
        assert method in SOURCE, f"حارس طريقة HTTP مفقود: {method}"
    assert "MT5_BRIDGE_TOKEN" in SOURCE
    assert "HOST not in" in SOURCE
    assert '"10m": mt5.TIMEFRAME_M10' in SOURCE
    assert '"2h": mt5.TIMEFRAME_H2' in SOURCE
    assert '"4h": mt5.TIMEFRAME_H4' in SOURCE
    assert "market_book_get" in SOURCE and "copy_ticks_from" in SOURCE
    print("نجح فحص جسر MT5: سعر/شموع/تدفق قراءة فقط، مع حظر مسارات الكتابة وقدرات التداول.")


if __name__ == "__main__":
    main()
