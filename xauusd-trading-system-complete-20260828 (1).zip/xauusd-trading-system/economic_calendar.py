#!/usr/bin/env python3
"""
وحدة التقويم الاقتصادي والأخبار الحية المؤثرة على الذهب والدولار
"""

from datetime import datetime

class EconomicCalendar:
    def __init__(self):
        # قائمة بالأحداث الاقتصادية القياسية المؤثرة على الذهب (مثال حي محاكى للواقع)
        self.events = [
            {
                "time": "15:30",
                "currency": "USD",
                "event": "معدل البطالة وبيانات الوظائف (NFP)",
                "impact": "High",
                "previous": "4.0%",
                "forecast": "3.9%",
                "actual": "3.9%",
                "gold_impact_bias": "Bullish if weaker than expected"
            },
            {
                "time": "17:00",
                "currency": "USD",
                "event": "مؤشر أسعار المستهلكين (CPI - التضخم)",
                "impact": "High",
                "previous": "3.4%",
                "forecast": "3.3%",
                "actual": "3.3%",
                "gold_impact_bias": "Bullish on inflation hedge"
            },
            {
                "time": "21:00",
                "currency": "USD",
                "event": "قرار الفائدة الصادر عن الفيدرالي الأمريكي (FOMC)",
                "impact": "High",
                "previous": "5.50%",
                "forecast": "5.50%",
                "actual": "5.50%",
                "gold_impact_bias": "Neutral to Bullish"
            }
        ]

    def get_upcoming_events(self):
        """استرجاع الأحداث الاقتصادية مع حالة التأثير الحالية"""
        return {
            "status": "active",
            "last_checked": datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC'),
            "high_impact_warning": True,
            "message": "يوجد أخبار عالية التأثير اليوم؛ يوصى بتوخي الحذر وتجنب فتح صفقات جديدة قبل صدور البيانات بـ 15 دقيقة.",
            "events": self.events
        }

if __name__ == "__main__":
    cal = EconomicCalendar()
    print(cal.get_upcoming_events())
