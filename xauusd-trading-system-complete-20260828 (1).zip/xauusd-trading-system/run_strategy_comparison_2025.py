"""مقارنة استراتيجيات XAUUSD قابلة للتفسير على بيانات 2025.

الاستراتيجيات محددة مسبقاً: OB+FVG الحالي، EMA20/50 pullback، Donchian(20)
breakout، وRSI(14)+Bollinger(20,2) mean reversion. لا تنفيذ أو تداول حي.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from ob_fvg_strategy import backtest_ob_fvg_strategy

SOURCE = Path("/tmp/XAU_15m_data.csv")
OUT_JSON = Path("/home/ubuntu/xauusd-trading-system/strategy_comparison_2025_results.json")
OUT_MD = Path("/home/ubuntu/xauusd-trading-system/strategy_comparison_2025_report.md")
START = pd.Timestamp("2025-01-01", tz="UTC")
END = pd.Timestamp("2026-01-01", tz="UTC")
HORIZON = 12
ATR_PERIOD = 14


def load_base() -> pd.DataFrame:
    raw = pd.read_csv(SOURCE, sep=";")
    idx = pd.to_datetime(raw.pop("Date"), format="%Y.%m.%d %H:%M", errors="coerce").dt.tz_localize("UTC")
    raw.columns = [c.title() for c in raw.columns]
    raw = raw.apply(pd.to_numeric, errors="coerce")
    raw.index = idx
    raw = raw.dropna(subset=["Open", "High", "Low", "Close"]).sort_index()
    return raw.loc[(raw.index >= START) & (raw.index < END)]


def resample(frame: pd.DataFrame, rule: str) -> pd.DataFrame:
    return frame.resample(rule, label="left", closed="left").agg({"Open":"first", "High":"max", "Low":"min", "Close":"last", "Volume":"sum"}).dropna()


def indicators(frame: pd.DataFrame) -> pd.DataFrame:
    out = frame.copy()
    prev_close = out["Close"].shift(1)
    tr = pd.concat([out["High"] - out["Low"], (out["High"] - prev_close).abs(), (out["Low"] - prev_close).abs()], axis=1).max(axis=1)
    out["ATR"] = tr.rolling(ATR_PERIOD, min_periods=ATR_PERIOD).mean()
    out["EMA20"] = out["Close"].ewm(span=20, adjust=False, min_periods=20).mean()
    out["EMA50"] = out["Close"].ewm(span=50, adjust=False, min_periods=50).mean()
    delta = out["Close"].diff()
    gain, loss = delta.clip(lower=0), -delta.clip(upper=0)
    avg_gain = gain.rolling(14, min_periods=14).mean()
    avg_loss = loss.rolling(14, min_periods=14).mean().replace(0, np.nan)
    out["RSI"] = 100 - (100 / (1 + avg_gain / avg_loss))
    mid = out["Close"].rolling(20, min_periods=20).mean()
    sd = out["Close"].rolling(20, min_periods=20).std(ddof=0)
    out["BB_UPPER"], out["BB_LOWER"] = mid + 2 * sd, mid - 2 * sd
    out["DONCHIAN_HIGH"] = out["High"].shift(1).rolling(20, min_periods=20).max()
    out["DONCHIAN_LOW"] = out["Low"].shift(1).rolling(20, min_periods=20).min()
    return out


def signal_frame(frame: pd.DataFrame, strategy: str) -> pd.Series:
    p, c = frame.shift(1), frame
    if strategy == "ema_pullback":
        return pd.Series(np.where((c.EMA20 > c.EMA50) & (c.Close <= c.EMA20) & (c.Close > c.EMA50), 1, np.where((c.EMA20 < c.EMA50) & (c.Close >= c.EMA20) & (c.Close < c.EMA50), -1, 0)), index=frame.index)
    if strategy == "donchian_breakout":
        return pd.Series(np.where(c.Close > c.DONCHIAN_HIGH, 1, np.where(c.Close < c.DONCHIAN_LOW, -1, 0)), index=frame.index)
    if strategy == "rsi_bollinger":
        return pd.Series(np.where((c.RSI < 30) & (c.Close < c.BB_LOWER), 1, np.where((c.RSI > 70) & (c.Close > c.BB_UPPER), -1, 0)), index=frame.index)
    raise ValueError(strategy)


def simulate(frame: pd.DataFrame, signals: pd.Series, stop_atr: float, target_r: float, start_at: pd.Timestamp | None = None, end_at: pd.Timestamp | None = None) -> dict:
    outcomes, trades = [], []
    i, n = 60, len(frame)
    if start_at is not None:
        i = max(i, int(frame.index.searchsorted(start_at)))
    end_limit = n - 1 if end_at is None else min(n - 1, int(frame.index.searchsorted(end_at, side="left")))
    while i < end_limit - 1:
        side = int(signals.iloc[i])
        atr = float(frame.ATR.iloc[i]) if pd.notna(frame.ATR.iloc[i]) else 0
        if side == 0 or atr <= 0:
            i += 1
            continue
        entry_i = i + 1
        entry = float(frame.Open.iloc[entry_i])
        risk = stop_atr * atr
        stop = entry - risk if side == 1 else entry + risk
        target = entry + target_r * risk if side == 1 else entry - target_r * risk
        end_i = min(n - 1, entry_i + HORIZON - 1)
        exit_i, exit_price, outcome = end_i, float(frame.Close.iloc[end_i]), "انتهت المدة"
        for j in range(entry_i, end_i + 1):
            high, low = float(frame.High.iloc[j]), float(frame.Low.iloc[j])
            hit_stop = low <= stop if side == 1 else high >= stop
            hit_target = high >= target if side == 1 else low <= target
            if hit_stop and hit_target:
                exit_i, exit_price, outcome = j, stop, "غموض داخل الشمعة — وقف محافظ"
                break
            if hit_stop:
                exit_i, exit_price, outcome = j, stop, "وقف"
                break
            if hit_target:
                exit_i, exit_price, outcome = j, target, "هدف"
                break
        r = ((exit_price - entry) / risk) if side == 1 else ((entry - exit_price) / risk)
        outcomes.append(r)
        trades.append({"decision_time": str(frame.index[i]), "entry_time": str(frame.index[entry_i]), "exit_time": str(frame.index[exit_i]), "direction": "شراء" if side == 1 else "بيع", "outcome": outcome, "r_multiple": round(r, 4)})
        i = exit_i + 1
    wins = [x for x in outcomes if x > 0]
    losses = [x for x in outcomes if x < 0]
    curve = np.cumsum(outcomes) if outcomes else np.array([])
    drawdown = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0.0
    gp, gl = sum(wins), abs(sum(losses))
    return {"signals": int((signals != 0).sum()), "filled_trades": len(outcomes), "wins": len(wins), "losses": len(losses), "win_rate_pct": round(100 * len(wins) / len(outcomes), 1) if outcomes else None, "gross_profit_r": round(gp, 2), "gross_loss_r": round(gl, 2), "total_r": round(sum(outcomes), 2), "average_r": round(sum(outcomes) / len(outcomes), 2) if outcomes else None, "profit_factor": round(gp / gl, 2) if gl else None, "max_drawdown_r": round(drawdown, 2), "sample_adequate": len(outcomes) >= 20, "trades": trades}


def main() -> None:
    base = load_base()
    results = {}
    for timeframe, rule in (("1h", "1h"), ("4h", "4h")):
        frame = indicators(resample(base, rule))
        for name, stop_atr, target_r in (("ema_pullback", 1.5, 2.0), ("donchian_breakout", 2.0, 2.0), ("rsi_bollinger", 1.5, 1.5)):
            full_metrics = simulate(frame, signal_frame(frame, name), stop_atr, target_r)
            oos_metrics = simulate(frame, signal_frame(frame, name), stop_atr, target_r, pd.Timestamp("2025-07-01", tz="UTC"), END)
            full_metrics["cost_sensitivity_r"] = {"0.05_per_trade": round(full_metrics["total_r"] - 0.05 * full_metrics["filled_trades"], 2), "0.10_per_trade": round(full_metrics["total_r"] - 0.10 * full_metrics["filled_trades"], 2)}
            results[f"{timeframe}:{name}"] = {"timeframe": timeframe, "strategy": name, "rules": {"stop_atr": stop_atr, "target_r": target_r, "horizon_bars": HORIZON}, "metrics": full_metrics, "oos_h2_2025": oos_metrics}
        ob = backtest_ob_fvg_strategy(frame, warmup_bars=180, horizon_bars=HORIZON, censor_gap_bars=1, evaluation_stride=1, max_evaluation_points=500, signal_lookback_bars=600, trade_output_limit=None)
        ob_metrics = ob["metrics"]
        if ob_metrics.get("total_r") is not None:
            ob_metrics["cost_sensitivity_r"] = {"0.05_per_trade": round(ob_metrics["total_r"] - 0.05 * ob_metrics["filled_trades"], 2), "0.10_per_trade": round(ob_metrics["total_r"] - 0.10 * ob_metrics["filled_trades"], 2)}
        results[f"{timeframe}:ob_fvg"] = {"timeframe": timeframe, "strategy": "ob_fvg", "rules": {"source_engine": "ob_fvg_strategy.py"}, "metrics": ob_metrics, "oos_h2_2025": None, "note": "يتطلب محرك OB+FVG دعماً صريحاً لبدء OOS؛ لذلك لا يُعرض كاختبار خارج العينة هنا.", "trades": ob["trades"]}
    payload = {"data_contract": {"source": "Kaggle XAU/USD Gold Price Historical Data, version 11", "timeframe_basis": "15m source resampled to 1h and 4h; same source and 2025 window", "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive", "costs": "zero-cost headline plus abstract sensitivity of 0.05R and 0.10R per trade", "reference_only": True}, "results": results}
    OUT_JSON.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    rows = []
    for key, value in results.items():
        m, oos = value["metrics"], value.get("oos_h2_2025") or {}
        om = oos.get("metrics", oos)
        rows.append(f"| {key} | {m.get('filled_trades')} | {m.get('wins')} | {m.get('losses')} | {m.get('win_rate_pct')}% | {m.get('total_r')} | {m.get('profit_factor')} | {m.get('max_drawdown_r', '—')} | {om.get('filled_trades', '—')} | {om.get('total_r', '—')} | {'نعم' if m.get('sample_adequate') else 'لا'} |")
    table = "\n".join(rows)
    OUT_MD.write_text(f"""# مقارنة استراتيجيات XAUUSD — بيانات 2025\n\nقارنت الدراسة أربع قواعد محددة مسبقاً على إطارَي الساعة و4 ساعات: OB+FVG الحالي، سحب الاتجاه EMA20/EMA50، اختراق Donchian(20)، وارتداد RSI(14)+Bollinger(20,2). الدخول في الاستراتيجيات الثلاث الجديدة يكون عند افتتاح الشمعة التالية للإشارة، والوقف والهدف يحددان من ATR المتاح لحظة الإشارة. لمس الوقف والهدف معاً يُحسب وقفاً تحفظياً.\n\n| الاستراتيجية | صفقات 2025 | رابحة | خاسرة | النجاح | الصافي 2025 (R) | معامل الربح | أقصى سحب (R) | صفقات H2 خارج العينة | صافي H2 (R) | عينة >=20؟ |\n| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |\n{table}\n\n## الحساسية للتكاليف\n\nإذا طُرحت تكلفة مجردة قدرها 0.05R أو 0.10R من كل صفقة مملوءة، فإن الصافي المعدل يساوي الصافي الأساسي ناقص عدد الصفقات مضروباً في التكلفة. هذه ليست تكلفة وسيط فعلية؛ يلزم Bid/Ask وعمولة وانزلاق من مصدر تنفيذ موثق لإدخال تكاليف حقيقية. أُضيف النصف الثاني من 2025 كاختبار خارج العينة للاستراتيجيات الجديدة ذات القواعد الثابتة؛ أما OB+FVG فتبقى نتيجته معروضة على نطاق السنة فقط لأن محركه الحالي لا يملك نقطة بدء OOS مستقلة.\n\n## القيود\n\nالمصدر شموع مرجعية عامة من Kaggle، وطُبّعت الفترة إلى UTC لأن المنطقة الزمنية الأصلية غير موثقة. لا يثبت الاختبار قابلية التنفيذ مع وسيط معين، ولا يثبت تدفق أوامر أو أخباراً تاريخية. عدد الصفقات الأقل من 20 لا يُفسر كأداء مثبت، و2025 وحدها لا تكفي لاختيار استراتيجية نهائية خارج العينة. النتائج بوحدة R وليست دولاراً أو وعداً بالربح، ولا تمثل نصيحة مالية شخصية.\n\n[1]: https://www.kaggle.com/datasets/novandraanugrah/xauusd-gold-price-historical-data-2004-2024 "Kaggle — XAU/USD Gold Price Historical Data"\n""", encoding="utf-8")
    print(f"JSON={OUT_JSON}")
    print(f"REPORT={OUT_MD}")
    for key, value in results.items():
        m = value["metrics"]
        print(key, m.get("filled_trades"), m.get("wins"), m.get("losses"), m.get("total_r"), m.get("profit_factor"))


if __name__ == "__main__":
    main()
