"""تشغيل اختبار OB+FVG على شموع مرجعية من سنة 2025 فقط.

التقرير تعليمي وتحليلي فقط. لا يستخدم سعراً تنفيذياً أو سبريداً أو انزلاقاً أو عمولات.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from mt5_price_connector import MT5PriceConnector
from ob_fvg_strategy import backtest_ob_fvg_strategy


YEAR_START = pd.Timestamp("2025-01-01", tz="UTC")
YEAR_END = pd.Timestamp("2026-01-01", tz="UTC")
OUTPUT_JSON = Path(__file__).with_name("ob_fvg_2025_backtest_results.json")
OUTPUT_MD = Path(__file__).with_name("ob_fvg_2025_backtest_report.md")


def utc_index(frame: pd.DataFrame) -> pd.DataFrame:
    clean = frame.copy()
    if clean.index.tz is None:
        clean.index = clean.index.tz_localize("UTC")
    else:
        clean.index = clean.index.tz_convert("UTC")
    return clean.sort_index()


def run_timeframe(connector: MT5PriceConnector, interval: str) -> dict:
    source_frame = utc_index(connector.fetch_ohlc_between(YEAR_START, YEAR_END, interval=interval))
    frame = source_frame.loc[(source_frame.index >= YEAR_START) & (source_frame.index < YEAR_END)].copy()
    if frame.empty or frame.index.min() > YEAR_START + pd.Timedelta(days=7) or frame.index.max() < YEAR_END - pd.Timedelta(days=7):
        raise RuntimeError(
            f"لا يغطي مصدر الشموع المرجعية كامل سنة 2025 للإطار {interval}. "
            f"النطاق المستلم: {source_frame.index.min()} إلى {source_frame.index.max()}."
        )

    # يحد الاختبار إلى 500 نقطة قرار موزعة على كامل السنة لتبقى عملية المراجعة متزامنة،
    # ولا يمنح أي شموع مستقبلية لإشارة القرار.
    result = backtest_ob_fvg_strategy(
        frame,
        warmup_bars=180,
        horizon_bars=12,
        censor_gap_bars=1,
        evaluation_stride=1,
        max_evaluation_points=500,
        signal_lookback_bars=600,
        trade_output_limit=None,
    )
    result["data_contract"] = {
        "source": "Yahoo Finance GC=F reference candles",
        "source_symbol": "GC=F",
        "reference_only": True,
        "period": "2025-01-01 inclusive إلى 2026-01-01 exclusive",
        "timeframe": interval,
        "bars": len(frame),
        "first_candle": str(frame.index.min()),
        "last_candle": str(frame.index.max()),
        "excluded_costs": "لا يشمل السبريد أو الانزلاق أو العمولات أو فروق تسعير الوسيط.",
    }
    return result


def metric(value: object, suffix: str = "") -> str:
    return "—" if value is None else f"{value}{suffix}"


def build_report(results: dict[str, dict]) -> str:
    lines = [
        "# اختبار تاريخي لاستراتيجية Order Block + Fair Value Gap — سنة 2025",
        "",
        "## النطاق والمنهجية",
        "",
        "اختُبرت شموع Yahoo Finance المرجعية للرمز GC=F ضمن سنة 2025 فقط، بعد فصل صارم بين الشموع المرجعية وأي سعر قابل للتنفيذ. استخدم الاختبار مشياً للأمام: الإشارة تُحسب من الشموع المتاحة حتى نقطة القرار فقط، ثم يبدأ التقييم بعد فجوة رقابة شمعة واحدة. يلامس وقف الخسارة والهدف في الشمعة نفسها يُسجل كوقف محافظ. لا تشمل النتائج السبريد أو الانزلاق أو العمولات أو أحجام العقود؛ لذا تعبر الأرباح والخسائر عن مضاعفات المخاطرة R، لا عن دولار أو ربح قابل للتنفيذ.",
        "",
        "| الإطار | الشموع | نقاط القرار | إعدادات مؤهلة | صفقات مملوءة | رابحة | خاسرة | نسبة النجاح | إجمالي الربح (R) | إجمالي الخسارة (R) | الصافي (R) | متوسط R | معامل الربح | كفاية العينة |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |",
    ]
    for interval, result in results.items():
        metrics = result["metrics"]
        contract = result["data_contract"]
        lines.append(
            "| {label} | {bars} | {decision_points} | {eligible_setups} | {filled_trades} | {wins} | {losses} | {win_rate} | {gross_profit} | {gross_loss} | {total_r} | {average_r} | {profit_factor} | {adequacy} |".format(
                label="ساعة" if interval == "1h" else "4 ساعات",
                bars=contract["bars"],
                decision_points=metrics.get("decision_points"),
                eligible_setups=metrics.get("eligible_setups"),
                filled_trades=metrics.get("filled_trades"),
                wins=metrics.get("wins"),
                losses=metrics.get("losses"),
                win_rate=metric(metrics.get("win_rate_pct"), "%"),
                gross_profit=metric(metrics.get("gross_profit_r")),
                gross_loss=metric(metrics.get("gross_loss_r")),
                total_r=metric(metrics.get("total_r")),
                average_r=metric(metrics.get("average_r")),
                profit_factor=metric(metrics.get("profit_factor")),
                adequacy="نعم" if metrics.get("sample_adequate") else "لا — أقل من 20 صفقة",
            )
        )
    lines.extend([
        "",
        "## قيود القراءة",
        "",
        "تطبيق الإعداد لا يساوي أمراً أو توصية تنفيذية. يعتمد على مناطق مستنتجة من OHLC وATR وpivots وحجم الشموع عند توفره، ولا يثبت وجود Order Flow أو أوامر مؤسسات. نقاط القرار موزعة عبر السنة مع حد أقصى 500 نقطة لكل إطار لتقييد كلفة الحساب؛ وهذا اختبار عينة زمنية، وليس دراسة تنفيذية كاملة. يتطلب أي تقييم قابل للتداول لاحقاً تغذية سعر وسيط موثقة وتكاليف تنفيذ فعلية.",
        "",
        "## مخرجات الملفات",
        "",
        "يتضمن ملف JSON جميع الصفقات المملوءة ومخرجات كل إطار، بينما يلخص هذا الملف المقاييس النهائية فقط.",
        "",
        "## المصدر والإفصاح",
        "",
        "استُخدمت شموع GC=F المرجعية من Yahoo Finance عبر طلب تاريخي زمني صريح.[1] مقياس R يعني ربحاً أو خسارة بوحدة المخاطرة المحددة لكل إعداد، وليس مبلغاً بالدولار أو نتيجة لحساب تداول حقيقي. هذه نتائج بحث وتحليل فقط وليست نصيحة مالية شخصية.",
        "",
        "[1]: https://finance.yahoo.com/quote/GC%3DF/history/ \"Yahoo Finance — GC=F historical data\"",
    ])
    return "\n".join(lines) + "\n"


def main() -> None:
    connector = MT5PriceConnector()
    results = {interval: run_timeframe(connector, interval) for interval in ("1h", "4h")}
    OUTPUT_JSON.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
    OUTPUT_MD.write_text(build_report(results), encoding="utf-8")
    for interval, result in results.items():
        metrics = result["metrics"]
        print(
            f"{interval}: filled={metrics.get('filled_trades')} wins={metrics.get('wins')} "
            f"losses={metrics.get('losses')} win_rate={metrics.get('win_rate_pct')} total_r={metrics.get('total_r')}"
        )
    print(f"JSON={OUTPUT_JSON}")
    print(f"REPORT={OUTPUT_MD}")


if __name__ == "__main__":
    main()
