from pathlib import Path


SOURCE = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")


def main() -> None:
    required = [
        'id="dataTransparency"',
        "renderDataTransparency",
        "renderDataTransparency",
        "renderEvidenceFamilies(latestSystem?.recommendation)",
        '"data_transparency": build_data_transparency(quote, analysis.get("technical"))',
        "window.renderDataTransparency?.(payload.data_transparency)",
        "window.renderDataTransparency=renderDataTransparency",
        "const hydrateTransparency",
        "window.setInterval(hydrateTransparency,6000)",
        "box.dataset.ready=quote.source&&candles.source?'1':'0'",
        "panel.dataset.ready==='1'",
        "panel.dataset.hydration='error'",
        "window.addEventListener('load',hydrateTransparency,{once:true})",
        "const hasTransparencySource=data=>Boolean(data?.quote?.source&&data?.candles?.source)",
        "if(hasTransparencySource(latestSystem?.data_transparency))renderDataTransparency",
        "payload.data_transparency",
        "سياق المصدر وحاجز القرار",
        "محجوب عن مستويات السعر",
        "لا تحول فرق المرجعين إلى شراء أو بيع",
        'id="evidenceFamilies"',
        "renderEvidenceFamilies",
        "لماذا هذه النتيجة؟",
        "لتفادي عدّ مؤشرات السعر المترابطة",
        "direction==='شراء'?'cellBuy':direction==='بيع'?'cellSell':'cellNeutral'",
        "منطقة بيع تاريخية للمراقبة",
        "حدود المنطقة من",
        "zoneHistoryNote",
    ]
    for fragment in required:
        assert fragment in SOURCE, fragment
    print("PASS: data transparency panel is connected to the existing system state")


if __name__ == "__main__":
    main()
