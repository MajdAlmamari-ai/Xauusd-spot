import json
from pathlib import Path


def main() -> None:
    policy = json.loads(Path(__file__).with_name("strategy_candidate_policy_2025.json").read_text(encoding="utf-8"))
    assert policy["live_decision_integration"] is False
    assert all(item["decision_weight"] == 0 for item in policy["watchlist_candidates"])
    assert {item["id"] for item in policy["watchlist_candidates"]} == {"rsi_bollinger_1h", "keltner_breakout_4h"}
    assert any(item["id"] == "donchian_adx_1h" for item in policy["rejected_for_now"])
    print("PASS: strategy policy keeps research candidates outside the live decision engine")


if __name__ == "__main__":
    main()
