from __future__ import annotations

from production_server import make_recommendation


def quote() -> dict:
    return {"status": "success", "stale": False, "live_for_analysis": True, "tradable": False, "instrument": "XAUUSD", "price_basis": "broker_spot"}


def technical() -> dict:
    return {
        "technical_signal": "شراء",
        "evidence_strength": {"score": 72.0, "label": "قوة أدلة متوسطة", "is_probability": False},
        "latest": 4700.80,
        "atr": 2.07,
        "data_contract": {"instrument": "XAUUSD", "price_basis": "broker_spot"},
        "data_quality": {"valid": True},
        "advanced_tools": {
            "confluence": {"bias": "توافق محدود / مختلط", "qualified_tools": 4},
            "multi_timeframe": {"status": "غير حاسم"},
            "tools": {"support_resistance": {"qualified": True, "levels": {"دعم 1": 4699.57, "مقاومة 1": 4701.00}}},
        },
    }


def main() -> None:
    liquidity = {"trap_detected": False, "liquidity_score": None}
    news = {"pending_event": False, "status": "calendar_ready_no_live_release_feed"}
    result = make_recommendation(quote(), technical(), liquidity, news)
    assert result["decision_state"] == "neutral"
    assert result["risk_reward"] is None
    assert result["entry"] is None and result["stop_loss"] is None and result["take_profit"] is None
    assert "عائداً/مخاطرة" in result["reason"]
    print("PASS: low risk-reward conditional recommendation is converted to neutral")


if __name__ == "__main__":
    main()
