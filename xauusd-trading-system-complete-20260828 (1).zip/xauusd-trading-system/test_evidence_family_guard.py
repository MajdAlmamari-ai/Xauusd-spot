"""يثبت أن قرار المؤشرات يمر عبر عائلات أدلة لا مجموع إشارات مترابطة."""

from __future__ import annotations

import pandas as pd

from technical_indicators import calculate_snapshot


def frame() -> pd.DataFrame:
    index = pd.date_range("2025-02-03", periods=280, freq="1h", tz="UTC")
    close = [2500.0 + step * 0.3 for step in range(len(index))]
    return pd.DataFrame({
        "Open": [value - 0.15 for value in close],
        "High": [value + 0.4 for value in close],
        "Low": [value - 0.5 for value in close],
        "Close": close,
        "Volume": [100.0] * len(index),
    }, index=index)


def main() -> None:
    snapshot = calculate_snapshot(frame())
    families = snapshot["evidence_families"]
    assert set(("trend", "momentum", "market_structure", "volume_context", "order_flow")).issubset(families)
    assert "Stochastic" not in families["momentum"]["members"]
    assert "ROC" not in families["momentum"]["members"]
    assert families["momentum"]["dependency"].startswith("مشتقات زخم من OHLC")
    assert families["evidence_strength"]["is_probability"] is False
    assert families["evidence_strength"]["calibration"].startswith("غير معاير")
    assert "technical_confidence" not in snapshot
    print("PASS: evidence families prevent double counting and expose no calibrated probability")


if __name__ == "__main__":
    main()
