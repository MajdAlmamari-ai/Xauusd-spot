from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path


RESULTS = Path(__file__).with_name("strategy_expansion_2025_results.json")
GAP_START = datetime.fromisoformat("2025-09-12T23:45:00+00:00")
GAP_END = datetime.fromisoformat("2025-10-15T07:45:00+00:00")


def parse(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def main() -> None:
    assert RESULTS.exists(), "شغّل run_strategy_expansion_2025.py أولاً"
    payload = json.loads(RESULTS.read_text(encoding="utf-8"))
    results = payload["results"]
    assert len(results) == 20
    assert "فجوة 2025-09-12 إلى 2025-10-15" in payload["data_contract"]["period"]
    for key, item in results.items():
        oos = item["oos_h2_2025_observed"]
        eligible = item["eligible_for_platform_candidate"]
        expected = bool(oos["filled_trades"] >= 20 and oos["cost_sensitivity_r"]["0.10_per_trade"] > 0 and (oos["profit_factor"] or 0) >= 1.1)
        assert eligible is expected, key
        for trade in item["metrics"]["trades"] + oos["trades"]:
            entered, exited = parse(trade["entry_time"]), parse(trade["exit_time"])
            assert not (entered <= GAP_START and exited >= GAP_END), (key, trade)
    assert all(item["eligible"] == results[item["key"]]["eligible_for_platform_candidate"] for item in payload["oos_ranking"])
    print("PASS: expanded 2025 strategies preserve data-gap and eligibility gates")


if __name__ == "__main__":
    main()
