#!/usr/bin/env python3
"""
محرك رصد السيولة، ضخ وسحب السيولة، واكتشاف الأفخاخ (Liquidity & Trap Detection Engine)
"""

class LiquidityEngine:
    def __init__(self):
        pass

    def analyze_liquidity(self, current_price, spread, volume_profile="Normal", recent_high_break=False, recent_low_break=False):
        """
        تحليل حالة السيولة ورصد احتمالية وجود فخ (Fakeout / Stop Hunt) أو ضخ/سحب سيولة
        """
        alerts = []
        trap_detected = False
        liquidity_status = "Normal Liquidity"

        # 1. رصد السبريد كدليل على ضغط السيولة
        if spread > 0.45:
            liquidity_status = "Low Liquidity / Widening Spread"
            alerts.append("تنبيه سيولة: اتساع ملحوظ في السبريد يشير إلى ضعف العمق أو ترقب حركة قوية.")
        elif spread < 0.25:
            liquidity_status = "High Institutional Depth"
            alerts.append("سيولة ممتازة: السبريد ضيق والعمق مؤسسي مستقر.")

        # 2. رصد الأفخاخ السعرية (Stop Hunts / Fakeouts)
        if recent_high_break:
            trap_detected = True
            alerts.append("فخ محتمل (Bull Trap): تم اختراق قمة سابقة لكن مع تراجع سريع، قد يكون هدفها ضرب وقфиات البائعين ثم الانعكاس.")
        elif recent_low_break:
            trap_detected = True
            alerts.append("فخ محتمل (Bear Trap): تم كسر قاع سابق لكن مع امتصاص سريع، قد يكون هدفها ضرب وقفايات المشترين ثم الارتداد.")

        # 3. تقدير تأثير السيولة على جودة الإشارة
        liquidity_score = 100
        if spread > 0.50:
            liquidity_score -= 30
        if trap_detected:
            liquidity_score -= 40

        return {
            "liquidity_status": liquidity_status,
            "trap_detected": trap_detected,
            "liquidity_score": max(10, liquidity_score),
            "alerts": alerts
        }

if __name__ == "__main__":
    engine = LiquidityEngine()
    print(engine.analyze_market_liquidity(4319.50, 0.30, "Normal", True, False))
