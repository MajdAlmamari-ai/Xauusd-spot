from technical_indicators import evidence_families


def tools(volume_bias="محايد"):
    return {
        "anchored_vwap": {"qualified": volume_bias != "محايد", "bias": volume_bias},
        "volume_profile": {"qualified": volume_bias != "محايد", "bias": volume_bias},
    }


def test_evidence_strength_varies_by_frame_inputs_and_explains_neutrality():
    bullish = evidence_families(
        latest=110, ema20_value=105, ema50_value=100, rsi_value=60,
        macd_histogram=1, adx_value=35, tools=tools("صاعد"),
        structure_confluence={"bias": "توافق صاعد"},
    )
    neutral = evidence_families(
        latest=103, ema20_value=105, ema50_value=100, rsi_value=60,
        macd_histogram=-1, adx_value=16, tools=tools(),
        structure_confluence={"bias": "توافق محدود / مختلط"},
    )
    assert bullish["decision_bias"] == "صاعد"
    assert neutral["decision_bias"] == "محايد"
    assert bullish["evidence_strength"]["score"] > neutral["evidence_strength"]["score"]
    assert neutral["neutral_reasons"]
    assert {part["family"] for part in bullish["evidence_strength"]["components"]} == {"الاتجاه", "الزخم", "بنية السوق", "سياق الحجم"}
    assert bullish["evidence_strength"]["is_probability"] is False


if __name__ == "__main__":
    test_evidence_strength_varies_by_frame_inputs_and_explains_neutrality()
    print("PASS: selected-frame evidence changes with input families and records neutral reasons")
