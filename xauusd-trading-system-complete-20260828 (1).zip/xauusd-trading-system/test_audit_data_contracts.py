"""اختبارات مستقلة لحواجز تدقيق البيانات؛ لا تعتمد على نتائج backtest محفوظة."""

from __future__ import annotations

import pandas as pd

from analysis_contracts import attach_candle_contract, decision_data_context, resample_complete_ohlc, validate_ohlc_frame
from technical_indicators import calculate_snapshot


def frame_from_rows(rows: int = 90) -> pd.DataFrame:
    index = pd.date_range("2025-01-02 00:00:00", periods=rows, freq="5min", tz="UTC")
    close = [2500.0 + index_value * 0.2 for index_value in range(rows)]
    return pd.DataFrame({
        "Open": [value - 0.1 for value in close],
        "High": [value + 0.3 for value in close],
        "Low": [value - 0.4 for value in close],
        "Close": close,
        "Volume": [10.0] * rows,
    }, index=index)


def test_resampled_candle_requires_all_components() -> None:
    raw = frame_from_rows(6)
    with_gap = raw.drop(raw.index[3])
    result = resample_complete_ohlc(with_gap, source_interval="5min", target_rule="10min", timeframe_id="10m")
    assert len(result) == 2, result
    assert result.attrs["data_contract"]["rejected_incomplete_buckets"] == 1
    assert result.attrs["data_contract"]["expected_components"] == 2


def test_mtf_alignment_rejects_incomplete_two_hour_bucket() -> None:
    index = pd.date_range("2025-01-02 00:00:00", periods=9, freq="1h", tz="UTC")
    raw = pd.DataFrame({"Open": range(100, 109), "High": range(101, 110), "Low": range(99, 108), "Close": range(100, 109), "Volume": [1.0] * 9}, index=index)
    raw = raw.drop(raw.index[5])
    result = resample_complete_ohlc(raw, source_interval="1h", target_rule="2h", timeframe_id="2h")
    assert list(result.index) == [pd.Timestamp("2025-01-02 00:00:00", tz="UTC"), pd.Timestamp("2025-01-02 02:00:00", tz="UTC"), pd.Timestamp("2025-01-02 06:00:00", tz="UTC")]
    assert result.attrs["data_contract"]["rejected_incomplete_buckets"] == 2


def test_data_context_blocks_spot_futures_levels() -> None:
    candles = attach_candle_contract(
        frame_from_rows(),
        timeframe_id="5m",
        source="Yahoo Finance reference OHLC",
        source_symbol="GC=F",
        instrument="GC=F",
        price_basis="futures_reference",
        source_kind="reference_ohlc",
    )
    quote = {
        "status": "success", "stale": False, "live_for_analysis": True,
        "instrument": "XAU/USD", "price_basis": "spot_reference",
    }
    context = decision_data_context(quote, candles)
    assert context["compatible_for_price_levels"] is False
    assert context["same_instrument"] is False
    assert context["same_price_basis"] is False


def test_snapshot_does_not_change_when_future_rows_exist_outside_input() -> None:
    raw = frame_from_rows(130)
    prefix = attach_candle_contract(raw.iloc[:90], timeframe_id="5m", source="fixture", source_symbol="GC=F", instrument="GC=F", price_basis="futures_reference", source_kind="fixture")
    snapshot_a = calculate_snapshot(prefix)
    snapshot_b = calculate_snapshot(raw.iloc[:90])
    assert snapshot_a["technical_signal"] == snapshot_b["technical_signal"]
    assert snapshot_a["evidence_families"] == snapshot_b["evidence_families"]
    assert snapshot_a["last_candle_time"] == snapshot_b["last_candle_time"]


def test_invalid_ohlc_is_blocked_not_repaired() -> None:
    raw = frame_from_rows(8)
    raw.iloc[2, raw.columns.get_loc("High")] = raw.iloc[2]["Low"] - 1
    quality = validate_ohlc_frame(raw, "5min")
    assert quality["valid"] is False
    assert quality["invalid_ohlc_rows"] == 1


def main() -> None:
    test_resampled_candle_requires_all_components()
    test_mtf_alignment_rejects_incomplete_two_hour_bucket()
    test_data_context_blocks_spot_futures_levels()
    test_snapshot_does_not_change_when_future_rows_exist_outside_input()
    test_invalid_ohlc_is_blocked_not_repaired()
    print("PASS: data contract, incomplete resampling, spot/futures barrier, and future-isolation checks")


if __name__ == "__main__":
    main()
