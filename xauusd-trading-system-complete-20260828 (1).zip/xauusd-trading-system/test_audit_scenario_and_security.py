"""حراس مستقلة لعقد السيناريو وللتقييد الأمني في الخادم الفعلي."""

from __future__ import annotations

from pathlib import Path

from production_server import build_scenario_contract


def technical_fixture() -> dict:
    return {
        "latest": 2500.0,
        "indicator_combinations": [{"status": "ملائم للسوق الاتجاهي"}],
        "data_contract": {"instrument": "XAUUSD", "price_basis": "broker_spot"},
        "data_quality": {"valid": True},
        "evidence_strength": {"score": 75, "label": "قوة أدلة مرتفعة", "is_probability": False},
        "evidence_families": {"decision_bias": "صاعد", "trend": {"direction": "صاعد"}},
        "advanced_tools": {"multi_timeframe": {"status": "متوافق"}, "confluence": {"details": "بنية صاعدة"}},
    }


def result_fixture(signal: str, state: str) -> dict:
    return {
        "signal": signal,
        "decision_state": state,
        "entry": 2500.0 if state == "signal" else None,
        "entry_zone": None,
        "stop_loss": 2490.0 if state == "signal" else None,
        "take_profit": 2520.0 if state == "signal" else None,
        "risk_reward": 2.0 if state == "signal" else None,
        "reason": "سبب اختبار",
        "data_context": {"compatible_for_price_levels": state == "signal"},
    }


def test_required_scenario_states_and_fields() -> None:
    technical = technical_fixture()
    cases = (("شراء مشروط", "signal", "BULLISH_SCENARIO"), ("بيع مشروط", "signal", "BEARISH_SCENARIO"), ("انتظار / حياد", "neutral", "CONDITIONAL"), ("NO TRADE", "blocked", "NO_TRADE"))
    required = {"htf_bias", "market_regime", "structure", "location", "trigger", "invalidation", "targets", "risk_reward", "evidence", "data_quality", "news_risk", "probability", "evidence_strength"}
    for signal, state, expected in cases:
        scenario = build_scenario_contract(result_fixture(signal, state), technical, {"status": "no_live_actual", "pending_event": False})
        assert scenario["scenario_type"] == expected
        assert required.issubset(scenario)
        assert scenario["probability"] is None
        assert scenario["evidence_strength"]["is_probability"] is False


def test_open_cors_is_not_configured() -> None:
    source = Path(__file__).with_name("production_server.py").read_text(encoding="utf-8")
    assert "CORS(app)" not in source
    assert "ALLOWED_CORS_ORIGINS" in source
    assert 'resources={r"/api/*": {"origins": _cors_origins}}' in source


def main() -> None:
    test_required_scenario_states_and_fields()
    test_open_cors_is_not_configured()
    print("PASS: scenario contract fields/states and CORS allow-list guard")


if __name__ == "__main__":
    main()
