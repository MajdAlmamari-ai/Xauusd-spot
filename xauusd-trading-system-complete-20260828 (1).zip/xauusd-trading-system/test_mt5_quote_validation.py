"""اختبارات تحقق عقد Quote من جسر MT5 قبل منحه صلاحية التحليل."""

from __future__ import annotations

from copy import deepcopy
import os

from mt5_price_connector import MT5PriceConnector


BASE_QUOTE = {
    "status": "success",
    "symbol": "XAUUSD",
    "bid": 4300.10,
    "ask": 4300.50,
    "last_price": 4300.30,
    "utc_time": "2026-08-23 00:00:00 UTC",
    "tick_age_seconds": 1.0,
    "stale": False,
}


class StubConnector(MT5PriceConnector):
    def __init__(self, payload: dict):
        super().__init__(symbol="XAUUSD", bridge_url="http://bridge.invalid")
        self.payload = payload

    def _bridge_request(self, _path: str, _params=None) -> dict:
        return deepcopy(self.payload)


def main() -> None:
    os.environ["LIVE_PRICE_SOURCE"] = "mt5"
    fresh = StubConnector(BASE_QUOTE).fetch_live_quote()
    assert fresh["status"] == "success"
    assert fresh["broker_quote_eligible"] is True
    assert fresh["live_for_analysis"] is True
    assert fresh["spread"] == 0.4

    stale_payload = deepcopy(BASE_QUOTE)
    stale_payload.update({"tick_age_seconds": 16.0, "stale": False})
    stale = StubConnector(stale_payload).fetch_live_quote()
    assert stale["status"] == "success"
    assert stale["stale"] is True
    assert stale["broker_quote_eligible"] is False
    assert stale["live_for_analysis"] is False

    missing_timestamp = deepcopy(BASE_QUOTE)
    missing_timestamp.pop("utc_time")
    invalid = StubConnector(missing_timestamp).fetch_live_quote()
    assert invalid["status"] == "error"

    wrong_symbol = deepcopy(BASE_QUOTE)
    wrong_symbol["symbol"] = "XAUUSD.a"
    invalid_symbol = StubConnector(wrong_symbol).fetch_live_quote()
    assert invalid_symbol["status"] == "error"

    invalid_spread = deepcopy(BASE_QUOTE)
    invalid_spread["ask"] = invalid_spread["bid"]
    invalid_quote = StubConnector(invalid_spread).fetch_live_quote()
    assert invalid_quote["status"] == "error"
    os.environ.pop("LIVE_PRICE_SOURCE", None)
    print("نجح تحقق Quote لوسيط MT5: حديث وصالح، متأخر، وطوابع/رموز/أسعار معيبة.")


if __name__ == "__main__":
    main()
